# NORM UI Context v3 — patch notes

> Historical note: these notes describe the UI-context v3 patch itself. This distribution additionally contains `PATCH_NOTES_STANDALONE_ENGINEERING.md`, which intentionally updates Stage 05–07 engineering rules after v3.

## Scope

Built directly on the owner-provided `skills-pipeline-v6.3-rc2-clean-norm-ui-context-v2` package. Existing v2 runtime overlay, organisms, situational overview, frontend engineering profiles and protected frontend rules are preserved.

## What changed

- Registry filter toolbar strong-default: segmented scope + quick-filter chips on the left; Search/Filter utilities on the right in the same desktop row.
- Explicit control taxonomy: segmented control ≠ binary Switch ≠ filter chip ≠ status tag.
- Starter demonstrates `Все / Мои` segmented control, separate pill chips, trailing Search/Filter, and a true boolean Switch inside a form.
- Entity-card target: identity/name is the left visual anchor; status is no longer a universal leading column before the title.
- Meaningful attention summary is explicitly allowed; only decorative/redundant KPI walls remain an anti-pattern.
- Collection variability formalized: decision registry, navigation collection, compact content/file list.
- Current Object View footer evidence is documented separately from the target/canonical `Object Action / Meta Zone` direction.
- New authoring contracts: `collection-presentation`, `semantic-form-section`, `related-entity-preview`, `workflow-footer`.
- Added aspect-level owner reference registry for Event/Measure/Risk lists, forms, views, Knowledge Base, Limit Campaign, Universal Object Modal and Pixso exports.
- Stage 03 now requires real navigation round-trip when navigation is part of acceptance criteria; toast-only simulation is insufficient.

## Deliberately unchanged

- Arial/system font strategy.
- Existing NORM shell width and overall application geometry.
- Situational overview / interactive analytics architecture from v2.
- Canonical target Object View without Footer; current footer-based exports remain current-state evidence.
- Stage 04+/frontend engineering rules and protected hashes.
