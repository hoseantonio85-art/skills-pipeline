# Validation — NORM UI Context v3 + Standalone Engineering patch

## Baseline

UI Context v3 was built directly from the owner-provided `skills-pipeline-v6.3-rc2-clean-norm-ui-context-v2` ZIP. This package then applies an intentional stages 05–07 standalone-engineering patch.

## UI-context validation retained

- `norm-product-context-v3-mvp/tools/validate_context.py` — must PASS.
- All YAML and JSON files must parse.
- Pattern registry paths resolve; pattern IDs remain unique.
- Product-context starter and GigaCode fallback starter remain unchanged by this patch.
- Stage 01–04 behavior is unchanged.

## Engineering patch validation

- `TARGET_REPO` remains the mandatory profile for existing MFE work.
- `STANDALONE_ENGINEERING` is explicitly greenfield-only.
- Planner/implementer/reviewer all carry the same profile semantics.
- Standalone output cannot claim production Single-SPA/auth/API/DEV integration without runtime evidence.
- `VERIFIED_STANDALONE_ENGINEERING` is distinct from `VERIFIED_FRONTEND`.
- Frontend rule sources retain prior constraints and add only profile carve-outs needed to avoid contradiction with the sandbox profile.
- `audit/FRONTEND_RULES_GOLDEN.sha256` is intentionally regenerated for this patch so `tools/audit_distribution.py` validates the new protected baseline.

## Environment semantics

Corporate install/dev/build restrictions are not bypassed. Approved Nexus/registry, existing workspace/cache or local package artifact may be used as dependency sources. When runtime checks cannot be executed, they are explicitly `skipped` or the stage uses `BLOCKED_BY_ENVIRONMENT`; no runtime PASS is inferred.
