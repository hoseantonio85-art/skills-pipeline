# Migration: NORM UI Context v2 → v3

## Recommended

Replace the full extracted `skills-pipeline-v6.3-rc2-clean-norm-ui-context-v2` distribution with this v3 package.

## Minimal manual update

If the rest of the local pipeline must stay untouched, replace:

1. `norm-product-context-v3-mvp/` — product context provider;
2. `gigacode-ready/.gigacode/skills/build-visual-html-prototype/` — stage-03 skill + fallback starter.

Frontend planner/implementer/reviewer files are intentionally unchanged by this patch.

## First regression test

Run the original Work Center smoke-test prompt from a clean conversation/project with no manual UI corrections.

Compare against v2 on:

- `Все / Мои` rendered as segmented control, not Switch;
- quick-filter chips immediately after segmented control;
- Search / Filter utilities aligned on the right of the same desktop row;
- chip geometry and active state;
- identity/name as left anchor of row-card; status not a mandatory leading column;
- meaningful summary allowed when it adds attention/drill-down value;
- navigation to source object/surface is actually prototyped, including return/context preservation;
- no mechanical copying of whole reference screens.
