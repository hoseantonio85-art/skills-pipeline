# Standalone Engineering patch — NORM UI Context v3

## Why

В закрытом корпоративном контуре существующий microfrontend можно локально подменить в DEV-shell, но новый greenfield service нельзя поднять на DEV до появления repository/MFE registration. При этом stages 05–07 ранее жёстко требовали target repo и блокировали engineering verification нового frontend.

## What changed

- Stage 05 теперь явно выбирает `Engineering profile: TARGET_REPO | STANDALONE_ENGINEERING`.
- `TARGET_REPO` полностью сохраняет target-first поведение для существующих сервисов.
- `STANDALONE_ENGINEERING` разрешён только для greenfield/new service до появления production target MFE/runtime.
- Standalone engineering = локальный React/TypeScript sandbox на реальном `@sber-orm/ui-kit`, product/frontend rules и typed mocks/fixtures.
- Dependency source может быть corporate Nexus/registry, existing workspace/cache или локальный package artifact (`.tgz`); UI Kit нельзя vendoring/copy/facade-ить.
- Local `createRoot`/router/demo controls разрешены только как изолированный sandbox harness.
- Production API, Single-SPA, auth, analytics и DEV integration нельзя имитировать или объявлять проверенными без фактического runtime evidence.
- `05_frontend_plan.md`, `06_frontend_implementation.md`, `07_frontend_review.md` теперь несут profile и integration-verification fields.
- Новый финальный статус `VERIFIED_STANDALONE_ENGINEERING` отделяет локально проверенный sandbox от `VERIFIED_FRONTEND` в target runtime.
- Добавлен `BLOCKED_BY_ENVIRONMENT` для случаев, когда разрешённые dependency/runtime checks невозможно выполнить в корпоративной среде.

## Safety rule

Standalone profile не является fallback, если агент просто не получил доступ к существующему repo. Если target repo должен существовать, но недоступен, результат остаётся `BLOCKED_BY_REPOSITORY`.

## Production handoff

После появления target repo/MFE registration выполняется integration pass:

1. перенос portable pages/components/stores/helpers;
2. удаление/изоляция sandbox shell;
3. подключение Single-SPA/host providers, auth/analytics и runtime externals;
4. mock/fixture adapter → real API/service contract;
5. re-check фактических package/UI Kit versions target repo;
6. DEV/runtime verification;
7. обычный `TARGET_REPO` review до `VERIFIED_FRONTEND`.

## Unchanged

- Product stages 01–04 and their authority boundaries.
- Stage 03 HTML/CSS/JS prototype as UX evidence.
- NORM UI patterns/organisms/composition policy from v3.
- Target-first authority for every existing MFE.
