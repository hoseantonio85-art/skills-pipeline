#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
notes = []

AUTHORING_DIRS = [
    '01_formulate-product-intent-and-brief-universal',
    '02_design-ux-solution-universal-v1',
    '03_build-visual-html-prototype-v1',
    '03_5_sync-ux-decisions-v1',
    '04_build-sdd-specification-v1',
    '05_07_frontend-engineering-v1',
]
for d in AUTHORING_DIRS:
    if (ROOT / d).exists():
        errors.append(f'authoring duplicate still present in clean runtime: {d}')

required = [
    'gigacode-ready/GIGACODE.md',
    'gigacode-ready/.gigacode/product-context.yaml',
    'gigacode-ready/.gigacode/skills/formulate-product-intent-and-brief/SKILL.md',
    'gigacode-ready/.gigacode/skills/design-ux-solution/SKILL.md',
    'gigacode-ready/.gigacode/skills/build-visual-html-prototype/SKILL.md',
    'gigacode-ready/.gigacode/skills/sync-ux-decisions/SKILL.md',
    'gigacode-ready/.gigacode/skills/build-sdd-specification/SKILL.md',
    'gigacode-ready/.gigacode/skills/frontend-standards/SKILL.md',
    'gigacode-ready/.gigacode/agents/frontend-planner.md',
    'gigacode-ready/.gigacode/agents/frontend-implementer.md',
    'gigacode-ready/.gigacode/agents/frontend-reviewer.md',
    'norm-product-context-v3-mvp/product-system/context-manifest.yaml',
]
for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f'missing runtime file: {rel}')

# Protected frontend hashes
manifest = ROOT / 'audit/FRONTEND_RULES_GOLDEN.sha256'
if not manifest.is_file():
    errors.append('missing audit/FRONTEND_RULES_GOLDEN.sha256')
else:
    for raw in manifest.read_text(encoding='utf-8').splitlines():
        raw = raw.strip()
        if not raw:
            continue
        expected, rel = raw.split(None, 1)
        path = ROOT / rel.strip()
        if not path.is_file():
            errors.append(f'protected frontend file missing: {rel}')
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            errors.append(f'protected frontend file changed: {rel}\n  expected {expected}\n  actual   {actual}')

# Ensure frontend context profiles still route all three full NORM rule sources.
ctx = ROOT / 'norm-product-context-v3-mvp/product-system/context-manifest.yaml'
if ctx.is_file():
    text = ctx.read_text(encoding='utf-8')
    sources = [
        'product-system/04_ui/frontend_prototype_rules.md',
        'sources/frontend-rules/component-structure-data-barrels-ui-kit.md',
        'sources/frontend-rules/frontend-standards-subagent.md',
    ]
    for profile in ['for_frontend_planning:', 'for_frontend_implementation:', 'for_frontend_review:']:
        if profile not in text:
            errors.append(f'missing frontend context profile: {profile}')
    for src in sources:
        count = text.count(src)
        if count < 3:
            errors.append(f'frontend rule source is not routed to all engineering profiles: {src} (count={count})')

# Ensure agents still explicitly load frontend-standards skill and references.
for name in ['frontend-planner.md', 'frontend-implementer.md', 'frontend-reviewer.md']:
    p = ROOT / 'gigacode-ready/.gigacode/agents' / name
    if p.is_file():
        t = p.read_text(encoding='utf-8')
        if '.gigacode/skills/frontend-standards/SKILL.md' not in t:
            errors.append(f'{name} no longer requires frontend-standards skill')
        if 'references' not in t:
            errors.append(f'{name} no longer explicitly mentions frontend-standards references')

# Deprecated pipeline statuses must not re-enter runtime skills/agents.
deprecated = [
    'READY_FOR_ANALYSIS', 'APPROVED_FOR_ANALYSIS', 'APPROVED_FOR_UX',
    'APPROVED_FOR_PROTOTYPE', 'READY_FOR_UX_REVIEW'
]
runtime_roots = [ROOT / 'gigacode-ready/.gigacode/skills', ROOT / 'gigacode-ready/.gigacode/agents']
for rr in runtime_roots:
    if rr.exists():
        for p in rr.rglob('*.md'):
            t = p.read_text(encoding='utf-8', errors='replace')
            for token in deprecated:
                if token in t:
                    errors.append(f'deprecated status {token} in runtime: {p.relative_to(ROOT)}')

if errors:
    print('DISTRIBUTION AUDIT: FAILED')
    for e in errors:
        print(f'- {e}')
    sys.exit(1)

print('DISTRIBUTION AUDIT: PASSED')
print('- clean runtime: no duplicated authoring packages')
print('- required runtime skills/agents present')
print('- protected frontend-rule hashes unchanged')
print('- all NORM frontend rule sources routed to stages 05–07')
print('- all frontend agents require frontend-standards + references')
print('- deprecated runtime status tokens absent')
