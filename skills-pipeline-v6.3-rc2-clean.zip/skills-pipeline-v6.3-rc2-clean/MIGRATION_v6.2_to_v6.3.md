# Migration v6.2 → v6.3 RC2 (no-loss + clean runtime)

## Цель RC1

Не менять доказавшую работоспособность архитектуру pipeline и frontend roles. Исправить source/runtime drift, status drift и NORM context routing до структурного удаления файлов.

## Исправлено

1. Stage 04 runtime references синхронизированы с product-SDD source version; `Technical design` удалён из Stage 04 contract.
2. Stage 01/02 references приведены к root status contract; устаревшие `READY_FOR_ANALYSIS`, `APPROVED_FOR_UX`, `APPROVED_FOR_PROTOTYPE` и локальные review statuses больше не являются pipeline contract.
3. Явный `context_id: none` допускает прямой UX только для автономной/greenfield инициативы по решению owner; existing-product задача без обязательного context остаётся `BLOCKED_BY_CONTEXT`.
4. NORM `for_ux_solution` снова получает source authority, glossary, release-evidence status и current-product evidence/status files, которые ожидает сам UX skill.
5. Context metadata обновлено для stages 05–07.
6. Full NORM frontend rules **не сокращались и не менялись**.
7. Добавлены golden hashes и distribution audit для защиты frontend rule layer и source/runtime equality.

## Пока намеренно НЕ сделано

- source-package duplicates не удалены;
- UI Kit/common-components binary evidence не вынесены;
- `frontend_prototype_rules.md` не переименован и не слит с другими rules;
- full frontend source rules не заменены compact skill;
- NORM UX/UI/visual knowledge не сокращалось.

Это будет отдельная cleanup-фаза только после regression test RC1.


## RC2 clean distribution

RC2 выполняет только структурную cleanup-фазу поверх no-loss RC1:

- authoring/source packages `01_* … 05_07_*` вынесены из основного runtime ZIP;
- assembled runtime `gigacode-ready` является единственной устанавливаемой копией skills/agents;
- source packages сохранены отдельно в authoring archive;
- NORM context сохранён целиком, включая frontend rules, UI Kit evidence, common-components evidence и analytical specs;
- protected frontend-rule layer должен совпадать с `audit/FRONTEND_RULES_GOLDEN.sha256`.

RC2 не изменяет UX/frontend rules и не универсализирует NORM-specific engineering constraints.
