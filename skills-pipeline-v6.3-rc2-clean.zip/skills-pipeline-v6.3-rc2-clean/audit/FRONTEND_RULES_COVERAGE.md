# Frontend Rules Coverage — RC2

## Result

**No-loss status: PASS.** RC2 preserves and routes the complete known NORM frontend rule layer used by stages 05–07.

This means **100% of the known frontend rules are available to the engineering agents as an aggregate context**. It does **not** mean they have been semantically collapsed into one file; overlap is intentionally retained until a separate rule-by-rule consolidation audit is performed.

## Protected rule layers

### 1. Active runtime engineering skill

- `gigacode-ready/.gigacode/skills/frontend-standards/SKILL.md`
- `references/01_target_first.md`
- `references/02_architecture_typescript.md`
- `references/03_ui_states_accessibility.md`
- `references/04_tests_review.md`

All three frontend agents explicitly require this skill and its references.

### 2. Full combined frontend rule source

- `norm-product-context-v3-mvp/sources/frontend-rules/frontend-standards-subagent.md`

The normative body is byte-for-byte identical to the supplied `frontend-standards-subagent-new(1).md`; the context copy only adds a four-line provenance header above it.

### 3. Additional component / barrel / UI Kit rules

- `norm-product-context-v3-mvp/sources/frontend-rules/component-structure-data-barrels-ui-kit.md`

Retained because it contains additional detailed rules and has not yet been proven redundant with the normalized runtime skill.

### 4. NORM frontend/prototype handoff rules

- `norm-product-context-v3-mvp/product-system/04_ui/frontend_prototype_rules.md`

Retained because it contributes NORM-specific frontend/prototype constraints and handoff expectations.

## Routing guarantee

`context-manifest.yaml` loads all three full NORM rule sources for:

- `for_frontend_planning`
- `for_frontend_implementation`
- `for_frontend_review`

At the same time, `frontend-planner`, `frontend-implementer`, and `frontend-reviewer` explicitly load the active `frontend-standards` skill and all references.

Therefore stages 05–07 receive both:

1. the compact active engineering norm;
2. the full NORM rule/provenance layer that has not yet been safely consolidated.

## Regression protection

`FRONTEND_RULES_GOLDEN.sha256` pins hashes for the protected files. `tools/audit_distribution.py` fails if:

- a protected file disappears or changes;
- a frontend context profile stops routing the full rule sources;
- a frontend agent stops requiring `frontend-standards` + references.

## Deliberately not done in RC2

- No semantic deduplication of frontend rules.
- No shortening of frontend standards.
- No removal of NORM/SberORM-specific stack rules.
- No removal of `sberorm-cloud-*-front`, UI Kit, Single-SPA, TypeScript/Biome or target-first constraints.

Any future consolidation must first prove rule-by-rule semantic coverage and pass regression tests.
