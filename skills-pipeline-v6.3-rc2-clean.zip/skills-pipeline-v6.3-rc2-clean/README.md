# Skills Pipeline v6.3 RC2 — clean runtime distribution

RC2 — структурно очищенная версия после полного smoke test v6.2 и no-loss RC1.

Главный принцип: **очистить дистрибутив без изменения поведения pipeline и без потери NORM/frontend knowledge**.

## Что находится в основном архиве

```text
gigacode-ready/               assembled GigaCode runtime: skills + agents + default selector
norm-product-context-v3-mvp/ NORM product/UX/UI/engineering context provider
PIPELINE.md                   этапы 01–07 и authority contract
STATUS_CONTRACTS.md           единый каталог pipeline statuses
audit/                        golden hashes защищённого frontend-rule layer
tools/                        проверки дистрибутива
```

NORM остаётся **default configured context** этой поставки. Другой продукт подключается осознанно через `context_id` и собственный provider/manifest.

## Что изменилось относительно RC1

Из основного runtime-архива вынесены только authoring/source packages `01_* … 05_07_*`, которые дублировали уже собранные файлы в `gigacode-ready`. Они сохранены отдельным архивом `skills-pipeline-v6.3-rc2-authoring-sources.zip`.

Никакие NORM product/UX/UI/frontend context files не удалены. UI Kit source package, common-components evidence, analytical specs и frontend-rule sources остаются в NORM context.

## Frontend no-loss guarantee

Защищённый слой не сокращён и не переписан:

- `gigacode-ready/.gigacode/skills/frontend-standards/**`
- `gigacode-ready/.gigacode/agents/frontend-*.md`
- `norm-product-context-v3-mvp/sources/frontend-rules/**`
- `norm-product-context-v3-mvp/product-system/04_ui/frontend_prototype_rules.md`

Stages 05–07 получают NORM frontend profile через `context-manifest.yaml`, а каждый frontend agent отдельно обязан читать `frontend-standards/SKILL.md` и все references.

Golden hashes: `audit/FRONTEND_RULES_GOLDEN.sha256`.

## Проверки

```bash
python3 norm-product-context-v3-mvp/tools/validate_context.py
python3 tools/audit_distribution.py
```

Обе проверки должны завершаться без ошибок перед regression/smoke test.
