# RC2 Cleanup Manifest

## Removed from main distribution

These authoring/source packages were moved to the separate authoring archive because their runtime skill/agent files are already assembled under `gigacode-ready`:

- `01_formulate-product-intent-and-brief-universal/`
- `02_design-ux-solution-universal-v1/`
- `03_build-visual-html-prototype-v1/`
- `03_5_sync-ux-decisions-v1/`
- `04_build-sdd-specification-v1/`
- `05_07_frontend-engineering-v1/`

## Explicitly retained

No files were removed from `norm-product-context-v3-mvp/`. In particular retained:

- full frontend rule sources;
- normalized frontend-standards runtime skill;
- NORM visual/UX rules;
- UI Kit normalized docs and raw `.tgz` evidence;
- common-components raw evidence;
- analytical specs;
- context manifest, source registry and provenance.

This cleanup changes packaging only, not normative content.
