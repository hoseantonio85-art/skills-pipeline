# Changelog

## 6.3.0-rc1-no-loss — 2026-08-19

- Reconciled NORM context metadata and loading profiles with stages 01–07.
- Restored source-authority/current-product evidence expected by UX stage.
- Kept full frontend rules unchanged and protected by golden hashes.
- No context files or frontend normative sources removed.

# 6.1.0-analytical-context

- Added `sources/analytical-specs/` as on-demand evidence layer with capability routing index.
- Product SDD boundary tightened: observable behavior only; implementation design moved after Stage 04.
- UX Solution and UX Sync can selectively use analytical specs for lifecycle, permissions, rules, states and edge-case validation.

# Changelog

## 3.0.0-mvp — 2026-08-06

- единый context repository для этапов 01–03;
- добавлен профиль `for_ui_prototype`;
- добавлен UI/frontend слой и фактический UI Kit `0.283.0`;
- добавлены stage access matrix и skill compatibility contract;
- полные frontend-правила и library packages вынесены в `sources/`;
- удалены ранняя универсальная методика и примеры, дублирующие skills;
- добавлены validation и packaging tools;
- каталог составных UI patterns оставлен расширяемым и необязательным для MVP.
