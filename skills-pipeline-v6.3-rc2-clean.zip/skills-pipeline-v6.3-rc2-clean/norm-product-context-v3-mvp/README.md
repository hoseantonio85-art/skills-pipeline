# NORM Product Context v3 — pipeline context package

Единый локальный context repository для продуктового и frontend-engineering pipeline.

Поддерживаемые этапы:

1. `formulate-product-intent-and-brief` — Stage 01;
2. `design-ux-solution` — Stage 02;
3. `build-visual-html-prototype` — Stage 03;
4. `sync-ux-decisions` — Stage 03.5;
5. `build-sdd-specification` — Stage 04;
6. `frontend-planner` — Stage 05;
7. `frontend-implementer` — Stage 06;
8. `frontend-reviewer` — Stage 07.

Точка входа:

```text
product-system/context-manifest.yaml
```

## Принцип устройства

- `product-system/` — нормализованные знания, разрешённые loading profiles;
- `sources/` — evidence/reference layer: analytical specs, exact UI Kit package, common components snapshot и полные frontend rules;
- `loading` в manifest определяет минимальный профиль каждого stage;
- `on_demand` используется для service/domain/UI Kit evidence без bulk-loading;
- feature-specific `00_intent.md` … `07_frontend_review.md` находятся в рабочем проекте, а не в product context.

NORM является default context этой поставки, если проектный selector не переключён на другой зарегистрированный `context_id`. Другой продукт подключается через тот же selector/registry/manifest contract; pipeline skills не должны искать соседние product folders вместо выбранного provider.

## Frontend rule safety

Stages 05–07 используют одновременно компактный `frontend-standards` skill и полный NORM frontend-rule evidence profile. Полные sources пока нельзя удалять или сокращать: compact skill ещё не доказан как semantic-lossless replacement.

См. `CONTEXT_SETUP.md`, `CONTEXT_MAINTENANCE.md` и `product-system/07_business_context/stage_access_matrix.yaml`.
