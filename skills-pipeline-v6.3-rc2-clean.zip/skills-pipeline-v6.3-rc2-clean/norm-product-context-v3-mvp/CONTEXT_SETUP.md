# Подключение единого контекста NORM

## 1. Распаковать context repository

Распакуйте NORM context в стабильную директорию, например:

```text
~/work/norm-product-context
```

Не копируйте context repository внутрь каждого frontend-проекта.

## 2. Зарегистрировать provider

Скопируйте:

```text
setup/product-contexts.yaml.example
```

в:

```text
~/.gigacode/product-contexts.yaml
```

Укажите абсолютный путь к NORM context repository.

## 3. Выбрать context в рабочем проекте

Создайте:

```text
<project>/.gigacode/product-context.yaml
```

```yaml
version: 1
context_id: norm
```

Явно выбранный другой `context_id` имеет приоритет. Для рабочей поставки пользователя NORM остаётся default configured context.

## 4. Установить runtime skills и agents

Из assembled runtime (`gigacode-ready`) должны быть доступны:

```text
.gigacode/skills/formulate-product-intent-and-brief/
.gigacode/skills/design-ux-solution/
.gigacode/skills/build-visual-html-prototype/
.gigacode/skills/sync-ux-decisions/
.gigacode/skills/build-sdd-specification/
.gigacode/skills/frontend-standards/
.gigacode/agents/frontend-planner.md
.gigacode/agents/frontend-implementer.md
.gigacode/agents/frontend-reviewer.md
```

Tool profiles:

- planner — Read-only;
- implementer — Read & Edit & Execution;
- reviewer — Read-only.

После установки/обновления выполните `/clear` или начните новую сессию.

## 5. Loading profiles

- Stage 01: `always` + `for_product_intent_and_brief`;
- Stage 02: `always` + `for_ux_solution`;
- Stage 03: `always` + `for_visual_html_prototype`;
- Stage 03.5: `always` + `for_ux_sync`;
- Stage 04: `always` + `for_sdd_specification`, затем selective analytical evidence;
- Stage 05: `always` + `for_frontend_planning` + target repo + `frontend-standards`;
- Stage 06: `always` + `for_frontend_implementation` + approved plan/target repo + `frontend-standards`;
- Stage 07: `always` + `for_frontend_review` + diff/target repo + `frontend-standards`.

Не передавайте модели весь archive целиком. Manifest, skill/agent и on-demand routing задают, что читать.

## 6. Проверка

Из корня context repository:

```bash
python3 tools/validate_context.py
```

Для создания standalone context ZIP:

```bash
python3 tools/package_context.py
```
