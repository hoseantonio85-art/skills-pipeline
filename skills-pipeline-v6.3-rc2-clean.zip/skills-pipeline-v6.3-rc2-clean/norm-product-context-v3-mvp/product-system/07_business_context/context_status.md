# Статус продуктового контекста NORM

## Метаданные

| Поле | Значение |
|---|---|
| Context ID | `norm` |
| Package version | `6.3.0-rc2-clean` |
| Package readiness | `ready_for_product_ux_sdd_and_frontend_engineering` |
| Production evidence | `documented-partial` |
| Product owner review | требуется для новых/изменённых product facts |
| Business analyst review | выборочно, через task/domain evidence |
| System analyst review | выборочно, через analytical specs / contracts |
| UX owner review | требуется для новых/изменённых UX/visual rules |
| Проверка production | не является частью canonical product context по умолчанию |

## Что присутствует

- product foundation, service map и service documents;
- роли, glossary, общие business rules, capabilities, constraints и decisions;
- UX principles и UX patterns;
- visual language, product likeness, layout/density и UI patterns;
- профили загрузки для этапов 01, 02, 03, 03.5, 04 и frontend 05–07;
- нормализованный UI Kit index/docs + exact package evidence `@sber-orm/ui-kit` 0.283.0;
- полный NORM frontend rules evidence layer;
- analytical specifications как on-demand evidence;
- current-product/source status documents, явно отделяющие product model от production evidence.

## Что отсутствует или подключается task-specific

- authoritative release registry;
- полная permissions matrix и formal domain model;
- полный каталог analytics events;
- актуальные frontend/backend repositories как постоянные providers;
- production screenshots/session recordings;
- утверждённый полный каталог composite components/pages/modal templates.

## Правило использования

Контекст пригоден для pipeline в пределах loading profile текущего stage. `ready` относится к полноте package contract, а не к доказанности каждой production-фичи.

Feature-specific Intent/Brief/UX/SDD и implementation artifacts хранятся в task increment. Production behavior, фактические права, API и release state подтверждаются task-specific evidence/target repo, а не выводятся из product philosophy или presence of files.
