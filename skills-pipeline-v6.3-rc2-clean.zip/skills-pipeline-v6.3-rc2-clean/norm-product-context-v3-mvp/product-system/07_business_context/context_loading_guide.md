# Руководство по загрузке контекста

## Общий принцип

Сначала читайте выбранный selector/provider manifest и профиль текущего stage. Не передавайте модели весь repository. Task artifacts имеют отдельную authority и не копируются в product context.

## Stage 01 — Intent + Product Brief

Автоматически: context status/authority, mission, constraints, product philosophy, service goal/map, roles, glossary, common rules, known capabilities и release-evidence status.

По запросу: релевантный service document и evidence, влияющее на product boundary/feasibility.

Не читать: UX/UI/UI Kit/frontend implementation rules.

## Stage 02 — UX Solution

Автоматически: source authority, current product evidence status/sources, product foundation, service map, roles/glossary/rules/capabilities, release status, UX principles и UX patterns.

По запросу: релевантные service documents, analytical specs и task-specific AS IS evidence.

Не читать: UI Kit API, design tokens и frontend implementation rules.

## Stage 03 — Visual HTML Prototype

Автоматически: UX principles/patterns, UI context status и visual rules.

По запросу: один relevant service document и выбранный UI pattern.

Не читать: весь UI Kit package, все services, frontend engineering rules.

## Stage 03.5 — UX Sync

Автоматически: UX principles/patterns. Главный вход — task artifacts + human review evidence. Analytical specs — selective consistency check.

## Stage 04 — Product SDD

Автоматически: source authority, foundation, service map, roles/glossary/common rules/capabilities/constraints.

По запросу: только подтверждённые service/domain/analytical sources для конкретного requirement.

Не копировать в SDD API/DTO/storage/components/stores/backend design или prototype code structure.

## Stage 05 — Frontend Plan

Автоматически: NORM UX principles/patterns + полный frontend engineering profile из manifest. Дополнительно обязательны approved SDD, final UX/Sync, target repo и `frontend-standards` skill.

Target repo остаётся implementation truth для actual package versions, runtime, exports и local conventions.

## Stage 06 — Frontend Implementation

Автоматически: frontend engineering profile. Работать только по выбранному increment из approved plan. Prototype = UX evidence, не source code.

## Stage 07 — Independent Frontend Review

Автоматически: тот же frontend engineering profile. Reviewer начинает с actual diff/changed files и independently checks SDD + plan + target repo + standards; implementer claims не являются evidence.

## Длинные задачи

Progress и реально прочитанные sources фиксируются в stage artifact. После `/clear` новая сессия продолжает по artifact/checkpoint, а не восстанавливает решения из памяти.
