# UI context

Раздел содержит стабильный UI/visual context для Stage 03 и engineering-reference layer для Stages 05–07.

- `ui_context_status.md` — доступность и ограничения;
- `prototype_ui_rules.md` — compact UX/UI rules Stage 03;
- `frontend_prototype_rules.md` — **legacy-named compact React/frontend rule source**; в v6.3 пока сохраняется в engineering profile без изменения содержания, пока не выполнен semantic no-loss merge/rename;
- `ui_sources.yaml` — маршруты к exact evidence;
- `ui-kit/component-index.yaml` — быстрый индекс UI Kit API;
- `ui-kit/ui_base.md` — документация, читаемая фрагментами;
- `patterns/` — optional registry UI patterns.

Полные packages не bulk-load. Full frontend normative sources в `sources/frontend-rules/` намеренно доступны Stages 05–07 через manifest до завершения rule-by-rule normalization.
