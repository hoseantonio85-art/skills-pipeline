#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

# Handoff cleanliness: only public working surfaces at archive root.
allowed_root = {
    'README.md','PIPELINE.md','STATUS_CONTRACTS.md','VERSION',
    'gigacode-ready','norm-product-context-v4','integrity','tools'
}
actual_root={p.name for p in ROOT.iterdir()}
for extra in sorted(actual_root-allowed_root):
    errors.append(f'unexpected root item: {extra}')
for missing in sorted(allowed_root-actual_root):
    errors.append(f'missing root item: {missing}')

# Historical/build clutter must not leak into handoff package.
for p in ROOT.rglob('*'):
    rel=p.relative_to(ROOT)
    if p.name == '__MACOSX' or p.name == '.DS_Store' or p.name.startswith('._'):
        errors.append(f'metadata/clutter present: {rel}')
    if p.is_file() and (p.suffix=='.patch' or p.name.startswith(('MIGRATION_','PATCH_NOTES_','VALIDATION_','CLEANUP_'))):
        errors.append(f'historical report present: {rel}')

AUTHORING_DIRS = [
    '01_formulate-product-intent-and-brief-universal','02_design-ux-solution-universal-v1',
    '03_build-visual-html-prototype-v1','03_5_sync-ux-decisions-v1',
    '04_build-sdd-specification-v1','05_07_frontend-engineering-v1',
]
for d in AUTHORING_DIRS:
    if (ROOT / d).exists(): errors.append(f'authoring duplicate still present: {d}')

required = [
    'gigacode-ready/GIGACODE.md',
    'gigacode-ready/.gigacode/product-context.yaml',
    'gigacode-ready/.gigacode/skills/formulate-product-intent-and-brief/SKILL.md',
    'gigacode-ready/.gigacode/skills/design-ux-solution/SKILL.md',
    'gigacode-ready/.gigacode/skills/build-visual-html-prototype/SKILL.md',
    'gigacode-ready/.gigacode/skills/sync-ux-decisions/SKILL.md',
    'gigacode-ready/.gigacode/skills/build-sdd-specification/SKILL.md',
    'gigacode-ready/.gigacode/skills/frontend-standards/SKILL.md',
    'gigacode-ready/.gigacode/agents/frontend-planner.md',
    'gigacode-ready/.gigacode/agents/frontend-implementer.md',
    'gigacode-ready/.gigacode/agents/frontend-reviewer.md',
    'norm-product-context-v4/product-system/context-manifest.yaml',
]
for rel in required:
    if not (ROOT / rel).is_file(): errors.append(f'missing runtime file: {rel}')

manifest = ROOT / 'integrity/FRONTEND_RULES_GOLDEN.sha256'
if not manifest.is_file():
    errors.append('missing integrity/FRONTEND_RULES_GOLDEN.sha256')
else:
    for raw in manifest.read_text(encoding='utf-8').splitlines():
        raw=raw.strip()
        if not raw: continue
        expected, rel = raw.split(None,1)
        path=ROOT/rel.strip()
        if not path.is_file():
            errors.append(f'protected frontend file missing: {rel}'); continue
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=expected:
            errors.append(f'protected frontend file changed: {rel}\n  expected {expected}\n  actual   {actual}')

ctx = ROOT / 'norm-product-context-v4/product-system/context-manifest.yaml'
if ctx.is_file():
    text=ctx.read_text(encoding='utf-8')
    sources=[
        'product-system/04_ui/frontend_prototype_rules.md',
        'sources/frontend-rules/component-structure-data-barrels-ui-kit.md',
        'sources/frontend-rules/frontend-standards-subagent.md',
    ]
    for profile in ['for_frontend_planning:','for_frontend_implementation:','for_frontend_review:']:
        if profile not in text: errors.append(f'missing frontend context profile: {profile}')
    for src in sources:
        if text.count(src)<3: errors.append(f'frontend source not routed to all engineering profiles: {src}')

for name in ['frontend-planner.md','frontend-implementer.md','frontend-reviewer.md']:
    p=ROOT/'gigacode-ready/.gigacode/agents'/name
    if p.is_file():
        t=p.read_text(encoding='utf-8')
        if '.gigacode/skills/frontend-standards/SKILL.md' not in t: errors.append(f'{name} no longer requires frontend-standards skill')
        if 'references' not in t: errors.append(f'{name} no longer explicitly mentions frontend-standards references')

deprecated=['READY_FOR_ANALYSIS','APPROVED_FOR_ANALYSIS','APPROVED_FOR_UX','APPROVED_FOR_PROTOTYPE','READY_FOR_UX_REVIEW']
for rr in [ROOT/'gigacode-ready/.gigacode/skills',ROOT/'gigacode-ready/.gigacode/agents']:
    for p in rr.rglob('*.md'):
        t=p.read_text(encoding='utf-8',errors='replace')
        for token in deprecated:
            if token in t: errors.append(f'deprecated status {token} in runtime: {p.relative_to(ROOT)}')

if errors:
    print('DISTRIBUTION AUDIT: FAILED')
    for e in errors: print(f'- {e}')
    sys.exit(1)
print('DISTRIBUTION AUDIT: PASSED')
print('- root contains only public working files')
print('- historical reports/patches/metadata absent')
print('- required runtime skills/agents/context present')
print('- protected frontend rules match integrity baseline')
print('- frontend context routing and stage contracts intact')
