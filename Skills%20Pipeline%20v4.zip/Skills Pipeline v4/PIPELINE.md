# Skills Pipeline v4 — AI-PDLC Runtime

```text
raw request / product idea
          ↓
01 formulate-product-intent-and-brief
   ├─ 00_intent.md
   └─ 01_product_brief.md
          ↓
02 design-ux-solution  ← selective domain evidence when relevant
   └─ 02_ux_solution.md
          ↓
03 build-visual-html-prototype
   ├─ 03_visual_prototype.md
   └─ runnable HTML/CSS/JS
          ↓
human UX/UI review
          ↓
03.5 sync-ux-decisions ← domain consistency check when relevant
   ├─ final 02_ux_solution.md
   └─ 03_5_ux_sync.md
          ↓
04 build-sdd-specification
   └─ 04_sdd_specification.md  (observable product behavior)
          ↓
──────── product / engineering boundary ────────
          ↓
05 frontend-planner  [subagent, read-only]
   ├─ TARGET_REPO → target-first plan
   ├─ STANDALONE_ENGINEERING → greenfield local engineering plan
   └─ 05_frontend_plan.md
          ↓
06 frontend-implementer  [subagent, edit + execution]
   ├─ production frontend code
   ├─ tests
   └─ 06_frontend_implementation.md
          ↓
07 frontend-reviewer  [subagent, independent review]
   └─ 07_frontend_review.md
          ↓
   PASS ───────────────→ VERIFIED_FRONTEND
    │
    └─ FIX_REQUIRED → 06 frontend-implementer (narrow fix scope)
                              ↓
                         07 re-review
```

## Knowledge layers

- **Product context** — stable product/domain knowledge, UX principles and guardrails.
- **Analytical specs** — on-demand domain/system evidence: lifecycle, states, business rules, permissions, validation, errors, integrations. Stored under `sources/analytical-specs/` and routed by `index.yaml`; never bulk-loaded by default.
- **Frontend standards** — engineering-only rules and target-repository evidence. They are intentionally unavailable to stages 01–04 and first become normative after `APPROVED_FOR_ENGINEERING`.
- **Repository/contracts** — implementation truth after Stage 04. Existing MFE uses target repo; greenfield standalone engineering uses approved reference evidence + actual UI Kit package until production target exists.
- **Task artifacts** — Intent, Brief, UX Solution, prototype, SDD, frontend plan, implementation handoff and review for the current increment.

## Artifact authority

- `00_intent.md`: why, Why Now, expected outcome, success and guardrails. Stable across UX iterations.
- `01_product_brief.md`: detailed product truth for UX discovery.
- `02_ux_solution.md`: approved user experience, scenarios, states and design rationale.
- HTML prototype: executable UX evidence, never a production implementation contract.
- `03_5_ux_sync.md`: review decision and deviations; cannot change Intent.
- `04_sdd_specification.md`: **product behavior contract** — scope, actors/permissions, states, scenarios, business rules, GWT, errors/edge cases, observable consistency and dependencies. It intentionally contains no implementation design.
- `05_frontend_plan.md`: **engineering translation contract** with explicit `Engineering profile: TARGET_REPO | STANDALONE_ENGINEERING`: affected surfaces, reuse map, component/state boundaries, UI Kit mapping, data/contracts, scenario-state coverage, tests, ordered increments and, for standalone, integration handoff gaps. It may not change product behavior.
- Production code + `06_frontend_implementation.md`: implementation evidence for exactly one or more explicitly enumerated engineering increments. Code is authoritative for what was implemented, not for silently changing product intent.
- `07_frontend_review.md`: independent conformance verdict against SDD + frontend plan + selected engineering profile + frontend standards. `VERIFIED_STANDALONE_ENGINEERING` never claims production MFE/DEV integration.
- Product context: stable product/domain knowledge and architecture/UX guardrails only.
- Analytical specs: reference/constraint source; technical details must be translated into observable behavior before entering SDD.
- Frontend standards: reusable engineering rules. In `TARGET_REPO`, target repository remains higher authority. In `STANDALONE_ENGINEERING`, approved reference baseline + actual UI Kit package are engineering evidence until target integration exists.

## Stage 04 boundary

Stage 04 отвечает на:

- что система должна делать;
- какие сценарии и состояния существуют;
- какие действия/permissions действуют;
- какие business rules и validation влияют на поведение;
- какие ошибки и edge cases надо обработать;
- какой observable outcome считается принятым.

Stage 04 **не отвечает** на API/DTO/storage, frontend/backend architecture, component/store design, transport topology, caching/locking mechanism или implementation task breakdown. Эти решения начинаются после `APPROVED_FOR_ENGINEERING`.

## Engineering workflow principles

1. **Plan before code for non-trivial frontend work.** Stage 05 is read-only and first selects `TARGET_REPO` or `STANDALONE_ENGINEERING`; existing MFE remains target-first.
2. **Prototype is evidence, not source code.** HTML/CSS/JS may clarify hierarchy and interaction, but Stage 05 must map behavior to real repository patterns and UI Kit instead of translating prototype code literally.
3. **One implementation context = one engineering increment.** Stage 06 receives a bounded slice from `05_frontend_plan.md`; large features are implemented incrementally.
4. **Plan deviation is explicit.** If repository truth invalidates the plan, implementation records `PLAN_DEVIATION` instead of silently inventing a new architecture or product rule.
5. **Review is independent.** Stage 07 starts from the diff and approved artifacts, not from the implementer's reasoning history.
6. **Reviewer does not become the implementer.** Broad fixes return to Stage 06. Reviewer may only make local mechanical fixes when explicitly requested; default pipeline mode is review-only.
7. **Frontend standards are shared knowledge, not a role.** Planner, implementer and reviewer read the same `.gigacode/skills/frontend-standards/` package; each subagent keeps a narrow responsibility.
8. **Profile evidence wins implementation disputes.** In `TARGET_REPO`, `AGENTS.md`, actual package versions, UI Kit exports, runtime integration and local patterns outrank generic guidance. In `STANDALONE_ENGINEERING`, approved reference evidence + actual UI Kit package outrank generic guidance, but may not be presented as production runtime truth.
9. **Standalone is not a fallback for missing access.** Use it only for greenfield/new service before target MFE/runtime exists; an unavailable existing repo remains a blocker.
10. **Integration claims stay explicit.** Standalone verification may prove UX behavior, TypeScript, UI Kit use, tests and local runtime, but not DEV/Single-SPA/auth/API integration.

## Stage responsibilities

### 05 frontend-planner

Answers: **Which engineering profile applies, and how can the approved behavior be implemented safely either in the target repo or in a portable greenfield sandbox?**

Required inputs:
- `04_sdd_specification.md` with `APPROVED_FOR_ENGINEERING`;
- final `02_ux_solution.md` and `03_5_ux_sync.md`;
- approved prototype as UX evidence when available;
- target repository and accessible contracts for `TARGET_REPO`; or greenfield evidence + reference baseline + actual UI Kit/dependency source for `STANDALONE_ENGINEERING`;
- frontend standards skill.

Must not edit production code.

### 06 frontend-implementer

Answers: **Can this bounded engineering increment be implemented according to the approved plan and selected engineering-profile rules?**

Required inputs:
- approved `05_frontend_plan.md`;
- selected increment ID(s);
- `04_sdd_specification.md`;
- selected engineering profile and its target/reference workspace;
- frontend standards skill.

It may edit code and run permitted checks. It must not broaden scope by itself.

### 07 frontend-reviewer

Answers: **Does the resulting diff conform to product behavior, approved engineering plan, selected engineering profile and frontend standards without overstating integration readiness?**

Required inputs:
- `git diff` / changed files;
- `04_sdd_specification.md`;
- `05_frontend_plan.md`;
- `06_frontend_implementation.md` when present;
- selected engineering profile and its target/reference workspace;
- frontend standards skill.

Default mode is read-only. Findings are `blocker | major | recommendation` and produce `PASS | FIX_REQUIRED | BLOCKED`.

## Status contracts

See `STATUS_CONTRACTS.md`. A later stage may read earlier outputs and on-demand evidence, but must not silently upgrade status or overwrite source authority.
