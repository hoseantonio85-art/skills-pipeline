# Skills Pipeline v4

Чистый runtime-дистрибутив AI-PDLC для GigaCode с NORM Product Context v4.

## Что внутри

```text
gigacode-ready/            готовые skills, agents и project-level GIGACODE.md
norm-product-context-v4/   NORM product/UX/UI/business/engineering context
PIPELINE.md                рабочая последовательность stages 01–07
STATUS_CONTRACTS.md        межэтапные статусы и gates
integrity/                 checksum baseline защищённых frontend rules
tools/                     проверка целостности дистрибутива
VERSION                    версия дистрибутива
```

## Установка

1. Скопируйте содержимое `gigacode-ready/` в рабочий проект.
2. Разместите `norm-product-context-v4/` в доступной локальной директории.
3. Настройте `~/.gigacode/product-contexts.yaml` по `gigacode-ready/USER_REGISTRY.example.yaml`.
4. Проверьте selector `.gigacode/product-context.yaml` (`context_id: norm`).
5. После обновления skills выполните `/clear` в GigaCode.

## Проверки

```bash
python3 norm-product-context-v4/tools/validate_context.py
python3 tools/audit_distribution.py
```

Обе команды должны завершиться без ошибок. Validator не создаёт отчёт-файл, если не передан `--write-report`.

## Что намеренно не входит

В v4 удалены historical migrations, patch notes, validation reports, authoring audit reports/screenshots, старые diff/patch файлы, macOS metadata и другие файлы, не нужные для runtime или сопровождения. Рабочие выводы из этих материалов уже нормализованы в context rules/patterns/registries.
