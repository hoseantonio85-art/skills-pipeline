# AI PDLC Pipeline — версия 7.0.2

Package version: 7.0.2. Context version: 7. Manifest schema: 8.

Обновление 7.0.2: настоящие логотипы в assets, растягивающиеся кнопки dock и правило кликабельной карточки. См. RELEASE-v7.0.2.md и QA-v7.0.2.md.

Исторические исправления ревью версии 7.0.1: заголовки скиллов, согласованность визуальных правил и паттернов, рабочий starter, доступность окон и панелей, проверки целостности пакета. Изменения перечислены в RELEASE-v7.0.1.md; RELEASE-v7.md сохраняет историю 7.0.0.

## Установка

1. Установите каждую папку skills/ в ~/.gigacode/skills/ либо project-level .gigacode/skills/ по прежнему протоколу.
2. agents/ установите в каталог агентов GigaCode.
3. context/ разместите отдельно. В ~/.gigacode/product-contexts.yaml задайте для norm provider.root на эту папку и provider.manifest: product-system/context-manifest.yaml. Сохраните прежний provider для отката и записи остальных продуктов.
4. В проекте .gigacode/product-context.yaml указывает context_id: norm. Подробности: context/CONTEXT_SETUP.md, context/setup/INSTALL_LAYOUT.md.
5. Проверка: python -X utf8 context/tools/validate_context.py --write-report (Python + PyYAML). Для context-only ZIP: python -X utf8 context/tools/package_context.py.

## Starter

Откройте context/product-system/04_ui/references/html/starter/index.html. Это Event fixture; data-scenario="ai" выбирает пример истории AI-запусков. Демонстрационные состояния доступны через ?demo=1. Читайте foundation/starter-contract.md перед адаптацией. Основной starter и fallback скилла совпадают побайтно.

Stage 03 сохраняет Product Fidelity / Concept Exploration, composition preflight, выбор источников по аспекту и визуальный QA. Event/AI primitives реализованы; Risk/Measure/Knowledge/Campaign требуют адаптации по contracts. Прототип не является production UI Kit или production contract.

## Проверки и границы

Числа ниже относятся к базовой версии 7.0.1. Проверки 7.0.2 записаны отдельно в QA-v7.0.2.md.

25/25 browser checks, 19/19 измерений выбранных геометрических зон, 0 JS errors. Семь исходных дефектов воспроизведены на 7.0.0. Все шесть скиллов проходят quick_validate; валидатор обнаруживает шесть видов намеренного повреждения пакета. Подробные доказательства находятся отдельно в pipeline-v7-review.

95% product fidelity и полный GigaCode end-to-end не аттестованы. Смена активного registry/установка не выполняется копированием этого дистрибутива автоматически. Версия 7.0.0 сохранена.
