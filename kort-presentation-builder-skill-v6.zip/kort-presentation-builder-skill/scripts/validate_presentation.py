#!/usr/bin/env python3
"""Validate a KORT HTML deck against the canonical v6 template contract.

Dependency-free: Python standard library only.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
CANONICAL = SKILL_ROOT / "templates" / "kort-presentation-system-v6.html"


def extract_tag_content(html: str, tag: str) -> str:
    m = re.search(rf"<{tag}\b[^>]*>(.*?)</{tag}>", html, flags=re.I | re.S)
    if not m:
        raise ValueError(f"<{tag}> not found")
    return m.group(1)


@dataclass
class SlideInfo:
    attrs: dict[str, str | None]
    signature: list[tuple[str, tuple[str, ...], tuple[str, ...]]] = field(default_factory=list)
    contenteditable_count: int = 0


class DeckParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.slides: list[SlideInfo] = []
        self._slide_depth = 0
        self._current: SlideInfo | None = None

    @staticmethod
    def _attrs(attrs):
        return {k: v for k, v in attrs}

    def handle_starttag(self, tag, attrs):
        d = self._attrs(attrs)
        classes = tuple(sorted((d.get("class") or "").split()))
        is_slide = tag == "section" and "slide" in classes

        if is_slide and self._current is None:
            self._current = SlideInfo(attrs=d)
            self._slide_depth = 1
            self._record(tag, d, root=True)
            return

        if self._current is not None:
            self._slide_depth += 1
            self._record(tag, d, root=False)

    def handle_startendtag(self, tag, attrs):
        d = self._attrs(attrs)
        if self._current is not None:
            self._record(tag, d, root=False)

    def handle_endtag(self, tag):
        if self._current is None:
            return
        self._slide_depth -= 1
        if self._slide_depth == 0:
            self.slides.append(self._current)
            self._current = None

    def _record(self, tag: str, d: dict[str, str | None], *, root: bool):
        assert self._current is not None
        classes = set((d.get("class") or "").split())
        if root:
            classes.discard("active")
        # Runtime/content metadata may vary and must not alter canonical structure.
        preserved_attrs = []
        for key in ("contenteditable", "data-click-upload"):
            if key in d:
                preserved_attrs.append(key)
        self._current.signature.append((tag, tuple(sorted(classes)), tuple(sorted(preserved_attrs))))
        if d.get("contenteditable") == "true":
            self._current.contenteditable_count += 1


def parse_deck(html: str) -> list[SlideInfo]:
    p = DeckParser()
    p.feed(html)
    return p.slides


def normalize_script(s: str) -> str:
    return s.strip().replace("\r\n", "\n")


def require_tokens(html: str, tokens: list[str], *, label: str, errors: list[str]) -> None:
    for token in tokens:
        if token not in html:
            errors.append(f"Required {label} missing: {token}")


def validate(output: Path, allow_custom: bool) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not CANONICAL.exists():
        return [f"Canonical template missing: {CANONICAL}"], warnings

    base = CANONICAL.read_text(encoding="utf-8")
    html = output.read_text(encoding="utf-8")

    try:
        base_style = extract_tag_content(base, "style").rstrip()
        out_style = extract_tag_content(html, "style")
        if not out_style.startswith(base_style):
            errors.append("Base CSS changed or local CSS was inserted inside canonical CSS. CSS must be append-only.")
    except ValueError as e:
        errors.append(str(e))

    try:
        base_script = normalize_script(extract_tag_content(base, "script"))
        out_script = normalize_script(extract_tag_content(html, "script"))
        if out_script != base_script:
            errors.append("Core JavaScript differs from canonical v6 template; authoring runtime may be broken.")
    except ValueError as e:
        errors.append(str(e))

    require_tokens(
        html,
        [
            'class="deck-shell"', 'id="deck"', 'class="nav"', 'id="overview"',
            'id="overviewGrid"', 'id="fileInput"', 'id="overviewBtn"', 'id="saveBtn"',
            'id="closeOverviewBtn"'
        ],
        label="runtime element",
        errors=errors,
    )

    # Semantic checks give precise diagnostics even though the full core script is also protected.
    require_tokens(
        html,
        [
            "function renderOverview(", "function moveSlide(", "function duplicateSlide(",
            "function deleteSlide(", "function refreshSlides(", "function downloadEdited(",
            "card.draggable=true", "data-action=\"duplicate\"", "data-action=\"delete\""
        ],
        label="v6 authoring capability",
        errors=errors,
    )

    base_slides = parse_deck(base)
    out_slides = parse_deck(html)
    if not out_slides:
        errors.append("No slides found.")
        return errors, warnings

    base_signatures = {tuple(s.signature) for s in base_slides}

    active_flags = []
    custom_count = 0
    for idx, slide in enumerate(out_slides, start=1):
        classes = (slide.attrs.get("class") or "").split()
        active_flags.append("active" in classes)
        is_custom = slide.attrs.get("data-custom") == "true"
        if is_custom:
            custom_count += 1

        sig_ok = tuple(slide.signature) in base_signatures
        if not sig_ok:
            if is_custom and allow_custom:
                warnings.append(f"Slide {idx}: custom structure accepted by --allow-custom.")
            else:
                errors.append(
                    f"Slide {idx}: DOM/class structure does not match any canonical v6 slide pattern. "
                    "Clone a template slide exactly or mark intentional custom slide and validate with --allow-custom."
                )

        if slide.contenteditable_count == 0:
            errors.append(f"Slide {idx}: no contenteditable=\"true\" nodes; manual browser editing was lost.")
        elif slide.contenteditable_count < 2:
            warnings.append(f"Slide {idx}: only {slide.contenteditable_count} editable node; verify editability.")

        if not slide.attrs.get("data-title"):
            warnings.append(f"Slide {idx}: missing data-title; overview will be less useful.")
        if not slide.attrs.get("data-purpose"):
            warnings.append(f"Slide {idx}: missing data-purpose; overview will be less useful.")

    if sum(active_flags) != 1:
        errors.append(f"Exactly one slide must have class active; found {sum(active_flags)}.")
    elif not active_flags[0]:
        warnings.append("Active slide is not first. Valid for a user-saved v6 copy; for a newly generated deck prefer slide 1 active.")

    if custom_count and not allow_custom:
        errors.append(f"Found {custom_count} custom slide(s), but --allow-custom was not provided.")

    return errors, warnings


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("html", type=Path)
    ap.add_argument("--allow-custom", action="store_true")
    args = ap.parse_args()

    if not args.html.exists():
        print(f"FAIL: file not found: {args.html}")
        return 2

    errors, warnings = validate(args.html, args.allow_custom)

    for w in warnings:
        print(f"WARN: {w}")
    for e in errors:
        print(f"ERROR: {e}")

    if errors:
        print(f"FAIL: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1

    print(f"PASS: 0 errors, {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
