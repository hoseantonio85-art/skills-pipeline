# build-kort-presentation

GigaCode skill for assembling self-contained KORT HTML presentations from the canonical v6 template.

v6 preserves the complete browser authoring runtime: slide overview, drag & drop reorder, duplicate, delete, inline editing, media upload, and saving an edited HTML copy.

## Install in a project

Copy this folder to:

```text
.gigacode/skills/build-kort-presentation/
```

Then run `/clear` so GigaCode reloads the skill.

## Suggested explicit invocation

```text
Используй skill build-kort-presentation.
Собери презентацию по материалам @docs/... и сохрани в presentation.html.
```

## Validation

```bash
python .gigacode/skills/build-kort-presentation/scripts/validate_presentation.py presentation.html
```
