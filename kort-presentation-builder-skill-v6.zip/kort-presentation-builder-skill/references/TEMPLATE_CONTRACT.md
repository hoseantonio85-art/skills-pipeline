# KORT Presentation Template Contract · v6

## 1. Что считается protected shell

Protected shell — всё, что обеспечивает визуальную системность, playback и authoring runtime презентации:

- canonical CSS внутри `<style>`;
- `.deck-shell`;
- `main#deck` как контейнер слайдов;
- controls после deck: `.help`, `.nav`, `.overview`, `#fileInput`;
- `#overviewBtn`, `#saveBtn`, `#closeOverviewBtn`;
- core `<script>`;
- print behavior;
- фиксированная сцена 1600×900 и scale logic.

Protected shell нельзя переписывать при обычной генерации презентации.

## 2. Authoring runtime v6 — обязательная часть контракта

Готовая презентация должна сохранять все встроенные возможности шаблона:

1. обзор слайдов;
2. drag & drop перестановку;
3. дублирование слайда;
4. удаление слайда;
5. открытие выбранного слайда из overview;
6. inline-редактирование текста;
7. загрузку изображений в media slots;
8. сохранение изменённой HTML-копии;
9. keyboard navigation, fullscreen и print.

Визуально корректный HTML, потерявший любую из этих возможностей, не соответствует v6 contract.

## 3. Разрешённая единица тиражирования

Единица тиражирования — полный блок:

```html
<section class="slide ..." data-theme="..." data-title="..." data-purpose="...">
  ...
</section>
```

Клонируй section целиком. Не собирай его заново из фрагментов.

Canonical slide должен оставаться автономным: его можно переставить, продублировать или удалить без изменения CSS/JS.

## 4. Что можно менять в canonical clone

- текст внутри `[contenteditable="true"]`;
- `data-title`;
- `data-purpose`;
- `background-image` у предусмотренного media slot;
- порядок slide sections;
- наличие/отсутствие clone в deck;
- `active` — ровно на одном slide;
- browser `<title>`.

Для автоматически созданного deck предпочтительно делать активным первый слайд, но сохранённая пользователем v6-копия может иметь активным любой один слайд.

Runtime может добавлять `data-uid` к slide. Это служебный атрибут и не меняет canonical structure.

## 5. Что нельзя менять в canonical clone

- структуру DOM;
- имена layout classes;
- наличие `contenteditable`;
- grid/flex structure;
- число карточек/шагов/людей/KPI внутри конкретного образца;
- semantic media slot attributes;
- base selectors в CSS.

Если структура контента не подходит — выбери другой template slide.

## 6. Что нельзя менять в runtime

Нельзя удалять или переписывать функции/поведение, обеспечивающие:

- `renderOverview`;
- `moveSlide`;
- `duplicateSlide`;
- `deleteSlide`;
- `refreshSlides`;
- `downloadEdited`;
- `show` / navigation;
- upload slots;
- localStorage text persistence;
- keyboard handling.

Практическое правило проще: core `<script>` должен быть byte-for-byte/normalize-equivalent canonical v6 script.

## 7. Custom extensions

Допустимы как редкое исключение.

Правила:

1. CSS только append-only после canonical CSS.
2. Все selectors scoped новым slide class.
3. Никаких правок существующих selectors.
4. Core JS неизменен.
5. Slide помечен `data-custom="true"`.
6. Пользовательский текст остаётся contenteditable.
7. Custom slide не зависит от фиксированной позиции в deck.
8. Custom slide безопасно переживает duplicate/delete/reorder.
9. Validator запускается с `--allow-custom`.

## 8. Почему contenteditable — часть контракта

HTML-шаблон рассчитан не только на показ, но и на последующее ручное редактирование прямо в браузере.
Удаление `contenteditable="true"` превращает reusable presentation system в статичный результат и считается регрессией.

## 9. Почему data-title и data-purpose — часть authoring UX

Overview v6 показывает название и назначение каждого слайда через `data-title` и `data-purpose`.
Не удаляй их и заполняй осмысленно: это помогает человеку собирать презентацию после генерации.

## 10. Стратегия исправления overflow

Порядок обязателен:

1. сократить copy;
2. разделить смысл;
3. сменить pattern;
4. custom extension только как последнее средство.

Не уменьшай системную типографику локально, пока не исчерпаны первые три шага.
