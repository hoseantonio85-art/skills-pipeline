# v6 notes

## Что изменилось относительно v5

Canonical template v6 добавляет browser authoring workflow поверх прежнего playback/editor shell:

- расширенный overview с карточками слайдов;
- drag & drop reorder;
- duplicate slide;
- delete slide;
- refresh/reindex после структурных изменений;
- кнопка сохранения текущей изменённой HTML-копии;
- сохранение текущего active slide при download;
- runtime metadata `data-uid` для slide instances.

## Следствие для skill

Слайд теперь рассматривается не только как визуальный archetype, но и как переносимая authoring-единица. Любой generated canonical slide должен безопасно работать после reorder / duplicate / delete без специальных правок кода.

## Следствие для validator

Validator v6:

- сравнивает core JS с canonical v6;
- проверяет обязательные authoring controls;
- отдельно диагностирует наличие функций overview/reorder/duplicate/delete/save;
- требует ровно один `active` slide, но допускает его не на первой позиции;
- игнорирует runtime `data-uid` при сравнении структуры slide;
- продолжает защищать `contenteditable`, canonical slide DOM и append-only CSS.
