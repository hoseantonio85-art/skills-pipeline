# build-ui-prototype — MVP v1

GigaCode skill этапа 03 AI PDLC:

```text
01 Product Task Brief
→ 02 UX Solution
→ 03 UI Prototype
→ 04 Frontend Implementation
```

## Что делает

Создаёт standalone React/TypeScript UI-прототип нового сервиса, самостоятельного раздела или автономного сценария по утверждённому `02_ux_solution.md`.

Prototype использует:

- `@sber-orm/ui-kit`;
- реальные design tokens;
- SCSS Modules;
- JSON i18n;
- fixtures и воспроизводимые scenario states;
- чистое разделение pages/components/data/helpers/state;
- `03_ui_prototype.md` как implementation contract и handoff.

## MVP-ограничение

Версия 1 поддерживает только:

```text
standalone_greenfield
```

Она не предназначена для точечного изменения существующего frontend-продукта. При таком входе skill возвращает `UNSUPPORTED_EXISTING_PRODUCT_INCREMENT`, а не воспроизводит продукт заново.

## Контекстная эффективность

Skill не копирует внутрь себя полный UI Kit, продуктовые репозитории и UX-контекст.

Он:

1. читает утверждённый UX Solution;
2. разрешает context manifest;
3. загружает только профиль `for_ui_prototype` или компактный fallback;
4. выбирает нужные компоненты UI Kit;
5. читает только их API и types;
6. хранит checkpoint в `03_ui_prototype.md`.

## Состав

```text
skill/build-ui-prototype/
├── SKILL.md
└── references/
    ├── input-contract.md
    ├── context-loading.md
    ├── implementation-rules.md
    ├── output-contract.md
    └── quality-checklist.md
```

## Что понадобится добавить позже

Skill уже совместим с будущим контекстом:

- `loading.for_ui_prototype` в context manifest;
- каталог composite patterns и surface templates;
- точечные reference implementations;
- режим `existing_product_increment` как отдельное расширение или отдельный skill.

Эти материалы не являются обязательными для MVP.
