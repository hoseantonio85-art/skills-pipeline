# Usage examples

## Создание prototype

```text
Используя skill build-ui-prototype, создай standalone UI-прототип по
increments/TARIFF-USER-MANAGEMENT/02_ux_solution.md.
Product context указан в .gigacode/product-context.yaml.
UI Kit доступен как установленная зависимость.
```

Или явно:

```text
/skills build-ui-prototype increments/TARIFF-USER-MANAGEMENT/02_ux_solution.md
```

## Продолжение после новой сессии

```text
Используя build-ui-prototype в режиме continue, продолжи реализацию по
increments/TARIFF-USER-MANAGEMENT/03_ui_prototype.md.
Не повторяй уже закрытый preflight; реализуй следующий незавершённый surface.
```

## Review

```text
Используя build-ui-prototype в режиме review, проверь весь prototype scope
по quality gate. Не переписывай UX-flow. Исправь только локальные и безопасные
нарушения, затем обнови 03_ui_prototype.md.
```

## Неподдерживаемый вход

```text
Добавь новый AI-блок в существующую RiskModal продукта.
```

Ожидаемое поведение MVP:

```yaml
status: UNSUPPORTED_EXISTING_PRODUCT_INCREMENT
required_capability: prototype-existing-product-increment
```
