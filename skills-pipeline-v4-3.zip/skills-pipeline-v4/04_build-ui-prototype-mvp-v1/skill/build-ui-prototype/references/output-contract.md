# Output Contract

## 1. Код prototype

Код создаётся в текущем prototype workspace или в явно указанной папке.

Не создавай второй вложенный app, если workspace уже является prototype-приложением. Не удаляй существующие файлы без анализа и явной необходимости.

## 2. Обязательный документ

Создай или обнови `03_ui_prototype.md` рядом с increment-файлами или в `docs/`, если так устроен workspace.

Используй следующую структуру.

```md
# UI Prototype — <название>

## 0. Metadata
- task_id
- status
- prototype_mode: standalone_greenfield
- context_id
- context_provider
- context_revision
- input_ux_solution
- created_at / updated_at

## 1. Scope
- что реализуется
- что не реализуется
- почему prototype является standalone

## 2. Sources actually read
| Source | Revision/status | Зачем прочитан | Ограничение |

## 3. UX traceability
| UX requirement / acceptance criterion | Prototype surface/state | Status |

## 4. Surfaces and scenarios
| Surface | User intention | States | Entry/exit |

## 5. Component tree
```text
App
└── ...
```

## 6. State ownership
| Flow/state | Owner | Data source | Production replacement |

## 7. UI Kit mapping
| Prototype element | UI Kit component/type | Verified source | Gap/decision |

## 8. Data and fixtures
- stable IDs
- fixture sets
- scenario switching

## 9. i18n
- namespace
- key groups
- runtime content exclusions

## 10. Implementation decisions
- composition
- responsive behavior
- accessibility
- task-specific UI decisions

## 11. Implemented states
- [ ] default/success
- [ ] loading
- [ ] empty
- [ ] error + retry
- [ ] disabled/pending
- [ ] modal/drawer states
- [ ] action success/failure

## 12. Verification
| Check | Status | Details |

## 13. Assumptions and limitations
- missing evidence
- unavailable runtime checks
- UI Kit gaps

## 14. Frontend handoff
### Keep
### Replace
### Remove from preview
### Verify in target repo

## 15. Review decision
- current status
- owner confirmation
- remaining blockers
```

## 3. Отдельные файлы

По умолчанию не создавай дополнительные `PLAN.md`, `SCENARIOS.md`, `MAPPING.md` и `HANDOFF.md`, если они дублируют `03_ui_prototype.md`.

Разделяй документы только если:

- prototype содержит более трёх независимых surfaces;
- scenario matrix стала неудобна для чтения;
- frontend handoff требует отдельного технического приложения;
- пользователь явно запросил отдельные артефакты.

## 4. Статус

До UI review:

```text
DRAFT_PROTOTYPE
```

После завершения доступных проверок:

```text
READY_FOR_UI_REVIEW
```

После явного подтверждения владельца:

```text
APPROVED_FOR_FRONTEND
```

Не ставь `APPROVED_FOR_FRONTEND` автоматически.

## 5. Финальный ответ GigaCode

Кратко сообщи:

1. что создано;
2. где находится prototype;
3. какие сценарии реализованы;
4. какие проверки выполнены;
5. какие ограничения остались;
6. текущий статус.

Не вставляй полный `03_ui_prototype.md` в ответ, если он сохранён в файл.
