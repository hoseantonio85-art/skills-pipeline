# Context Loading and Context Budget

## 1. Цель

Загрузить достаточно знания для точного prototype, не превращая этап 03 в исследование всех репозиториев и всей документации продукта.

## 2. Порядок разрешения контекста

1. Возьми `context_id` из `02_ux_solution.md`.
2. Если его нет, проверь `01_product_brief.md`.
3. Затем проверь `.gigacode/product-context.yaml`.
4. Разреши путь через `~/.gigacode/product-contexts.yaml`.
5. Прочитай `product-system/context-manifest.yaml`.
6. Зафиксируй provider, revision, status и limitations.

Не выбирай NORM или другой продукт автоматически, если context ID неоднозначен.

## 3. Профиль загрузки

Если manifest содержит:

```yaml
loading:
  for_ui_prototype:
```

прочитай только:

- `loading.always`;
- `loading.for_ui_prototype`;
- on-demand документы, непосредственно связанные с surfaces задачи.

Соблюдай `profile_exclusions.ui_prototype`.

## 4. Fallback до появления профиля этапа 03

Если `for_ui_prototype` ещё не определён, используй минимальный fallback фрагментами, а не полными файлами:

```text
product-system/01_product_foundation/product_philosophy.md
  — только принципы, влияющие на текущий сценарий
product-system/03_ux/ux_principles.md
  — summary, progressive disclosure, layers, actions и AI только при применимости
product-system/03_ux/ux_patterns.md
  — только разделы выбранных page/modal/drawer/list/state patterns
product-system/04_ui/ui_base.md
  — сначала содержание, затем только разделы выбранных компонентов и типов
```

Используй `grep_search`, заголовки и точечное чтение диапазонов, если инструменты это поддерживают. Не читай UX/UI-файл целиком только потому, что он указан в fallback.

Если `product-system/04_ui/ui_base.md` отсутствует, используй установленный package, tarball, type declarations или другую актуальную документацию той же версии. Отсутствие именно этого файла не является blocker; blocker — невозможность проверить фактический UI Kit API вообще.

Дополнительно прочитай не более одного релевантного service document, если без него невозможно понять терминологию или сущности. Не перечитывай service map, roles и business rules, если необходимые факты уже подтверждены в Brief и UX Solution.

## 5. UI Kit loading

`ui_base.md`, package source или Storybook могут быть большими.

Правильный порядок:

1. По UX Solution составь список surfaces и действий.
2. Предварительно выбери необходимые UI primitives.
3. Прочитай table of contents / exports.
4. Открой только разделы выбранных компонентов и используемых enum/type.
5. При неоднозначности прочитай один пример.

Пример:

```text
Нужны: Page layout, modal confirmation, switch, badges.
Читать: Row/Col, Text/Title, Modal, Switch, Badge, Button, Icon и используемые enums.
Не читать: DatePicker, charts, file upload и остальные разделы.
```

## 6. Product repositories

В MVP запрещено обязательное полное исследование продуктовых frontend-репозиториев.

Разрешено точечно открыть один явно указанный reference-файл, если:

- UX/UI-правила допускают несколько трактовок;
- пользователь дал путь;
- reference нужен для конкретного surface;
- его чтение не превращается в reverse engineering всего продукта.

Если references не подключены, продолжай по UX Solution, доступным UX/UI-правилам и UI Kit. Зафиксируй ограничение в `03_ui_prototype.md`.

## 7. Практический бюджет

До implementation plan обычно достаточно:

- 1 UX Solution;
- 0–1 Product Brief;
- 1 context manifest;
- до 6 релевантных фрагментов продуктовых/UX/UI-документов;
- 0–1 service document;
- только выбранные фрагменты UI Kit API.

Если до планирования пришлось открыть больше 10 внешних фрагментов, остановись и проверь, не исследуешь ли ты продукт вместо создания prototype.

Не загружай:

- все service documents;
- все examples;
- весь исходный UI Kit;
- несколько frontend-репозиториев;
- Lovable prompts;
- production API docs, если prototype использует fixtures.

## 8. Работа в длинной сессии

Храни рабочее состояние в `03_ui_prototype.md`:

- прочитанные sources;
- component tree;
- UI Kit mapping;
- build checkpoints;
- выполненные проверки;
- оставшиеся задачи.

При продолжении работы сначала читай этот checkpoint и только активные файлы, а не повторяй исследование.

Если scope содержит несколько независимых surfaces, реализуй их последовательно. После каждого surface обновляй checkpoint. При заметном ухудшении качества используй `/stats`, `/compress` или новую сессию в режиме `continue` — файлы должны содержать достаточный handoff.

## 9. Правило отсутствующего знания

Если контекст не отвечает на визуальный вопрос:

- используй UI Kit и общие UX/UI-правила;
- выбери минимальное консистентное решение;
- пометь его как task-specific UI decision.

Если контекст не отвечает на бизнес- или flow-вопрос:

- не додумывай;
- верни задачу на этап 01 или 02.
