# Prototype Quality Checklist

## 1. Input and scope

- [ ] `02_ux_solution.md` найден.
- [ ] UX status = `APPROVED_FOR_PROTOTYPE`.
- [ ] Prototype mode = `standalone_greenfield`.
- [ ] Scope и out of scope зафиксированы.
- [ ] Нет blocker-вопросов, меняющих flow или бизнес-правила.
- [ ] Этап 03 не подменяет production frontend implementation.

## 2. Context budget

- [ ] Context ID и manifest разрешены.
- [ ] Зафиксированы revision и limitations.
- [ ] Прочитан только профиль `for_ui_prototype` или минимальный fallback.
- [ ] Продуктовые frontend-репозитории не сканировались целиком.
- [ ] UI Kit прочитан только по выбранным компонентам.
- [ ] `03_ui_prototype.md` содержит список реально прочитанных sources.

## 3. UX/UI fidelity

- [ ] Главный пользовательский вопрос понятен.
- [ ] Главный сигнал виден до второстепенных деталей.
- [ ] Порядок зон соответствует UX information hierarchy.
- [ ] Page/modal/drawer используются в утверждённых ролях.
- [ ] Основные действия расположены по правилам контейнера.
- [ ] Есть понятный feedback после значимых действий.
- [ ] Empty и error states ведут к следующему шагу.
- [ ] Интерфейс не выглядит как случайный AI-dashboard.
- [ ] Не добавлены неподтверждённые продуктовые capabilities.

## 4. UI Kit and tokens

- [ ] UI Kit импортируется напрямую.
- [ ] Проверены реальные exports, props и enum установленной версии.
- [ ] Нет скрывающих adapters/facades.
- [ ] Нет Tailwind, shadcn, Radix, lucide, sonner и параллельной UI-библиотеки.
- [ ] Layout использует Row/Col, где это layout-контейнер.
- [ ] Типографика использует Text/Title, где это возможно.
- [ ] Нет hardcoded colors в TS, TSX, SCSS, SVG и chart config.
- [ ] Используются только реальные design tokens.

## 5. Code structure

- [ ] Route page является композицией.
- [ ] Mock arrays и fixtures вынесены в `data`.
- [ ] Чистые transformations находятся в `helpers`.
- [ ] Route-specific components не подняты без причины в общий `components`.
- [ ] У самостоятельных component folders есть рабочий `index.ts`.
- [ ] Нет глубоких импортов в обход component public API.
- [ ] Нет component/page файлов больше 400 строк без обоснования.
- [ ] Нет god-hook, смешивающего независимые flows.
- [ ] Нет пустых `styles.module.scss`, `types.ts`, `constants.ts` и barrels.
- [ ] Каждый style module импортируется.

## 6. Data and i18n

- [ ] Domain entities используют stable IDs.
- [ ] Localized labels не используются в guards и business logic.
- [ ] UI labels, buttons, statuses, notifications и errors находятся в JSON i18n.
- [ ] Runtime content находится в data/fixtures.
- [ ] Config не содержит CSS class strings, colors, JSX или handlers.

## 7. State and scenarios

- [ ] Реализован default/success state.
- [ ] Реализованы применимые loading, empty и recoverable error states.
- [ ] Реализованы pending/disabled states действий.
- [ ] Реализованы modal/drawer open/close states.
- [ ] Action success/failure воспроизводимы, если предусмотрены UX.
- [ ] Пользователь может переключить demo-сценарий без правки исходного кода.
- [ ] Scenario state не смешан с localized labels.

## 8. Accessibility

- [ ] Keyboard path покрывает основные действия.
- [ ] Visible focus не удалён.
- [ ] Interactive custom containers имеют правильную семантику.
- [ ] Modal focus/escape behavior проверен или делегирован подтверждённому API UI Kit.
- [ ] Reduced motion учтён, если есть animation.

## 9. Tests

- [ ] Каждый новый helper имеет тест.
- [ ] Derived counters, filters и normalizers проверены.
- [ ] Store/model transitions проверены, если они есть.
- [ ] Отсутствие component tests обосновано отсутствием нетривиальной UI-логики.

## 10. Static checks

Выполни доступные проверки:

```text
rg hardcoded colors
rg forbidden imports and re-exports
find empty styles.module.scss
count lines in TSX/hooks/models
grep inline styles and obvious user strings
grep localized strings in comparisons/guards
git diff --check
```

Также проверь:

- [ ] unused-проверки не отключены без причины;
- [ ] нет dead files и dead exports;
- [ ] нет mojibake или повреждённой кодировки;
- [ ] нет vendored/generated/temporary artifacts.

## 11. Runtime checks

Если разрешены и доступны:

- [ ] typecheck;
- [ ] lint;
- [ ] tests;
- [ ] build;
- [ ] preview ключевых viewport и scenarios.

Если проверка не запускалась, укажи причину. Не утверждай, что она прошла.

## 12. Blockers

Prototype не может получить `READY_FOR_UI_REVIEW`, если найдено хотя бы одно:

- неподдерживаемый `existing_product_increment`;
- неутверждённый UX input;
- invented UI Kit API;
- hardcoded color или локальная palette;
- запрещённая dependency или скрытый re-export;
- отсутствующая обязательная UX state;
- page с бизнес-логикой или большими fixtures;
- component больше 400 строк без обоснования;
- пользовательский текст вне i18n;
- localized label как business ID;
- новый helper/store без теста;
- пустой или неиспользуемый style module;
- очевидный dead code;
- повреждённая кодировка;
- prototype не запускается при доступной и разрешённой runtime-проверке.

## 13. Verdict

Используй один из результатов:

```text
PASS — READY_FOR_UI_REVIEW
PASS_WITH_LIMITATIONS — READY_FOR_UI_REVIEW
FAIL — DRAFT_PROTOTYPE
BLOCKED_BY_INPUT
BLOCKED_BY_CONTEXT
BLOCKED_BY_UI_KIT
UNSUPPORTED_EXISTING_PRODUCT_INCREMENT
```

`PASS_WITH_LIMITATIONS` допустим, если ограничения относятся к недоступной runtime-проверке или отсутствующему optional evidence, но UX-flow и статический quality gate закрыты.
