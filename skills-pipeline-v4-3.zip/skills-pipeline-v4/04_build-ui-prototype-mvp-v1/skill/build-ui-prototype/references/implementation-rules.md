# Prototype Implementation Rules

## 1. Приоритеты

При конфликте правил используй порядок:

1. утверждённый UX Solution и бизнес-ограничения;
2. manifest и продуктовые UX/UI-правила;
3. фактический API установленной версии UI Kit;
4. эти prototype frontend rules;
5. общие best practices.

Не меняй UX-flow ради удобства реализации.

## 2. Визуальная задача

Prototype должен выглядеть частью целевого продукта, а не самостоятельным авторским сайтом.

- Не придумывай новую палитру, шрифты или визуальный язык.
- Не используй типовые AI-dashboard клише без связи с содержанием.
- Структура и акценты должны выражать информационный приоритет из UX Solution.
- Summary и главный сигнал идут раньше деталей.
- Используй прогрессивное раскрытие.
- Декор не должен конкурировать с содержанием.
- Анимация допустима только для понятного feedback и смены состояния.
- UI-copy краткий, активный и одинаково называет действие во всём flow.
- Empty и error states объясняют следующий шаг.

## 3. UI Kit

Используй компоненты напрямую из `@sber-orm/ui-kit`.

Запрещено:

- скрывать UI Kit за общим facade или adapter;
- копировать пакет в `vendor`;
- создавать дубли `BaseButton`, `CustomModal`, `ActionInput`, если штатный компонент подходит;
- параллельно использовать Tailwind, shadcn, Radix, lucide, sonner и другой UI framework;
- использовать сырой `button`, `input`, `select`, `textarea`, если есть штатный компонент.

Технические HTML wrappers допустимы для:

- ограничения ширины;
- CSS-state;
- tooltip target;
- divider;
- notification host;
- декоративного слоя без интерактивной семантики.

Layout по умолчанию собирай через `Row`/`Col`, типографику — через `Text`/`Title`, если это поддерживает фактический API.

## 4. Цвета и токены

Все цвета должны приходить из UI Kit или theme tokens.

Разрешено:

- semantic props UI Kit;
- реально существующие CSS variables UI Kit/theme;
- `transparent`, `currentColor`, `inherit` по смыслу.

Запрещено:

- `#hex`;
- `rgb`, `rgba`, `hsl`, `hsla`, `oklch`;
- named colors;
- локальная palette;
- fallback на hardcoded color;
- цветовые строки и CSS-class strings в TS/TSX config;
- hardcoded colors в SVG, canvas и charts.

Предпочитай semantic tokens palette tokens, если semantic token соответствует назначению.

## 5. Структура кода

Рекомендуемая структура нового prototype:

```text
src/
├── @types/       # domain types и stable IDs
├── components/   # реально переиспользуемые UI-блоки
├── data/         # fixtures и scenario datasets
├── helpers/      # чистые transformations
├── i18n/         # JSON resources и setup
├── pages/        # route-level composition
├── providers/    # prototype-level providers
└── stores/       # только нетривиальное состояние сценариев
```

Route-specific components размещай в:

```text
pages/<Page>/components/<Component>/
```

Самостоятельный visual component обычно содержит:

```text
ComponentName.tsx
styles.module.scss
index.ts
```

Создавай `types.ts`, `constants.ts`, hooks и nested components только при реальной необходимости. Пустые файлы и пустые barrels запрещены.

`index.ts` является публичным API папки компонента. Не обходи его глубоким импортом.

## 6. Размер и ответственность

- Route-level page содержит composition и orchestration, но не mock arrays и бизнес-вычисления.
- Нормальный размер visual component — около 200–300 строк.
- Файл больше 400 строк — blocker без явного обоснования.
- Не создавай god-hook, смешивающий независимые user flows.
- Дроби по смысловым зонам и сценариям, а не механически по размеру.
- Не универсализируй компонент без реального повторного использования.

## 7. Data и stable IDs

Runtime/mock content хранится в `data`:

- ФИО и email;
- названия компаний;
- номера договоров;
- даты и суммы;
- demo comments;
- scenario fixtures.

UI labels, button text, statuses и errors находятся в i18n, а не в `data`.

Business logic использует stable IDs:

```ts
status: 'active'
roleIds: ['ORMCLOUD_RISKMANAGER']
```

Нельзя использовать локализованные строки как enum values, guards, object keys или API/store values.

Не храни CSS-классы, цвета, JSX и handlers в config/data.

## 8. i18n

Весь новый пользовательский системный текст находится в JSON namespace, например:

```text
src/i18n/locales/ru/<feature>.json
```

TypeScript используется только для setup, resources и типизации.

Runtime content не переносится в i18n.

Используй единый словарь действий во всём flow: если действие называется «Деактивировать», success feedback не должен внезапно называться «Отключено», если это меняет смысл.

## 9. State и сценарии

До кодинга составь scenario matrix.

По возможности поддержи воспроизводимые состояния:

- default/success;
- loading/refreshing;
- empty;
- recoverable error + retry;
- validation error;
- disabled/pending action;
- modal/drawer open and close;
- optimistic/success/failure outcome, если предусмотрено UX.

Для простого локального presentation state допустим `useState`.

Если flow содержит несколько действий, derived values или повторное использование состояния, создай scenario-specific hook или store. Не вводи MST только ради standalone preview, если его нет в starter; границы state должны позволять заменить prototype state продуктовым store на этапе 04.

Чистые вычисления выноси в helpers и покрывай Vitest-тестами.

## 10. React patterns

- Обработчики, передаваемые детям, участвующие в dependencies или засоряющие JSX, выноси в `useCallback`.
- `useMemo` и `React.memo` применяй только с понятной причиной.
- Не пиши многострочную бизнес-логику внутри JSX.
- Интерактивная карточка должна иметь keyboard semantics: `role`, `tabIndex`, `aria-label`, Enter и Space, если нет подходящего UI Kit component.
- Modal закрывается Escape и возвращает focus к trigger, если библиотека не делает это автоматически.
- Учитывай visible focus и reduced motion.

## 11. Standalone preview

MVP создаёт standalone preview, а не product microfrontend.

Разрешено:

- `createRoot` и локальный entrypoint;
- локальный router, только если нужен для демонстрации нескольких prototype surfaces;
- prototype shell и scenario switcher;
- fixtures и mock repository.

Обязательно пометь в handoff, что не переносится в production:

- preview shell;
- scenario switcher;
- local router, если target предоставляет host routing;
- fixtures;
- mock permissions;
- mock repository.

Запрещено утверждать, что standalone prototype уже совместим с Single-SPA/MST/runtime без исследования target repo.

## 12. Dependencies и команды

Сначала прочитай `AGENTS.md`, `GIGACODE.md`, package manager и repository scripts.

- Не устанавливай зависимости молча.
- Не обновляй версии существующих зависимостей без необходимости.
- Не vendor-ь UI Kit.
- Локальный `file:` dependency на предоставленный tarball допустим только при явном выборе для preview и должен быть отмечен в handoff.
- Не запускай тяжёлые команды, если repository instructions или среда это запрещают.

## 13. Минимальные тесты

Обязательны тесты для:

- новых helpers;
- derived counters;
- filters;
- normalizers;
- state transitions, если они вынесены в store/model;
- validation logic.

Отсутствие component snapshot test не является нарушением. Component test нужен, если важную логику нельзя проверить ниже по слою.
