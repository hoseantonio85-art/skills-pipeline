---
name: build-ui-prototype
description: Создаёт самостоятельно запускаемый UI-прототип нового сервиса, самостоятельного раздела или автономного пользовательского сценария по утверждённым Product Task Brief и UX Solution. Используй, когда UX Solution имеет статус APPROVED_FOR_PROTOTYPE и нужно реализовать React/TypeScript-прототип на @sber-orm/ui-kit с mock-данными, состояниями, i18n, SCSS Modules, проверками и handoff для frontend. Загружает только релевантные части продуктового контекста и API выбранных компонентов UI Kit. Не используй для точечной доработки существующего интерфейса или продуктового репозитория, production-интеграции, API и полного frontend implementation.
---

# Build UI Prototype

## 1. Назначение

Ты превращаешь утверждённое UX-решение в исполняемый UI-прототип, который:

- визуально и композиционно соответствует продукту и его UI Kit;
- воспроизводит утверждённый flow, основные состояния и обратную связь;
- позволяет провести UX/UI review;
- служит однозначной reference implementation для следующего frontend-этапа;
- не выдаётся за production frontend.

Skill является универсальным и не содержит фактов конкретного продукта.
Продуктовые факты, UX-правила, UI-правила и документация UI Kit приходят из выбранного контекста.

Формула результата:

```text
01_product_brief.md
+ 02_ux_solution.md со статусом APPROVED_FOR_PROTOTYPE
+ релевантный профиль продуктового контекста
+ точечно прочитанный API UI Kit
+ правила прототипной frontend-реализации
= работающий standalone UI prototype + 03_ui_prototype.md
```

## 2. MVP-граница

Поддерживаемый режим:

```text
standalone_greenfield
```

Используй его для:

- нового сервиса;
- нового самостоятельного раздела;
- нового автономного пользовательского сценария;
- нового набора surfaces, который можно проверить отдельно от существующего frontend-продукта.

Не поддерживается в MVP:

```text
existing_product_increment
```

Не продолжай генерацию, если задача требует:

- добавить кнопку, блок или состояние в существующий экран;
- изменить существующую modal, drawer или страницу;
- встроить новую ветку в уже реализованный flow;
- сохранить и модифицировать конкретную реализацию текущего frontend-репозитория.

В таком случае верни:

```yaml
status: UNSUPPORTED_EXISTING_PRODUCT_INCREMENT
required_capability: prototype-existing-product-increment
reason: краткое объяснение точки встраивания
```

Не воспроизводи весь существующий продукт заново ради локального изменения.

## 3. Главный контракт

Обязательный вход:

```text
02_ux_solution.md
status: APPROVED_FOR_PROTOTYPE
```

Желательный вход:

```text
01_product_brief.md
```

Минимальный результат:

```text
работающий код прототипа
03_ui_prototype.md
```

`03_ui_prototype.md` должен фиксировать:

- metadata и статус;
- границы prototype scope;
- surfaces и сценарии;
- component tree;
- state ownership;
- UI Kit mapping;
- данные и fixtures;
- i18n namespace;
- допущения и ограничения;
- реализованные состояния;
- выполненные проверки;
- handoff для frontend implementation.

Следующий этап:

```text
04_frontend_implementation
```

## 4. Роль

Работай одновременно как:

- senior product/UI designer, который сохраняет UX-логику и визуальный язык продукта;
- frontend prototyper, который пишет чистый и переносимый React/TypeScript-код;
- строгий self-reviewer, который проверяет весь созданный scope перед завершением.

Ты не должен заново проектировать продуктовую задачу или UX-flow. Если UI-решение требует изменить утверждённый flow, зафиксируй конфликт и верни задачу на этап 02.

## 5. Обязательные reference-файлы

Перед работой прочитай:

```text
references/input-contract.md
references/context-loading.md
references/implementation-rules.md
```

До начала JSX используй:

```text
references/output-contract.md
```

Перед завершением выполни:

```text
references/quality-checklist.md
```

Не копируй содержимое reference-файлов в рабочие документы целиком. Применяй правила, а в `03_ui_prototype.md` фиксируй только решения конкретной задачи.

## 6. Режимы работы

### `create`

Создать новый standalone-прототип по утверждённому UX Solution.

### `continue`

Продолжить реализацию по существующему `03_ui_prototype.md`, не повторяя preflight и уже закрытые решения.

### `improve`

Улучшить существующий прототип в пределах утверждённого UX и текущего scope.

### `review`

Проверить существующий прототип по quality gate. Не переписывать его полностью без явного запроса.

Если режим не указан:

- для пустого prototype workspace выбери `create`;
- при наличии `03_ui_prototype.md` и незавершённого плана выбери `continue`;
- при запросе проверки выбери `review`.

## 7. Контекст и защита контекстного окна

Используй `references/context-loading.md` как обязательный бюджет контекста.

Главные правила:

1. Сначала прочитай `02_ux_solution.md`, а не все продуктовые документы.
2. Разреши context ID через `.gigacode/product-context.yaml`, brief или UX metadata.
3. Прочитай manifest и только профиль `for_ui_prototype`, если он существует.
4. Если профиль ещё не создан, используй минимальный fallback из `context-loading.md`.
5. Не сканируй продуктовые frontend-репозитории целиком в MVP.
6. Не читай всю документацию UI Kit до выбора компонентов.
7. Сначала составь UI Kit mapping, затем открой только нужные exports, types и разделы документации.
8. Не загружай examples и supporting methodology без конкретной необходимости.
9. При спорном решении прочитай один наиболее релевантный reference, а не коллекцию репозиториев.
10. Храни прогресс в `03_ui_prototype.md`, а не только в истории диалога.

Если scope большой, реализуй по surfaces и после каждого логического блока обновляй checkpoint в `03_ui_prototype.md`. Не создавай параллельные планы с дублирующим содержанием.

Каталог составных паттернов в MVP необязателен:

- используй утверждённый паттерн, если он доступен и релевантен;
- отсутствие паттерна не является blocker;
- без паттерна собирай task-specific композицию из UX Solution, UX/UI-правил и UI Kit;
- не ищи паттерн по множеству репозиториев только ради подтверждения обычной композиции.

## 8. Input gate

Используй `references/input-contract.md`.

Не начинай финальную реализацию, если:

- нет `02_ux_solution.md`;
- UX status не `APPROVED_FOR_PROTOTYPE`;
- не определены surfaces, основные действия или ключевые состояния;
- есть blocker-вопрос, меняющий flow или бизнес-логику;
- задача относится к `existing_product_increment`;
- UI Kit недоступен и невозможно проверить реальные exports/props;
- пользователь требует production-интеграцию вместо прототипа.

При неполном входе можешь создать только implementation outline со статусом `BLOCKED_BY_INPUT`, но не выдавай его за готовый прототип.

## 9. Алгоритм работы

### Шаг 1. Найти входные increment-файлы

Найди:

- `02_ux_solution.md`;
- `01_product_brief.md`, если есть;
- существующий `03_ui_prototype.md`, если режим `continue`, `improve` или `review`.

Зафиксируй task ID, context ID, UX status, scope и open questions.

### Шаг 2. Классифицировать prototype mode

Проверь, является ли решение самостоятельным greenfield-прототипом.

Если UX Solution описывает изменение конкретного существующего surface, остановись с `UNSUPPORTED_EXISTING_PRODUCT_INCREMENT`.

### Шаг 3. Проверить input gate

Применяй `references/input-contract.md`.

Не заменяй отсутствующие бизнес-правила визуальными допущениями.

### Шаг 4. Разрешить продуктовый контекст

Используй `references/context-loading.md`.

Зафиксируй в `03_ui_prototype.md`:

- context ID;
- provider;
- manifest;
- revision;
- реально прочитанные документы;
- ограничения evidence.

### Шаг 5. Сформировать компактный implementation contract

До JSX зафиксируй в `03_ui_prototype.md`:

- prototype scope и out of scope;
- surfaces;
- component tree;
- owner состояния каждого user flow;
- scenario matrix;
- stable domain IDs;
- data/fixture plan;
- i18n namespace;
- UI Kit mapping;
- token policy;
- acceptance checklist.

Не делай визуальный конфиг внутри page/component.

### Шаг 6. Проверить API UI Kit

Сначала составь список нужных компонентов.

Затем для каждого компонента:

1. найди export в установленной версии пакета или её type declarations;
2. проверь реальные props, enum и допустимые значения;
3. найди один пример использования, если API неоднозначен;
4. запиши mapping в `03_ui_prototype.md`.

Не придумывай `EIconName`, props, variants или компоненты по памяти.

Если штатного компонента нет:

- используй узкий композиционный компонент из доступных primitives;
- применяй только реальные токены;
- зафиксируй UI Kit gap;
- не создавай скрывающий adapter/facade.

### Шаг 7. Подготовить структуру prototype code

Для нового standalone prototype используй React + TypeScript + Vite или уже подготовленный совместимый starter.

Минимальная структура:

```text
src/
├── @types/
├── components/
├── data/
├── helpers/
├── i18n/
├── pages/
├── providers/
├── stores/          # только если есть нетривиальное scenario state
├── App.tsx
└── main.tsx
```

Не создавай пустые папки или файлы ради формальной структуры.

Page содержит композицию и orchestration верхнего уровня. Route-specific UI остаётся в `pages/<Page>/components`. В `src/components` помещай только реально переиспользуемые элементы.

### Шаг 8. Реализовать prototype

Следуй `references/implementation-rules.md`.

Порядок:

1. domain types и stable IDs;
2. fixtures и scenario data;
3. pure helpers и их тесты, если есть вычисления;
4. scenario state;
5. i18n resources;
6. route-level page composition;
7. локальные visual components;
8. modals/drawers/feedback;
9. scenario switching или воспроизводимые входные состояния;
10. accessibility и focus behavior.

Не начинай с одного большого `Index.tsx`.

### Шаг 9. Самопроверка UI

Проверь:

- сохраняется ли главный пользовательский вопрос из UX Solution;
- виден ли главный сигнал без ручного исследования экрана;
- соответствует ли порядок зон информационному приоритету;
- ведут ли действия к понятному feedback;
- не превратился ли интерфейс в типовой AI-dashboard;
- нет ли декора, который конкурирует с содержанием;
- все ли обязательные состояния воспроизводимы.

Если preview и screenshot-инструменты доступны, проверь согласованные viewport. Если недоступны, явно укажи отсутствие визуальной runtime-проверки.

### Шаг 10. Техническая проверка

Используй `references/quality-checklist.md`.

Сначала выполни лёгкие статические проверки. Build, test, lint и dev server запускай только если это разрешено repository instructions и средой.

Не устанавливай зависимости молча. Не модифицируй и не vendor-ь UI Kit.

### Шаг 11. Завершить handoff

Обнови `03_ui_prototype.md` по `references/output-contract.md`.

Статус до пользовательского UI review:

```text
READY_FOR_UI_REVIEW
```

После явного подтверждения UI/UX владельца:

```text
APPROVED_FOR_FRONTEND
```

Если runtime-проверки не выполнены, это должно быть явно отражено, но не обязательно блокирует UI review, когда статический scope проверен и причина объективна.

## 10. Статусы

Разрешённые статусы:

- `DRAFT_PROTOTYPE`;
- `READY_FOR_UI_REVIEW`;
- `APPROVED_FOR_FRONTEND`;
- `BLOCKED_BY_INPUT`;
- `BLOCKED_BY_CONTEXT`;
- `BLOCKED_BY_UI_KIT`;
- `UNSUPPORTED_EXISTING_PRODUCT_INCREMENT`;
- `ARCHIVED`.

Не придумывай дополнительные статусы без необходимости.

## 11. Граница frontend-этапа

Skill может:

- создать самостоятельно запускаемый UI prototype;
- использовать fixtures и mock repository;
- реализовать утверждённые interactions и состояния;
- создать композиционные компоненты поверх UI Kit;
- добавить чистые helpers и минимальные тесты;
- подготовить frontend handoff.

Skill не может:

- интегрировать prototype в существующий product repo;
- реализовывать production API и auth;
- создавать Single-SPA integration;
- утверждать production readiness;
- заменять системный анализ;
- принимать новые продуктовые решения вместо этапов 01–02;
- делать широкий frontend refactoring;
- создавать новый UI Kit или vendor-копию существующего.

## 12. Definition of Done

Prototype готов к UI review, когда:

- UX Solution утверждён;
- prototype mode поддерживается;
- context ID и evidence зафиксированы;
- прочитан только релевантный контекст;
- UI Kit mapping основан на фактическом API;
- все P0/P1 surfaces и действия реализованы;
- обязательные loading, empty, error, success, disabled/pending и modal/drawer states воспроизводимы, если они применимы;
- главный сигнал и информационная иерархия соответствуют UX Solution;
- используются UI Kit и реальные дизайн-токены;
- отсутствуют hardcoded colors и запрещённые UI-зависимости;
- пользовательские UI-строки находятся в i18n;
- fixtures отделены от UI;
- stable IDs не зависят от перевода;
- page не содержит mock arrays и бизнес-вычисления;
- нет components больше 400 строк без обоснования;
- helpers и нетривиальная scenario logic покрыты тестами;
- нет пустых style modules, dead code и повреждённой кодировки;
- выполнен доступный набор проверок;
- `03_ui_prototype.md` содержит handoff и известные ограничения;
- пользователь может проверить ключевые сценарии без изменения исходного кода.
