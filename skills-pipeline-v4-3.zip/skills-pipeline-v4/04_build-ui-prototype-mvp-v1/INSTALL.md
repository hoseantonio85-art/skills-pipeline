# Installation

## Project-level installation

Скопируйте папку:

```text
skill/build-ui-prototype
```

в:

```text
<project>/.gigacode/skills/build-ui-prototype
```

Итог:

```text
.gigacode/
└── skills/
    └── build-ui-prototype/
        ├── SKILL.md
        └── references/
```

После установки или обновления выполните в GigaCode:

```text
/clear
```

Это необходимо, чтобы CLI перечитал skill metadata и description.

## Context setup

Skill использует тот же registry продуктовых контекстов, что этапы 01–02:

```text
~/.gigacode/product-contexts.yaml
```

В prototype workspace желательно указать context ID:

```text
.gigacode/product-context.yaml
```

Пример:

```yaml
context_id: norm
```

До появления `loading.for_ui_prototype` skill использует минимальный fallback, описанный в `references/context-loading.md`.

## Required input

Поместите в workspace или укажите путь к:

```text
01_product_brief.md        # желательно
02_ux_solution.md          # обязательно
```

`02_ux_solution.md` должен иметь статус `APPROVED_FOR_PROTOTYPE`.

## UI Kit

Должен быть доступен фактический API версии `@sber-orm/ui-kit` через установленный package, tarball, types или актуальную документацию.

Skill не должен угадывать props и не vendor-ит пакет.
