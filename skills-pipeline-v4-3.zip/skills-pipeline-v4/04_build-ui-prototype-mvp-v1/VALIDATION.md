# Validation

Пакет считается структурно корректным, если:

- `SKILL.md` содержит YAML frontmatter с `name` и сильным `description`;
- все пять reference-файлов существуют;
- все ссылки из `SKILL.md` разрешаются относительно папки skill;
- в reference-файлах нет product-specific фактов;
- MVP явно ограничен `standalone_greenfield`;
- отсутствует обязательное чтение полных frontend-репозиториев;
- UI Kit загружается точечно после mapping;
- output contract содержит `03_ui_prototype.md` и handoff;
- quality gate проверяет UX/UI, frontend structure, tokens, i18n, states и tests.

Рекомендуемый smoke test:

1. Установить skill project-level.
2. Выполнить `/clear`.
3. Передать утверждённые `01_product_brief.md` и `02_ux_solution.md` для самостоятельного нового сервиса.
4. Вызвать `/skills build-ui-prototype`.
5. Убедиться, что агент сначала создаёт compact implementation contract, затем проверяет только нужные UI Kit components.
6. Передать UX Solution с локальным изменением существующей modal и проверить возврат `UNSUPPORTED_EXISTING_PRODUCT_INCREMENT`.
