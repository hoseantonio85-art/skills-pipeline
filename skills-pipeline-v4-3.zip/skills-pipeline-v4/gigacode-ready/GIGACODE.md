# NORM product pipeline

For product and UX tasks, use the matching skill from `.gigacode/skills/` explicitly or automatically.

Before any NORM conclusion:

1. Read `.gigacode/product-context.yaml` and obtain `context_id`.
2. Read `~/.gigacode/product-contexts.yaml`.
3. Resolve `contexts[context_id].provider.root` and `provider.manifest`.
4. Read `<provider.root>/<provider.manifest>` and the profile required by the active skill.
5. List the manifest and actually read files in `Context trace`.

If NORM is selected but the registry, manifest or required profile cannot be read, stop with `BLOCKED_BY_CONTEXT`. Do not produce a generic NORM result.

Use file editing tools for Markdown, HTML, CSS and JavaScript. Do not write document contents through shell commands. Use shell only to run and verify the prototype.
