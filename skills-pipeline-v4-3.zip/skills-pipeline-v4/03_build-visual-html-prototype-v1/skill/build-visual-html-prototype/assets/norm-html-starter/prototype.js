const demoStates = ['default', 'loading', 'empty', 'error'];

function showDemo(state) {
  demoStates.forEach((name) => {
    document.getElementById(`state-${name}`).hidden = name !== state;
  });
  document.querySelectorAll('[data-demo]').forEach((button) => {
    button.classList.toggle('active', button.dataset.demo === state);
  });
}

document.querySelectorAll('[data-demo]').forEach((button) => {
  button.addEventListener('click', () => showDemo(button.dataset.demo));
});

document.querySelectorAll('.chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach((item) => item.classList.remove('active'));
    chip.classList.add('active');
  });
});

const modal = document.getElementById('object-modal');
document.querySelectorAll('[data-open-modal]').forEach((button) => {
  button.addEventListener('click', () => { modal.hidden = false; });
});
document.querySelectorAll('[data-close-modal]').forEach((button) => {
  button.addEventListener('click', () => { modal.hidden = true; });
});
modal.addEventListener('click', (event) => {
  if (event.target === modal) modal.hidden = true;
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') modal.hidden = true;
});

showDemo('default');
