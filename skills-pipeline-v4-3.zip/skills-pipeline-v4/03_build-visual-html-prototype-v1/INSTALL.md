# Установка visual HTML pipeline

Установите skill `build-visual-html-prototype` в каталог skills GigaCode. Распакуйте `norm-product-context-v3-mvp` в стабильную директорию.

Предпочтительная настройка проекта:

```text
<project>/.gigacode/product-context.yaml
```

```yaml
version: 1
context_id: norm
```

Отдельно зарегистрируйте контекст в `~/.gigacode/product-contexts.yaml`:

```yaml
contexts:
  norm:
    label: NORM
    description: Единый продуктовый контекст NORM
    status: ready
    provider:
      type: local_repository
      root: "/absolute/path/to/norm-product-context-v3-mvp"
      manifest: "product-system/context-manifest.yaml"
```

После установки очистите текущую сессию GigaCode. В output каждого этапа проверьте Context trace и список реально прочитанных файлов.
