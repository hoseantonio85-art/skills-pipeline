# HTML references

HTML в этом разделе нужен для повышения product likeness Stage 03. Это visual/composition evidence, а не production UI Kit implementation и не React contract.

## `starter/`

Product-scoped starter для новых NORM HTML prototypes. Он продублирован из legacy skill asset для обратной совместимости. Новый runtime должен брать путь из product context manifest; legacy copy внутри skill пока сохраняется как fallback.

## `norm-vertical-slice/`

Reference scene для цепочки:

`Registry page → Search/Filters → Entity Card → Object Modal/View → Action/Meta Zone → Drawer`.

Использовать выборочно. Не bulk-load HTML, если для задачи достаточно runtime pattern/organism descriptions.
