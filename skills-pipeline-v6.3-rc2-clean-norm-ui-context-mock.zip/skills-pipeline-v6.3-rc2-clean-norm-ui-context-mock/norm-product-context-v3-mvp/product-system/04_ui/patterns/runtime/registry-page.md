# Registry Page — runtime pattern

## Intent

Рабочая страница со списком однотипных сущностей. Пользователь должен быстро понять scope выдачи, переключить сегмент, найти сущность, уточнить фильтры и открыть объект.

## Canonical composition

```txt
Page
├─ Title + total/context
├─ Optional service-specific insight area
├─ RegistryPageControls
│  ├─ Section / quick filters
│  ├─ Search trigger
│  ├─ Advanced filter trigger
│  └─ Expandable search
├─ Entity list
│  └─ EntityCard × N
└─ Optional NORM floating create/chat surface
```

## Rules

- Search и Filter находятся в одном control row; search может раскрываться отдельной строкой под ним.
- Quick filters отражают частые срезы; расширенные поля не выносятся все на страницу.
- Filter открывает Drawer.
- Page не оборачивать целиком в большую white card: registry должен сохранять ощущение workspace/canvas.
- Список должен иметь один устойчивый vertical rhythm.
- Service-specific insights допустимы между controls/title и list, но не становятся частью universal registry pattern.

## States

- loading: skeleton/list loader, controls не прыгают;
- empty: объяснение + следующий шаг;
- filtered empty: отличать от системного empty;
- error: recoverable retry;
- search expanded/collapsed;
- filters active indicator.

## NORM profile

- spacious top area;
- entity cards radius 16 / ~24px padding;
- bottom floating create/chat surface допустим как NORM-specific behavior;
- reference: `norm-vertical-slice.html#registry`.
