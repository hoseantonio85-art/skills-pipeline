# NORM Visual DNA — runtime

Использовать только после определения `product: norm`.

## Perception

NORM — светлый enterprise workspace с большим количеством воздуха на уровне page и более плотными entity/object surfaces. Интерфейс должен выглядеть спокойным и системным, а не «маркетинговым SaaS».

## Geometry

- App/page: много свободного белого/very-light пространства.
- Entity cards: radius `16px`, padding около `24px`, тонкая border/elevation.
- Secondary blocks: radius `16px`, soft secondary background.
- Large Object Modal: NORM profile `max-width: 1320px`, radius `24px`, viewport margin/padding около `24px`.
- Object View rail: desktop target около `280px`; при узком container rail переносится ниже main content.
- UI Kit Modal baseline: header `32px 40px`, close top/right `32/40`, title около `28/40`.

## Density rhythm

- Page header и верхние controls — воздушные.
- Cards — компактнее и информативнее страницы.
- Modal sections — плотные белые blocks на very-light modal workspace.
- Meta labels и technical IDs — secondary/quiet.

## Color behavior

Не использовать decorative palette. Цвет — преимущественно semantic:

- primary action: фирменный зелёный UI Kit;
- danger/warning/info — только по смыслу;
- status chips — мягкие tinted backgrounds;
- secondary surfaces — neutral gray;
- borders — тонкие neutral tokens.

В production-коде использовать только реальные UI Kit / theme tokens. HTML reference может имитировать их локальными CSS variables, но не является источником production token names.

## Typography

- Заголовки страницы/объекта — сильные, но не oversized.
- Body и metadata компактные.
- Technical IDs, dates, compact labels могут использовать code/secondary styling.
- Иерархия строится weight + spacing, а не постоянным увеличением font-size.

## Controls

- Quick filters — chips, компактная горизонтальная группа.
- Search — tertiary icon trigger → раскрываемое full-width field.
- Filter — tertiary button с icon + label; active filters обозначаются компактным indicator.
- Primary action заметен, но не заполняет экран цветом.

## Product signature

Чтобы reference воспринимался как NORM, должны одновременно присутствовать:

1. характерная светлая sidebar/navigation shell;
2. просторный registry workspace;
3. компактные chips и тихие controls;
4. плотные bordered entity cards;
5. bottom floating create/chat surface там, где это уместно для NORM;
6. крупная 1320 Object Modal;
7. узкая secondary action/meta rail с блоками radius 16.

## Anti-patterns

- generic dashboard с десятком разноцветных KPI cards;
- glassmorphism / gradients ради декора;
- огромные hero-заголовки;
- тёмные массивные borders;
- одинаковая плотность страницы, карточки и Modal;
- Footer actions в Object View;
- произвольная правая панель, не связанная с metadata/actions объекта.
