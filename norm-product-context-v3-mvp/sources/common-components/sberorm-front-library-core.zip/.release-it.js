const version = '${version}';
const packageName = process.env.npm_package_name;

module.exports = {
  npm: {
    publish: false,
  },
  git: {
    tag: false,
    tagName: `${packageName}-v${version}`,
    commitsPath: '.',
    commitMessage: `feat(${packageName}): released version v${version}`,
    pushArgs: ['--follow-tags', '--force'],
    requireUpstream: false,
    requireCleanWorkingDir: false,
  },
};
