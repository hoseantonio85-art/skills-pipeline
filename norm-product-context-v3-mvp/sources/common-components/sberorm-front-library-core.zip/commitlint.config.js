module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'header-max-length': [2, 'always', 150],
    'body-max-line-length': [0],
    'footer-max-line-length': [0],
    'subject-case': [
      0,
      'never',
      ['upper-case', 'sentence-case', 'start-case', 'pascal-case'],
    ],
    'subject-empty': [2, 'never'],
    'type-case': [2, 'always', 'lower-case'],
    'type-empty': [2, 'never'],
    'type-enum': [
      2,
      'always',
      [
        'feat',
        'wip',
        'fix',
        'merge',
        'docs',
        'test',
        'refactor',
        'build',
        'chore',
      ],
    ],
  },
};
