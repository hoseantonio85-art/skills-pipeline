# Changelog

## 0.245.0 (2026-06-04)

## 0.244.0 (2026-06-02)

## 0.243.0 (2026-06-01)

## 0.242.0 (2026-06-01)

## 0.241.0 (2026-05-29)

## 0.240.0 (2026-05-20)

## 0.239.0 (2026-05-06)

## 0.238.0 (2026-04-22)

## 0.237.0 (2026-04-22)

## 0.236.0 (2026-04-15)

## 0.235.0 (2026-04-14)

## 0.234.0 (2026-04-13)

## 0.233.0 (2026-04-07)

## 0.232.0 (2026-04-06)

## 0.231.0 (2026-04-03)

## 0.230.0 (2026-04-03)

## 0.229.0 (2026-04-03)

## 0.228.0 (2026-03-26)

## 0.227.0 (2026-03-26)

## 0.226.0 (2026-03-26)

* Pull request #462: Feature/GMRT-131/npm package type ([72d36de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/72d36de)), closes [#462](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/462)

## 0.225.0 (2026-03-25)

## 0.224.0 (2026-03-25)

## 0.223.0 (2026-03-25)

* Pull request #461: feat: [GMRT-131] New npm package ([c962b19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c962b19)), closes [#461](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/461)

## 0.222.0 (2026-03-25)

## 0.221.0 (2026-03-23)

## 0.220.0 (2026-03-03)

## 0.219.0 (2026-02-25)

## 0.218.0 (2026-02-25)

## 0.217.0 (2026-02-24)

## 0.216.0 (2026-02-24)

## 0.215.0 (2026-02-24)

## 0.214.0 (2026-02-19)

## 0.213.0 (2026-02-17)

## 0.212.0 (2026-02-16)

## 0.211.0 (2026-02-16)

## 0.210.0 (2026-02-12)

## 0.209.0 (2026-02-11)

## 0.208.0 (2026-02-11)

## 0.207.0 (2026-02-10)

## 0.206.0 (2026-02-10)

## 0.205.0 (2026-02-10)

## 0.204.0 (2026-02-09)

## 0.203.0 (2026-02-09)

## 0.202.0 (2026-02-05)

## 0.201.0 (2026-02-03)

## 0.200.0 (2026-02-03)

## 0.199.0 (2026-02-02)

## 0.198.0 (2026-01-28)

## 0.197.0 (2026-01-26)

* Pull request #429: Feature/GMRT-1123 remove Loader ([b866466](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b866466)), closes [#429](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/429)

## 0.196.0 (2026-01-23)

## 0.195.0 (2026-01-19)

## 0.194.0 (2026-01-16)

## 0.193.0 (2026-01-12)

## 0.192.0 (2025-12-17)

## 0.191.0 (2025-12-16)

## 0.190.0 (2025-12-15)

## 0.189.0 (2025-12-11)

## 0.188.0 (2025-12-11)

## 0.187.0 (2025-12-10)

## 0.186.0 (2025-12-08)

## 0.185.0 (2025-12-01)

## 0.184.0 (2025-11-28)

## 0.183.0 (2025-11-28)

## 0.182.0 (2025-11-12)

## 0.181.0 (2025-10-29)

## 0.180.0 (2025-10-29)

## 0.179.0 (2025-10-27)

## 0.178.0 (2025-10-27)

## 0.177.0 (2025-10-24)

## 0.176.0 (2025-10-22)

## 0.175.0 (2025-10-22)

## 0.174.0 (2025-10-22)

## 0.173.0 (2025-10-22)

## 0.172.0 (2025-10-21)

## 0.171.0 (2025-10-21)

## 0.170.0 (2025-10-21)

## 0.169.0 (2025-10-20)

## 0.168.0 (2025-10-17)

## 0.167.0 (2025-10-16)

## 0.166.0 (2025-10-15)

## 0.165.0 (2025-10-14)

## 0.164.0 (2025-10-13)

## 0.163.0 (2025-10-13)

## 0.162.0 (2025-10-10)

## 0.161.0 (2025-10-08)

## 0.160.0 (2025-10-08)

## 0.159.0 (2025-10-02)

## 0.158.0 (2025-10-01)

## 0.157.0 (2025-09-23)

## 0.156.0 (2025-09-18)

## 0.155.0 (2025-09-17)

## 0.154.0 (2025-09-17)

## 0.153.0 (2025-09-15)

## 0.152.0 (2025-09-12)

## 0.151.0 (2025-09-12)

## 0.150.0 (2025-09-11)

## 0.149.0 (2025-09-09)

## 0.148.0 (2025-09-09)

## 0.147.0 (2025-09-03)

## 0.146.0 (2025-09-03)

## 0.145.0 (2025-09-02)

## 0.144.0 (2025-08-26)

## 0.143.0 (2025-08-25)

## 0.142.0 (2025-08-21)

## 0.141.0 (2025-08-20)

## 0.140.0 (2025-08-19)

## 0.139.0 (2025-08-19)

## 0.138.0 (2025-08-18)

## 0.137.0 (2025-08-18)

## 0.136.0 (2025-08-18)

## 0.135.0 (2025-08-18)

## 0.134.0 (2025-08-13)

## 0.133.0 (2025-08-12)

## 0.132.0 (2025-08-12)

* feat: [RSCLD-770] Update biome packages ([21f82e1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/21f82e1))

## 0.131.0 (2025-08-08)

## 0.130.0 (2025-08-05)

## 0.129.0 (2025-08-01)

* Pull request #375: Feature/RSCLD-555 CurrencyRange ([88bc9fe](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/88bc9fe)), closes [#375](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/375)

## 0.128.0 (2025-07-24)

## 0.127.0 (2025-07-23)

* Pull request #374: Feature/RSCLD-739 RadioChips ([2776dfb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2776dfb)), closes [#374](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/374)

## 0.126.0 (2025-07-22)

## 0.125.0 (2025-07-21)

## 0.124.0 (2025-07-21)

## 0.123.0 (2025-07-18)

* Pull request #373: Feature/RSCLD-725 InputListField ([12e5fe7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/12e5fe7)), closes [#373](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/373)

## 0.122.0 (2025-07-17)

* feat: [RSCLD-725] Add InputListField ([bdde4f8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bdde4f8))

## 0.121.0 (2025-07-17)

## 0.120.0 (2025-07-17)

* Pull request #372: Feature/RSCLD-725 InputListField ([6772c36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6772c36)), closes [#372](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/372)

## 0.119.0 (2025-07-16)

## 0.118.0 (2025-07-15)

## 0.117.0 (2025-07-14)

* Pull request #369: Feature/RSCLD-590 DatePicker ([ab1ab96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ab1ab96)), closes [#369](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/369)

## 0.116.0 (2025-07-07)

* Pull request #367: Feature/RSCLD-590 DatePicker ([1e7f42a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1e7f42a)), closes [#367](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/367)

## 0.115.0 (2025-07-03)

## 0.114.0 (2025-07-02)

## 0.113.0 (2025-07-02)

## 0.112.0 (2025-06-30)

## 0.111.0 (2025-06-26)

## 0.110.0 (2025-06-26)

## 0.109.0 (2025-06-26)

## 0.108.0 (2025-06-24)

## 0.107.0 (2025-06-23)

## 0.106.0 (2025-06-23)

## 0.105.0 (2025-06-23)

* Pull request #364: Feature/RSCLD-552 fields ([9b7325c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9b7325c)), closes [#364](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/364)

## 0.104.0 (2025-06-23)

## 0.103.0 (2025-06-20)

* feat: [RSCLD-568] Fix tooltip arrow ([73fbd08](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/73fbd08))

## 0.102.0 (2025-06-19)

## 0.101.0 (2025-06-19)

## 0.100.0 (2025-06-19)

## 0.99.0 (2025-06-18)

## 0.98.0 (2025-06-18)

## 0.97.0 (2025-06-18)

## 0.96.0 (2025-06-17)

## 0.95.0 (2025-06-17)

## 0.94.0 (2025-06-11)

## 0.93.0 (2025-06-10)

## 0.92.0 (2025-06-10)

## 0.91.0 (2025-06-10)

## 0.90.0 (2025-06-09)

## 0.89.0 (2025-06-09)

## 0.88.0 (2025-06-06)

## 0.87.0 (2025-06-06)

## 0.86.0 (2025-06-05)

## 0.85.0 (2025-06-02)

* feat: [RSCLD-446] Up versions ([b9a9df0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b9a9df0))
* Pull request #354: Feature/RSCLD-446 comments ([206f892](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/206f892)), closes [#354](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/354)

## 0.81.0 (2025-05-30)

* Pull request #353: Feature/RSCLD-446_comments ([8daff73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8daff73)), closes [#353](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/353)

## 0.80.0 (2025-05-30)

## 0.79.0 (2025-05-23)

## 0.78.0 (2025-05-22)

## 0.77.0 (2025-05-14)

## 0.76.0 (2025-05-14)

## 0.75.0 (2025-05-14)

## 0.74.0 (2025-04-29)

* Pull request #346: Feature/RSCLD-359_Notice ([f5f4445](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f5f4445)), closes [#346](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/346)

## 0.73.0 (2025-04-29)

* feat: [RSCLD-359] Add Notice ([a139c4a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a139c4a))

## 0.72.0 (2025-04-29)

## 0.71.0 (2025-04-28)

## 0.70.0 (2025-04-28)

## 0.69.0 (2025-04-28)

## 0.68.0 (2025-04-25)

## 0.67.0 (2025-04-23)

## 0.66.0 (2025-04-22)

* Pull request #341: Feature/RSCLD-361_TitleBlock ([2ddd5fd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2ddd5fd)), closes [#341](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/341)

## 0.65.0 (2025-04-22)

## 0.64.0 (2025-04-21)

## 0.63.0 (2025-04-21)

## 0.62.0 (2025-04-21)

## 0.61.0 (2025-04-18)

## 0.60.0 (2025-04-17)

## 0.59.0 (2025-04-17)

* Pull request #336: feat: [RSCLD-344] Support tooltips in fields ([0b8e380](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b8e380)), closes [#336](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/336)

## 0.58.0 (2025-04-16)

## 0.57.0 (2025-04-11)

## 0.56.0 (2025-04-11)

* Pull request #332: feat: [RSCLD-222] Popover, Tooltip ([c6aa509](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c6aa509)), closes [#332](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/332)

## 0.55.0 (2025-04-09)

* Pull request #329: feat: [RSCLD-310] New components: badge, level ([528dff0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/528dff0)), closes [#329](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/329)

## 0.54.0 (2025-04-03)

## 0.53.0 (2025-04-02)

* Pull request #319: Feature/RSCLD-192_Alert ([4865c5f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4865c5f)), closes [#319](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/319)

## 0.52.0 (2025-03-26)

## 0.51.0 (2025-03-26)

## 0.50.0 (2025-03-21)

## 0.49.0 (2025-03-21)

## 0.48.0 (2025-03-18)

## 0.47.0 (2025-03-13)

## 0.46.0 (2025-03-13)

## 0.45.0 (2025-03-11)

## 0.44.0 (2025-03-10)

## 0.43.0 (2025-03-10)

## 0.42.0 (2025-03-10)

* Pull request #309: Feature/RSCLD-177_Input ([1dc2f68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1dc2f68)), closes [#309](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/309)

## 0.41.0 (2025-03-06)

* Pull request #302: Feature/RSCLD-112_Button ([d0d4a66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d0d4a66)), closes [#302](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/302)

## 0.40.0 (2025-03-03)

## 0.39.0 (2025-03-03)

## 0.38.0 (2025-02-28)

* Pull request #306: Bugfix/RSCLD-131_Combobox ([8cbc5eb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8cbc5eb)), closes [#306](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/306)

## 0.34.0 (2025-02-28)

## 0.33.0 (2025-02-26)

## 0.32.0 (2025-02-26)

## 0.31.0 (2025-02-24)

## 0.30.0 (2025-02-24)

## 0.29.0 (2025-02-24)

## 0.28.0 (2025-02-24)

## 0.27.0 (2025-02-21)

## 0.26.0 (2025-02-21)

* Pull request #293: Feature/GMRT-76 export fields ([1d543f4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1d543f4)), closes [#293](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/293)

## 0.25.0 (2025-02-19)

* Pull request #292: Feature/RSCLD-88_popover ([b344047](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b344047)), closes [#292](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/292)

## 0.24.0 (2025-02-19)

## 0.23.0 (2025-02-19)

## 0.22.0 (2025-02-19)

## 0.21.0 (2025-02-18)

## 0.20.0 (2025-02-18)

## 0.19.0 (2025-02-18)

## 0.18.0 (2025-02-18)

## 0.17.0 (2025-02-18)

* Pull request #289: Bugfix/GMRT-78 hook use markdown ([0b7143d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b7143d)), closes [#289](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/289)

## 0.16.0 (2025-02-18)

## 0.15.0 (2025-02-18)

## 0.14.0 (2025-02-18)

* Pull request #286: Feature/GMRT-78 hook use markdown ([74a7223](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/74a7223)), closes [#286](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/286)

## 0.13.0 (2025-02-17)

## 0.12.0 (2025-02-17)

## 0.11.0 (2025-02-14)

## 0.10.0 (2025-02-14)

* Pull request #283: Feature/RSCLD-81_colors ([a326985](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a326985)), closes [#283](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/283)

## 0.9.0 (2025-02-13)

## 0.8.0 (2025-02-13)

## 0.7.0 (2025-02-13)

## 0.6.0 (2025-02-12)

* Pull request #277: Feature/SBRORMCLD-1209 set NotificationContainer to errorBoundary ([d97766e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d97766e)), closes [#277](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/277)

## 0.5.0 (2025-02-11)

## 0.4.0 (2025-02-11)

## [0.3.201](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.200...@sber-orm/custom-system-v0.3.201) (2025-02-11)

## [0.3.200](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.199...@sber-orm/custom-system-v0.3.200) (2025-02-11)

## [0.3.199](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.198...@sber-orm/custom-system-v0.3.199) (2025-02-11)

## [0.3.198](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.197...@sber-orm/custom-system-v0.3.198) (2025-02-10)

## [0.3.197](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.196...@sber-orm/custom-system-v0.3.197) (2025-02-07)

## [0.3.196](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.195...@sber-orm/custom-system-v0.3.196) (2025-02-07)

## [0.3.195](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.194...@sber-orm/custom-system-v0.3.195) (2025-02-07)

## [0.3.194](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.193...@sber-orm/custom-system-v0.3.194) (2025-02-07)

## [0.3.193](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.192...@sber-orm/custom-system-v0.3.193) (2025-02-07)

## [0.3.192](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.191...@sber-orm/custom-system-v0.3.192) (2025-02-07)

## [0.3.191](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.190...@sber-orm/custom-system-v0.3.191) (2025-02-06)

## [0.3.190](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.189...@sber-orm/custom-system-v0.3.190) (2025-02-06)

## [0.3.189](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.188...@sber-orm/custom-system-v0.3.189) (2025-02-05)

## [0.3.188](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.187...@sber-orm/custom-system-v0.3.188) (2025-02-05)

## [0.3.187](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.186...@sber-orm/custom-system-v0.3.187) (2025-02-04)

## [0.3.186](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.185...@sber-orm/custom-system-v0.3.186) (2025-02-03)

## [0.3.185](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.184...@sber-orm/custom-system-v0.3.185) (2025-02-03)

## [0.3.184](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.183...@sber-orm/custom-system-v0.3.184) (2025-02-03)

## [0.3.183](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.182...@sber-orm/custom-system-v0.3.183) (2025-01-31)

## [0.3.182](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.181...@sber-orm/custom-system-v0.3.182) (2025-01-31)

## [0.3.181](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.180...@sber-orm/custom-system-v0.3.181) (2025-01-31)

## [0.3.180](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.179...@sber-orm/custom-system-v0.3.180) (2025-01-30)

## [0.3.179](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.178...@sber-orm/custom-system-v0.3.179) (2025-01-30)

## [0.3.178](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.177...@sber-orm/custom-system-v0.3.178) (2025-01-30)

## [0.3.177](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.176...@sber-orm/custom-system-v0.3.177) (2025-01-29)

## [0.3.176](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.175...@sber-orm/custom-system-v0.3.176) (2025-01-29)

## [0.3.175](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.174...@sber-orm/custom-system-v0.3.175) (2025-01-29)

## [0.3.174](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.173...@sber-orm/custom-system-v0.3.174) (2025-01-29)

## [0.3.173](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.172...@sber-orm/custom-system-v0.3.173) (2025-01-29)

## [0.3.172](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.171...@sber-orm/custom-system-v0.3.172) (2025-01-28)

## [0.3.171](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.170...@sber-orm/custom-system-v0.3.171) (2025-01-24)

## [0.3.170](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.169...@sber-orm/custom-system-v0.3.170) (2025-01-23)

## [0.3.169](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.168...@sber-orm/custom-system-v0.3.169) (2025-01-21)

## [0.3.168](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.167...@sber-orm/custom-system-v0.3.168) (2025-01-17)

## [0.3.167](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.166...@sber-orm/custom-system-v0.3.167) (2025-01-16)

## [0.3.166](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.165...@sber-orm/custom-system-v0.3.166) (2025-01-15)

## [0.3.165](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.164...@sber-orm/custom-system-v0.3.165) (2025-01-15)

## [0.3.164](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.163...@sber-orm/custom-system-v0.3.164) (2025-01-15)

## [0.3.163](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.162...@sber-orm/custom-system-v0.3.163) (2025-01-14)

## [0.3.162](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.161...@sber-orm/custom-system-v0.3.162) (2025-01-14)

## [0.3.161](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.160...@sber-orm/custom-system-v0.3.161) (2025-01-13)

## [0.3.160](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.159...@sber-orm/custom-system-v0.3.160) (2025-01-13)

## [0.3.159](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.158...@sber-orm/custom-system-v0.3.159) (2025-01-10)

## [0.3.158](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.157...@sber-orm/custom-system-v0.3.158) (2024-12-20)

## [0.3.157](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.156...@sber-orm/custom-system-v0.3.157) (2024-12-20)

## [0.3.156](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.155...@sber-orm/custom-system-v0.3.156) (2024-12-20)

## [0.3.155](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.154...@sber-orm/custom-system-v0.3.155) (2024-12-19)

## [0.3.154](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.153...@sber-orm/custom-system-v0.3.154) (2024-12-18)

## [0.3.153](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.152...@sber-orm/custom-system-v0.3.153) (2024-12-18)

## [0.3.152](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.151...@sber-orm/custom-system-v0.3.152) (2024-12-17)

## [0.3.151](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.150...@sber-orm/custom-system-v0.3.151) (2024-12-16)

## [0.3.150](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.149...@sber-orm/custom-system-v0.3.150) (2024-12-16)

## [0.3.149](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.148...@sber-orm/custom-system-v0.3.149) (2024-12-16)

## [0.3.148](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.147...@sber-orm/custom-system-v0.3.148) (2024-12-13)

## [0.3.147](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.146...@sber-orm/custom-system-v0.3.147) (2024-12-13)

## [0.3.146](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.145...@sber-orm/custom-system-v0.3.146) (2024-12-13)

## [0.3.145](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.144...@sber-orm/custom-system-v0.3.145) (2024-12-10)

## [0.3.144](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.143...@sber-orm/custom-system-v0.3.144) (2024-12-09)

## [0.3.143](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.142...@sber-orm/custom-system-v0.3.143) (2024-12-06)

## [0.3.142](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.141...@sber-orm/custom-system-v0.3.142) (2024-12-05)

## [0.3.141](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.140...@sber-orm/custom-system-v0.3.141) (2024-12-04)

## [0.3.140](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.139...@sber-orm/custom-system-v0.3.140) (2024-12-04)

## [0.3.139](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.138...@sber-orm/custom-system-v0.3.139) (2024-12-03)

## [0.3.138](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.137...@sber-orm/custom-system-v0.3.138) (2024-12-03)

## [0.3.137](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.136...@sber-orm/custom-system-v0.3.137) (2024-12-03)

## [0.3.136](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.135...@sber-orm/custom-system-v0.3.136) (2024-12-03)

## [0.3.135](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.134...@sber-orm/custom-system-v0.3.135) (2024-12-03)

## [0.3.134](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.133...@sber-orm/custom-system-v0.3.134) (2024-12-02)

## [0.3.133](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.132...@sber-orm/custom-system-v0.3.133) (2024-12-02)

## [0.3.132](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.131...@sber-orm/custom-system-v0.3.132) (2024-12-02)

## [0.3.131](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.130...@sber-orm/custom-system-v0.3.131) (2024-11-28)

## [0.3.130](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.129...@sber-orm/custom-system-v0.3.130) (2024-11-28)

## [0.3.129](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.128...@sber-orm/custom-system-v0.3.129) (2024-11-27)

## [0.3.128](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.127...@sber-orm/custom-system-v0.3.128) (2024-11-27)

## [0.3.127](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.126...@sber-orm/custom-system-v0.3.127) (2024-11-26)

## [0.3.126](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.125...@sber-orm/custom-system-v0.3.126) (2024-11-25)

## [0.3.125](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.124...@sber-orm/custom-system-v0.3.125) (2024-11-20)

## [0.3.124](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.123...@sber-orm/custom-system-v0.3.124) (2024-11-19)

## [0.3.123](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.122...@sber-orm/custom-system-v0.3.123) (2024-11-18)

## [0.3.122](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.121...@sber-orm/custom-system-v0.3.122) (2024-11-14)

## [0.3.121](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.120...@sber-orm/custom-system-v0.3.121) (2024-11-14)

## [0.3.120](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.119...@sber-orm/custom-system-v0.3.120) (2024-11-12)

## [0.3.119](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.118...@sber-orm/custom-system-v0.3.119) (2024-11-12)

## [0.3.118](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.117...@sber-orm/custom-system-v0.3.118) (2024-11-12)

## [0.3.117](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.116...@sber-orm/custom-system-v0.3.117) (2024-11-08)

## [0.3.116](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.115...@sber-orm/custom-system-v0.3.116) (2024-11-07)

## [0.3.115](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.114...@sber-orm/custom-system-v0.3.115) (2024-11-07)

## [0.3.114](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.113...@sber-orm/custom-system-v0.3.114) (2024-11-07)

## [0.3.113](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.112...@sber-orm/custom-system-v0.3.113) (2024-11-07)

## [0.3.112](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.111...@sber-orm/custom-system-v0.3.112) (2024-11-06)

## [0.3.111](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.110...@sber-orm/custom-system-v0.3.111) (2024-11-05)

## [0.3.110](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.109...@sber-orm/custom-system-v0.3.110) (2024-11-05)

## [0.3.109](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.108...@sber-orm/custom-system-v0.3.109) (2024-11-02)

## [0.3.108](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.107...@sber-orm/custom-system-v0.3.108) (2024-11-02)

## [0.3.107](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.106...@sber-orm/custom-system-v0.3.107) (2024-11-01)

## [0.3.106](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.105...@sber-orm/custom-system-v0.3.106) (2024-11-01)

## [0.3.105](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.104...@sber-orm/custom-system-v0.3.105) (2024-10-31)

## [0.3.104](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.103...@sber-orm/custom-system-v0.3.104) (2024-10-29)

## [0.3.103](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.102...@sber-orm/custom-system-v0.3.103) (2024-10-28)

## [0.3.102](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.101...@sber-orm/custom-system-v0.3.102) (2024-10-28)

## [0.3.101](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.100...@sber-orm/custom-system-v0.3.101) (2024-10-28)

## [0.3.100](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.99...@sber-orm/custom-system-v0.3.100) (2024-10-28)

## [0.3.99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.98...@sber-orm/custom-system-v0.3.99) (2024-10-25)

## [0.3.98](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.97...@sber-orm/custom-system-v0.3.98) (2024-10-25)

## [0.3.97](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.96...@sber-orm/custom-system-v0.3.97) (2024-10-25)

## [0.3.96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.95...@sber-orm/custom-system-v0.3.96) (2024-10-24)

## [0.3.95](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.94...@sber-orm/custom-system-v0.3.95) (2024-10-24)

## [0.3.94](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.93...@sber-orm/custom-system-v0.3.94) (2024-10-24)

## [0.3.93](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.92...@sber-orm/custom-system-v0.3.93) (2024-10-24)

## [0.3.92](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.91...@sber-orm/custom-system-v0.3.92) (2024-10-24)

## [0.3.91](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.90...@sber-orm/custom-system-v0.3.91) (2024-10-24)

## [0.3.90](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.89...@sber-orm/custom-system-v0.3.90) (2024-10-23)

## [0.3.89](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.88...@sber-orm/custom-system-v0.3.89) (2024-10-23)

## [0.3.88](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.87...@sber-orm/custom-system-v0.3.88) (2024-10-23)

## [0.3.87](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.86...@sber-orm/custom-system-v0.3.87) (2024-10-22)

## [0.3.86](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.85...@sber-orm/custom-system-v0.3.86) (2024-10-21)

## [0.3.85](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.84...@sber-orm/custom-system-v0.3.85) (2024-10-21)

## [0.3.84](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.83...@sber-orm/custom-system-v0.3.84) (2024-10-21)

## [0.3.83](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.82...@sber-orm/custom-system-v0.3.83) (2024-10-21)

## [0.3.82](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.81...@sber-orm/custom-system-v0.3.82) (2024-10-21)

## [0.3.81](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.80...@sber-orm/custom-system-v0.3.81) (2024-10-18)

## [0.3.80](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.79...@sber-orm/custom-system-v0.3.80) (2024-10-18)

## [0.3.79](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.78...@sber-orm/custom-system-v0.3.79) (2024-10-17)

## [0.3.78](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.77...@sber-orm/custom-system-v0.3.78) (2024-10-17)

## [0.3.77](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.76...@sber-orm/custom-system-v0.3.77) (2024-10-16)

## [0.3.76](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.75...@sber-orm/custom-system-v0.3.76) (2024-10-16)

## [0.3.75](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.74...@sber-orm/custom-system-v0.3.75) (2024-10-15)

## [0.3.74](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.73...@sber-orm/custom-system-v0.3.74) (2024-10-14)

## [0.3.73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.72...@sber-orm/custom-system-v0.3.73) (2024-10-14)

## [0.3.72](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.71...@sber-orm/custom-system-v0.3.72) (2024-10-14)

## [0.3.71](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.70...@sber-orm/custom-system-v0.3.71) (2024-10-14)

## [0.3.70](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.69...@sber-orm/custom-system-v0.3.70) (2024-10-14)

## [0.3.69](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.68...@sber-orm/custom-system-v0.3.69) (2024-10-09)

## [0.3.68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.67...@sber-orm/custom-system-v0.3.68) (2024-10-08)

## [0.3.67](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.66...@sber-orm/custom-system-v0.3.67) (2024-10-03)

## [0.3.66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.65...@sber-orm/custom-system-v0.3.66) (2024-10-02)

## [0.3.65](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.64...@sber-orm/custom-system-v0.3.65) (2024-09-30)

## [0.3.64](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.63...@sber-orm/custom-system-v0.3.64) (2024-09-30)

## [0.3.63](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.62...@sber-orm/custom-system-v0.3.63) (2024-09-27)

## [0.3.62](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.61...@sber-orm/custom-system-v0.3.62) (2024-09-27)

## [0.3.61](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.60...@sber-orm/custom-system-v0.3.61) (2024-09-27)

## [0.3.60](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.59...@sber-orm/custom-system-v0.3.60) (2024-09-27)

## [0.3.59](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.58...@sber-orm/custom-system-v0.3.59) (2024-09-27)

## [0.3.58](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.57...@sber-orm/custom-system-v0.3.58) (2024-09-27)

## [0.3.57](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.56...@sber-orm/custom-system-v0.3.57) (2024-09-26)

## [0.3.56](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.55...@sber-orm/custom-system-v0.3.56) (2024-09-26)

## [0.3.55](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.54...@sber-orm/custom-system-v0.3.55) (2024-09-25)

## [0.3.54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.53...@sber-orm/custom-system-v0.3.54) (2024-09-24)

## [0.3.53](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.52...@sber-orm/custom-system-v0.3.53) (2024-09-23)

## [0.3.52](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.51...@sber-orm/custom-system-v0.3.52) (2024-09-23)

## [0.3.51](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.50...@sber-orm/custom-system-v0.3.51) (2024-09-16)

## [0.3.50](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.49...@sber-orm/custom-system-v0.3.50) (2024-09-09)

## [0.3.49](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.48...@sber-orm/custom-system-v0.3.49) (2024-09-09)

## [0.3.48](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.47...@sber-orm/custom-system-v0.3.48) (2024-09-06)

## [0.3.47](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.46...@sber-orm/custom-system-v0.3.47) (2024-09-06)

## [0.3.46](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.45...@sber-orm/custom-system-v0.3.46) (2024-09-05)

## [0.3.45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.44...@sber-orm/custom-system-v0.3.45) (2024-09-04)

## [0.3.44](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.43...@sber-orm/custom-system-v0.3.44) (2024-09-04)

## [0.3.43](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.42...@sber-orm/custom-system-v0.3.43) (2024-09-03)

## [0.3.42](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.41...@sber-orm/custom-system-v0.3.42) (2024-09-03)

## [0.3.41](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.40...@sber-orm/custom-system-v0.3.41) (2024-09-03)

## [0.3.40](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.39...@sber-orm/custom-system-v0.3.40) (2024-09-02)

## [0.3.39](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.38...@sber-orm/custom-system-v0.3.39) (2024-09-02)

## [0.3.38](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.37...@sber-orm/custom-system-v0.3.38) (2024-08-30)

## [0.3.37](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.36...@sber-orm/custom-system-v0.3.37) (2024-08-30)

## [0.3.36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.35...@sber-orm/custom-system-v0.3.36) (2024-08-30)

## [0.3.35](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.32...@sber-orm/custom-system-v0.3.35) (2024-08-30)

## [0.3.34](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.33...@sber-orm/custom-system-v0.3.34) (2024-08-29)

## [0.3.33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.32...@sber-orm/custom-system-v0.3.33) (2024-08-29)

## [0.3.32](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.31...@sber-orm/custom-system-v0.3.32) (2024-08-29)

## [0.3.31](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.30...@sber-orm/custom-system-v0.3.31) (2024-08-28)

## [0.3.30](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.29...@sber-orm/custom-system-v0.3.30) (2024-08-26)

## [0.3.29](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.28...@sber-orm/custom-system-v0.3.29) (2024-08-26)

## [0.3.28](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.27...@sber-orm/custom-system-v0.3.28) (2024-08-23)

## [0.3.27](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.26...@sber-orm/custom-system-v0.3.27) (2024-08-23)

## [0.3.26](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.25...@sber-orm/custom-system-v0.3.26) (2024-08-22)

## [0.3.25](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.24...@sber-orm/custom-system-v0.3.25) (2024-08-22)

## [0.3.24](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.23...@sber-orm/custom-system-v0.3.24) (2024-08-22)

## [0.3.23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.22...@sber-orm/custom-system-v0.3.23) (2024-08-21)

## [0.3.22](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.21...@sber-orm/custom-system-v0.3.22) (2024-08-21)

## [0.3.21](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.20...@sber-orm/custom-system-v0.3.21) (2024-08-21)

## [0.3.20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.19...@sber-orm/custom-system-v0.3.20) (2024-08-21)

## [0.3.19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.18...@sber-orm/custom-system-v0.3.19) (2024-08-21)

## [0.3.18](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.17...@sber-orm/custom-system-v0.3.18) (2024-08-21)

## [0.3.17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.16...@sber-orm/custom-system-v0.3.17) (2024-08-20)

## [0.3.16](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.15...@sber-orm/custom-system-v0.3.16) (2024-08-19)

## [0.3.15](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.14...@sber-orm/custom-system-v0.3.15) (2024-08-16)

## [0.3.14](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.13...@sber-orm/custom-system-v0.3.14) (2024-08-16)

## [0.3.13](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.12...@sber-orm/custom-system-v0.3.13) (2024-08-09)

## [0.3.12](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.11...@sber-orm/custom-system-v0.3.12) (2024-08-09)

## [0.3.11](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.10...@sber-orm/custom-system-v0.3.11) (2024-08-09)

## [0.3.10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.9...@sber-orm/custom-system-v0.3.10) (2024-08-08)

## [0.3.9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.8...@sber-orm/custom-system-v0.3.9) (2024-08-08)

## [0.3.8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.7...@sber-orm/custom-system-v0.3.8) (2024-08-07)

## [0.3.7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.6...@sber-orm/custom-system-v0.3.7) (2024-08-07)

## [0.3.6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.5...@sber-orm/custom-system-v0.3.6) (2024-08-07)

## [0.3.5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.4...@sber-orm/custom-system-v0.3.5) (2024-08-07)

## [0.3.4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.2...@sber-orm/custom-system-v0.3.4) (2024-08-06)

## [0.3.3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.2...@sber-orm/custom-system-v0.3.3) (2024-08-05)

## [0.3.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.1...@sber-orm/custom-system-v0.3.2) (2024-05-30)

## [0.3.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/custom-system-v0.3.0...@sber-orm/custom-system-v0.3.1) (2024-05-29)

## 0.3.0 (2024-04-23)

### Features

- [ORMCORE-163] Add components/styles package ([19f149f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/19f149f9a6215e6cc642c687f3a70c75ceec0e32))
- [ORMCORE-163] Add custom-system package ([a899d1e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/a899d1e7bd536d46c30aa5e02c307d73c4ba23f2))
- [ORMCORE-237] Add eslint, tsconfig, prettier packages ([fc41d54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/fc41d545f3e1e94e983ce196731ac578ef4d2d6c))
