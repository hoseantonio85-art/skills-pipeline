const mediaSeparator = 0.2;
const desktop = 1440;
const desktopWide = 1920;
const laptop = 1024;
const laptopMedium = 1280;

export const Media = {
  desktop,

  desktopMedium: 1728,
  desktopMediumMax: desktopWide - mediaSeparator,
  desktopWide,
  laptop,

  laptopMax: desktop - mediaSeparator,
  laptopMedium,
  laptopSmallMax: laptopMedium - mediaSeparator,
  laptopWide: 1366,

  mediaSeparator,
  tabletMax: laptop - mediaSeparator,
};
