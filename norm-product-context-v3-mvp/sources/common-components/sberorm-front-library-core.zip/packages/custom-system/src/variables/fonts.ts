export const Font = {
  SBSansText: 'SBSansText',
};
