/* eslint-disable perfectionist/sort-objects */
export const TitleSize = {
  H900: 'H900',
  H800: 'H800',
  H700: 'H700',
  H600: 'H600',
  H500: 'H500',
  H400: 'H400',
  H300: 'H300',
  H200: 'H200',
  H100: 'H100',
};

export const ComponentSize = {
  small: 'small',
  medium: 'medium',
  large: 'large',
};

/** Относительные размеры */
export type TSize = 'sm' | 'md' | 'lg';
