export const boxShadow = {
  level1:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 1px 2px rgba(36, 41, 46, 0.12)',
  level2:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 2px 4px rgba(36, 41, 46, 0.12)',
  level3:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 4px 8px rgba(36, 41, 46, 0.12)',
  level4:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 8px 16px rgba(36, 41, 46, 0.16)',
  level5:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 16px 24px rgba(36, 41, 46, 0.12)',
  level6:
    '0px 0px 1px rgba(36, 41, 46, 0.32), 0px 24px 40px rgba(36, 41, 46, 0.12)',
};
