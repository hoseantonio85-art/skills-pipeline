import { colors } from './colors';

export const uiColors = {
  borderDisabled: colors.GrayAlpha100,
  borderFocused: colors.ArcticGreen500,
  // Borders
  borderInput: colors.GrayAlpha200,
};
