/* eslint-disable perfectionist/sort-objects */
/** Вариант размеров кнопок */
export const buttonBaseSize = {
  sm: {
    'font-size': '14px',
    padding: '2px 8px',
  },
  md: {
    'font-size': '14px',
    padding: '6px 12px',
  },
  lg: {
    'font-size': '14px',
    'font-weight': '500',
    padding: '10px 12px',
  },
};
