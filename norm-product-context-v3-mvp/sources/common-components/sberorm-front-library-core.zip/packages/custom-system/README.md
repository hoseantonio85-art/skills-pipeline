# @sber-orm/custom-system

Общий конфиг с общими переменными.

## установка

`$ npm i -D @sber-orm/custom-system`

## использование

```js
import { colors } from "@sber-orm/custom-system";
import { uiColors } from "@sber-orm/custom-system";
import { Media } from "@sber-orm/custom-system";
```
