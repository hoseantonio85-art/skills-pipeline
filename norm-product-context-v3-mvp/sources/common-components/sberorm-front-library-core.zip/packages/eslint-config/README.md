# @sber-orm/eslint-config

Общий конфиг для ESLint.

## установка

`$ npm i -D @sber-orm/eslint-config`

## использование

`.eslintrc`

```json
{
  "extends": ["@sber-orm/eslint-config"],
  "parserOptions": {
    "tsconfigRootDir": "./",
    "project": "./tsconfig.json"
  },
  "ignorePatterns": ["node_modules/", "dist/", ".eslintrc", ".eslintrc.json", ".vscode", ".idea", "public", "*.config.js"]
}
```
