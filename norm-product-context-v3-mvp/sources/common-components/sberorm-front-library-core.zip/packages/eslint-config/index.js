module.exports = {
  ignorePatterns: [
    'dist',
    '.eslintrc.cjs',
    '.eslintrc.js',
    '.dev',
    'importmap.json',
    'node_modules',
  ],
  env: {
    browser: true,
    es2023: true,
    node: true,
  },
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
      modules: true,
      experimentalObjectRestSpread: true,
    },
    ecmaVersion: 2023,
    sourceType: 'module',
  },
  extends: ['plugin:@sber-orm/recommended'],
  plugins: ['@sber-orm'],
  settings: {
    react: {
      pragma: 'React',
      fragment: 'Fragment',
      version: 'detect',
    },
    'import/resolver': {
      node: {
        paths: ['src'],
        extensions: ['.js', '.jsx', '.ts', '.d.ts', '.tsx'],
        moduleDirectory: ['src', 'node_modules'],
      },
      typescript: {
        alwaysTryTypes: true,
      },
    },
  },
};
