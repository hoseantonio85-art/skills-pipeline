# @sber-orm/tsconfig-config

Общий TypeScript конфиг.

## установка

`$ npm i -D @sber-orm/tsconfig-config`

## использование

`tsconfig.json`

```json
{
  "extends": "@sber-orm/tsconfig-config",
  "compilerOptions": {
    "rootDir": "./src",
    "outDir": "./dist",
    "target": "esnext",
    "lib": ["dom", "esnext"]
  },
  "include": ["src"]
}
```
