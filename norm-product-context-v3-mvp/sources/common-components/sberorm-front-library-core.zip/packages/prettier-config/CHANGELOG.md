# Changelog

## 0.245.0 (2026-06-04)

## 0.244.0 (2026-06-02)

## 0.243.0 (2026-06-01)

## 0.242.0 (2026-06-01)

## 0.241.0 (2026-05-29)

## 0.240.0 (2026-05-20)

## 0.239.0 (2026-05-06)

## 0.238.0 (2026-04-22)

## 0.237.0 (2026-04-22)

## 0.236.0 (2026-04-15)

## 0.235.0 (2026-04-14)

## 0.234.0 (2026-04-13)

## 0.233.0 (2026-04-07)

## 0.232.0 (2026-04-06)

## 0.231.0 (2026-04-03)

## 0.230.0 (2026-04-03)

## 0.229.0 (2026-04-03)

## 0.228.0 (2026-03-26)

## 0.227.0 (2026-03-26)

## 0.226.0 (2026-03-26)

* Pull request #462: Feature/GMRT-131/npm package type ([72d36de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/72d36de)), closes [#462](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/462)

## 0.225.0 (2026-03-25)

## 0.224.0 (2026-03-25)

## 0.223.0 (2026-03-25)

* Pull request #461: feat: [GMRT-131] New npm package ([c962b19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c962b19)), closes [#461](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/461)

## 0.222.0 (2026-03-25)

## 0.221.0 (2026-03-23)

## 0.220.0 (2026-03-03)

## 0.219.0 (2026-02-25)

## 0.218.0 (2026-02-25)

## 0.217.0 (2026-02-24)

## 0.216.0 (2026-02-24)

## 0.215.0 (2026-02-24)

## 0.214.0 (2026-02-19)

## 0.213.0 (2026-02-17)

## 0.212.0 (2026-02-16)

## 0.211.0 (2026-02-16)

## 0.210.0 (2026-02-12)

## 0.209.0 (2026-02-11)

## 0.208.0 (2026-02-11)

## 0.207.0 (2026-02-10)

## 0.206.0 (2026-02-10)

## 0.205.0 (2026-02-10)

## 0.204.0 (2026-02-09)

## 0.203.0 (2026-02-09)

## 0.202.0 (2026-02-05)

## 0.201.0 (2026-02-03)

## 0.200.0 (2026-02-03)

## 0.199.0 (2026-02-02)

## 0.198.0 (2026-01-28)

## 0.197.0 (2026-01-26)

## 0.196.0 (2026-01-23)

## 0.195.0 (2026-01-19)

## 0.194.0 (2026-01-16)

## 0.193.0 (2026-01-12)

## 0.192.0 (2025-12-17)

## 0.191.0 (2025-12-16)

## 0.190.0 (2025-12-15)

## 0.189.0 (2025-12-11)

## 0.188.0 (2025-12-11)

## 0.187.0 (2025-12-10)

## 0.186.0 (2025-12-08)

## 0.185.0 (2025-12-01)

## 0.184.0 (2025-11-28)

## 0.183.0 (2025-11-28)

## 0.182.0 (2025-11-12)

## 0.181.0 (2025-10-29)

## 0.180.0 (2025-10-29)

## 0.179.0 (2025-10-27)

## 0.178.0 (2025-10-27)

## 0.177.0 (2025-10-24)

## 0.176.0 (2025-10-22)

## 0.175.0 (2025-10-22)

## 0.174.0 (2025-10-22)

## 0.173.0 (2025-10-22)

## 0.172.0 (2025-10-21)

## 0.171.0 (2025-10-21)

## 0.170.0 (2025-10-21)

## 0.169.0 (2025-10-20)

## 0.168.0 (2025-10-17)

## 0.167.0 (2025-10-16)

## 0.166.0 (2025-10-15)

## 0.165.0 (2025-10-14)

## 0.164.0 (2025-10-13)

## 0.163.0 (2025-10-13)

## 0.162.0 (2025-10-10)

## 0.161.0 (2025-10-08)

## 0.160.0 (2025-10-08)

## 0.159.0 (2025-10-02)

## 0.158.0 (2025-10-01)

## 0.157.0 (2025-09-23)

## 0.156.0 (2025-09-18)

## 0.155.0 (2025-09-17)

## 0.154.0 (2025-09-17)

## 0.153.0 (2025-09-15)

## 0.152.0 (2025-09-12)

## 0.151.0 (2025-09-12)

## 0.150.0 (2025-09-11)

## 0.149.0 (2025-09-09)

## 0.148.0 (2025-09-09)

## 0.147.0 (2025-09-03)

## 0.146.0 (2025-09-03)

## 0.145.0 (2025-09-02)

## 0.144.0 (2025-08-26)

## 0.143.0 (2025-08-25)

## 0.142.0 (2025-08-21)

## 0.141.0 (2025-08-20)

## 0.140.0 (2025-08-19)

## 0.139.0 (2025-08-19)

## 0.138.0 (2025-08-18)

## 0.137.0 (2025-08-18)

## 0.136.0 (2025-08-18)

## 0.135.0 (2025-08-18)

## 0.134.0 (2025-08-13)

## 0.133.0 (2025-08-12)

## 0.132.0 (2025-08-12)

## 0.131.0 (2025-08-08)

## 0.130.0 (2025-08-05)

## 0.129.0 (2025-08-01)

* Pull request #375: Feature/RSCLD-555 CurrencyRange ([88bc9fe](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/88bc9fe)), closes [#375](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/375)

## 0.128.0 (2025-07-24)

## 0.127.0 (2025-07-23)

* Pull request #374: Feature/RSCLD-739 RadioChips ([2776dfb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2776dfb)), closes [#374](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/374)

## 0.126.0 (2025-07-22)

## 0.125.0 (2025-07-21)

## 0.124.0 (2025-07-21)

## 0.123.0 (2025-07-18)

* Pull request #373: Feature/RSCLD-725 InputListField ([12e5fe7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/12e5fe7)), closes [#373](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/373)

## 0.122.0 (2025-07-17)

* feat: [RSCLD-725] Add InputListField ([bdde4f8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bdde4f8))

## 0.121.0 (2025-07-17)

## 0.120.0 (2025-07-17)

* Pull request #372: Feature/RSCLD-725 InputListField ([6772c36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6772c36)), closes [#372](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/372)

## 0.119.0 (2025-07-16)

## 0.118.0 (2025-07-15)

## 0.117.0 (2025-07-14)

* Pull request #369: Feature/RSCLD-590 DatePicker ([ab1ab96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ab1ab96)), closes [#369](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/369)

## 0.116.0 (2025-07-07)

* Pull request #367: Feature/RSCLD-590 DatePicker ([1e7f42a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1e7f42a)), closes [#367](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/367)

## 0.115.0 (2025-07-03)

## 0.114.0 (2025-07-02)

## 0.113.0 (2025-07-02)

## 0.112.0 (2025-06-30)

## 0.111.0 (2025-06-26)

## 0.110.0 (2025-06-26)

## 0.109.0 (2025-06-26)

## 0.108.0 (2025-06-24)

## 0.107.0 (2025-06-23)

## 0.106.0 (2025-06-23)

## 0.105.0 (2025-06-23)

* Pull request #364: Feature/RSCLD-552 fields ([9b7325c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9b7325c)), closes [#364](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/364)

## 0.104.0 (2025-06-23)

## 0.103.0 (2025-06-20)

* feat: [RSCLD-568] Fix tooltip arrow ([73fbd08](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/73fbd08))

## 0.102.0 (2025-06-19)

## 0.101.0 (2025-06-19)

## 0.100.0 (2025-06-19)

## 0.99.0 (2025-06-18)

## 0.98.0 (2025-06-18)

## 0.97.0 (2025-06-18)

## 0.96.0 (2025-06-17)

## 0.95.0 (2025-06-17)

## 0.94.0 (2025-06-11)

## 0.93.0 (2025-06-10)

## 0.92.0 (2025-06-10)

## 0.91.0 (2025-06-10)

## 0.90.0 (2025-06-09)

## 0.89.0 (2025-06-09)

## 0.88.0 (2025-06-06)

## 0.87.0 (2025-06-06)

## 0.86.0 (2025-06-05)

## 0.85.0 (2025-06-02)

* feat: [RSCLD-446] Up versions ([b9a9df0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b9a9df0))
* Pull request #354: Feature/RSCLD-446 comments ([206f892](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/206f892)), closes [#354](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/354)

## 0.82.0 (2025-05-30)

* Pull request #353: Feature/RSCLD-446_comments ([8daff73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8daff73)), closes [#353](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/353)

## 0.81.0 (2025-05-30)

## 0.80.0 (2025-05-23)

## 0.79.0 (2025-05-22)

## 0.78.0 (2025-05-14)

## 0.77.0 (2025-05-14)

## 0.76.0 (2025-05-14)

## 0.75.0 (2025-04-29)

* Pull request #346: Feature/RSCLD-359_Notice ([f5f4445](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f5f4445)), closes [#346](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/346)

## 0.74.0 (2025-04-29)

* feat: [RSCLD-359] Add Notice ([a139c4a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a139c4a))

## 0.73.0 (2025-04-29)

## 0.72.0 (2025-04-28)

## 0.71.0 (2025-04-28)

## 0.70.0 (2025-04-28)

## 0.69.0 (2025-04-25)

## 0.68.0 (2025-04-23)

## 0.67.0 (2025-04-22)

* Pull request #341: Feature/RSCLD-361_TitleBlock ([2ddd5fd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2ddd5fd)), closes [#341](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/341)

## 0.66.0 (2025-04-22)

## 0.65.0 (2025-04-21)

## 0.64.0 (2025-04-21)

## 0.63.0 (2025-04-21)

## 0.62.0 (2025-04-18)

## 0.61.0 (2025-04-17)

## 0.60.0 (2025-04-17)

* Pull request #336: feat: [RSCLD-344] Support tooltips in fields ([0b8e380](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b8e380)), closes [#336](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/336)

## 0.59.0 (2025-04-16)

## 0.58.0 (2025-04-11)

## 0.57.0 (2025-04-11)

* Pull request #332: feat: [RSCLD-222] Popover, Tooltip ([c6aa509](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c6aa509)), closes [#332](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/332)

## 0.56.0 (2025-04-09)

* Pull request #329: feat: [RSCLD-310] New components: badge, level ([528dff0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/528dff0)), closes [#329](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/329)

## 0.55.0 (2025-04-03)

## 0.54.0 (2025-04-02)

* Pull request #319: Feature/RSCLD-192_Alert ([4865c5f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4865c5f)), closes [#319](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/319)

## 0.53.0 (2025-03-26)

## 0.52.0 (2025-03-26)

## 0.51.0 (2025-03-21)

## 0.50.0 (2025-03-21)

## 0.49.0 (2025-03-18)

## 0.48.0 (2025-03-13)

## 0.47.0 (2025-03-13)

## 0.46.0 (2025-03-11)

## 0.45.0 (2025-03-10)

## 0.44.0 (2025-03-10)

## 0.43.0 (2025-03-10)

* Pull request #309: Feature/RSCLD-177_Input ([1dc2f68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1dc2f68)), closes [#309](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/309)

## 0.42.0 (2025-03-06)

* Pull request #302: Feature/RSCLD-112_Button ([d0d4a66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d0d4a66)), closes [#302](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/302)

## 0.41.0 (2025-03-03)

## 0.40.0 (2025-03-03)

## 0.39.0 (2025-02-28)

* Pull request #306: Bugfix/RSCLD-131_Combobox ([8cbc5eb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8cbc5eb)), closes [#306](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/306)

## 0.35.0 (2025-02-28)

## 0.34.0 (2025-02-26)

## 0.33.0 (2025-02-26)

## 0.32.0 (2025-02-24)

## 0.31.0 (2025-02-24)

## 0.30.0 (2025-02-24)

## 0.29.0 (2025-02-24)

## 0.28.0 (2025-02-21)

## 0.27.0 (2025-02-21)

## 0.26.0 (2025-02-19)

* Pull request #292: Feature/RSCLD-88_popover ([b344047](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b344047)), closes [#292](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/292)

## 0.25.0 (2025-02-19)

## 0.24.0 (2025-02-19)

## 0.23.0 (2025-02-19)

## 0.22.0 (2025-02-18)

## 0.21.0 (2025-02-18)

## 0.20.0 (2025-02-18)

## 0.19.0 (2025-02-18)

## 0.18.0 (2025-02-18)

## 0.17.0 (2025-02-18)

## 0.16.0 (2025-02-18)

## 0.15.0 (2025-02-18)

## 0.14.0 (2025-02-17)

## 0.13.0 (2025-02-17)

## 0.12.0 (2025-02-14)

## 0.11.0 (2025-02-14)

* Pull request #283: Feature/RSCLD-81_colors ([a326985](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a326985)), closes [#283](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/283)

## 0.10.0 (2025-02-13)

## 0.9.0 (2025-02-13)

## 0.8.0 (2025-02-13)

## 0.7.0 (2025-02-12)

* Pull request #277: Feature/SBRORMCLD-1209 set NotificationContainer to errorBoundary ([d97766e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d97766e)), closes [#277](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/277)

## 0.6.0 (2025-02-11)

## 0.5.0 (2025-02-11)

## [0.4.199](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.198...@sber-orm/prettier-config-v0.4.199) (2025-02-11)

## [0.4.198](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.197...@sber-orm/prettier-config-v0.4.198) (2025-02-11)

## [0.4.197](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.196...@sber-orm/prettier-config-v0.4.197) (2025-02-11)

## [0.4.196](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.195...@sber-orm/prettier-config-v0.4.196) (2025-02-10)

## [0.4.195](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.194...@sber-orm/prettier-config-v0.4.195) (2025-02-07)

## [0.4.194](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.193...@sber-orm/prettier-config-v0.4.194) (2025-02-07)

## [0.4.193](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.192...@sber-orm/prettier-config-v0.4.193) (2025-02-07)

## [0.4.192](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.191...@sber-orm/prettier-config-v0.4.192) (2025-02-07)

## [0.4.191](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.190...@sber-orm/prettier-config-v0.4.191) (2025-02-07)

## [0.4.190](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.189...@sber-orm/prettier-config-v0.4.190) (2025-02-07)

## [0.4.189](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.188...@sber-orm/prettier-config-v0.4.189) (2025-02-06)

## [0.4.188](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.187...@sber-orm/prettier-config-v0.4.188) (2025-02-06)

## [0.4.187](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.186...@sber-orm/prettier-config-v0.4.187) (2025-02-05)

## [0.4.186](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.185...@sber-orm/prettier-config-v0.4.186) (2025-02-05)

## [0.4.185](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.184...@sber-orm/prettier-config-v0.4.185) (2025-02-04)

## [0.4.184](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.183...@sber-orm/prettier-config-v0.4.184) (2025-02-03)

## [0.4.183](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.182...@sber-orm/prettier-config-v0.4.183) (2025-02-03)

## [0.4.182](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.181...@sber-orm/prettier-config-v0.4.182) (2025-02-03)

## [0.4.181](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.180...@sber-orm/prettier-config-v0.4.181) (2025-01-31)

## [0.4.180](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.179...@sber-orm/prettier-config-v0.4.180) (2025-01-31)

## [0.4.179](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.178...@sber-orm/prettier-config-v0.4.179) (2025-01-31)

## [0.4.178](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.177...@sber-orm/prettier-config-v0.4.178) (2025-01-30)

## [0.4.177](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.176...@sber-orm/prettier-config-v0.4.177) (2025-01-30)

## [0.4.176](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.175...@sber-orm/prettier-config-v0.4.176) (2025-01-30)

## [0.4.175](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.174...@sber-orm/prettier-config-v0.4.175) (2025-01-29)

## [0.4.174](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.173...@sber-orm/prettier-config-v0.4.174) (2025-01-29)

## [0.4.173](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.172...@sber-orm/prettier-config-v0.4.173) (2025-01-29)

## [0.4.172](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.171...@sber-orm/prettier-config-v0.4.172) (2025-01-29)

## [0.4.171](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.170...@sber-orm/prettier-config-v0.4.171) (2025-01-29)

## [0.4.170](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.169...@sber-orm/prettier-config-v0.4.170) (2025-01-28)

## [0.4.169](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.168...@sber-orm/prettier-config-v0.4.169) (2025-01-24)

## [0.4.168](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.167...@sber-orm/prettier-config-v0.4.168) (2025-01-23)

## [0.4.167](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.166...@sber-orm/prettier-config-v0.4.167) (2025-01-21)

## [0.4.166](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.165...@sber-orm/prettier-config-v0.4.166) (2025-01-17)

## [0.4.165](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.164...@sber-orm/prettier-config-v0.4.165) (2025-01-16)

## [0.4.164](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.163...@sber-orm/prettier-config-v0.4.164) (2025-01-15)

## [0.4.163](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.162...@sber-orm/prettier-config-v0.4.163) (2025-01-15)

## [0.4.162](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.161...@sber-orm/prettier-config-v0.4.162) (2025-01-15)

## [0.4.161](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.160...@sber-orm/prettier-config-v0.4.161) (2025-01-14)

## [0.4.160](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.159...@sber-orm/prettier-config-v0.4.160) (2025-01-14)

## [0.4.159](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.158...@sber-orm/prettier-config-v0.4.159) (2025-01-13)

## [0.4.158](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.157...@sber-orm/prettier-config-v0.4.158) (2025-01-13)

## [0.4.157](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.156...@sber-orm/prettier-config-v0.4.157) (2025-01-10)

## [0.4.156](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.155...@sber-orm/prettier-config-v0.4.156) (2024-12-20)

## [0.4.155](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.154...@sber-orm/prettier-config-v0.4.155) (2024-12-20)

## [0.4.154](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.153...@sber-orm/prettier-config-v0.4.154) (2024-12-20)

## [0.4.153](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.152...@sber-orm/prettier-config-v0.4.153) (2024-12-19)

## [0.4.152](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.151...@sber-orm/prettier-config-v0.4.152) (2024-12-18)

## [0.4.151](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.150...@sber-orm/prettier-config-v0.4.151) (2024-12-18)

## [0.4.150](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.149...@sber-orm/prettier-config-v0.4.150) (2024-12-17)

## [0.4.149](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.148...@sber-orm/prettier-config-v0.4.149) (2024-12-16)

## [0.4.148](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.147...@sber-orm/prettier-config-v0.4.148) (2024-12-16)

## [0.4.147](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.146...@sber-orm/prettier-config-v0.4.147) (2024-12-16)

## [0.4.146](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.145...@sber-orm/prettier-config-v0.4.146) (2024-12-13)

## [0.4.145](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.144...@sber-orm/prettier-config-v0.4.145) (2024-12-13)

## [0.4.144](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.143...@sber-orm/prettier-config-v0.4.144) (2024-12-13)

## [0.4.143](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.142...@sber-orm/prettier-config-v0.4.143) (2024-12-10)

## [0.4.142](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.141...@sber-orm/prettier-config-v0.4.142) (2024-12-09)

## [0.4.141](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.140...@sber-orm/prettier-config-v0.4.141) (2024-12-06)

## [0.4.140](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.139...@sber-orm/prettier-config-v0.4.140) (2024-12-05)

## [0.4.139](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.138...@sber-orm/prettier-config-v0.4.139) (2024-12-04)

## [0.4.138](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.137...@sber-orm/prettier-config-v0.4.138) (2024-12-04)

## [0.4.137](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.136...@sber-orm/prettier-config-v0.4.137) (2024-12-03)

## [0.4.136](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.135...@sber-orm/prettier-config-v0.4.136) (2024-12-03)

## [0.4.135](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.134...@sber-orm/prettier-config-v0.4.135) (2024-12-03)

## [0.4.134](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.133...@sber-orm/prettier-config-v0.4.134) (2024-12-03)

## [0.4.133](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.132...@sber-orm/prettier-config-v0.4.133) (2024-12-03)

## [0.4.132](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.131...@sber-orm/prettier-config-v0.4.132) (2024-12-02)

## [0.4.131](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.130...@sber-orm/prettier-config-v0.4.131) (2024-12-02)

## [0.4.130](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.129...@sber-orm/prettier-config-v0.4.130) (2024-12-02)

## [0.4.129](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.128...@sber-orm/prettier-config-v0.4.129) (2024-11-28)

## [0.4.128](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.127...@sber-orm/prettier-config-v0.4.128) (2024-11-28)

## [0.4.127](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.126...@sber-orm/prettier-config-v0.4.127) (2024-11-27)

## [0.4.126](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.125...@sber-orm/prettier-config-v0.4.126) (2024-11-27)

## [0.4.125](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.124...@sber-orm/prettier-config-v0.4.125) (2024-11-26)

## [0.4.124](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.123...@sber-orm/prettier-config-v0.4.124) (2024-11-25)

## [0.4.123](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.122...@sber-orm/prettier-config-v0.4.123) (2024-11-20)

## [0.4.122](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.121...@sber-orm/prettier-config-v0.4.122) (2024-11-19)

## [0.4.121](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.120...@sber-orm/prettier-config-v0.4.121) (2024-11-18)

## [0.4.120](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.119...@sber-orm/prettier-config-v0.4.120) (2024-11-14)

## [0.4.119](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.118...@sber-orm/prettier-config-v0.4.119) (2024-11-14)

## [0.4.118](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.117...@sber-orm/prettier-config-v0.4.118) (2024-11-12)

## [0.4.117](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.116...@sber-orm/prettier-config-v0.4.117) (2024-11-12)

## [0.4.116](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.115...@sber-orm/prettier-config-v0.4.116) (2024-11-12)

## [0.4.115](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.114...@sber-orm/prettier-config-v0.4.115) (2024-11-08)

## [0.4.114](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.113...@sber-orm/prettier-config-v0.4.114) (2024-11-07)

## [0.4.113](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.112...@sber-orm/prettier-config-v0.4.113) (2024-11-07)

## [0.4.112](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.111...@sber-orm/prettier-config-v0.4.112) (2024-11-07)

## [0.4.111](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.110...@sber-orm/prettier-config-v0.4.111) (2024-11-07)

## [0.4.110](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.109...@sber-orm/prettier-config-v0.4.110) (2024-11-06)

## [0.4.109](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.108...@sber-orm/prettier-config-v0.4.109) (2024-11-05)

## [0.4.108](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.107...@sber-orm/prettier-config-v0.4.108) (2024-11-05)

## [0.4.107](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.106...@sber-orm/prettier-config-v0.4.107) (2024-11-02)

## [0.4.106](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.105...@sber-orm/prettier-config-v0.4.106) (2024-11-02)

## [0.4.105](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.104...@sber-orm/prettier-config-v0.4.105) (2024-11-01)

## [0.4.104](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.103...@sber-orm/prettier-config-v0.4.104) (2024-11-01)

## [0.4.103](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.102...@sber-orm/prettier-config-v0.4.103) (2024-10-31)

## [0.4.102](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.101...@sber-orm/prettier-config-v0.4.102) (2024-10-29)

## [0.4.101](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.100...@sber-orm/prettier-config-v0.4.101) (2024-10-28)

## [0.4.100](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.99...@sber-orm/prettier-config-v0.4.100) (2024-10-28)

## [0.4.99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.98...@sber-orm/prettier-config-v0.4.99) (2024-10-28)

## [0.4.98](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.97...@sber-orm/prettier-config-v0.4.98) (2024-10-28)

## [0.4.97](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.96...@sber-orm/prettier-config-v0.4.97) (2024-10-25)

## [0.4.96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.95...@sber-orm/prettier-config-v0.4.96) (2024-10-25)

## [0.4.95](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.94...@sber-orm/prettier-config-v0.4.95) (2024-10-25)

## [0.4.94](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.93...@sber-orm/prettier-config-v0.4.94) (2024-10-24)

## [0.4.93](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.92...@sber-orm/prettier-config-v0.4.93) (2024-10-24)

## [0.4.92](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.91...@sber-orm/prettier-config-v0.4.92) (2024-10-24)

## [0.4.91](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.90...@sber-orm/prettier-config-v0.4.91) (2024-10-24)

## [0.4.90](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.89...@sber-orm/prettier-config-v0.4.90) (2024-10-24)

## [0.4.89](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.88...@sber-orm/prettier-config-v0.4.89) (2024-10-24)

## [0.4.88](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.87...@sber-orm/prettier-config-v0.4.88) (2024-10-23)

## [0.4.87](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.86...@sber-orm/prettier-config-v0.4.87) (2024-10-23)

## [0.4.86](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.85...@sber-orm/prettier-config-v0.4.86) (2024-10-23)

## [0.4.85](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.84...@sber-orm/prettier-config-v0.4.85) (2024-10-22)

## [0.4.84](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.83...@sber-orm/prettier-config-v0.4.84) (2024-10-21)

## [0.4.83](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.82...@sber-orm/prettier-config-v0.4.83) (2024-10-21)

## [0.4.82](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.81...@sber-orm/prettier-config-v0.4.82) (2024-10-21)

## [0.4.81](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.80...@sber-orm/prettier-config-v0.4.81) (2024-10-21)

## [0.4.80](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.79...@sber-orm/prettier-config-v0.4.80) (2024-10-21)

## [0.4.79](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.78...@sber-orm/prettier-config-v0.4.79) (2024-10-18)

## [0.4.78](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.77...@sber-orm/prettier-config-v0.4.78) (2024-10-18)

## [0.4.77](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.76...@sber-orm/prettier-config-v0.4.77) (2024-10-17)

## [0.4.76](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.75...@sber-orm/prettier-config-v0.4.76) (2024-10-17)

## [0.4.75](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.74...@sber-orm/prettier-config-v0.4.75) (2024-10-16)

## [0.4.74](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.73...@sber-orm/prettier-config-v0.4.74) (2024-10-16)

## [0.4.73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.72...@sber-orm/prettier-config-v0.4.73) (2024-10-15)

## [0.4.72](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.71...@sber-orm/prettier-config-v0.4.72) (2024-10-14)

## [0.4.71](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.70...@sber-orm/prettier-config-v0.4.71) (2024-10-14)

## [0.4.70](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.69...@sber-orm/prettier-config-v0.4.70) (2024-10-14)

## [0.4.69](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.68...@sber-orm/prettier-config-v0.4.69) (2024-10-14)

## [0.4.68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.67...@sber-orm/prettier-config-v0.4.68) (2024-10-14)

## [0.4.67](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.66...@sber-orm/prettier-config-v0.4.67) (2024-10-09)

## [0.4.66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.65...@sber-orm/prettier-config-v0.4.66) (2024-10-08)

## [0.4.65](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.64...@sber-orm/prettier-config-v0.4.65) (2024-10-03)

## [0.4.64](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.63...@sber-orm/prettier-config-v0.4.64) (2024-10-02)

## [0.4.63](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.62...@sber-orm/prettier-config-v0.4.63) (2024-09-30)

## [0.4.62](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.61...@sber-orm/prettier-config-v0.4.62) (2024-09-30)

## [0.4.61](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.60...@sber-orm/prettier-config-v0.4.61) (2024-09-27)

## [0.4.60](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.59...@sber-orm/prettier-config-v0.4.60) (2024-09-27)

## [0.4.59](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.58...@sber-orm/prettier-config-v0.4.59) (2024-09-27)

## [0.4.58](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.57...@sber-orm/prettier-config-v0.4.58) (2024-09-27)

## [0.4.57](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.56...@sber-orm/prettier-config-v0.4.57) (2024-09-27)

## [0.4.56](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.55...@sber-orm/prettier-config-v0.4.56) (2024-09-27)

## [0.4.55](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.54...@sber-orm/prettier-config-v0.4.55) (2024-09-26)

## [0.4.54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.53...@sber-orm/prettier-config-v0.4.54) (2024-09-26)

## [0.4.53](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.52...@sber-orm/prettier-config-v0.4.53) (2024-09-25)

## [0.4.52](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.51...@sber-orm/prettier-config-v0.4.52) (2024-09-24)

## [0.4.51](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.50...@sber-orm/prettier-config-v0.4.51) (2024-09-23)

## [0.4.50](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.49...@sber-orm/prettier-config-v0.4.50) (2024-09-23)

## [0.4.49](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.48...@sber-orm/prettier-config-v0.4.49) (2024-09-16)

## [0.4.48](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.47...@sber-orm/prettier-config-v0.4.48) (2024-09-09)

## [0.4.47](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.46...@sber-orm/prettier-config-v0.4.47) (2024-09-09)

## [0.4.46](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.45...@sber-orm/prettier-config-v0.4.46) (2024-09-06)

## [0.4.45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.44...@sber-orm/prettier-config-v0.4.45) (2024-09-06)

## [0.4.44](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.43...@sber-orm/prettier-config-v0.4.44) (2024-09-05)

## [0.4.43](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.42...@sber-orm/prettier-config-v0.4.43) (2024-09-04)

## [0.4.42](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.41...@sber-orm/prettier-config-v0.4.42) (2024-09-04)

## [0.4.41](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.40...@sber-orm/prettier-config-v0.4.41) (2024-09-03)

## [0.4.40](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.39...@sber-orm/prettier-config-v0.4.40) (2024-09-03)

## [0.4.39](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.38...@sber-orm/prettier-config-v0.4.39) (2024-09-03)

## [0.4.38](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.37...@sber-orm/prettier-config-v0.4.38) (2024-09-02)

## [0.4.37](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.36...@sber-orm/prettier-config-v0.4.37) (2024-09-02)

## [0.4.36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.35...@sber-orm/prettier-config-v0.4.36) (2024-08-30)

## [0.4.35](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.34...@sber-orm/prettier-config-v0.4.35) (2024-08-30)

## [0.4.34](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.33...@sber-orm/prettier-config-v0.4.34) (2024-08-30)

## [0.4.33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.30...@sber-orm/prettier-config-v0.4.33) (2024-08-30)

## [0.4.32](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.31...@sber-orm/prettier-config-v0.4.32) (2024-08-29)

## [0.4.31](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.30...@sber-orm/prettier-config-v0.4.31) (2024-08-29)

## [0.4.30](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.29...@sber-orm/prettier-config-v0.4.30) (2024-08-29)

## [0.4.29](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.28...@sber-orm/prettier-config-v0.4.29) (2024-08-28)

## [0.4.28](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.27...@sber-orm/prettier-config-v0.4.28) (2024-08-26)

## [0.4.27](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.26...@sber-orm/prettier-config-v0.4.27) (2024-08-26)

## [0.4.26](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.25...@sber-orm/prettier-config-v0.4.26) (2024-08-23)

## [0.4.25](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.24...@sber-orm/prettier-config-v0.4.25) (2024-08-23)

## [0.4.24](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.23...@sber-orm/prettier-config-v0.4.24) (2024-08-22)

## [0.4.23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.22...@sber-orm/prettier-config-v0.4.23) (2024-08-22)

## [0.4.22](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.21...@sber-orm/prettier-config-v0.4.22) (2024-08-22)

## [0.4.21](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.20...@sber-orm/prettier-config-v0.4.21) (2024-08-21)

## [0.4.20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.19...@sber-orm/prettier-config-v0.4.20) (2024-08-21)

## [0.4.19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.18...@sber-orm/prettier-config-v0.4.19) (2024-08-21)

## [0.4.18](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.17...@sber-orm/prettier-config-v0.4.18) (2024-08-21)

## [0.4.17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.16...@sber-orm/prettier-config-v0.4.17) (2024-08-21)

## [0.4.16](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.15...@sber-orm/prettier-config-v0.4.16) (2024-08-21)

## [0.4.15](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.14...@sber-orm/prettier-config-v0.4.15) (2024-08-20)

## [0.4.14](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.13...@sber-orm/prettier-config-v0.4.14) (2024-08-19)

## [0.4.13](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.12...@sber-orm/prettier-config-v0.4.13) (2024-08-16)

## [0.4.12](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.11...@sber-orm/prettier-config-v0.4.12) (2024-08-16)

## [0.4.11](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.10...@sber-orm/prettier-config-v0.4.11) (2024-08-09)

## [0.4.10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.9...@sber-orm/prettier-config-v0.4.10) (2024-08-09)

## [0.4.9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.8...@sber-orm/prettier-config-v0.4.9) (2024-08-09)

## [0.4.8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.7...@sber-orm/prettier-config-v0.4.8) (2024-08-08)

## [0.4.7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.6...@sber-orm/prettier-config-v0.4.7) (2024-08-08)

## [0.4.6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.5...@sber-orm/prettier-config-v0.4.6) (2024-08-07)

## [0.4.5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.4...@sber-orm/prettier-config-v0.4.5) (2024-08-07)

## [0.4.4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.3...@sber-orm/prettier-config-v0.4.4) (2024-08-07)

## [0.4.3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.4.2...@sber-orm/prettier-config-v0.4.3) (2024-08-07)

## [0.4.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.3.2...@sber-orm/prettier-config-v0.4.2) (2024-08-06)

## [0.4.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.3.2...@sber-orm/prettier-config-v0.4.1) (2024-08-05)

## [0.4.0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.3.2...@sber-orm/prettier-config-v0.4.0) (2024-07-31)

### Features

- [ORMCORE-291] Change package eslint-config ([cd136ef](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/cd136efa286b04516c23a2a7ab7034d2036cec91))
- [SBRORMCLD-278] Update eslint-plugin package ([09a0cbf](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/09a0cbf9733ab29f5300f7d2ee711de489b04415))
- [SBRORMCLD-278] Update prettier-config package ([c0f1319](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/c0f1319e185bcc672719612a41a3c03bc62f9bda))

## [0.3.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.3.1...@sber-orm/prettier-config-v0.3.2) (2024-05-30)

## [0.3.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/prettier-config-v0.3.0...@sber-orm/prettier-config-v0.3.1) (2024-05-29)

## 0.3.0 (2024-04-23)

### Features

- [ORMCORE-160] Add eslint, prettier, tsconfig config ([5851814](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/585181418d4348d17bb0afcd3710952de3b8f64f))
- [ORMCORE-160] Add openapi ([b817ee9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/b817ee93a867c442d8a1066c0e2f693cd48dd473))
- [ORMCORE-237] Add build and publish packages ([deb2273](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/deb2273cc12712687e506f932a1f7044ed86c477))
- [ORMCORE-237] Add eslint, tsconfig, prettier packages ([fc41d54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/fc41d545f3e1e94e983ce196731ac578ef4d2d6c))
