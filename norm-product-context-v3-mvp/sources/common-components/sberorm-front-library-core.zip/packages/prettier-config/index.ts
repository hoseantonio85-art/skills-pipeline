import cn from 'classnames';
import React, { useCallback, useEffect, useRef, useState } from 'react';

import {
  useEventCallback,
  useForkRef,
  useKeeper,
  useMutation,
  useResizeHook,
  useThrottle,
} from '../../hooks';
import { ScrollhostContainer } from './components/ScrollhostContainer';
import {
  EOffsetAttributes,
  EOffsetSizeAttributes,
  EScrollOffsetAttributes,
  EScrollSizeAttributes,
  ESizeAttributes,
} from './consts';
import classes from './styles.module.scss';
import { IAxes, IScrollbarProperties, TAxis } from './types';
import { ownerDocument, useDebounceRaf } from './utils';
