# @sber-orm/prettier-config

Общий конфиг для Prettier.

## установка

`$ npm i -D @sber-orm/prettier-config`

## использование

`.prettierrc.json`

```
"@sber-orm/prettier-config"
```
