/** @type import('prettier').Config */
module.exports = {
  $schema: 'http://json.schemastore.org/prettierrc',
  useTabs: false,
  trailingComma: 'all',
  tabWidth: 2,
  semi: true,
  singleQuote: true,
  jsxSingleQuote: true,
  printWidth: 150,
  bracketSameLine: true,
  endOfLine: 'auto',

  importOrder: [
    '<THIRD_PARTY_MODULES>',
    '^@(.*)$',
    '^[./]',
    '^(.*).scss',
    '^(.*).css',
  ],
  importOrderSeparation: true,
  importOrderSortSpecifiers: true,
  plugins: ['@trivago/prettier-plugin-sort-imports'],
};
