# Changelog

## 0.241.0 (2026-06-04)

## 0.240.0 (2026-06-02)

## 0.239.0 (2026-06-01)

## 0.238.0 (2026-06-01)

## 0.237.0 (2026-05-29)

## 0.236.0 (2026-05-20)

## 0.235.0 (2026-05-06)

## 0.234.0 (2026-04-22)

## 0.233.0 (2026-04-22)

## 0.232.0 (2026-04-15)

## 0.231.0 (2026-04-14)

## 0.230.0 (2026-04-13)

## 0.229.0 (2026-04-07)

## 0.228.0 (2026-04-06)

## 0.227.0 (2026-04-03)

## 0.226.0 (2026-04-03)

## 0.225.0 (2026-04-03)

## 0.224.0 (2026-03-26)

## 0.223.0 (2026-03-26)

## 0.222.0 (2026-03-26)

* Pull request #462: Feature/GMRT-131/npm package type ([72d36de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/72d36de)), closes [#462](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/462)

## 0.221.0 (2026-03-25)

## 0.220.0 (2026-03-25)

## 0.219.0 (2026-03-25)

* Pull request #461: feat: [GMRT-131] New npm package ([c962b19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c962b19)), closes [#461](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/461)

## 0.218.0 (2026-03-25)

## 0.217.0 (2026-03-23)

## 0.216.0 (2026-03-03)

## 0.215.0 (2026-02-25)

## 0.214.0 (2026-02-25)

## 0.213.0 (2026-02-24)

## 0.212.0 (2026-02-24)

## 0.211.0 (2026-02-24)

## 0.210.0 (2026-02-19)

## 0.209.0 (2026-02-17)

## 0.208.0 (2026-02-16)

## 0.207.0 (2026-02-16)

## 0.206.0 (2026-02-12)

## 0.205.0 (2026-02-11)

## 0.204.0 (2026-02-11)

## 0.203.0 (2026-02-10)

## 0.202.0 (2026-02-10)

## 0.201.0 (2026-02-10)

## 0.200.0 (2026-02-09)

## 0.199.0 (2026-02-09)

## 0.198.0 (2026-02-05)

## 0.197.0 (2026-02-03)

## 0.196.0 (2026-02-03)

## 0.195.0 (2026-02-02)

## 0.194.0 (2026-01-28)

## 0.193.0 (2026-01-26)

* Pull request #429: Feature/GMRT-1123 remove Loader ([b866466](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b866466)), closes [#429](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/429)

## 0.192.0 (2026-01-23)

## 0.191.0 (2026-01-19)

## 0.190.0 (2026-01-16)

## 0.189.0 (2026-01-12)

## 0.188.0 (2025-12-17)

## 0.187.0 (2025-12-16)

## 0.186.0 (2025-12-15)

## 0.185.0 (2025-12-11)

## 0.184.0 (2025-12-11)

## 0.183.0 (2025-12-10)

## 0.182.0 (2025-12-08)

## 0.181.0 (2025-12-01)

## 0.180.0 (2025-11-28)

## 0.179.0 (2025-11-28)

## 0.178.0 (2025-11-12)

## 0.177.0 (2025-10-29)

## 0.176.0 (2025-10-29)

## 0.175.0 (2025-10-27)

## 0.174.0 (2025-10-27)

## 0.173.0 (2025-10-24)

## 0.172.0 (2025-10-22)

## 0.171.0 (2025-10-22)

## 0.170.0 (2025-10-22)

## 0.169.0 (2025-10-22)

## 0.168.0 (2025-10-21)

## 0.167.0 (2025-10-21)

## 0.166.0 (2025-10-21)

## 0.165.0 (2025-10-20)

## 0.164.0 (2025-10-17)

## 0.163.0 (2025-10-16)

## 0.162.0 (2025-10-15)

## 0.161.0 (2025-10-14)

## 0.160.0 (2025-10-13)

## 0.159.0 (2025-10-13)

## 0.158.0 (2025-10-10)

## 0.157.0 (2025-10-08)

## 0.156.0 (2025-10-08)

## 0.155.0 (2025-10-02)

## 0.154.0 (2025-10-01)

## 0.153.0 (2025-09-23)

## 0.152.0 (2025-09-18)

## 0.151.0 (2025-09-17)

## 0.150.0 (2025-09-17)

## 0.149.0 (2025-09-15)

## 0.148.0 (2025-09-12)

## 0.147.0 (2025-09-12)

## 0.146.0 (2025-09-11)

## 0.145.0 (2025-09-09)

## 0.144.0 (2025-09-09)

## 0.143.0 (2025-09-03)

## 0.142.0 (2025-09-03)

## 0.141.0 (2025-09-02)

## 0.140.0 (2025-08-26)

## 0.139.0 (2025-08-25)

## 0.138.0 (2025-08-21)

## 0.137.0 (2025-08-20)

## 0.136.0 (2025-08-19)

## 0.135.0 (2025-08-19)

## 0.134.0 (2025-08-18)

## 0.133.0 (2025-08-18)

## 0.132.0 (2025-08-18)

## 0.131.0 (2025-08-18)

## 0.130.0 (2025-08-13)

## 0.129.0 (2025-08-12)

## 0.128.0 (2025-08-12)

* feat: [RSCLD-770] Update biome packages ([21f82e1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/21f82e1))

## 0.127.0 (2025-08-08)

## 0.126.0 (2025-08-05)

## 0.125.0 (2025-08-01)

* Pull request #375: Feature/RSCLD-555 CurrencyRange ([88bc9fe](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/88bc9fe)), closes [#375](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/375)

## 0.124.0 (2025-07-24)

## 0.123.0 (2025-07-23)

* Pull request #374: Feature/RSCLD-739 RadioChips ([2776dfb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2776dfb)), closes [#374](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/374)

## 0.122.0 (2025-07-22)

## 0.121.0 (2025-07-21)

## 0.120.0 (2025-07-21)

## 0.119.0 (2025-07-18)

* Pull request #373: Feature/RSCLD-725 InputListField ([12e5fe7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/12e5fe7)), closes [#373](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/373)

## 0.118.0 (2025-07-17)

* feat: [RSCLD-725] Add InputListField ([bdde4f8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bdde4f8))

## 0.117.0 (2025-07-17)

## 0.116.0 (2025-07-17)

* Pull request #372: Feature/RSCLD-725 InputListField ([6772c36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6772c36)), closes [#372](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/372)

## 0.115.0 (2025-07-16)

## 0.114.0 (2025-07-15)

## 0.113.0 (2025-07-14)

* Pull request #369: Feature/RSCLD-590 DatePicker ([ab1ab96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ab1ab96)), closes [#369](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/369)

## 0.112.0 (2025-07-07)

* Pull request #367: Feature/RSCLD-590 DatePicker ([1e7f42a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1e7f42a)), closes [#367](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/367)

## 0.111.0 (2025-07-03)

## 0.110.0 (2025-07-02)

## 0.109.0 (2025-07-02)

## 0.108.0 (2025-06-30)

## 0.107.0 (2025-06-26)

## 0.106.0 (2025-06-26)

## 0.105.0 (2025-06-26)

## 0.104.0 (2025-06-24)

## 0.103.0 (2025-06-23)

## 0.102.0 (2025-06-23)

## 0.101.0 (2025-06-23)

* Pull request #364: Feature/RSCLD-552 fields ([9b7325c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9b7325c)), closes [#364](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/364)

## 0.100.0 (2025-06-23)

## 0.99.0 (2025-06-20)

* feat: [RSCLD-568] Fix tooltip arrow ([73fbd08](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/73fbd08))

## 0.98.0 (2025-06-19)

## 0.97.0 (2025-06-19)

## 0.96.0 (2025-06-19)

## 0.95.0 (2025-06-18)

## 0.94.0 (2025-06-18)

## 0.93.0 (2025-06-18)

## 0.92.0 (2025-06-17)

## 0.91.0 (2025-06-17)

## 0.90.0 (2025-06-11)

## 0.89.0 (2025-06-10)

## 0.88.0 (2025-06-10)

## 0.87.0 (2025-06-10)

## 0.86.0 (2025-06-09)

## 0.85.0 (2025-06-09)

## 0.84.0 (2025-06-06)

## 0.83.0 (2025-06-06)

## 0.82.0 (2025-06-05)

## 0.81.0 (2025-06-02)

* feat: [RSCLD-446] Up versions ([b9a9df0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b9a9df0))
* Pull request #354: Feature/RSCLD-446 comments ([206f892](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/206f892)), closes [#354](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/354)

## 0.78.0 (2025-05-30)

* Pull request #353: Feature/RSCLD-446_comments ([8daff73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8daff73)), closes [#353](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/353)

## 0.77.0 (2025-05-30)

## 0.76.0 (2025-05-23)

## 0.75.0 (2025-05-22)

## 0.74.0 (2025-05-14)

## 0.73.0 (2025-05-14)

## 0.72.0 (2025-05-14)

## 0.71.0 (2025-04-29)

* Pull request #346: Feature/RSCLD-359_Notice ([f5f4445](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f5f4445)), closes [#346](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/346)

## 0.70.0 (2025-04-29)

* feat: [RSCLD-359] Add Notice ([a139c4a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a139c4a))

## 0.69.0 (2025-04-29)

## 0.68.0 (2025-04-28)

## 0.67.0 (2025-04-28)

## 0.66.0 (2025-04-28)

## 0.65.0 (2025-04-25)

## 0.64.0 (2025-04-23)

## 0.63.0 (2025-04-22)

* Pull request #341: Feature/RSCLD-361_TitleBlock ([2ddd5fd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2ddd5fd)), closes [#341](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/341)

## 0.62.0 (2025-04-22)

## 0.61.0 (2025-04-21)

## 0.60.0 (2025-04-21)

## 0.59.0 (2025-04-21)

## 0.58.0 (2025-04-18)

## 0.57.0 (2025-04-17)

## 0.56.0 (2025-04-17)

* Pull request #336: feat: [RSCLD-344] Support tooltips in fields ([0b8e380](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b8e380)), closes [#336](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/336)

## 0.55.0 (2025-04-16)

## 0.54.0 (2025-04-11)

## 0.53.0 (2025-04-11)

* Pull request #332: feat: [RSCLD-222] Popover, Tooltip ([c6aa509](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c6aa509)), closes [#332](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/332)

## 0.52.0 (2025-04-09)

* Pull request #329: feat: [RSCLD-310] New components: badge, level ([528dff0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/528dff0)), closes [#329](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/329)

## 0.51.0 (2025-04-03)

## 0.50.0 (2025-04-02)

* Pull request #319: Feature/RSCLD-192_Alert ([4865c5f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4865c5f)), closes [#319](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/319)

## 0.49.0 (2025-03-26)

## 0.48.0 (2025-03-26)

## 0.47.0 (2025-03-21)

## 0.46.0 (2025-03-21)

## 0.45.0 (2025-03-18)

## 0.44.0 (2025-03-13)

## 0.43.0 (2025-03-13)

## 0.42.0 (2025-03-11)

## 0.41.0 (2025-03-10)

## 0.40.0 (2025-03-10)

## 0.39.0 (2025-03-10)

* Pull request #309: Feature/RSCLD-177_Input ([1dc2f68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1dc2f68)), closes [#309](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/309)

## 0.38.0 (2025-03-06)

* Pull request #302: Feature/RSCLD-112_Button ([d0d4a66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d0d4a66)), closes [#302](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/302)

## 0.37.0 (2025-03-03)

## 0.36.0 (2025-03-03)

## 0.35.0 (2025-02-28)

* Pull request #306: Bugfix/RSCLD-131_Combobox ([8cbc5eb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8cbc5eb)), closes [#306](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/306)

## 0.31.0 (2025-02-28)

## 0.30.0 (2025-02-26)

## 0.29.0 (2025-02-26)

## 0.28.0 (2025-02-24)

## 0.27.0 (2025-02-24)

## 0.26.0 (2025-02-24)

## 0.25.0 (2025-02-24)

## 0.24.0 (2025-02-21)

## 0.23.0 (2025-02-21)

## 0.22.0 (2025-02-19)

* Pull request #292: Feature/RSCLD-88_popover ([b344047](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b344047)), closes [#292](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/292)

## 0.21.0 (2025-02-19)

## 0.20.0 (2025-02-19)

## 0.19.0 (2025-02-19)

## 0.18.0 (2025-02-18)

## 0.17.0 (2025-02-18)

## 0.16.0 (2025-02-18)

## 0.15.0 (2025-02-18)

## 0.14.0 (2025-02-18)

## 0.13.0 (2025-02-18)

## 0.12.0 (2025-02-18)

## 0.11.0 (2025-02-18)

## 0.10.0 (2025-02-17)

## 0.9.0 (2025-02-17)

## 0.8.0 (2025-02-14)

## 0.7.0 (2025-02-14)

* Pull request #283: Feature/RSCLD-81_colors ([a326985](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a326985)), closes [#283](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/283)

## 0.6.0 (2025-02-13)

## 0.5.0 (2025-02-13)

## 0.4.0 (2025-02-13)

## 0.3.0 (2025-02-12)

* Pull request #277: Feature/SBRORMCLD-1209 set NotificationContainer to errorBoundary ([d97766e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d97766e)), closes [#277](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/277)

## 0.2.0 (2025-02-11)

## 0.1.0 (2025-02-11)

## [0.0.200](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.199...@sber-orm/eslint-plugin-v0.0.200) (2025-02-11)

## [0.0.199](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.198...@sber-orm/eslint-plugin-v0.0.199) (2025-02-11)

## [0.0.198](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.197...@sber-orm/eslint-plugin-v0.0.198) (2025-02-11)

## [0.0.197](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.196...@sber-orm/eslint-plugin-v0.0.197) (2025-02-10)

## [0.0.196](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.195...@sber-orm/eslint-plugin-v0.0.196) (2025-02-07)

## [0.0.195](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.194...@sber-orm/eslint-plugin-v0.0.195) (2025-02-07)

## [0.0.194](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.193...@sber-orm/eslint-plugin-v0.0.194) (2025-02-07)

## [0.0.193](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.192...@sber-orm/eslint-plugin-v0.0.193) (2025-02-07)

## [0.0.192](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.191...@sber-orm/eslint-plugin-v0.0.192) (2025-02-07)

## [0.0.191](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.190...@sber-orm/eslint-plugin-v0.0.191) (2025-02-07)

## [0.0.190](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.189...@sber-orm/eslint-plugin-v0.0.190) (2025-02-06)

## [0.0.189](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.188...@sber-orm/eslint-plugin-v0.0.189) (2025-02-06)

## [0.0.188](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.187...@sber-orm/eslint-plugin-v0.0.188) (2025-02-05)

## [0.0.187](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.186...@sber-orm/eslint-plugin-v0.0.187) (2025-02-05)

## [0.0.186](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.185...@sber-orm/eslint-plugin-v0.0.186) (2025-02-04)

## [0.0.185](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.184...@sber-orm/eslint-plugin-v0.0.185) (2025-02-03)

## [0.0.184](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.183...@sber-orm/eslint-plugin-v0.0.184) (2025-02-03)

## [0.0.183](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.182...@sber-orm/eslint-plugin-v0.0.183) (2025-02-03)

## [0.0.182](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.181...@sber-orm/eslint-plugin-v0.0.182) (2025-01-31)

## [0.0.181](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.180...@sber-orm/eslint-plugin-v0.0.181) (2025-01-31)

## [0.0.180](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.179...@sber-orm/eslint-plugin-v0.0.180) (2025-01-31)

## [0.0.179](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.178...@sber-orm/eslint-plugin-v0.0.179) (2025-01-30)

## [0.0.178](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.177...@sber-orm/eslint-plugin-v0.0.178) (2025-01-30)

## [0.0.177](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.176...@sber-orm/eslint-plugin-v0.0.177) (2025-01-30)

## [0.0.176](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.175...@sber-orm/eslint-plugin-v0.0.176) (2025-01-29)

## [0.0.175](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.174...@sber-orm/eslint-plugin-v0.0.175) (2025-01-29)

## [0.0.174](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.173...@sber-orm/eslint-plugin-v0.0.174) (2025-01-29)

## [0.0.173](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.172...@sber-orm/eslint-plugin-v0.0.173) (2025-01-29)

## [0.0.172](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.171...@sber-orm/eslint-plugin-v0.0.172) (2025-01-29)

## [0.0.171](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.170...@sber-orm/eslint-plugin-v0.0.171) (2025-01-28)

## [0.0.170](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.169...@sber-orm/eslint-plugin-v0.0.170) (2025-01-24)

## [0.0.169](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.168...@sber-orm/eslint-plugin-v0.0.169) (2025-01-23)

## [0.0.168](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.167...@sber-orm/eslint-plugin-v0.0.168) (2025-01-21)

## [0.0.167](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.166...@sber-orm/eslint-plugin-v0.0.167) (2025-01-17)

## [0.0.166](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.165...@sber-orm/eslint-plugin-v0.0.166) (2025-01-16)

## [0.0.165](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.164...@sber-orm/eslint-plugin-v0.0.165) (2025-01-15)

## [0.0.164](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.163...@sber-orm/eslint-plugin-v0.0.164) (2025-01-15)

## [0.0.163](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.162...@sber-orm/eslint-plugin-v0.0.163) (2025-01-15)

## [0.0.162](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.161...@sber-orm/eslint-plugin-v0.0.162) (2025-01-14)

## [0.0.161](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.160...@sber-orm/eslint-plugin-v0.0.161) (2025-01-14)

## [0.0.160](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.159...@sber-orm/eslint-plugin-v0.0.160) (2025-01-13)

## [0.0.159](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.158...@sber-orm/eslint-plugin-v0.0.159) (2025-01-13)

## [0.0.158](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.157...@sber-orm/eslint-plugin-v0.0.158) (2025-01-10)

## [0.0.157](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.156...@sber-orm/eslint-plugin-v0.0.157) (2024-12-20)

## [0.0.156](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.155...@sber-orm/eslint-plugin-v0.0.156) (2024-12-20)

## [0.0.155](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.154...@sber-orm/eslint-plugin-v0.0.155) (2024-12-20)

## [0.0.154](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.153...@sber-orm/eslint-plugin-v0.0.154) (2024-12-19)

## [0.0.153](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.152...@sber-orm/eslint-plugin-v0.0.153) (2024-12-18)

## [0.0.152](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.151...@sber-orm/eslint-plugin-v0.0.152) (2024-12-18)

## [0.0.151](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.150...@sber-orm/eslint-plugin-v0.0.151) (2024-12-17)

## [0.0.150](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.149...@sber-orm/eslint-plugin-v0.0.150) (2024-12-16)

## [0.0.149](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.148...@sber-orm/eslint-plugin-v0.0.149) (2024-12-16)

## [0.0.148](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.147...@sber-orm/eslint-plugin-v0.0.148) (2024-12-16)

## [0.0.147](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.146...@sber-orm/eslint-plugin-v0.0.147) (2024-12-13)

## [0.0.146](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.145...@sber-orm/eslint-plugin-v0.0.146) (2024-12-13)

## [0.0.145](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.144...@sber-orm/eslint-plugin-v0.0.145) (2024-12-13)

## [0.0.144](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.143...@sber-orm/eslint-plugin-v0.0.144) (2024-12-10)

## [0.0.143](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.142...@sber-orm/eslint-plugin-v0.0.143) (2024-12-09)

## [0.0.142](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.141...@sber-orm/eslint-plugin-v0.0.142) (2024-12-06)

## [0.0.141](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.140...@sber-orm/eslint-plugin-v0.0.141) (2024-12-05)

## [0.0.140](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.139...@sber-orm/eslint-plugin-v0.0.140) (2024-12-04)

## [0.0.139](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.138...@sber-orm/eslint-plugin-v0.0.139) (2024-12-04)

## [0.0.138](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.137...@sber-orm/eslint-plugin-v0.0.138) (2024-12-03)

## [0.0.137](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.136...@sber-orm/eslint-plugin-v0.0.137) (2024-12-03)

## [0.0.136](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.135...@sber-orm/eslint-plugin-v0.0.136) (2024-12-03)

## [0.0.135](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.134...@sber-orm/eslint-plugin-v0.0.135) (2024-12-03)

## [0.0.134](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.133...@sber-orm/eslint-plugin-v0.0.134) (2024-12-03)

## [0.0.133](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.132...@sber-orm/eslint-plugin-v0.0.133) (2024-12-02)

## [0.0.132](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.131...@sber-orm/eslint-plugin-v0.0.132) (2024-12-02)

## [0.0.131](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.130...@sber-orm/eslint-plugin-v0.0.131) (2024-12-02)

## [0.0.130](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.129...@sber-orm/eslint-plugin-v0.0.130) (2024-11-28)

## [0.0.129](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.128...@sber-orm/eslint-plugin-v0.0.129) (2024-11-28)

## [0.0.128](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.127...@sber-orm/eslint-plugin-v0.0.128) (2024-11-27)

## [0.0.127](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.126...@sber-orm/eslint-plugin-v0.0.127) (2024-11-27)

## [0.0.126](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.125...@sber-orm/eslint-plugin-v0.0.126) (2024-11-26)

## [0.0.125](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.124...@sber-orm/eslint-plugin-v0.0.125) (2024-11-25)

## [0.0.124](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.123...@sber-orm/eslint-plugin-v0.0.124) (2024-11-20)

## [0.0.123](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.122...@sber-orm/eslint-plugin-v0.0.123) (2024-11-19)

## [0.0.122](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.121...@sber-orm/eslint-plugin-v0.0.122) (2024-11-18)

## [0.0.121](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.120...@sber-orm/eslint-plugin-v0.0.121) (2024-11-14)

## [0.0.120](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.119...@sber-orm/eslint-plugin-v0.0.120) (2024-11-14)

## [0.0.119](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.118...@sber-orm/eslint-plugin-v0.0.119) (2024-11-12)

## [0.0.118](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.117...@sber-orm/eslint-plugin-v0.0.118) (2024-11-12)

## [0.0.117](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.116...@sber-orm/eslint-plugin-v0.0.117) (2024-11-12)

## [0.0.116](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.115...@sber-orm/eslint-plugin-v0.0.116) (2024-11-08)

## [0.0.115](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.114...@sber-orm/eslint-plugin-v0.0.115) (2024-11-07)

## [0.0.114](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.113...@sber-orm/eslint-plugin-v0.0.114) (2024-11-07)

## [0.0.113](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.112...@sber-orm/eslint-plugin-v0.0.113) (2024-11-07)

## [0.0.112](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.111...@sber-orm/eslint-plugin-v0.0.112) (2024-11-07)

## [0.0.111](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.110...@sber-orm/eslint-plugin-v0.0.111) (2024-11-06)

## [0.0.110](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.109...@sber-orm/eslint-plugin-v0.0.110) (2024-11-05)

## [0.0.109](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.108...@sber-orm/eslint-plugin-v0.0.109) (2024-11-05)

## [0.0.108](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.107...@sber-orm/eslint-plugin-v0.0.108) (2024-11-02)

## [0.0.107](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.106...@sber-orm/eslint-plugin-v0.0.107) (2024-11-02)

## [0.0.106](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.105...@sber-orm/eslint-plugin-v0.0.106) (2024-11-01)

## [0.0.105](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.104...@sber-orm/eslint-plugin-v0.0.105) (2024-11-01)

## [0.0.104](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.103...@sber-orm/eslint-plugin-v0.0.104) (2024-10-31)

## [0.0.103](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.102...@sber-orm/eslint-plugin-v0.0.103) (2024-10-29)

## [0.0.102](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.101...@sber-orm/eslint-plugin-v0.0.102) (2024-10-28)

## [0.0.101](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.100...@sber-orm/eslint-plugin-v0.0.101) (2024-10-28)

## [0.0.100](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.99...@sber-orm/eslint-plugin-v0.0.100) (2024-10-28)

## [0.0.99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.98...@sber-orm/eslint-plugin-v0.0.99) (2024-10-28)

## [0.0.98](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.97...@sber-orm/eslint-plugin-v0.0.98) (2024-10-25)

## [0.0.97](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.96...@sber-orm/eslint-plugin-v0.0.97) (2024-10-25)

## [0.0.96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.95...@sber-orm/eslint-plugin-v0.0.96) (2024-10-25)

## [0.0.95](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.94...@sber-orm/eslint-plugin-v0.0.95) (2024-10-24)

## [0.0.94](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.93...@sber-orm/eslint-plugin-v0.0.94) (2024-10-24)

## [0.0.93](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.92...@sber-orm/eslint-plugin-v0.0.93) (2024-10-24)

## [0.0.92](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.91...@sber-orm/eslint-plugin-v0.0.92) (2024-10-24)

## [0.0.91](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.90...@sber-orm/eslint-plugin-v0.0.91) (2024-10-24)

## [0.0.90](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.89...@sber-orm/eslint-plugin-v0.0.90) (2024-10-24)

## [0.0.89](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.88...@sber-orm/eslint-plugin-v0.0.89) (2024-10-23)

## [0.0.88](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.87...@sber-orm/eslint-plugin-v0.0.88) (2024-10-23)

## [0.0.87](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.86...@sber-orm/eslint-plugin-v0.0.87) (2024-10-23)

## [0.0.86](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.85...@sber-orm/eslint-plugin-v0.0.86) (2024-10-22)

## [0.0.85](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.84...@sber-orm/eslint-plugin-v0.0.85) (2024-10-21)

## [0.0.84](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.83...@sber-orm/eslint-plugin-v0.0.84) (2024-10-21)

## [0.0.83](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.82...@sber-orm/eslint-plugin-v0.0.83) (2024-10-21)

## [0.0.82](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.81...@sber-orm/eslint-plugin-v0.0.82) (2024-10-21)

## [0.0.81](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.80...@sber-orm/eslint-plugin-v0.0.81) (2024-10-21)

## [0.0.80](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.79...@sber-orm/eslint-plugin-v0.0.80) (2024-10-18)

## [0.0.79](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.78...@sber-orm/eslint-plugin-v0.0.79) (2024-10-18)

## [0.0.78](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.77...@sber-orm/eslint-plugin-v0.0.78) (2024-10-17)

## [0.0.77](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.76...@sber-orm/eslint-plugin-v0.0.77) (2024-10-17)

## [0.0.76](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.75...@sber-orm/eslint-plugin-v0.0.76) (2024-10-16)

## [0.0.75](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.74...@sber-orm/eslint-plugin-v0.0.75) (2024-10-16)

## [0.0.74](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.73...@sber-orm/eslint-plugin-v0.0.74) (2024-10-15)

## [0.0.73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.72...@sber-orm/eslint-plugin-v0.0.73) (2024-10-14)

## [0.0.72](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.71...@sber-orm/eslint-plugin-v0.0.72) (2024-10-14)

## [0.0.71](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.70...@sber-orm/eslint-plugin-v0.0.71) (2024-10-14)

## [0.0.70](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.69...@sber-orm/eslint-plugin-v0.0.70) (2024-10-14)

## [0.0.69](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.68...@sber-orm/eslint-plugin-v0.0.69) (2024-10-14)

## [0.0.68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.67...@sber-orm/eslint-plugin-v0.0.68) (2024-10-09)

## [0.0.67](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.66...@sber-orm/eslint-plugin-v0.0.67) (2024-10-08)

## [0.0.66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.65...@sber-orm/eslint-plugin-v0.0.66) (2024-10-03)

## [0.0.65](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.64...@sber-orm/eslint-plugin-v0.0.65) (2024-10-02)

## [0.0.64](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.63...@sber-orm/eslint-plugin-v0.0.64) (2024-09-30)

## [0.0.63](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.62...@sber-orm/eslint-plugin-v0.0.63) (2024-09-30)

## [0.0.62](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.61...@sber-orm/eslint-plugin-v0.0.62) (2024-09-27)

## [0.0.61](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.60...@sber-orm/eslint-plugin-v0.0.61) (2024-09-27)

## [0.0.60](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.59...@sber-orm/eslint-plugin-v0.0.60) (2024-09-27)

## [0.0.59](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.58...@sber-orm/eslint-plugin-v0.0.59) (2024-09-27)

## [0.0.58](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.57...@sber-orm/eslint-plugin-v0.0.58) (2024-09-27)

## [0.0.57](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.56...@sber-orm/eslint-plugin-v0.0.57) (2024-09-27)

## [0.0.56](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.55...@sber-orm/eslint-plugin-v0.0.56) (2024-09-26)

## [0.0.55](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.54...@sber-orm/eslint-plugin-v0.0.55) (2024-09-26)

## [0.0.54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.53...@sber-orm/eslint-plugin-v0.0.54) (2024-09-25)

## [0.0.53](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.52...@sber-orm/eslint-plugin-v0.0.53) (2024-09-24)

## [0.0.52](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.51...@sber-orm/eslint-plugin-v0.0.52) (2024-09-23)

## [0.0.51](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.50...@sber-orm/eslint-plugin-v0.0.51) (2024-09-23)

## [0.0.50](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.49...@sber-orm/eslint-plugin-v0.0.50) (2024-09-16)

## [0.0.49](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.48...@sber-orm/eslint-plugin-v0.0.49) (2024-09-09)

## [0.0.48](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.47...@sber-orm/eslint-plugin-v0.0.48) (2024-09-09)

## [0.0.47](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.46...@sber-orm/eslint-plugin-v0.0.47) (2024-09-06)

## [0.0.46](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.45...@sber-orm/eslint-plugin-v0.0.46) (2024-09-06)

## [0.0.45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.44...@sber-orm/eslint-plugin-v0.0.45) (2024-09-05)

## [0.0.44](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.43...@sber-orm/eslint-plugin-v0.0.44) (2024-09-04)

## [0.0.43](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.42...@sber-orm/eslint-plugin-v0.0.43) (2024-09-04)

## [0.0.42](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.41...@sber-orm/eslint-plugin-v0.0.42) (2024-09-03)

## [0.0.41](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.40...@sber-orm/eslint-plugin-v0.0.41) (2024-09-03)

## [0.0.40](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.39...@sber-orm/eslint-plugin-v0.0.40) (2024-09-03)

## [0.0.39](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.38...@sber-orm/eslint-plugin-v0.0.39) (2024-09-02)

## [0.0.38](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.37...@sber-orm/eslint-plugin-v0.0.38) (2024-09-02)

## [0.0.37](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.36...@sber-orm/eslint-plugin-v0.0.37) (2024-08-30)

## [0.0.36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.35...@sber-orm/eslint-plugin-v0.0.36) (2024-08-30)

## [0.0.35](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.34...@sber-orm/eslint-plugin-v0.0.35) (2024-08-30)

## [0.0.34](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.31...@sber-orm/eslint-plugin-v0.0.34) (2024-08-30)

## [0.0.33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.32...@sber-orm/eslint-plugin-v0.0.33) (2024-08-29)

## [0.0.32](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.31...@sber-orm/eslint-plugin-v0.0.32) (2024-08-29)

## [0.0.31](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.30...@sber-orm/eslint-plugin-v0.0.31) (2024-08-29)

## [0.0.30](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.29...@sber-orm/eslint-plugin-v0.0.30) (2024-08-28)

## [0.0.29](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.28...@sber-orm/eslint-plugin-v0.0.29) (2024-08-26)

## [0.0.28](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.27...@sber-orm/eslint-plugin-v0.0.28) (2024-08-26)

## [0.0.27](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.26...@sber-orm/eslint-plugin-v0.0.27) (2024-08-23)

## [0.0.26](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.25...@sber-orm/eslint-plugin-v0.0.26) (2024-08-23)

## [0.0.25](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.24...@sber-orm/eslint-plugin-v0.0.25) (2024-08-22)

## [0.0.24](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.23...@sber-orm/eslint-plugin-v0.0.24) (2024-08-22)

## [0.0.23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.22...@sber-orm/eslint-plugin-v0.0.23) (2024-08-22)

## [0.0.22](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.21...@sber-orm/eslint-plugin-v0.0.22) (2024-08-21)

## [0.0.21](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.20...@sber-orm/eslint-plugin-v0.0.21) (2024-08-21)

## [0.0.20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.19...@sber-orm/eslint-plugin-v0.0.20) (2024-08-21)

## [0.0.19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.18...@sber-orm/eslint-plugin-v0.0.19) (2024-08-21)

## [0.0.18](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.17...@sber-orm/eslint-plugin-v0.0.18) (2024-08-21)

## [0.0.17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.16...@sber-orm/eslint-plugin-v0.0.17) (2024-08-21)

## [0.0.16](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.15...@sber-orm/eslint-plugin-v0.0.16) (2024-08-20)

## [0.0.15](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.14...@sber-orm/eslint-plugin-v0.0.15) (2024-08-19)

## [0.0.14](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.13...@sber-orm/eslint-plugin-v0.0.14) (2024-08-16)

## [0.0.13](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.12...@sber-orm/eslint-plugin-v0.0.13) (2024-08-16)

## [0.0.12](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.11...@sber-orm/eslint-plugin-v0.0.12) (2024-08-09)

## [0.0.11](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.10...@sber-orm/eslint-plugin-v0.0.11) (2024-08-09)

## [0.0.10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.9...@sber-orm/eslint-plugin-v0.0.10) (2024-08-09)

## [0.0.9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.8...@sber-orm/eslint-plugin-v0.0.9) (2024-08-08)

## [0.0.8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.7...@sber-orm/eslint-plugin-v0.0.8) (2024-08-08)

## [0.0.7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.6...@sber-orm/eslint-plugin-v0.0.7) (2024-08-07)

## [0.0.6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.5...@sber-orm/eslint-plugin-v0.0.6) (2024-08-07)

## [0.0.5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.4...@sber-orm/eslint-plugin-v0.0.5) (2024-08-07)

## [0.0.4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/eslint-plugin-v0.0.3...@sber-orm/eslint-plugin-v0.0.4) (2024-08-07)

## 0.0.3 (2024-08-06)

## 0.0.2 (2024-08-05)
