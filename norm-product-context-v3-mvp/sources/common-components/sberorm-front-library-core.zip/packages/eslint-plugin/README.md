# @sber-orm/eslint-plugin

Плагин для ESLint.

## установка

`$ npm i -D @sber-orm/eslint-plugin`

## использование

### Полная конфигурация

Рекомендуется для новых проектов или если вы хотите увидеть все ошибки и предупреждения ESLint для существующих проектов.

Добавьте `@sber-orm` в раздел `extends` или `plugins` вашего файла конфигурации `.eslintrc`.

`.eslintrc`

```json
{
  "parser": "@typescript-eslint/parser",
  "parserOptions": {
    "ecmaVersion": 13,
    "sourceType": "module",
    "ecmaFeatures": {
      "jsx": true,
      "modules": true,
      "experimentalObjectRestSpread": true
    }
  },
  "ignorePatterns": ["**/*", "node_modules"],
  "settings": {
    "react": {
      "pragma": "React",
      "fragment": "Fragment",
      "version": "detect"
    },
    "import/resolver": {
      "typescript": {
        "alwaysTryTypes": true
      }
    }
  },
  "extends": ["plugin:@sber-orm/recommended"],
  "plugins": ["@sber-orm"]
}
```

### Постепенные улучшения

Если у вас есть существующий проект большой/старый/и т. д., вы можете применить настройку конфигурации `@sber-orm` постепенно:

- plugin:@sber-orm/common
- plugin:@sber-orm/prettier
- plugin:@sber-orm/import
- plugin:@sber-orm/simpleImportSort
- plugin:@sber-orm/react
- plugin:@sber-orm/promise
- plugin:@sber-orm/unicorn
- plugin:@sber-orm/sonarjs
- plugin:@sber-orm/typescript
- plugin:@sber-orm/perfectionist

```
{
  ...
  "extends": [
    "plugin:@sber-orm/common",
    "plugin:@sber-orm/prettier",
    ...
  ],
  "plugins": [
    "@sber-orm"
  ]
}
```
