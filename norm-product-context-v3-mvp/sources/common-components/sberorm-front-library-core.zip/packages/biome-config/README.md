# @sber-orm/biome-config

Общий конфиг для biome.

## установка

`$ npm i -D @sber-orm/biome-config`

## использование

`biome.json`

```json
{
  "extends": ["@sber-orm/biome-config"],
  "ignorePatterns": [
    "node_modules/",
    "dist/",
    ".biome.json",
    ".vscode",
    ".idea",
    "public",
    "*.config.js"
  ]
}
```
