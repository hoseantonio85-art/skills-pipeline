# Changelog

## 1.22.0 (2026-06-04)

## 1.21.0 (2026-06-02)

## 1.20.0 (2026-06-01)

## 1.19.0 (2026-06-01)

## 1.18.0 (2026-05-29)

## 1.17.0 (2026-05-20)

## 1.16.0 (2026-05-06)

## 1.15.0 (2026-04-22)

## 1.14.0 (2026-04-22)

## 1.13.0 (2026-04-15)

## 1.12.0 (2026-04-14)

## 1.11.0 (2026-04-13)

## 1.10.0 (2026-04-07)

## 1.9.0 (2026-04-06)

## 1.8.0 (2026-04-03)

## 1.7.0 (2026-04-03)

## 1.6.0 (2026-04-03)

## 1.5.0 (2026-03-26)

## 1.4.0 (2026-03-26)

## 1.3.0 (2026-03-26)

* Pull request #462: Feature/GMRT-131/npm package type ([72d36de](https://stash.sigma.sbrf.ru:7999/sberorm/sberorm-front-lib-core/commits/72d36de)), closes [#462](https://stash.sigma.sbrf.ru:7999/sberorm/sberorm-front-lib-core/issues/462)

## 1.2.0 (2026-03-25)

## 1.1.0 (2026-03-25)

* feat: [GMRT-131] Add releasing components ([87d0b7b](https://stash.sigma.sbrf.ru:7999/sberorm/sberorm-front-lib-core/commits/87d0b7b))
