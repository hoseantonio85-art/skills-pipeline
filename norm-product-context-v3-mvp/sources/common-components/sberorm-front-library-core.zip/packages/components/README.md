# @sber-orm/components

Общие компоненты СберОРМ.

## установка

`$ npm i -D @sber-orm/components`
или
`$ yarn add @sber-orm/components`

## использование

1. Импортировать стили

```scss
@import "@sber-orm/components/src/colors.module.scss";
@import "@sber-orm/components/style.css";
```

2. Импортировать компонент `<файл компонента>.tsx`

```ts
import { TrackProvider } from "@sber-orm/components";
```

## разработка

1. Установить зависимости из папки components
   `yarn install`
2. Запустить сторибук
   `npm run storybook`
