# GIGACODE.md — Руководство по проекту @sber-orm/components

## 📋 Обзор проекта

Это **React UI Component Library** — библиотека общих компонентов для проектов СберОРМ. Проект представляет собой публичную NPM-пакетную библиотеку с открытым исходным кодом.

**Основные характеристики:**
- **Тип проекта:** React UI Component Library (TypeScript)
- **Версия:** 0.228.0 (по состоянию на март 2026 г.)
- **Репозиторий:** https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core.git
- **Пакет:** `@sber-orm/components`
- **Структура:** Monorepo (пакет components в workspace)

### Технологический стек

| Категория | Технология | Версия |
|-----------|-----------|--------|
| **Core** | React | ^18.3.1 |
| **Core** | ReactDOM | ^18.3.1 |
| **Language** | TypeScript | * |
| **Build Tool** | Vite | ^6.0.0-alpha.18 |
| **Build Tool** | TSUP | ^8.0.2 |
| **Testing** | Vitest | ^3.0.4 |
| **Testing** | React Testing Library | ^16.2.0 |
| **Storybook** | Storybook | ^8.2.6 |
| **Styles** | Sass/SCSS | ^1.77.8 |
| **Icons** | @sber-orm/ui-kit | * |
| **i18n** | i18next | ^23.11.5 |
| **Date** | dayjs | 1.11.13 |
| **Code Quality** | Biome | 2.3.11 |
| **Tracking** | @sbol/clickstream-agent | 0.9.1 |

---

## 🏗️ Архитектура проекта

### Структура папок

```
src/
├── @types/                          # TypeScript-типы и декларации
│   ├── api.ts                       # Автогенерированные типы из Swagger API
│   └── vite-env.d.ts              # Декларации Vite (SVGR, SCSS)
│
├── components/                      # 📦 UI-компоненты (14 групп)
│   ├── Clickstream/                 # Система трекинга событий
│   ├── ConfirmationModal/           # Модальное окно подтверждения
│   ├── Drawer/                      # Выдвижная панель
│   ├── ErrorBoundary/               # Обработка ошибок рендеринга
│   ├── Fields/                      # Поля форм (22 компонента)
│   ├── File/                        # Работа с файлами
│   ├── ModalDialog/                 # Базовое модальное окно
│   ├── ModalFactory/                # Фабрика модальных окон
│   ├── ModalLayout/                 # Макет модального окна
│   ├── PortalDialog/                # Компонент Portal
│   ├── Search/                      # Поле поиска
│   ├── TitleBlock/                  # Блок заголовка
│   ├── UploadFileButton/            # Кнопка загрузки файлов
│   ├── ViewMessages/                # Отображение уведомлений
│   └── WorkflowActions/             # Действия по workflow
│
├── i18n/                            # Локализация (i18next)
│   ├── locales/                     # Файлы переводов
│   ├── config.ts                    # Конфигурация i18next
│   └── index.ts                     # Инициализация
│
├── stories/                         # Storybook-истории (81 файл)
│   └── *.stories.tsx                # Story для каждого компонента
│
├── utils/                           # Утилиты (без состояния)
│   ├── validators/                  # Валидаторы полей
│   ├── const.ts                     # Константы
│   ├── date.ts                      # Утилиты работы с датами
│   ├── field.ts                     # Конвертация полей для API
│   ├── fileSaver.ts                 # Сохранение файлов
│   ├── safeLoadable.tsx             # Ленивая загрузка компонентов
│   └── index.ts                     # Экспорт
│
└── index.ts                         # Осевой экспорт: components + utils
```

### Распределение ролей по слоям

| Слой | Назначение | Ключевые файлы |
|------|-----------|----------------|
| **Component Layer** | UI-компоненты | `src/components/**/*.tsx` |
| **Utility Layer** | Чистые функции | `src/utils/*.ts(x)` |
| **I18n Layer** | Локализация | `src/i18n/*` |
| **API Types Layer** | TypeScript-типы | `src/@types/api.ts` |
| **State Management** | Context API | `src/components/**/Context.ts`, `provider/` |

---

## 🚀 Сборка и запуск

### Установка зависимостей

```bash
npm install
# или
yarn install
```

### Запуск в режиме разработки

```bash
# Запуск Storybook (dev-сервер на порту 6006)
npm run storybook
# или
npm start
```

### Сборка для продакшена

```bash
# Полная сборка (Vite + TSUP + типы)
npm run build

# Сборка типов отдельно
npm run build:types
```

### Тестирование

```bash
# Unit-тесты
npm run test

# UI-тесты (Storybook + E2E)
npm run test:ui
```

### Качество кода

```bash
# Линтинг (Biome)
npm run lint

# Проверка типов TypeScript
npm run lint:ts

# Форматирование
npm run format
```

### Релизы

```bash
# Тестовый релиз (dry-run)
npm run debug:release

# Реальный релиз
npm run release
```

---

## 📦 Экспорты и использование

### Основной экспорт (`index.ts`)

```typescript
export * from './components';
export * from './utils';
```

### Импорт компонентов

```typescript
// Именованный импорт компонентов
import { 
  InputField, 
  DateField, 
  CurrencyField,
  ModalDialog,
  ErrorBoundary,
  UploadFileButton,
  WorkflowActions
} from '@sber-orm/components';

// Импорт всех полей через карту
import { fields } from '@sber-orm/components';
const { input, date, currency } = fields;

// Импорт утилит
import { 
  validatorsSchema, 
  fieldNotEmpty, 
  convertToSearchPayload,
  safeLoadable 
} from '@sber-orm/components';
```

### Доступные компоненты (14 групп)

1. **Clickstream** — трекинг событий (`TrackProvider`)
2. **ConfirmationModal** — модальное окно подтверждения
3. **Drawer** — выдвижная панель
4. **ErrorBoundary** — обработка ошибок рендеринга
5. **Fields** — 22 компонента полей форм:
   - `ArrayListField`, `BooleanSwitcher`, `CheckboxField`
   - `CurrencyField`, `CurrencyRangeField`
   - `DateField`, `DateRangeField`, `NewDateRangeField`
   - `InputField`, `InputNumberField`, `InputListField`
   - `ListField`, `MultiSwitcherField`, `MultiTreeField`
   - `SeverityField`, `SeverityMultiSwitcherField`
   - `SwitcherField`, `TextareaField`, `ToggleField`
   - `TreeField`, `TogglerMogglerField`, `DeadlineStagesField`
6. **File** — отображение файлов
7. **ModalDialog** — базовое модальное окно
8. **ModalFactory** — фабрика модальных окон
9. **ModalLayout** — макет модального окна с навигацией
10. **PortalDialog** — компонент Portal
11. **Search** — поле поиска
12. **TitleBlock** — блок заголовка
13. **UploadFileButton** — кнопка загрузки файлов
14. **ViewMessages** — отображение уведомлений (Alert)
15. **WorkflowActions** — действия по workflow

### Доступные утилиты

| Модуль | Назначение |
|--------|-----------|
| `validators/*` | Валидаторы (required, max, min, regex, dateInPast и др.) |
| `field.ts` | Конвертация полей в payload для API (`convertToSearchPayload`) |
| `date.ts` | Форматирование дат |
| `fileSaver.ts` | Сохранение файлов |
| `safeLoadable.tsx` | Ленивая загрузка компонентов с retry-логикой |
| `const.ts` | Константы (MAX_FILE_SIZE, ALLOWED_EXTENSIONS) |

---

## 🎨 Стили и темы

### Импорт стилей

```scss
@import "@sber-orm/components/src/colors.module.scss";
@import "@sber-orm/components/style.css";
```

---

## 🌐 Локализация (i18n)

Проект использует `i18next` с `react-i18next`:

- **Язык по умолчанию:** `ru` (русский)
- **Namespace по умолчанию:** `common`
- **Файлы переводов:** `src/i18n/locales/ru/common.json`

### Использование в компонентах

```typescript
import { useTranslation } from 'react-i18next';

const MyComponent = () => {
  const { t } = useTranslation(['common', 'workflow', 'errors']);
  
  return <div>{t('common:someKey')}</div>;
};
```

---

## 📊 Трекинг событий (ClickStream)

### Инициализация

```typescript
import { ClickStreamProvider } from '@sber-orm/components';

<ClickStreamProvider
  appBlockName="app-name"
  clickStreamEnabled={true}
  clickStreamKey="key"
  clickStreamUrl="url"
  tenantId="tenant"
  userInfo={userInfo}
>
  <App />
</ClickStreamProvider>
```

---

## ⚙️ Конфигурационные файлы

| Файл | Назначение |
|------|-----------|
| `vite.config.ts` | Конфигурация Vite (сборка для Storybook + многоточечная сборка) |
| `tsup.config.ts` | Конфигурация TSUP (сборка ESM-пакета) |
| `tsconfig.json` | Настройки TypeScript (extends @sber-orm/tsconfig-config) |
| `biome.json` | Настройки линтинга (extends @sber-orm/biome-config) |
| `.lintstagedrc.json` | Хуки Git pre-commit |
| `.release-it.cjs` | Настройки автоматического релиза |
| `.storybook/main.ts` | Конфигурация Storybook |
| `.swcrc` | Конфигурация SWC |

### Ключевые настройки Vite

```typescript
// Внешние зависимости (не инклюдятся в бандл)
external: ['react', 'react-dom', 'react/jsx-runtime', /^react(\/.*)?$/]

// Режимы сборки
// development: dev-сервер на порту 6006
// production: оптимизированный бандл
```

---

## 🧪 Тестирование

### Unit-тесты

- **Инструмент:** Vitest
- **Окружение:** happy-dom (имитация браузера)
- **Покрытие:** Istanbul

```bash
npm run test
```

### UI-тесты

```bash
npm run test:ui
# Сначала собирает Storybook, затем запускает E2E-тесты
```

### Тестовые файлы

- `src/utils/**/*.test.ts(x)` — unit-тесты утилит
- `src/stories/*.stories.tsx` — Storybook-истории
- `src/components/**/*test.ts(x)` — интеграционные тесты

---

## 📝 Development Conventions

### Стиль кода

- **Язык:** TypeScript (строгая типизация)
- **Форматирование:** Biome (автоформатирование при коммите)
- **JSX:** React 18 (jsx: react-jsx)
- **Styles:** SCSS modules (`styles.module.scss`)

### Структура компонентов

Каждый компонент в отдельной папке:

```
ComponentName/
├── ComponentName.tsx        # Основной компонент
├── types.ts                 # TypeScript-типы
├── index.ts                 # Экспорт
└── styles.module.scss       # Стили (module)
```

### Паттерны управления состоянием

- **Context API** — глобальное состояние (ClickStream, Modal)
- **useReducer** — сложная логика состояния (ModalFactory)
- **useRef/useEffect** — побочные эффекты
- **Хуки** — логика компонентов (useTracking, useModalManager)

### Валидация

- **Схема:** `validatorsSchema` в `src/utils/validators/index.ts`
- **Поддерживаемые правила:** required, max, min, regex, dateInPast, equalsValue и др.
- **Файлы валидации файлов:** `src/components/File/validate.ts`

---

## 🔗 Интеграция с API

Проект использует TypeScript-типы, сгенерированные из Swagger-спецификации:

```typescript
// Основные типы из @types/api.ts
import { 
  FormComponent,     // Компонент формы
  FormField,         // Поле формы
  FilterParam,       // Параметр фильтрации
  WorkflowAction,    // Действие workflow
  ObjectField        // Объект поля данных
} from '@sber-orm/components';
```

### Конвертация полей

```typescript
import { convertToSearchPayload } from '@sber-orm/components';

const payload = convertToSearchPayload(fields);
// Возвращает массив FilterParam для API
```

---

## 📦 Release workflow

### Автоматический релиз

```bash
npm run release
# Выполняет:
# 1. release-it с параметрами CI
# 2. Сборку типов (release:types)
```

### Конфигурация

Релиз настроен через `@sber-orm/config-release-it/.release-it.workspace.js`:

- Автоматическая генерация CHANGELOG.md
- Увеличение версии (semver)
- Публикация в NPM
- Создание Git-тега

---

## 🎯 Стратегия разработки

### При добавлении нового компонента

1. Создать папку `src/components/ComponentName/`
2. Добавить `ComponentName.tsx`, `types.ts`, `index.ts`, `styles.module.scss`
3. Добавить story в `src/stories/ComponentName.stories.tsx`
4. Экспортировать в `src/components/index.ts`
5. Добавить валидацию (если требуется) в `src/utils/validators/`

### При изменении типов API

1. Обновить `src/@types/api.ts` (автогенерация из Swagger)
2. Обновить компоненты, использующие измененные типы
3. Запустить `npm run lint:ts` для проверки типов

---

## 📚 Дополнительные ресурсы

- **Документация в .ai/** — AI-ориентированные документы:
  - `.ai/PROJECT_OVERVIEW.md` — Общий обзор проекта
  - `.ai/ARCHITECTURE.md` — Подробная архитектура
- **Storybook** — `npm run storybook` (localhost:6006)
- **CHANGELOG.md** — История изменений версий

---

**Генерировано автоматически для GigaCode AI-ассистента.**
