import fs from 'node:fs';
import path from 'node:path';
import react from '@vitejs/plugin-react-swc';
import { defineConfig } from 'vite';
import { checker } from 'vite-plugin-checker';
import svgr from 'vite-plugin-svgr';

const getComponentList = () => {
  const componentsDir = path.resolve(__dirname, 'src/components');
  if (!fs.existsSync(componentsDir)) {
    return [];
  }

  const components = fs
    .readdirSync(componentsDir)
    .filter((item) => {
      const itemPath = path.join(componentsDir, item);
      return (
        fs.statSync(itemPath).isDirectory() &&
        fs.existsSync(path.join(itemPath, 'index.ts'))
      );
    })
    .sort();

  return components;
};

const componentList = getComponentList();

export default defineConfig(({ mode }) => {
  const isProduction = mode === 'production';
  return {
    build: {
      copyPublicDir: false,
      rollupOptions: {
        external: [
          'react',
          'react-dom',
          'react/jsx-runtime',
          /^react(\/.*)?$/,
          /^react-dom(\/.*)?$/,
          /^react-dom(\/.*)?$/,
          /^react-dom\/(server|client)(\/.*)?$/,
          /^react-dom\/server-legacy(\/.*)?$/,
          'react-dom/server',
          'react-dom/server.browser',
          'react-dom/server-legacy',
          'react-dom/server-legacy.browser',
        ],
        input: {
          index: path.resolve(__dirname, 'src/index.ts'),
          ...Object.fromEntries(
            componentList.map((component) => [
              `components/${component}/index`,
              path.resolve(__dirname, `src/components/${component}/index.ts`),
            ]),
          ),
        },
        output: {
          hoistTransitiveImports: false,
          preserveModules: false,
          preserveModulesRoot: 'src',
          exports: 'named',
          entryFileNames: '[name].js',
          chunkFileNames: 'chunks/[name]-[hash].js',
          assetFileNames: (assetInfo) => {
            if (assetInfo.name?.endsWith('.css')) {
              return 'index.css';
            }
            return 'assets/[name]-[hash][extname]';
          },
          globals: {
            react: 'React',
            'react-dom': 'ReactDOM',
            'react/jsx-runtime': 'jsxRuntime',
          },
          manualChunks: (id) => {
            if (id.includes('node_modules')) {
              if (id.includes('react') || id.includes('react-dom')) {
                if (id.includes('server') || id.includes('legacy')) {
                  return null;
                }
                return 'vendor-react';
              }
              if (id.includes('dayjs')) {
                return 'vendor-dayjs';
              }
              if (id.includes('classnames')) {
                return 'vendor-utils';
              }
              return 'vendor-other';
            }
            if (id.includes('src/utils/')) {
              return 'shared-utils';
            }
            if (id.includes('src/constants/')) {
              return 'shared-constants';
            }
          },
        },
      },
      lib: {
        entry: path.resolve(__dirname, 'src/index.ts'),
        name: 'components',
        formats: ['es'],
      },
      target: 'es2020',
      outDir: 'dist',
      sourcemap: isProduction,
      minify: isProduction ? 'esbuild' : false,
      reportCompressedSize: true,
      emptyOutDir: true,
    },
    css: {
      preprocessorOptions: {
        scss: {
          api: 'modern',
        },
        sass: {
          api: 'modern',
        },
      },
    },
    server: {
      port: 6006,
    },
    plugins: [
      react(),
      checker({
        typescript: true,
      }),
      svgr({
        exportAsDefault: true,
        svgrOptions: {
          plugins: ['@svgr/plugin-svgo', '@svgr/plugin-jsx'],
          svgoConfig: {
            plugins: [
              {
                name: 'removeViewBox',
                active: false,
              },
            ],
          },
        },
      }),
    ],
    test: {
      environment: 'happy-dom', // Использование jsdom для имитации браузерного окружения
      coverage: {
        enabled: true,
        provider: 'istanbul',
        extension: ['.ts'],
      },
    },
  };
});
