import type { ReactElement } from 'react';

import classes from './styles.module.scss';

interface IContainerProperties {
  children?: ReactElement | ReactElement[];
}

export const Container = ({ children }: IContainerProperties) => (
  <div className={classes.container}>{children}</div>
);

interface IItemProperties {
  height?: number;
  label?: string;
  children: ReactElement;
  width?: number;
  fullWidth?: boolean;
}

export const Item = ({
  children,
  fullWidth,
  height,
  label,
  width,
}: IItemProperties) => (
  <div
    className={classes.item}
    style={{ height: `${height}px`, width: fullWidth ? '100%' : `${width}px` }}
  >
    {children}
    <label className={classes.label}>{label}</label>
  </div>
);
