import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const CurrencyRangeField = fields.currencyRange;

const meta: Meta<typeof CurrencyRangeField> = {
  args: {
    fieldConfig: {
      title: 'Сумма компенсации потери',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: CurrencyRangeField,
  title: 'components/CurrencyRange',
};

export default meta;

export const CurrencyRange: StoryFn<typeof CurrencyRangeField> = (
  arguments_,
) => {
  const [value, setValue] = useState<[number | undefined, number | undefined]>([
    123, 7777777,
  ]);

  return (
    <Container>
      <Item label='Default' width={512}>
        <CurrencyRangeField
          {...arguments_}
          onChange={(val) => setValue(val)}
          field={{ value: value as [number, number] }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <CurrencyRangeField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value: value as [number, number] }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <CurrencyRangeField
          {...arguments_}
          raw
          field={{ value: value as [number, number] }}
        />
      </Item>
    </Container>
  );
};
