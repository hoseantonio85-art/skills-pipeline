import { Meta, StoryFn } from '@storybook/react';
import { useState } from 'react';

import { Search as SearchComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof SearchComponent> = {
  args: {},
  component: SearchComponent,
  title: 'components/Search',
};

export default meta;

export const Search: StoryFn<typeof SearchComponent> = (arguments_) => {
  const [value, setValue] = useState('');

  function handleChange(term: string) {
    setValue(term);
  }

  function handleSubmit() {
    setValue('');
  }

  return (
    <Container>
      <Item label='Default' width={400}>
        <SearchComponent
          {...arguments_}
          value={value}
          onChange={handleChange}
          onSubmit={handleSubmit}
        />
      </Item>
      <Item label='Loading' width={400}>
        <SearchComponent
          {...arguments_}
          value={value}
          onChange={handleChange}
          onSubmit={handleSubmit}
          loading
        />
      </Item>
      <Item label='Default with placeholder' width={400}>
        <SearchComponent
          {...arguments_}
          value={value}
          onChange={handleChange}
          onSubmit={handleSubmit}
          placeholder='Search'
        />
      </Item>
      <Item label='With label' width={400}>
        <SearchComponent
          {...arguments_}
          value={value}
          onChange={handleChange}
          onSubmit={handleSubmit}
          label='Label'
          placeholder='Search'
          secondary={false}
        />
      </Item>
      <Item label='Disabled' width={400}>
        <SearchComponent
          {...arguments_}
          value={value}
          onChange={handleChange}
          onSubmit={handleSubmit}
          disabled
        />
      </Item>
    </Container>
  );
};
