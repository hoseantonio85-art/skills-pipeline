import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const CheckboxField = fields.checkbox;

const meta: Meta<typeof CheckboxField> = {
  args: {
    fieldConfig: {
      title: 'Вкл/Выкл',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: CheckboxField,
  title: 'components/Checkbox',
};

export default meta;

export const Checkbox: StoryFn<typeof CheckboxField> = (arguments_) => {
  const [value, setValue] = useState<boolean>(true);

  return (
    <Container>
      <Item label='Default' width={512}>
        <CheckboxField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <CheckboxField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <CheckboxField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
