import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const TextareaField = fields.textarea;

const meta: Meta<typeof TextareaField> = {
  args: {
    fieldConfig: {
      title: 'Номер бухгалтерского докумена',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: TextareaField,
  title: 'components/Textarea',
};

export default meta;

export const Textarea: StoryFn<typeof TextareaField> = (arguments_) => {
  const [value, setValue] = useState<string | undefined>('FU-12313-4123');

  return (
    <Container>
      <Item label='Default' width={512} height={156}>
        <TextareaField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512} height={156}>
        <TextareaField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <TextareaField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
