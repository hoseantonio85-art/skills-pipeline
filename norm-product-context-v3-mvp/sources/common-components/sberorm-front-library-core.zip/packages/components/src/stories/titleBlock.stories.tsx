import { Meta, StoryFn } from '@storybook/react';

import { TitleBlock as TitleBlockComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof TitleBlockComponent> = {
  argTypes: {
    size: {
      control: { type: 'radio' },
      options: ['sm', 'md'],
    },
  },
  args: {},
  component: TitleBlockComponent,
  title: 'components/TitleBlock',
};

export default meta;

export const TitleBlock: StoryFn<typeof TitleBlockComponent> = () => (
  <Container>
    <Item label='Default'>
      <TitleBlockComponent>Title</TitleBlockComponent>
    </Item>
    <Item label='With helpMessage'>
      <TitleBlockComponent helpMessage='helpMessage'>Title</TitleBlockComponent>
    </Item>
    <Item label='With subTitle'>
      <TitleBlockComponent subTitle='subTitle'>Title</TitleBlockComponent>
    </Item>
    <Item label='With subTitle and helpMessage'>
      <TitleBlockComponent subTitle='subTitle' helpMessage='helpMessage'>
        Title
      </TitleBlockComponent>
    </Item>
  </Container>
);
