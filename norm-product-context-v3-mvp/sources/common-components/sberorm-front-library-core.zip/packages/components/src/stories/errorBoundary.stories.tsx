import { Button, Link, Text } from '@sber-orm/ui-kit';
import { Meta, StoryFn } from '@storybook/react';
import { useState } from 'react';
import { ErrorComponent, ErrorPageWrap, getErrorComponentProps } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof ErrorPageWrap> = {
  args: {},
  component: ErrorPageWrap,
  title: 'components/ErrorBoundary',
};

export default meta;

export const ErrorBoundary: StoryFn<typeof ErrorPageWrap> = () => {
  const [is401Visible, setIs401Visible] = useState<boolean>(false);

  const supportLinkButton = (
    <a
      href='https://ticket.example.com'
      target='_blank'
      rel='noopener noreferrer'
    >
      <Button variant='secondary' size='S' fullWidth>
        Support
      </Button>
    </a>
  );

  const supportLinkText = (
    <Text medium>
      <Link href='https://ticket.example.com' target='_blank'>
        Обратиться в службу поддержки
      </Link>
    </Text>
  );

  return (
    <Container>
      <Item label='Default ErrorPage' height={600} width={600}>
        <ErrorPageWrap
          {...getErrorComponentProps({ text: 'Request timeout error text' })}
        />
      </Item>
      <Item label='Not found ErrorPage' height={600} width={600}>
        <ErrorPageWrap {...getErrorComponentProps({ code: 404 })} />
      </Item>
      <Item label='Request timeout ErrorPage' height={600} width={600}>
        <ErrorPageWrap {...getErrorComponentProps({ code: 408 })} />
      </Item>
      <Item label='Bad request ErrorPage' height={600} width={600}>
        <ErrorPageWrap {...getErrorComponentProps({ code: 400 })} />
      </Item>
      <Item label='401 Unauthorized' height={600} width={600}>
        {is401Visible ? (
          <ErrorPageWrap {...getErrorComponentProps({ code: 401 })} />
        ) : (
          <Button onClick={() => setIs401Visible(true)}>Show 401</Button>
        )}
      </Item>
      <Item label='403 Foebidden' height={600} width={600}>
        <ErrorPageWrap {...getErrorComponentProps({ code: 403 })} />
      </Item>
      <Item label='Business ErrorPage' height={600} width={600}>
        <ErrorPageWrap
          {...getErrorComponentProps({
            code: 200,
            text: 'Business error text',
            title: 'Business error title',
          })}
        />
      </Item>
      <Item label='ErrorComponent ErrorPage' height={600} width={600}>
        <ErrorComponent code='PROGRAM_CRASHED' text='Program Crashed' />
      </Item>
      <Item label='ErrorPage with Button supportLink' height={600} width={600}>
        <ErrorPageWrap
          {...getErrorComponentProps({
            code: 404,
            supportLink: supportLinkButton,
          })}
        />
      </Item>
      <Item label='ErrorPage with Text supportLink' height={600} width={600}>
        <ErrorPageWrap
          {...getErrorComponentProps({
            code: 408,
            supportLink: supportLinkText,
          })}
        />
      </Item>
      <Item label='ErrorPage with Custom supportLink' height={600} width={600}>
        <ErrorPageWrap
          {...getErrorComponentProps({
            code: 'APP_ERROR',
            text: 'Custom error text',
            supportLink: (
              <a
                href='https://ticket.example.com'
                target='_blank'
                rel='noopener noreferrer'
              >
                <Button variant='secondary' size='S' fullWidth>
                  Support
                </Button>
              </a>
            ),
          })}
        />
      </Item>
      <Item label='ErrorComponent with supportLink' height={600} width={600}>
        <ErrorComponent
          code='PROGRAM_CRASHED'
          text='Program Crashed'
          supportLink={supportLinkButton}
        />
      </Item>
    </Container>
  );
};
