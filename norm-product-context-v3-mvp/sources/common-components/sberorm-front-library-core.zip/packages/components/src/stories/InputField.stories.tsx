import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const InputField = fields.input;

const meta: Meta<typeof InputField> = {
  args: {
    fieldConfig: {
      title: 'Номер бухгалтерского докумена',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: InputField,
  title: 'components/Input',
};

export default meta;

export const Input: StoryFn<typeof InputField> = (arguments_) => {
  const [value, setValue] = useState<string>('FU-12313-4123');

  return (
    <Container>
      <Item label='Default' width={512}>
        <InputField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <InputField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <InputField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
