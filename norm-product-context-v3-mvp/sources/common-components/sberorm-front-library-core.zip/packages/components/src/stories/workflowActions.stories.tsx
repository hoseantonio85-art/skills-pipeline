import { Meta, StoryFn } from '@storybook/react';

import { WorkflowActions as WorkflowActionsComponent } from '..';
import { Container } from './utils';

const meta: Meta<typeof WorkflowActionsComponent> = {
  args: {
    actions: [
      { id: 'cancel', title: 'Cancel' },
      {
        id: 'delete',
        params: { comment: true, type: 'context' },
        title: 'Delete',
      },
      {
        id: 'save',
        params: {
          comment: true,
          requiredComment: true,
          type: 'primary',
        },
        title: 'Save',
      },
      {
        id: 'approve',
        params: {
          comment: true,
          confirmMsg: true,
          confirmMsgTitle: 'Утвердить событие',
          confirmMsgText:
            'Подберет самостоятельно даже после утверждения события',
          confirmMsgBtn: 'Продолжить',
          type: 'primary',
        },
        title: 'Approve',
      },
    ],
    // biome-ignore lint/suspicious/noConsole: Console
    onUpdate: (action, comment) => console.log(action, comment),
    localStorageKey: 'test',
  },
  component: WorkflowActionsComponent,
  title: 'components/WorkflowActions',
};

export default meta;

export const WorkflowActions: StoryFn<typeof WorkflowActionsComponent> = (
  arguments_,
) => (
  <Container>
    <WorkflowActionsComponent {...arguments_} testId={'test'} />
  </Container>
);
