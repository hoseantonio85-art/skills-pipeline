import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const TogglerMogglerField = fields.togglerMoggler;

const meta: Meta<typeof TogglerMogglerField> = {
  args: {
    fieldConfig: {
      title: 'Риски из АС Сенат',
    },
  },
  component: TogglerMogglerField,
  title: 'components/TogglerMoggler',
};

export default meta;

export const TogglerMoggler: StoryFn<typeof TogglerMogglerField> = (
  arguments_,
) => {
  const [value, setValue] = useState<boolean | undefined>(true);

  return (
    <Container>
      <Item label='Default' width={512}>
        <TogglerMogglerField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <TogglerMogglerField
          {...arguments_}
          required
          fieldConfig={{
            ...arguments_.fieldConfig,
            editable: false,
            extras: { icon: 'bankStatus' },
          }}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <TogglerMogglerField
          {...arguments_}
          required
          fieldConfig={{
            ...arguments_.fieldConfig,
            editable: false,
            extras: { icon: 'fire' },
          }}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <TogglerMogglerField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
