import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { SeverityMultiSwitcherField } from '..';
import classes from './styles.module.scss';
import { Container, Item } from './utils';

const meta: Meta<typeof SeverityMultiSwitcherField> = {
  args: {
    fieldConfig: {
      title: 'Уровень риска',
      availableItems: [
        { id: 'low', value: 'Низкий' },
        { id: 'medium', value: 'Средний' },
        { id: 'high', value: 'Высокий' },
        { id: 'critical', value: 'Критичный' },
      ],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
    classes: {
      container: classes.nonFinEffectImpact,
      low: classes.low,
      medium: classes.medium,
      high: classes.high,
      critical: classes.critical,
    },
  },
  component: SeverityMultiSwitcherField,
  title: 'components/SeverityMultiSwitcher',
};

export default meta;

export const SeverityMultiSwitcher: StoryFn<
  typeof SeverityMultiSwitcherField
> = (arguments_) => {
  const [value, setValue] = useState<string[]>(['high']);

  return (
    <Container>
      <Item label='Default' width={512}>
        <SeverityMultiSwitcherField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <SeverityMultiSwitcherField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <SeverityMultiSwitcherField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
