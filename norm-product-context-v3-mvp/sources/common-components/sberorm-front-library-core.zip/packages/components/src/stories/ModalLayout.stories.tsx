import { Meta, StoryFn } from '@storybook/react';

import { ModalLayout as ModalLayoutComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof ModalLayoutComponent> = {
  args: {},
  component: ModalLayoutComponent,
  title: 'components/ModalLayout',
};

export default meta;

export const ModalLayout: StoryFn<typeof ModalLayoutComponent> = () => (
  <Container>
    <Item label='Basic'>
      <ModalLayoutComponent
        onOpenNext={console.log}
        onOpenPrevious={console.log}
        onClose={console.log}
        onBack={console.log}
      >
        {[1, 2, 3, 4, 5, 6, 7, 8].map((item, index) => (
          <span
            key={item}
            style={index === 0 ? { marginTop: '100px', display: 'block' } : {}}
          >
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga id
            labore, magnam mollitia nihil perspiciatis repudiandae ut. Aliquam
            aperiam commodi dolore pariatur perferendis repudiandae vel,
            veritatis? Dolor labore maiores mollitia nulla quia sit sunt
            voluptas voluptates. Aut eaque iste repellat sapiente similique
            veritatis. Aliquam consectetur cum error facere illum iusto modi
            natus possimus quae quo?
          </span>
        ))}
      </ModalLayoutComponent>
    </Item>
  </Container>
);
