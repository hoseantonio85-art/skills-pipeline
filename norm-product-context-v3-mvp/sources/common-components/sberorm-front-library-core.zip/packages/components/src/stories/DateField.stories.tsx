import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const DateField = fields.date;

const meta: Meta<typeof DateField> = {
  args: {
    fieldConfig: {
      title: 'Дата компенсации',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: DateField,
  title: 'components/Date',
};

export default meta;

export const _Date: StoryFn<typeof DateField> = (arguments_) => {
  const [value, setValue] = useState<string | null>('2025-02-06T10:56:00.528Z');

  return (
    <Container>
      <Item label='Default' width={512}>
        <DateField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <DateField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <DateField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
