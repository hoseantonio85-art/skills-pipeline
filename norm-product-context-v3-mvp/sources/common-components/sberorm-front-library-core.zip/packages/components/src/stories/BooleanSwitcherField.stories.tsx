import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const BooleanSwitcherField = fields.booleanSwitcher;

const meta: Meta<typeof BooleanSwitcherField> = {
  args: {
    fieldConfig: {
      title: 'BooleanSwitcher',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: BooleanSwitcherField,
  title: 'components/BooleanSwitcher',
};

export default meta;

export const BooleanSwitcher: StoryFn<typeof BooleanSwitcherField> = (
  arguments_,
) => {
  const [value, setValue] = useState<boolean>(true);

  return (
    <Container>
      <Item label='Default' width={512}>
        <BooleanSwitcherField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Not chosen' width={512}>
        <BooleanSwitcherField {...arguments_} onChange={setValue} field={{}} />
      </Item>
      <Item label='Readonly' width={512}>
        <BooleanSwitcherField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <BooleanSwitcherField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
