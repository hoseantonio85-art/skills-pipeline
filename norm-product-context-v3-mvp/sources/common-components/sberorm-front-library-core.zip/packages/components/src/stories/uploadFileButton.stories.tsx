import { Meta, StoryFn } from '@storybook/react';
import { useState } from 'react';

import { UploadFileButton as UploadFileButtonComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof UploadFileButtonComponent> = {
  args: {},
  component: UploadFileButtonComponent,
  title: 'components/UploadFileButton',
};

export default meta;

const ALLOWED_EXTENSIONS = [
  'xls',
  'xlsx',
  'xlsm',
  'xlsb',
  'xltx',
  'xltm',
  'xlt',
  'xls',
  'xml',
  'xlam',
  'xla',
  'xlw',
  'xlr',
];

export const UploadFileButton: StoryFn<
  typeof UploadFileButtonComponent
> = () => {
  const [files, setFiles] = useState<File[]>([]);

  const handleSubmit = (fileAttach: File | null) => {
    if (
      fileAttach &&
      files.filter((file) => file.name === fileAttach.name).length === 0
    ) {
      setFiles([...files, fileAttach]);
    }
  };

  return (
    <Container>
      <Item label='Default' height={300} width={500}>
        <UploadFileButtonComponent
          onUpload={handleSubmit}
          addButtonText='Добавить'
          uploadButtonText='Обновить'
          accepts={ALLOWED_EXTENSIONS}
        />
      </Item>
    </Container>
  );
};
