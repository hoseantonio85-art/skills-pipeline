import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const CurrencyField = fields.currency;

const meta: Meta<typeof CurrencyField> = {
  args: {
    fieldConfig: {
      title: 'Сумма компенсации потери',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: CurrencyField,
  title: 'components/Currency',
};

export default meta;

export const Currency: StoryFn<typeof CurrencyField> = (arguments_) => {
  const [value, setValue] = useState<number>(7777777);

  return (
    <Container>
      <Item label='Default' width={512}>
        <CurrencyField
          {...arguments_}
          onChange={(val) => setValue(val as number)}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <CurrencyField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <CurrencyField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
