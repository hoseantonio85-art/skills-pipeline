import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import classes from './styles.module.scss';
import { Container, Item } from './utils';

const SeverityField = fields.severity;

const meta: Meta<typeof SeverityField> = {
  args: {
    fieldConfig: {
      title: 'Уровень риска',
      availableItems: [{ id: 'high', value: 'Высокий' }],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
    classes: {
      container: classes.nonFinEffectImpact,
      low: classes.low,
      medium: classes.medium,
      high: classes.high,
      critical: classes.critical,
    },
  },
  component: SeverityField,
  title: 'components/Severity',
};

export default meta;

export const Severity: StoryFn<typeof SeverityField> = (arguments_) => {
  const [value, setValue] = useState<string>('high');

  return (
    <Container>
      <Item label='Default' width={512}>
        <SeverityField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <SeverityField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <SeverityField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
