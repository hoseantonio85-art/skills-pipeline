import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const TreeField = fields.tree;

const rootResponse = {
  items: [
    {
      id: 'SBR_castp_01',
      value: 'Внешние причины',
      name: 'Внешние причины',
      leaf: true,
    },
    {
      id: 'SBR_castp_02',
      value:
        'Действия персонала и других связанных с кредитной организацией лиц',
      name: 'Действия персонала и других связанных с кредитной организацией лиц',
      leaf: false,
    },
    {
      id: 'SBR_03',
      value: 'Недостатки процессов',
      name: 'Недостатки процессов',
      leaf: true,
    },
    {
      id: 'SBR_castp_05',
      value: 'Сбои систем и оборудования',
      name: 'Сбои систем и оборудования',
      leaf: true,
    },
  ],
};
const nonRootResponse = {
  items: [
    {
      id: 'a',
      value: 'Внешние причины 2',
      name: 'Внешние причины 2',
      leaf: true,
    },
    {
      id: 'b',
      value:
        'Действия персонала и других связанных с кредитной организацией лиц 2',
      name: 'Действия персонала и других связанных с кредитной организацией лиц 2',
      leaf: true,
    },
    {
      id: 'c',
      value: 'Недостатки процессов 2',
      name: 'Недостатки процессов 2',
      leaf: true,
    },
    {
      id: 'd',
      value: 'Сбои систем и оборудования 2',
      name: 'Сбои систем и оборудования 2',
      leaf: true,
    },
  ],
};

const meta: Meta<typeof TreeField> = {
  args: {
    fieldConfig: {
      title: 'Тип причины',
      pathItems: [...rootResponse.items, ...nonRootResponse.items],
      validation: [
        {
          type: 'onlyLeaf',
          condition: 'nonFinEffectTypeCb',
          text: 'Должно быть указано значение последнего уровня',
        },
      ],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: TreeField,
  title: 'components/Tree',
};

export default meta;

export const Tree: StoryFn<typeof TreeField> = (arguments_) => {
  const [value, setValue] = useState<string | undefined>('SBR_castp_01');
  const loadStructure = (_dict: string, key?: string) => {
    if (key) {
      return Promise.resolve({
        levels: [
          { ...rootResponse, selectedId: 'SBR_castp_02' },
          { ...nonRootResponse },
        ],
      });
    }

    return Promise.resolve({ levels: [{ ...rootResponse }] });
  };

  return (
    <Container>
      <Item label='Default' width={512}>
        <TreeField
          {...arguments_}
          onChange={(value: string) => {
            setValue(value);
          }}
          field={{ value }}
          loadStructure={loadStructure}
        />
      </Item>
      <Item label='With select config' width={512}>
        <TreeField
          {...arguments_}
          onChange={(value: string) => {
            setValue(value);
          }}
          field={{ value }}
          loadStructure={loadStructure}
          selectProps={{
            size: 'S',
            labelInside: false,
            tooltip: undefined,
            placeholder: 'Тип причины',
            required: true,
          }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <TreeField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <TreeField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
