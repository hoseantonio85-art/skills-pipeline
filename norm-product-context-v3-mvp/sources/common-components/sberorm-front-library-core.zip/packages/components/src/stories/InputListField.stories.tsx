import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const InputListField = fields.inputList;

const meta: Meta<typeof InputListField> = {
  args: {
    fieldConfig: {
      title: 'Риск-фактор',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: InputListField,
  title: 'components/InputList',
};

export default meta;

export const InputList: StoryFn<typeof InputListField> = (arguments_) => {
  const [value, setValue] = useState<string[]>([
    'Зависимость от стабильности работы IT-инфраструктуры',
    'Нарушение регламентов защиты данных в условиях ужесточения требований ФЗ-420',
  ]);

  return (
    <Container>
      <Item label='Default' width={840} height={240}>
        <InputListField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={840} height={200}>
        <InputListField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <InputListField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
