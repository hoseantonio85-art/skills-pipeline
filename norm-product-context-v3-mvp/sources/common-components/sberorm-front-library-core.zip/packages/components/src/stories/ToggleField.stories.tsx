import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const ToggleField = fields.toggle;

const meta: Meta<typeof ToggleField> = {
  args: {
    fieldConfig: {
      title: 'Вкл/Выкл',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: ToggleField,
  title: 'components/Toggle',
};

export default meta;

export const Toggle: StoryFn<typeof ToggleField> = (arguments_) => {
  const [value, setValue] = useState<boolean>(true);

  return (
    <Container>
      <Item label='Default' width={512}>
        <ToggleField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <ToggleField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <ToggleField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
