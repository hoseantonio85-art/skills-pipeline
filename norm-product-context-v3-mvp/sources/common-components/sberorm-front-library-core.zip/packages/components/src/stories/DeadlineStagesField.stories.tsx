import { Meta, StoryFn } from '@storybook/react';

import { fields } from '..';
import { Container, Item } from './utils';

const DeadlineStagesField = fields.deadlineStagesField;

const meta: Meta<typeof DeadlineStagesField> = {
  args: {
    fieldConfig: {
      title: 'Этапы кампании',
      value: '',
      availableItems: [
        {
          id: 'first',
          value: 'Первичная оценка',
          extras: {
            startDate: '2025-08-28T06:36:39.024Z',
            endDate: '2025-08-28T06:36:39.024Z',
          },
        },
        {
          id: 'second',
          value: 'Проверка банком',
          extras: {
            startDate: '2024-12-31T06:36:39.024Z',
            endDate: '2025-12-31T06:36:39.024Z',
          },
        },
        {
          id: 'third',
          value: 'Подготовка материалов',
          extras: {
            startDate: '2025-08-28T06:36:39.024Z',
            endDate: '2025-12-31T06:36:39.024Z',
          },
        },
        {
          id: 'fourth',
          value: 'Утверждение лимита',
          extras: {
            startDate: '2025-12-31T06:36:39.024Z',
            endDate: '2026-04-08T06:36:39.024Z',
          },
        },
      ],
      extras: {
        hint: `
**Первичная оценка**
Дедлайн: 28 августа

**Проверка банком**
Дедлайн: 31 декабря

**Подготовка материалов**
Дедлайн: 8 апреля

**Утверждение лимита**
Дедлайн: 8 апреля`,
      },
    },
  },
  component: DeadlineStagesField,
  title: 'components/DeadlineStages',
};

export default meta;

export const DeadlineStages: StoryFn<typeof DeadlineStagesField> = (
  arguments_,
) => {
  return (
    <Container>
      <Item label='Default' height={350}>
        <DeadlineStagesField {...arguments_} />
      </Item>
    </Container>
  );
};
