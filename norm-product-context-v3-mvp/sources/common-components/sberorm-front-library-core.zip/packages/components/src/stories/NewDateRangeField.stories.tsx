import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const NewDateRangeFieldField = fields.dateRange;

const meta: Meta<typeof NewDateRangeFieldField> = {
  args: {
    fieldConfig: {
      title: 'Дата компенсации',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: NewDateRangeFieldField,
  title: 'components/DateRangeFieldNew',
};

export default meta;

export const DateRangeFieldNew: StoryFn<typeof NewDateRangeFieldField> = (
  arguments_,
) => {
  const [value, setValue] = useState<[string, string]>([
    '2025-02-03T21:00:00.000Z',
    '2025-02-05T21:00:00.000Z',
  ]);

  return (
    <Container>
      <Item label='Default' width={512}>
        <NewDateRangeFieldField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <NewDateRangeFieldField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          fallbackFieldConfig={{ required: true }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <NewDateRangeFieldField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
