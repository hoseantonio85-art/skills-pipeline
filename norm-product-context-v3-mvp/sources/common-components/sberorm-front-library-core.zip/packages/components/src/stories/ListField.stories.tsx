import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const ListField = fields.list;

const meta: Meta<typeof ListField> = {
  args: {
    fieldConfig: {
      title: 'Профиль риска',
      availableItems: [
        {
          value: 'Внутреннее мошенничество с целью получения выгоды',
          id: 'test',
        },
        {
          value: 'Возврат средств и компенсации клиентам по продуктам',
          id: 'a',
        },
        {
          value: 'Выдача кредита заемщику, несоответствующему требованиям',
          id: 'b',
        },
        { value: 'Излишние выплаты сотрудникам', id: 'c' },
        {
          value: 'Компрометация данных и мошенничество в удаленных каналах',
          id: 'd',
        },
        { value: 'Нарушение лимита кредитного риска на контрагента', id: 'e' },
        {
          value: 'Недобросовестные практики продаж продуктов и услуг',
          id: 'f',
        },
        {
          value:
            'Недостачи или излишки по неустановленной операции, в т.ч. технические',
          id: 'g',
        },
        { value: 'Недоступность услуг клиентам', id: 'k' },
      ],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: ListField,
  title: 'components/List',
};

export default meta;

export const List: StoryFn<typeof ListField> = (arguments_) => {
  const [value, setValue] = useState<string | undefined>('d');

  return (
    <Container>
      <Item label='Default' width={512}>
        <ListField {...arguments_} onChange={setValue} field={{ value }} />
      </Item>
      <Item label='Readonly' width={512}>
        <ListField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <ListField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
