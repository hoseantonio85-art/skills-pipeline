import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const MultiTreeField = fields.multiTree;

const rootResponse = {
  levels: [
    {
      items: [
        {
          id: 'SBR_castp_01',
          value: 'Внешние причины',
          name: 'Внешние причины',
          leaf: true,
        },
        {
          id: 'SBR_castp_02',
          value:
            'Действия персонала и других связанных с кредитной организацией лиц',
          name: 'Действия персонала и других связанных с кредитной организацией лиц',
          leaf: false,
        },
        {
          id: 'SBR_03',
          value: 'Недостатки процессов',
          name: 'Недостатки процессов',
          leaf: true,
        },
        {
          id: 'SBR_castp_05',
          value: 'Сбои систем и оборудования',
          name: 'Сбои систем и оборудования',
          leaf: true,
        },
      ],
    },
  ],
};
const nonRootResponse = {
  levels: [
    {
      items: [
        {
          id: 'a',
          value: 'Внешние причины 2',
          name: 'Внешние причины 2',
          leaf: true,
        },
        {
          id: 'b',
          value:
            'Действия персонала и других связанных с кредитной организацией лиц 2',
          name: 'Действия персонала и других связанных с кредитной организацией лиц 2',
          leaf: true,
        },
        {
          id: 'c',
          value: 'Недостатки процессов 2',
          name: 'Недостатки процессов 2',
          leaf: true,
        },
        {
          id: 'd',
          value: 'Сбои систем и оборудования 2',
          name: 'Сбои систем и оборудования 2',
          leaf: true,
        },
      ],
    },
  ],
};

const meta: Meta<typeof MultiTreeField> = {
  args: {
    fieldConfig: {
      title: 'Тип причины',
      pathItems: [
        ...rootResponse.levels[0].items,
        ...nonRootResponse.levels[0].items,
      ],
      validation: [
        {
          type: 'onlyLeaf',
          condition: 'nonFinEffectTypeCb',
          text: 'Должно быть указано значение последнего уровня',
        },
      ],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: MultiTreeField,
  title: 'components/MultiTree',
};

export default meta;

export const MultiTree: StoryFn<typeof MultiTreeField> = (arguments_) => {
  const [value, setValue] = useState<string[]>(['SBR_castp_01', 'SBR_03']);
  const loadStructure = (_dict: string, key?: string) => {
    if (key) {
      return Promise.resolve({ ...structuredClone(nonRootResponse) });
    }

    return Promise.resolve({ ...structuredClone(rootResponse) });
  };

  return (
    <Container>
      <Item label='Default' width={512}>
        <MultiTreeField
          {...arguments_}
          onChange={(value: string[]) => {
            setValue(value);
          }}
          field={{ value }}
          loadStructure={loadStructure}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <MultiTreeField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <MultiTreeField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
