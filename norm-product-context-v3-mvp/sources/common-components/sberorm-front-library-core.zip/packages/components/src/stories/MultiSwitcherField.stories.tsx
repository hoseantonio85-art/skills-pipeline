import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const MultiSwitcherField = fields.multiSwitcher;

const meta: Meta<typeof MultiSwitcherField> = {
  args: {
    fieldConfig: {
      title: 'Номер бухгалтерского докумена',
      availableItems: [
        { id: 'a', value: 'First' },
        { id: 'b', value: 'Second' },
        { id: 'c', value: 'Third' },
        { id: 'd', value: 'Fourth' },
        { id: 'e', value: 'Fifth' },
        { id: 'f', value: 'Sixth' },
        { id: 'g', value: 'Seventh' },
        { id: 'h', value: 'Eighth' },
      ],
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: MultiSwitcherField,
  title: 'components/MultiSwitcher',
};

export default meta;

export const MultiSwitcher: StoryFn<typeof MultiSwitcherField> = (
  arguments_,
) => {
  const [value, setValue] = useState<string[]>(['a', 'c']);

  return (
    <Container>
      <Item label='Default' width={512}>
        <MultiSwitcherField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <MultiSwitcherField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <MultiSwitcherField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
