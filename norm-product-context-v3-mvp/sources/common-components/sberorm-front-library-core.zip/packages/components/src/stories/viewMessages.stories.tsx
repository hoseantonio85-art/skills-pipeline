import { Meta, StoryFn } from '@storybook/react';

import { ViewMessages as ViewMessagesComponent } from '..';
import { Container } from './utils';

const meta: Meta<typeof ViewMessagesComponent> = {
  args: {
    items: [
      { notificationType: 'error', text: 'Text' },
      { notificationType: 'error', title: 'Title' },
      { notificationType: 'error', text: 'Text', title: 'Title' },
      {
        actions: [{ title: 'Action 1' }, { title: 'Action 2' }],
        notificationType: 'info',
        text: 'Info',
      },
      {
        notificationType: 'error',
        text: 'Text to [support](mailto:support_sbernorm@sberbank.ru)',
      },
    ],
  },
  component: ViewMessagesComponent,
  title: 'components/ViewMessages',
};

export default meta;

export const ViewMessages: StoryFn<typeof ViewMessagesComponent> = (
  arguments_,
) => (
  <Container>
    <ViewMessagesComponent {...arguments_} />
  </Container>
);
