import { Button } from '@sber-orm/ui-kit';
import { Meta, StoryFn } from '@storybook/react';
import { useEffect, useRef } from 'react';

import {
  ConfirmationModal as ConfirmationModalComponent,
  IModalDialogRef,
} from '..';
import { Container } from './utils';

const meta: Meta<typeof ConfirmationModalComponent> = {
  args: {},
  component: ConfirmationModalComponent,
  title: 'components/ConfirmationModal',
};

export default meta;

export const ConfirmationModal: StoryFn<
  typeof ConfirmationModalComponent
> = () => {
  const confirmationRef = useRef<IModalDialogRef | null>(null);

  useEffect(() => {
    if (confirmationRef.current) {
      confirmationRef.current.open();
    }
  }, [confirmationRef.current]);

  return (
    <Container>
      <Button onClick={() => confirmationRef.current?.open()}>Open</Button>
      <ConfirmationModalComponent
        ref={confirmationRef}
        title='Confirmation title'
        handleSubmit={() => confirmationRef.current?.close()}
        cancelButtonText='Cancle text'
        submitButtonText='Submit text'
      />
    </Container>
  );
};
