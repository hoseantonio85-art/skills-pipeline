import { Button } from '@sber-orm/ui-kit';
import { Meta, StoryFn } from '@storybook/react';
import { useState } from 'react';

import { Drawer as DrawerComponent } from '..';
import { Container } from './utils';

const meta: Meta<typeof DrawerComponent> = {
  args: {},
  component: DrawerComponent,
  title: 'components/Drawer',
};

export default meta;

export const Drawer: StoryFn<typeof DrawerComponent> = () => {
  const [opened, setOpened] = useState(true);

  return (
    <Container>
      <Button onClick={() => setOpened(true)}>Open</Button>
      <DrawerComponent
        position='absolute'
        fullHeight
        open={opened}
        notMountIfClosed
        title='Test title'
        onClose={() => setOpened(false)}
        width={400}
      >
        Test content
      </DrawerComponent>
    </Container>
  );
};
