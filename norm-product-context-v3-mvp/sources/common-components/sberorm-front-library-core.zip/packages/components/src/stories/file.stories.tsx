import { Meta, StoryFn } from '@storybook/react';

import { File as FileComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof FileComponent> = {
  args: {
    filename: 'File',
    progress: 50,
    size: 1024,
  },
  component: FileComponent,
  title: 'components/File',
};

export default meta;

export const File: StoryFn<typeof FileComponent> = (arguments_) => (
  <Container>
    <Item label='Default file'>
      <FileComponent {...arguments_} />
    </Item>
    <Item label='Pdf file'>
      <FileComponent {...arguments_} extension='pdf' />
    </Item>
    <Item label='Excel file'>
      <FileComponent {...arguments_} extension='xls' />
    </Item>
    <Item label='Word file'>
      <FileComponent {...arguments_} extension='doc' />
    </Item>
    <Item label='PowerPoint file'>
      <FileComponent {...arguments_} extension='ppt' />
    </Item>
    <Item label='Archive file'>
      <FileComponent {...arguments_} extension='zip' />
    </Item>
    <Item label='Default file loading'>
      <FileComponent {...arguments_} loading />
    </Item>
    <Item label='Default file error'>
      <FileComponent {...arguments_} errorText='Error' error />
    </Item>
  </Container>
);
