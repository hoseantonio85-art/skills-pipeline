import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const DateRangeField = fields.datetime;

const meta: Meta<typeof DateRangeField> = {
  args: {
    fieldConfig: {
      title: 'Дата компенсации',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: DateRangeField,
  title: 'components/DateRange',
};

export default meta;

export const DateRange: StoryFn<typeof DateRangeField> = (arguments_) => {
  const [first, setFirst] = useState<string>('2025-02-03T21:00:00.000Z');
  const [second, setSecond] = useState<string>('2025-02-05T21:00:00.000Z');

  const onChange = (f: string, s: string) => {
    setFirst(f);
    setSecond(s);
  };

  return (
    <Container>
      <Item label='Default' width={512}>
        <DateRangeField
          {...arguments_}
          onChange={onChange}
          field={{ value: first }}
          fallbackField={{ value: second }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <DateRangeField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value: first }}
          fallbackField={{ value: second }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <DateRangeField
          {...arguments_}
          raw
          field={{ value: first }}
          fallbackField={{ value: second }}
        />
      </Item>
    </Container>
  );
};
