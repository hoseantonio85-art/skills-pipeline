import { Meta, StoryFn } from '@storybook/react';

import { useState } from 'react';
import { fields } from '..';
import { Container, Item } from './utils';

const InputNumberField = fields.inputNumber;

const meta: Meta<typeof InputNumberField> = {
  args: {
    fieldConfig: {
      title: 'Номер бухгалтерского докумена',
      extras: {
        hint: `Опиши конкретные шаги и действия, необходимые для снижения риска. 
Например: «Запуск системы двухфакторной аутентификации через корпоративное приложение ОТР при входе в АС НОРМ из внешней сети.»`,
      },
    },
  },
  component: InputNumberField,
  title: 'components/InputNumber',
};

export default meta;

export const InputNumber: StoryFn<typeof InputNumberField> = (arguments_) => {
  const [value, setValue] = useState<number | undefined>(123);

  return (
    <Container>
      <Item label='Default' width={512}>
        <InputNumberField
          {...arguments_}
          onChange={setValue}
          field={{ value }}
        />
      </Item>
      <Item label='Readonly' width={512}>
        <InputNumberField
          {...arguments_}
          required
          fieldConfig={{ ...arguments_.fieldConfig, editable: false }}
          field={{ value }}
        />
      </Item>
      <Item label='Raw' width={512}>
        <InputNumberField {...arguments_} raw field={{ value }} />
      </Item>
    </Container>
  );
};
