import { createContext, useContext } from 'react';

import { IErrorInstanceType } from './types';

export interface IErrorBoundaryContextValue {
  setApplicationError: (error: IErrorInstanceType) => void;
}

export const ErrorBoundaryContext = createContext<IErrorBoundaryContextValue>(
  {} as IErrorBoundaryContextValue,
);

export const useErrorBoundary = () => {
  const boundaryContext = useContext(ErrorBoundaryContext);

  if (!boundaryContext) {
    throw new Error(
      'useErrorBoundary hook should be used in errorBoundary context only',
    );
  }

  return boundaryContext;
};
