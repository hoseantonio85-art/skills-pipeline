import { useCallback, useEffect, useRef } from 'react';

import { useModal } from '../provider';

export const useModalQueue = () => {
  const { queue, currentModal } = useModal();

  const queueStateRef = useRef({
    queueLength: queue.length + (currentModal ? 1 : 0),
    waitingInQueue: queue.length,
    hasNext: queue.length > 0,
  });

  useEffect(() => {
    queueStateRef.current = {
      queueLength: queue.length + (currentModal ? 1 : 0),
      waitingInQueue: queue.length,
      hasNext: queue.length > 0,
    };
  }, [queue, currentModal]);

  const getQueueState = useCallback(() => queueStateRef.current, []);

  return {
    getQueueState,
    queueLength: queueStateRef.current.queueLength,
    waitingInQueue: queueStateRef.current.waitingInQueue,
    hasNext: queueStateRef.current.hasNext,
  };
};
