import { TPushData } from './types';

type TWindowWithDataLayer = Window & {
  dataLayer: Record<string, unknown>[];
};

declare const window: TWindowWithDataLayer;

export function dispatchTrackingEvent(data: TPushData) {
  if (window !== undefined && Object.keys(data).length > 0) {
    (window.dataLayer = window.dataLayer || []).push(data);
  }
}
