import {
  BarChart,
  Icon,
  MarkdownViewer,
  Row,
  Text,
  Title,
  Tooltip,
} from '@sber-orm/ui-kit';
import cn from 'classnames';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';

dayjs.extend(duration);

import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

const currentDate = dayjs().toISOString();

const calculatePercentage = (startDate: string, endDate: string) => {
  const start = dayjs(startDate);
  const end = dayjs(endDate);
  const current = dayjs(currentDate);

  if (current.isBefore(start)) {
    return 0;
  }
  if (current.isAfter(end)) {
    return 100;
  }

  const totalDuration = end.diff(start);
  const elapsedDuration = current.diff(start);

  return (elapsedDuration / totalDuration) * 100;
};

export const DeadlineStagesField = ({
  fieldConfig,
}: IEditFieldProps<string>) => {
  const { title, availableItems } = fieldConfig ?? {};

  const hintText = String(fieldConfig?.extras?.hint || '');

  if (!availableItems?.length) {
    return null;
  }

  return (
    <Row direction='column' gutter={24} align='top'>
      {!!title && (
        <Row gutter={4}>
          <Title size='H400'>{title}</Title>
          {!!hintText && (
            <Tooltip
              placement='top-end'
              content={<MarkdownViewer markdown={hintText} />}
              fallbackPlacements={['left-start']}
            >
              <span className={classes.tooltipIcon}>
                <Icon width={16} height={16} name='infoOutlined' />
              </span>
            </Tooltip>
          )}
        </Row>
      )}

      {availableItems.map(({ id, value, extras }, index) => {
        const startDate = extras?.['startDate'] as string;
        const endDate = extras?.['endDate'] as string;
        const percents = calculatePercentage(startDate, endDate);

        return (
          <Row key={id} className={classes.deadlineStages}>
            <div
              className={cn(classes.deadlineStagesBarChart, {
                [classes.deadlineStagesBarChartGreen]: percents <= 49,
                [classes.deadlineStagesBarChartOrange]:
                  percents > 49 && percents <= 84,
                [classes.deadlineStagesBarChartRed]:
                  percents > 84 && percents < 100,
                [classes.deadlineStagesBarChartGray]: percents === 0,
                [classes.deadlineStagesBarChartCompleted]: percents === 100,
              })}
              data-order={index + 1}
            >
              <BarChart percents={percents} size={50} withoutAnimation />
              {percents === 100 && (
                <Icon
                  name='check'
                  className={classes.deadlineStagesCompletedIcon}
                />
              )}
            </div>
            <div>
              <Text
                className={cn(classes.deadlineStagesTitle, {
                  [classes.deadlineStagesTitleGray]: percents === 0,
                })}
              >
                {value}
              </Text>
              <Text
                size='sm'
                className={cn(classes.deadlineStagesDescription, {
                  [classes.deadlineStagesDescriptionGray]: percents === 0,
                })}
              >
                Дедлайн: {dayjs(endDate).locale('ru').format('D MMMM')}
              </Text>
            </div>
          </Row>
        );
      })}
    </Row>
  );
};
