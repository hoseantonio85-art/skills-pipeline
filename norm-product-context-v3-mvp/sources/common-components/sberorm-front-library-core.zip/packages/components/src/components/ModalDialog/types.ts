import { TTitleProps as TTitleProperties } from '@sber-orm/ui-kit';
import React, { ReactNode } from 'react';

export interface IModalDialogProperties extends React.PropsWithChildren {
  title?: string;
  titleProps?: TTitleProperties;
  isOpen?: boolean;
  hideCross?: boolean;
  disabledClickOutside?: boolean;
  onClose?: (() => void) | undefined;
  footer?: ReactNode;
  hasLogo?: boolean;
  state?: EState;
  logoImg?: React.ComponentType;
  onOpen?: () => void;
  fullHeight?: boolean;
  classes?: {
    wrapper?: string;
  };
}

export enum EState {
  fullScreen = 'fullScreen',
  small = 'small',
  icon = 'icon',
}

export interface IModalDialogRef {
  open: () => void;
  close: () => void;
}
