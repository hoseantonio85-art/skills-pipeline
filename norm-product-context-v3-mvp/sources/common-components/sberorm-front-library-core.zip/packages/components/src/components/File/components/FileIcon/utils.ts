import { EFileType } from '@sber-orm/ui-kit';

export function checkFileType(extension: string) {
  if (/(xls|xlsb|xlsm|xlsx)$/i.test(extension)) {
    return EFileType.excel;
  }
  if (/(doc|docm|docx)$/i.test(extension)) {
    return EFileType.word;
  }
  if (/(pdf|ppdf)$/i.test(extension)) {
    return EFileType.pdf;
  }
  if (/(ppt|pptm|pptx)$/i.test(extension)) {
    return EFileType.powerPoint;
  }
  if (/(zip|rar)$/i.test(extension)) {
    return EFileType.archive;
  }

  return extension;
}
