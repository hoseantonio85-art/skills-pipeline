import { EFileType, EIconName, Icon } from '@sber-orm/ui-kit';
import React from 'react';

import classes from '../../styles.module.scss';
import { TFileIconProperties } from '../../types';
import { checkFileType } from './utils';

const iconMap: { [key in EFileType as string]: keyof typeof EIconName } = {
  [EFileType.archive]: 'archive',
  [EFileType.excel]: 'excel',
  [EFileType.pdf]: 'pdf',
  [EFileType.powerPoint]: 'powerPoint',
  [EFileType.word]: 'word',
};

export const FileIcon: React.FC<TFileIconProperties> = (properties) => {
  const { error = true, extension } = properties;

  const iconExtension = checkFileType(extension || '');

  return (
    <div className={classes.iconWrapper}>
      {error ? (
        <Icon name='file' />
      ) : (
        <>
          {!iconMap[iconExtension] && <Icon name='file' />}
          {iconMap[iconExtension] && <Icon name={iconMap[iconExtension]} />}
        </>
      )}
    </div>
  );
};
