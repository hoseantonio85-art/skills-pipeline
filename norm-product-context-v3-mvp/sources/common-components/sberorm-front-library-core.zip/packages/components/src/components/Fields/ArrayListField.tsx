import { MarkdownViewer, Select } from '@sber-orm/ui-kit';
import { useMemo } from 'react';

import { IEditFieldProps } from './types';

export const ArrayListField = ({
  error,
  field,
  fieldName,
  fieldConfig,
  noLabel,
  onChange,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<string[]>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const options = useMemo(
    () =>
      (fieldConfig?.availableItems || []).map((availableItem) => ({
        key: availableItem.id,
        label: availableItem.value,
        value: availableItem.id,
      })),
    [fieldConfig?.availableItems],
  );
  const value = options.filter((option) =>
    ((field?.value as string[]) || [])?.includes(option.key),
  );

  const handleChange = (optionIds: string[]) => {
    onChange(optionIds);
  };

  if (raw) {
    return value ? value.map((val) => val.label).join(', ') : null;
  }

  return (
    <Select
      options={options}
      label={label}
      disableCloseOnSelect
      multiple
      required={!!required}
      labelInside
      showOptionSearch
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      placeholder=''
      canClear
      size='L'
      value={value}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
