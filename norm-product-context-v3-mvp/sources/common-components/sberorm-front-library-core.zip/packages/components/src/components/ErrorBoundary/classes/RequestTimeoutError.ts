import { ErrorCodes, type TErrorCodeValues } from '../types';

export class RequestTimeoutError extends Error {
  code: TErrorCodeValues;

  constructor(message: string) {
    super(message);

    this.code = ErrorCodes.REQUEST_TIMEOUT;
  }
}
