import { ErrorCodes, type TErrorCodeValues } from '../types';

export class BadRequestError extends Error {
  code: TErrorCodeValues;

  constructor(message = '') {
    super(message);

    this.code = ErrorCodes.BAD_REQUEST;
  }
}
