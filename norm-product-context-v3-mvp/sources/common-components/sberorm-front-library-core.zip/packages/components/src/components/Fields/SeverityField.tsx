import { MarkdownViewer, Row, Text } from '@sber-orm/ui-kit';
import cn from 'classnames';
import { useMemo } from 'react';
import styles from './styles.module.scss';
import { IEditFieldProps } from './types';

export const SeverityField = ({
  field,
  fieldConfig,
  noLabel,
  raw = false,
  classes,
}: IEditFieldProps<string>) => {
  const rawValue = field?.value;
  const title = noLabel ? undefined : fieldConfig?.title;

  const helpText = String(fieldConfig?.extras?.help || '');

  const value = useMemo(() => {
    const availableItems = fieldConfig?.availableItems;

    return (
      availableItems?.find((availableItem) => availableItem.id === rawValue)
        ?.value || rawValue
    );
  }, [fieldConfig, rawValue]);

  if (raw) {
    return value || null;
  }

  return (
    <Row direction='column' align='top' gutter={8}>
      <Row gutter={16}>
        <Text size='md'>{title}:</Text>
        <div
          className={cn(
            styles.severity,
            classes?.container,
            classes?.[String(rawValue)],
          )}
        >
          <Text size='md'>{value}</Text>
        </div>
      </Row>

      {!!helpText && (
        <Text size='sm' tooltip>
          <MarkdownViewer markdown={helpText} />
        </Text>
      )}
    </Row>
  );
};
