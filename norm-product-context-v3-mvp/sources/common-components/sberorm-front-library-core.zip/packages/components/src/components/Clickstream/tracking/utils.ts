import type { TPushData } from './types';

export function deepmerge(
  contextData: TPushData,
  ownData: TPushData,
  mergeData?: TPushData | null,
): TPushData {
  const mapProperties = new Map();

  if (contextData.properties) {
    for (const item of contextData.properties) {
      mapProperties.set(item.key, item);
    }
  }
  if (ownData.properties) {
    for (const item of ownData.properties) {
      mapProperties.set(item.key, { ...mapProperties.get(item.key), ...item });
    }
  }
  if (mergeData?.properties) {
    // eslint-disable-next-line no-unsafe-optional-chaining
    for (const item of mergeData.properties) {
      mapProperties.set(item.key, { ...mapProperties.get(item.key), ...item });
    }
  }
  const mergedProperties = [...mapProperties.values()];

  return Object.assign({}, contextData, ownData, mergeData, {
    ...(mergedProperties.length > 0 ? { properties: mergedProperties } : {}),
  });
}
