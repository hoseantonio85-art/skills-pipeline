import { MarkdownViewer, MoneyRangeInput } from '@sber-orm/ui-kit';

import { useCallback, useMemo } from 'react';
import { IEditFieldProps } from './types';

export const CurrencyRangeField = ({
  error,
  field,
  fieldName,
  fieldConfig,
  onChange,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<[number | undefined, number | undefined]>) => {
  const value = useMemo<[number | null, number | null]>(
    () =>
      ((field?.value as [number | null, number | null])?.map<number | null>(
        (item) => item ?? null,
      ) as [number | null, number | null]) || [null, null],
    [field?.value],
  );

  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const helpText = String(fieldConfig?.extras?.help || '');

  const handleChange = useCallback(
    (newValue: [number | undefined | null, number | undefined | null]) => {
      let [from, to] = newValue;

      if (typeof from === 'number' && from < 0) {
        from = Math.abs(from);
      }
      if (typeof to === 'number' && to < 0) {
        to = Math.abs(to);
      }

      onChange([from ?? undefined, to ?? undefined]);
    },
    [onChange],
  );

  if (raw) {
    return value ? value.map((item) => item || '0.00').join(' - ') : null;
  }

  return (
    <MoneyRangeInput
      fullWidth
      size='L'
      canClear
      value={value}
      required={!!required}
      decimalSeparator='.'
      precision={2}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
