import type { BaseItem, Profile } from '@sbol/clickstream-agent';
import React from 'react';

export type TPushData = Partial<BaseItem> & {
  /** Тип события (Клик, свайп, левый клик) */
  eventType?: string;
};
export type TTrackingProfile = Profile & {
  clickStreamEnabled: boolean;
  clickStreamKey: string;
  clickStreamUrl: string;
  sessionKey?: string;
};

export type TProperties = Record<string, string | number | boolean>;

/**
 * This component will pass any tracking data as context to tracking calls made in any components within its subtree.
 */

export type TTrackingComponent<P = {}> = React.FC<React.PropsWithChildren<P>>;

type TFalsy = false | null | undefined | '';

export interface IOptions<T> {
  /**
   * By default, data tracking objects are pushed to `window.dataLayer[]`. This is a good default if you use Google
   * Tag Manager. You can override this by passing in a dispatch function as a second parameter to the tracking
   * decorator `{ dispatch: fn() }` on some top-level component high up in your app (typically some root-level
   * component that wraps your entire app).
   */
  dispatch?(data: T, props?: TProperties): void;

  /**
   * To dispatch tracking data when a component mounts, you can pass in `{ dispatchOnMount: true }` as the second
   * parameter to `@track()`. This is useful for dispatching tracking data on "Page" components.
   *
   * If you pass in a function, the function will be called with all of the tracking data from the app's context when
   * the component mounts. The return value of this function will be dispatched in `componentDidMount()`. The object
   * returned from this function call will be merged with the context data and then dispatched. A use case for this
   * would be that you want to provide extra tracking data without adding it to the context.
   */
  dispatchOnMount?: boolean | ((contextData: T) => T) | undefined;

  /**
   * When there's a need to implicitly dispatch an event with some data for every component, you can define an
   * `options.process` function. This function should be declared once, at some top-level component. It will get
   * called with each component's tracking data as the only argument. The returned object from this function will be
   * merged with all the tracking context data and dispatched in `componentDidMount()`. If a falsy value is returned
   * (`false`, `null`, `undefined`, ...), nothing will be dispatched.
   *
   * A common use case for this is to dispatch a `pageview` event for every component in the application that has a
   * `page` property on its `trackingData`.
   */
  process?(ownTrackingData: T): T | TFalsy;

  /**
   * This method returns all of the contextual tracking data up until this point in the component hierarchy.
   */
  getTrackingData?(): T;

  /**
   * This is another dispatch tracking data
   */
  mergeOptions?: T;
}

/**
 * A React context used to support passing and dispatching tracking data throughout a tree of components.
 */
export interface ITrackingContextProps<T = unknown> {
  tracking: IOptions<T> & { data?: {} | undefined };
}
