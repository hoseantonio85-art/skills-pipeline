import {
  Chips,
  IChipsItem,
  Icon,
  MarkdownViewer,
  Row,
  Text,
  Tooltip,
} from '@sber-orm/ui-kit';
import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

export const BooleanSwitcher = ({
  error,
  fieldName,
  field,
  fieldConfig,
  noLabel,
  raw,
  onChange,
  onTrack,
  required,
  testId,
}: IEditFieldProps<boolean>) => {
  const label = noLabel ? undefined : fieldConfig?.title;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const items: IChipsItem[] = [
    {
      id: 'true',
      title: 'Да',
    },
    {
      id: 'false',
      title: 'Нет',
    },
  ];

  const handleChange = (newValue: string) => {
    onChange?.(JSON.parse(newValue));
    onTrack?.(fieldName!, newValue);
  };

  if (raw) {
    return field?.value ? 'Да' : 'Нет';
  }

  return (
    <Row direction='column' justify='start' align='top' gutter={8}>
      {label && (
        <Row gutter={4} noFlex>
          <Text>
            {label}
            {required && <span className={classes.required}>*</span>}
          </Text>
          {!!hintText && (
            <Tooltip
              placement='top-end'
              content={<MarkdownViewer markdown={hintText} />}
              fallbackPlacements={['left-start']}
            >
              <span className={classes.tooltipIcon}>
                <Icon width={16} height={16} name='infoOutlined' />
              </span>
            </Tooltip>
          )}
        </Row>
      )}
      <Row gutter={4} wrap>
        {items?.map((chips) => (
          <Chips
            key={chips.id}
            item={chips}
            selected={String(field?.value) === chips.id}
            onChange={handleChange}
            size='S'
            testId={testId ? `${testId}-${fieldName}` : undefined}
          />
        ))}
      </Row>
      {!!error && (
        <div className={classes.errorText}>
          <Icon width={16} height={16} name='errorRounded' />
          {error}
        </div>
      )}
      {!error && !!helpText && (
        <Text size='sm' tooltip>
          <MarkdownViewer markdown={helpText} />
        </Text>
      )}
    </Row>
  );
};
