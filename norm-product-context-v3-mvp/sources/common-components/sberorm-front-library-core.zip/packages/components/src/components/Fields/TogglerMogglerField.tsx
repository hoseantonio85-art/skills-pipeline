import { EIconName, Icon, Row, Switch, Text } from '@sber-orm/ui-kit';
import { ChangeEvent } from 'react';
import { useTranslation } from 'react-i18next';
import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

export const TogglerMogglerField = ({
  fieldName,
  field,
  fieldConfig,
  noLabel,
  raw,
  onChange,
  onTrack,
  testId,
  readonly,
}: IEditFieldProps<boolean | undefined>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const { t } = useTranslation();

  const icon = String(fieldConfig?.extras?.icon || '');

  const handleChange = (event?: ChangeEvent<HTMLInputElement>) => {
    const newValue = event?.target.checked || !field?.value;
    onChange(newValue || undefined);
    onTrack?.(fieldName!, String(newValue));
  };

  if (raw) {
    return field?.value ? t('yes') : t('no');
  }

  return (
    <Row
      justify='between'
      align='middle'
      gutter={16}
      className={classes.togglerMoggler}
      onClick={editable ? () => handleChange() : undefined}
    >
      <Row gutter={4} noFlex>
        {!!icon && (Object.values(EIconName) as string[]).includes(icon) && (
          <Icon name={icon as EIconName} />
        )}
        <Text bold size='lg' nowrap>
          {label}
        </Text>
      </Row>

      <div
        className={classes.switchWrapper}
        onClick={(event) => event.stopPropagation()}
      >
        <Switch
          disabled={!editable}
          checked={!!field?.value}
          onChange={handleChange}
          data-testid={testId}
        />
      </div>
    </Row>
  );
};
