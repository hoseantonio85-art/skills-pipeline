import { ErrorCodes, type TErrorCodeValues } from '../types';

export class PageNotFoundError {
  code: TErrorCodeValues;

  constructor() {
    this.code = ErrorCodes.PAGE_NOT_FOUND;
  }
}
