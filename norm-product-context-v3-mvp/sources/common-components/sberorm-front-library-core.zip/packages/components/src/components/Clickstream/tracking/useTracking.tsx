import { useCallback, useMemo } from 'react';

import { TrackingContext } from './TrackingContext';
import { IOptions, TPushData, TTrackingComponent } from './types';
import { useTrackingImpl } from './useTrackingImpl';

export function useTracking(
  trackingData: TPushData | (() => TPushData) = {},
  options: IOptions<TPushData> = {},
) {
  const contextValue = useTrackingImpl(trackingData, options);

  const Track: TTrackingComponent = useCallback(
    ({ children }) => (
      <TrackingContext.Provider value={contextValue}>
        {children}
      </TrackingContext.Provider>
    ),
    [contextValue],
  );

  return useMemo(
    () => ({
      Track,
      getTrackingData: contextValue.tracking.getTrackingData,
      trackEvent: contextValue.tracking.dispatch,
    }),
    [contextValue, Track],
  );
}
