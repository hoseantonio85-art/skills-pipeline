import { ErrorPageWrap } from './components';
import { IErrorInstanceType, IErrorPageWrapProps } from './types';
import { getErrorComponentProps } from './utils';

export const ErrorComponent = (
  props: IErrorInstanceType & Partial<IErrorPageWrapProps>,
) => {
  const { addNotification, ...error } = props;
  const errorComponentProps = getErrorComponentProps(error);

  return (
    <ErrorPageWrap {...errorComponentProps} addNotification={addNotification} />
  );
};
