import { DateRangePicker, MarkdownViewer } from '@sber-orm/ui-kit';
import dayjs from 'dayjs';
import isBetween from 'dayjs/plugin/isBetween';

import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

dayjs.extend(isBetween);

export const NewDateRangeField = ({
  error,
  field,
  fieldName,
  fieldConfig,
  fallbackFieldConfig,
  onChange,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<[string, string]>) => {
  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const endRequired = fallbackFieldConfig?.required ?? false;

  const helpText = String(fieldConfig?.extras?.help || '');

  const getValue = (): [dayjs.Dayjs | null, dayjs.Dayjs | null] => {
    const [d1, d2] = (field?.value as [string, string]) || [];
    const date1 = String(d1);
    const date2 = String(d2) || 'error';
    const date1Valid = dayjs(date1).isValid();
    const date2Valid = dayjs(date2).isValid();

    return [date1Valid ? dayjs(date1) : null, date2Valid ? dayjs(date2) : null];
  };

  if (raw) {
    return getValue()
      .map((date) => date?.format('DD.MM.YYYY'))
      .join(' - ');
  }

  const value = getValue();

  const handleChange = (values: [unknown, unknown]) => {
    const dateFrom = values[0] as null | dayjs.Dayjs;
    const dateTo = (values[1] as null | dayjs.Dayjs)
      ?.hour(23)
      .minute(59)
      .second(59)
      .millisecond(999);

    onChange([dateFrom?.toISOString() || '', dateTo?.toISOString() || '']);
  };

  return (
    <DateRangePicker
      value={value}
      required={!!required}
      startLabel={'От'}
      endLabel={'До'}
      className={classes.dateRangePicker}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      endRequired={!!endRequired}
      fullWidth
      datePanelStyle='single'
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
