import {
  ComboboxEvent,
  MarkdownViewer,
  Select,
  TreeItem,
  TSelectProperties,
} from '@sber-orm/ui-kit';
import { Key, useCallback, useEffect, useMemo, useState } from 'react';

import { Item, SearchResponseEntry } from '../../@types/api';
import { fieldNotEmpty } from '../../utils';
import { IEditFieldProps } from './types';

interface ITreeFieldItem extends TreeItem {
  value?: string;
  leaf?: boolean;
}

export interface ITreeFieldProps extends IEditFieldProps<string> {
  selectProps?: TSelectProperties;
}

type TTreeSelectModeType = Exclude<
  NonNullable<TSelectProperties['treeProps']>['selectMode'],
  undefined
>;

const addChildrenToNode = (
  nodeKey: Key,
  children: ITreeFieldItem[],
  tree: ITreeFieldItem[],
) => {
  for (const item of tree) {
    if (item.key === nodeKey) {
      item.children = children;
      item.loadable = false;
      return tree;
    }
    if (item.children) {
      addChildrenToNode(nodeKey, children, item.children as ITreeFieldItem[]);
    }
  }

  return tree;
};

const mapItemsToTree = (items: Item[]): ITreeFieldItem[] =>
  items.map((item) => ({
    key: item.id!,
    label: item.name || item.id!,
    leaf: item.leaf,
    loadable: !item.leaf,
    value: item.id!,
  }));

const mapSearchResultsToOptions = (
  searchEntries: SearchResponseEntry[],
): ITreeFieldItem[] => {
  const optionsMap = new Map<string, ITreeFieldItem>();

  searchEntries.forEach((entry) => {
    const fullPath = entry.path;
    if (fullPath && fullPath.length === 0) {
      return;
    }

    const lastItem = fullPath?.[fullPath.length - 1];
    if (!lastItem?.id) {
      return;
    }

    // TODO если нужно будет выводить путь до найденного элемента
    // const label = fullPath
    //   .map((item) => item.name || item.id)
    //   .filter(Boolean)
    //   .join(' / ');

    optionsMap.set(lastItem.id, {
      key: lastItem.id,
      label: lastItem.name || lastItem.id,
      leaf: lastItem.leaf ?? false,
      value: lastItem.id,
    });
  });

  return Array.from(optionsMap.values());
};

export const TreeField = (props: ITreeFieldProps) => {
  const {
    error,
    field,
    fieldConfig,
    fieldName,
    noLabel,
    onChange,
    onTrack,
    raw,
    required,
    loadStructure,
    onSearchStructure,
    selectProps = {},
    testId,
    readonly,
  } = props;

  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const label = noLabel ? undefined : fieldConfig?.title;
  const value = field?.value;
  const pathItems = fieldConfig?.pathItems || [];
  const validation = fieldConfig?.validation || [];
  const dictionary = fieldConfig?.extras?.['dictionary'] as string;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const [initialized, setInitialized] = useState<boolean>();
  const [options, setOptions] = useState<ITreeFieldItem[]>([]);
  const [selectedValue, setSelectedValue] = useState<
    ITreeFieldItem | undefined
  >(undefined);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!fieldNotEmpty(field)) {
      setSelectedValue(undefined);
      return;
    }

    if (isSearching) {
      return;
    }

    const stringValue = String(value);
    if (selectedValue?.key === stringValue) {
      return;
    }

    const label =
      pathItems.find((pathItem) => pathItem.id === stringValue)?.value ||
      stringValue;

    setSelectedValue({
      key: stringValue,
      label,
      value: stringValue,
    });
  }, [value]);

  const selectMode = useMemo<TTreeSelectModeType>(
    () =>
      validation.some((valid) => valid.type === 'onlyLeaf')
        ? 'strict'
        : 'directory',
    [validation],
  );

  const selectOptions = useMemo(() => selectProps, [selectProps]);

  const onSelect = useCallback(
    (newValue: string, _event: ComboboxEvent, newOption: ITreeFieldItem) => {
      setSelectedValue(newOption);
      onTrack?.(fieldName!, (newOption?.label as string) ?? undefined);

      onChange(newValue);
    },
    [onChange, onTrack, fieldName],
  );

  const onLoadData = useCallback(
    async (option: ITreeFieldItem) => {
      const { levels } = await loadStructure(dictionary, String(option.key));

      const items = levels?.pop()?.items || [];
      const children = mapItemsToTree(items);

      setOptions((prev) => {
        return addChildrenToNode(option.key, children, [...prev]);
      });
    },
    [loadStructure, dictionary],
  );

  const handleInputChange = useCallback(
    async (searchValue: string) => {
      if (!onSearchStructure || !searchValue.trim()) {
        const { levels } = await loadStructure(dictionary);
        const items = levels?.pop()?.items || [];

        setOptions(mapItemsToTree(items));

        setIsSearching(false);
        return;
      }

      setIsSearching(true);
      try {
        const result = await onSearchStructure(searchValue.trim(), dictionary);
        if (!result) {
          return;
        }

        const searchEntries = result?.items || [];

        if (searchEntries.length > 0) {
          const searchOptions = mapSearchResultsToOptions(searchEntries);
          setOptions(searchOptions);
        } else {
          setOptions([]);
        }
      } catch {
        setOptions([]);
      }
    },
    [onSearchStructure, dictionary, loadStructure],
  );

  const handleInitialize = useCallback(async () => {
    if (initialized || !editable) {
      return;
    }
    const { levels } = await loadStructure(
      dictionary,
      selectedValue?.value || undefined,
    );

    if (!levels || levels.length === 0) {
      setInitialized(true);
      return;
    }

    const root = levels?.shift();
    let newOptions: ITreeFieldItem[] = root?.items
      ? mapItemsToTree(root.items)
      : [];

    let selectedId = root?.selectedId;
    levels.forEach((level) => {
      if (selectedId && level.items?.length) {
        newOptions = addChildrenToNode(
          selectedId,
          mapItemsToTree(level.items),
          newOptions,
        );
        selectedId = level.selectedId;
      }
    });

    setOptions(newOptions);
    setInitialized(true);
  }, [loadStructure, dictionary, initialized, selectedValue]);

  const treeProps = useMemo(
    () => ({
      onLoadData,
      selectMode,
    }),
    [onLoadData, selectMode],
  );

  if (raw) {
    const labels = pathItems?.map((item) => item.value).filter(Boolean);
    return <>{labels.length > 0 ? labels.join(' / ') : null}</>;
  }

  return (
    <Select
      options={options}
      label={label}
      tree
      treeProps={treeProps}
      value={selectedValue || null}
      required={!!required}
      onChange={onSelect}
      labelInside
      size='L'
      canClear
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      hideDropdownOnOutsideScroll={false}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      onMenuOpen={handleInitialize}
      onMenuClose={() => {
        if (isSearching && !!onSearchStructure) {
          handleInputChange('');
        }
      }}
      disabled={!editable}
      useCustomSearch={!!onSearchStructure}
      showOptionSearch={!!onSearchStructure}
      onInputChange={onSearchStructure ? handleInputChange : undefined}
      {...selectOptions}
      disableCloseOnSelect={isSearching}
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
