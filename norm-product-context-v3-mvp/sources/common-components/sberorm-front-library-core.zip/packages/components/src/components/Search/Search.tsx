import { Icon, OldInput } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React, { useState } from 'react';

import classes from './styles.module.scss';
import { ISearchProps } from './types';

export const Search = ({
  className,
  disabled,
  label,
  loading,
  onChange,
  onClick,
  onSubmit,
  onClear,
  placeholder,
  secondary = true,
  size = 'lg',
  testId,
  value,
}: ISearchProps) => {
  const [focused, setFocused] = useState<boolean>(false);

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !(event.key === 'Enter' && event.shiftKey)) {
      event.preventDefault();
      onSubmit(value);
    }
  };

  return (
    <OldInput
      className={className}
      disabled={disabled}
      value={value}
      fullWidth
      secondary={secondary}
      canClear={!loading}
      placeholder={label ? undefined : placeholder}
      label={label}
      testId={testId}
      prefix={
        <Icon
          name='search'
          className={cn(classes.icon, classes[`iconSize${size}`], {
            [classes.iconDisabled]: disabled,
            [classes.iconNotSecondary]: !secondary,
          })}
          onClick={() => onSubmit(value)}
        />
      }
      size={size}
      onChange={onChange}
      onKeyDown={onKeyDown}
      onClear={onClear}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      labelInside={!!label}
      onClick={onClick}
      labelledClasses={
        label
          ? {
              topLabelsWrapper: cn(classes.topLabelsWrapper, {
                [classes.topLabelsWrapperFocused]: focused || value,
              }),
            }
          : undefined
      }
      suffix={
        loading ? (
          <Icon
            name='track'
            width={16}
            height={16}
            className={classes.loadingIndicator}
          />
        ) : undefined
      }
    />
  );
};
