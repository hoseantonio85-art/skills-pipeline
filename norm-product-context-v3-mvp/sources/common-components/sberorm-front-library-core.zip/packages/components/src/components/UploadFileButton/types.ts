import type {
  IFileAttach,
  IFileProperties,
  IFileValidationParameters,
} from '../File';

export type TFile = Pick<IFileProperties, 'onDownload' | 'onRemove' | 'author'>;
export type TFileAccepts = Pick<IFileValidationParameters, 'accepts'>;

export interface IUploadButtonProperties extends TFile, TFileAccepts {
  fileInfos?: File[];
  addButtonText?: string;
  uploadButtonText?: string;
  helpText?: string;
  onUpload: (
    item: File | null,
    onUploadProgress?: (fileId: string, value: number) => void,
  ) => void;
  multiple?: boolean;
  autoUpload?: boolean;
}

export type TErrorMessage = Pick<IFileProperties, 'error' | 'errorText'>;
export interface IFileProgress {
  percentage: number;
  fileName: string;
}

export type TFileAttach = IFileAttach & Pick<IFileProperties, 'source'>;
