import {
  ALLOWED_EXTENSIONS,
  MAX_FILE_NAME_LENGTH,
  MAX_FILE_SIZE,
} from './const';
import { IFileValidation, IFileValidationParameters } from './types';

export class FileValidation {
  private accepts = ALLOWED_EXTENSIONS;

  private readonly maxSize = MAX_FILE_SIZE;

  private readonly maxLength: number = MAX_FILE_NAME_LENGTH;

  constructor(parameters: IFileValidationParameters = {}) {
    if (parameters?.accepts) {
      this.accepts = parameters.accepts;
    }

    if (parameters?.maxSize) {
      this.maxSize = parameters.maxSize;
    }

    if (parameters?.maxLength) {
      this.maxLength = parameters.maxLength;
    }
  }

  fileAcceptExtensionsValidate(fileInput: File): IFileValidation {
    const allowedExtensionsReg = new RegExp(
      '(' + this.accepts.join('|').replaceAll('.', String.raw`\.`) + ')$',
      'i',
    );

    if (!allowedExtensionsReg.test(fileInput.name)) {
      return {
        error: 'Расширение файла не поддерживается.',
        success: false,
      };
    }

    return { success: true };
  }

  fileSizeValidate(fdata: File): IFileValidation {
    if (fdata.size > this.maxSize) {
      return {
        error: `Файл слишком большой, пожалуйста, выберите файл размером менее ${(this.maxSize / (1024 * 1024)) as number} МБ.`,
        success: false,
      };
    }

    return { success: true };
  }

  fileNameLengthValidate(fdata: File): IFileValidation {
    if (fdata.name.length >= this.maxLength) {
      return {
        error: `Длина наименования файла должна быть менее ${this.maxLength} символов.`,
        success: false,
      };
    }

    return { success: true };
  }

  validate(file: File): IFileValidation {
    const validateFunctions = [
      this.fileAcceptExtensionsValidate,
      this.fileSizeValidate,
      this.fileNameLengthValidate,
    ];

    // eslint-disable-next-line no-underscore-dangle
    for (const function_ of validateFunctions) {
      const validObject = function_.call(this, file);

      if (!validObject.success) {
        return validObject;
      }
    }

    return { success: true };
  }
}
