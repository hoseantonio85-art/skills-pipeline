import { MarkdownViewer, Select } from '@sber-orm/ui-kit';
import { useMemo } from 'react';

import { IEditFieldProps } from './types';

export const ListField = ({
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<string | undefined>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const options = useMemo(
    () =>
      (fieldConfig?.availableItems || []).map((availableItem) => ({
        key: availableItem.id,
        label: availableItem.value,
        value: availableItem.id,
      })),
    [fieldConfig?.availableItems],
  );
  const value = options.find((option) => option.key === field?.value);

  const handleChange = (optionId: string) => {
    onChange(optionId || undefined);
    onTrack?.(
      fieldName!,
      options.find((option) => option.key === optionId)?.label,
    );
  };

  if (raw) {
    return value ? value.label : null;
  }

  return (
    <Select
      options={options}
      label={label}
      hideDropdownOnOutsideScroll={false}
      placeholder=''
      labelInside
      size='L'
      canClear
      showOptionSearch
      required={!!required}
      value={value}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
