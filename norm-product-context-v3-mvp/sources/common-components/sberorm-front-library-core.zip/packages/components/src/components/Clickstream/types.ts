export enum EEventType {
  business = 'business',
  sensitive = 'sensitive',
  technical = 'technical',
}

export type TEventType = keyof typeof EEventType;

export interface IDispatchEventProps {
  delay?: number;
  eventType?: TEventType;
}

interface IUserInfo {
  /** Внутренний табельный номер сотрудника */
  personalNumber?: string;
  /** Имя */
  firstName?: string;
  /** Отчество */
  middleName?: string;
  /** Фамилия */
  lastName?: string;
  /** Должность */
  position?: string;
  /** Внутренний идентификатор сотрудника в Сбер ОРМ */
  userId?: string;
  /** Тип сотрудника РК или РМ */
  userType?: string;
}

export interface IClickStreamProviderProps {
  disabled?: boolean;
  userInfo: IUserInfo;
  appBlockName: string;
  clickStreamEnabled: boolean;
  clickStreamKey: string;
  clickStreamUrl: string;
  tenantId?: string;
}
