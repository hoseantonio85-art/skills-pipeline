import { Button, Row, Text, Title } from '@sber-orm/ui-kit';
import React, { useImperativeHandle, useState } from 'react';

import { Drawer } from '../Drawer';
import { type IModalDialogRef } from '../ModalDialog';
import Logo from './images/confirmation-logo.svg?react';
import classes from './styles.module.scss';
import { IConfirmationModalProps } from './types';

export const ConfirmationModal = React.forwardRef<
  IModalDialogRef,
  IConfirmationModalProps
>((props, ref) => {
  const {
    cancelButtonText,
    handleSubmit,
    img,
    submitButtonText,
    text,
    title,
    prefixFooter,
    testId,
  } = props;
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const handleClose = () => {
    setIsOpen(false);
  };

  useImperativeHandle(ref, () => ({
    close: handleClose,
    open: () => setIsOpen(true),
  }));

  const Img = img ?? Logo;

  const drawerFooter = (
    <Row gutter={16} wrap>
      {prefixFooter}
      <Button
        size='L'
        variant='secondary'
        onClick={handleClose}
        fullWidth
        className={classes.footerBtn}
        data-testid={testId ? `${testId}-cancel` : undefined}
      >
        {cancelButtonText || 'Отменить'}
      </Button>
      <Button
        size='L'
        variant='danger'
        onClick={handleSubmit}
        fullWidth
        className={classes.footerBtn}
        data-testid={testId ? `${testId}-submit` : undefined}
      >
        {submitButtonText}
      </Button>
    </Row>
  );

  return (
    <Drawer
      position='absolute'
      open={isOpen}
      onClose={handleClose}
      footer={drawerFooter}
      inModal
    >
      <Row
        direction='column'
        align='middle'
        justify='center'
        className={classes.content}
      >
        <Img className={classes.img} />
        <Title className={classes.title} size='H700'>
          {title}
        </Title>
        {text && (
          <Text className={classes.text} size='lg'>
            {text}
          </Text>
        )}
      </Row>
    </Drawer>
  );
});
ConfirmationModal.displayName = 'ConfirmationModal';
