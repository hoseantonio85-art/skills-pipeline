import { IOldInputProperties } from '@sber-orm/ui-kit';

export interface ISearchProps {
  onChange(value: string): void;
  value?: string;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  onSubmit(value?: string): void;
  onClick?: () => void;
  onClear?: () => void;
  label?: string;
  secondary?: boolean;
  loading?: boolean;
  size?: IOldInputProperties['size'];
  testId?: string;
}
