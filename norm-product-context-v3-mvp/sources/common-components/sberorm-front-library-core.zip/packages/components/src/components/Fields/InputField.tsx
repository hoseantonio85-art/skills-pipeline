import {
  Input,
  MarkdownViewer,
  useComponentDidMount,
  useDebounce,
} from '@sber-orm/ui-kit';
import { useEffect, useState } from 'react';

import { IEditFieldProps } from './types';

export const InputField = ({
  className,
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
}: IEditFieldProps<string>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = fieldConfig?.editable ?? true;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const [value, setValue] = useState<string>(String(field?.value || ''));

  const trackValue = useDebounce(value, 1000);
  const isComponentMounted = useComponentDidMount();

  const handleChange = (newValue: string) => {
    setValue(newValue);
    onChange(newValue);
  };

  useEffect(() => {
    isComponentMounted && onTrack?.(fieldName!, trackValue);
  }, [trackValue]);

  useEffect(() => {
    setValue(String(field?.value || ''));
  }, [field?.value]);

  if (raw) {
    return value || null;
  }

  return (
    <Input
      labelInside
      className={className}
      fullWidth
      required={!!required}
      size='L'
      label={label}
      value={value}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
