import { ETextSize, ETitleSize, Row, Text, Title } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React from 'react';

import classes from './styles.module.scss';
import type { TTitleBlockProperties } from './types';

const titleSizes = {
  [ETextSize.lg]: ETitleSize.H800,
  [ETextSize.md]: ETitleSize.H800,
  [ETextSize.sm]: ETitleSize.H500,
  [ETextSize.xlg]: ETitleSize.H800,
  [ETextSize.xxlg]: ETitleSize.H900,
} as const;

export const TitleBlock = React.forwardRef<
  HTMLDivElement,
  TTitleBlockProperties
>((props, ref) => {
  const {
    children,
    helpMessage,
    mb = 0,
    size = ETextSize.md,
    nowrap,
    subTitle,
  } = props;

  return (
    <Row ref={ref} gutter={4} align='top' justify='start' mb={mb} noFlex>
      <div
        className={cn(classes.dash, {
          [classes['dash-sm']]: size === ETextSize.sm,
        })}
      >
        &mdash;
      </div>
      <div>
        <Title
          size={titleSizes[size]}
          nowrap={nowrap}
          mb={
            Number(helpMessage?.length) > 0 || Number(subTitle?.length) > 0
              ? 4
              : 0
          }
        >
          {children}
        </Title>
        {subTitle && (
          <Text size='lg' mb={helpMessage ? 4 : 0}>
            {subTitle}
          </Text>
        )}
        {helpMessage && (
          <Text size='sm' mb={0} className={classes.help}>
            {helpMessage}
          </Text>
        )}
      </div>
    </Row>
  );
});
TitleBlock.displayName = 'TitleBlock';
