import { INotificationOptions } from '@sber-orm/ui-kit';
import React from 'react';

export const ErrorCodes = {
  BUSINESS: 200,
  BAD_REQUEST: 400,
  UNAUTHIRIZED: 401,
  FORBIDDEN: 403,
  PAGE_NOT_FOUND: 404,
  REQUEST_TIMEOUT: 408,
  SERVICE_UNAVAILABLE: 503,
  GATEWAY_TIMEOUT: 504,
  APP_ERROR: 'APP_ERROR',
  PROGRAM_CRASHED: 'PROGRAM_CRASHED',
} as const;

export type TErrorCodeValues = (typeof ErrorCodes)[keyof typeof ErrorCodes];
export type TNotificationCallback = (
  text: string,
  opts?: INotificationOptions,
) => void;

export interface IErrorInstanceType {
  exception?: string;
  message?: string;
  stack?: string;
  code?: TErrorCodeValues;
  title?: string;
  text?: string;
  addNotification?: TNotificationCallback;
  supportLink?: React.ReactNode;
}

export enum EBusinessErrorTypes {
  business = 'E003',
  critical = 'E001',
  warning = 'E002',
  notification = 'E004',
}

export interface IErrorMessage {
  uuid?: string;
  code?: string;
  system?: string;
  title?: string;
  text?: string;
  exception?: string;
}

export interface IPageErrorComponentProperties {
  error: IErrorInstanceType | null;
  pathName: string;
}

export interface IErrorBoundaryProperties {
  children?: React.ReactNode;
  pathName: string;
  notificationCallback?: TNotificationCallback;
  supportLink?: React.ReactNode;
}

export enum ERESTErrorEvents {
  http = 'httpError',
  business = 'businessError',
}

export interface IErrorPageWrapProps {
  title: string;
  subTitle: string;
  IconComponent: React.FC<React.SVGProps<SVGSVGElement> & { title?: string }>;
  errorText?: string;
  withButton?: boolean;
  withCopy?: boolean;
  withRefresh?: boolean;
  center?: boolean;
  modal?: boolean;
  addNotification?: TNotificationCallback;
  onMainPageClick?: () => void;
  supportLink?: React.ReactNode;
}
