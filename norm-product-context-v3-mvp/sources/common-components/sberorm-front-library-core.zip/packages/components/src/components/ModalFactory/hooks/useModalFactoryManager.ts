import { useCallback, useEffect, useRef } from 'react';
import { useModal } from '../provider';
import { IModalProps } from '../types';

export const useModalManager = () => {
  const {
    openModal,
    closeModal,
    closeAllModals,
    currentModal,
    isModalOpen,
    queue,
  } = useModal();

  const stateRef = useRef({
    queue,
    currentModal,
    waitingInQueue: queue.length,
  });

  useEffect(() => {
    stateRef.current = {
      queue,
      currentModal,
      waitingInQueue: queue.length,
    };
  }, [queue, currentModal]);

  const createModal = useCallback(
    <T extends IModalProps>(
      component: React.ComponentType<T>,
      defaultProps?: Omit<T, 'isOpen' | 'onClose'>,
      baseId?: string,
    ) => {
      const modalActionId =
        baseId ||
        `modal-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

      return {
        open: (props?: Omit<T, 'isOpen' | 'onClose'>) => {
          openModal(modalActionId, component, {
            ...defaultProps,
            ...props,
          } as Omit<T, 'isOpen' | 'onClose'>);
          return modalActionId;
        },
        close: () => closeModal(modalActionId),
        getState: () => stateRef.current,
        id: modalActionId,
      };
    },
    [openModal, closeModal],
  );

  return {
    createModal,
    closeModal,
    closeAllModals,
    isModalOpen,
    currentModal,
    waitingInQueue: stateRef.current.waitingInQueue,
    stateRef,
  };
};
