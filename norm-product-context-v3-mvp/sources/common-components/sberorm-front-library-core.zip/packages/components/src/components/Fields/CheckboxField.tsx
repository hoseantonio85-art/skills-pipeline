import { Checkbox } from '@sber-orm/ui-kit';
import { ChangeEvent, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { IEditFieldProps } from './types';

export const CheckboxField = ({
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  testId,
  readonly,
}: IEditFieldProps<boolean>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const { t } = useTranslation();

  const value = useMemo<boolean>(() => Boolean(field?.value), [field?.value]);

  const helpText = String(fieldConfig?.extras?.help || '');

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.checked);
    onTrack?.(fieldName!, String(event.target.checked));
  };

  if (raw) {
    return field?.value ? t('yes') : t('no');
  }

  return (
    <Checkbox
      label={label}
      checked={value}
      // required={!!required} TODO
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={error ?? helpText}
      disabled={!editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
