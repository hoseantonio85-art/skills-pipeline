import React from 'react';

import { ITrackingContextProps, TPushData } from './types';

export const TrackingContext = React.createContext<
  Partial<ITrackingContextProps<TPushData>>
>({});
