import {
  Button,
  Input,
  MarkdownViewer,
  Row,
  Text,
  useComponentDidMount,
  useDebounce,
} from '@sber-orm/ui-kit';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './styles.module.scss';
import { IEditFieldProps } from './types';

export const InputListField = ({
  className,
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<string[]>) => {
  const { t } = useTranslation();

  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const [values, setValues] = useState<string[]>(
    (field?.value && (field?.value as string[]).length
      ? field?.value
      : ['']) as string[],
  );

  const trackValue = useDebounce(values, 1000);
  const isComponentMounted = useComponentDidMount();

  const handleAdd = () => {
    setValues([...values, '']);
  };

  const handleChange = (value: string, index: number) => {
    if (index > -1) {
      const newValues = [
        ...values.slice(0, index),
        value,
        ...values.slice(index + 1, values.length),
      ];

      setValues(newValues);
      onChange(newValues.filter((item) => !!item));
    }
  };

  const handleDelete = (index: number) => {
    if (index > -1) {
      const newValues = [
        ...values.slice(0, index),
        ...values.slice(index + 1, values.length),
      ];

      setValues(newValues);
      onChange(newValues.filter((item) => !!item));
    }
  };

  useEffect(() => {
    isComponentMounted && onTrack?.(fieldName!, trackValue.join(', '));
  }, [trackValue]);

  if (raw) {
    return values.join(', ') || null;
  }

  return (
    <Row direction='column' justify='start' align='top' gutter={16}>
      {values.map((result, index) => (
        <Row className={styles.inputList} key={index} align='top' gutter={16}>
          <Input
            size='L'
            className={className}
            onChange={(value) => handleChange(value, index)}
            value={result}
            required={index === 0 && required}
            label={label}
            disabled={!editable}
            tooltip={
              index === 0 && !!hintText ? (
                <MarkdownViewer markdown={hintText} />
              ) : undefined
            }
            error={index === 0 && typeof error === 'string'}
            helperText={index === 0 && error}
            labelInside
            data-testid={testId ? `${testId}-${fieldName}-${index}` : undefined}
          />
          {values.length > 1 && editable && (
            <Button
              variant='tertiary'
              icon='trash'
              onClick={() => handleDelete(index)}
              size='L'
              iconOnly
              data-testid={
                testId ? `${testId}-${fieldName}-${index}-delete` : undefined
              }
            />
          )}
        </Row>
      ))}
      {editable && (
        <Button
          onClick={handleAdd}
          icon='plus'
          size='M'
          variant='tertiary'
          fullWidth
          data-testid={testId ? `${testId}-${fieldName}-add` : undefined}
        >
          {t('add')}
        </Button>
      )}
      {!error && !!helpText && (
        <Text size='sm' tooltip>
          <MarkdownViewer markdown={helpText} />
        </Text>
      )}
    </Row>
  );
};
