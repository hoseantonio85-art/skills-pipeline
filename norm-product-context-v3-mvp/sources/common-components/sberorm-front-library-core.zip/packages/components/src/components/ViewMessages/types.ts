/** Действие */
export interface IAction {
  /** Текст действия */
  title?: string;
  /** Тип действия. Внешняя (external) или подсказка-дровер (hint) */
  type?: string;
  /** Адрес ссылки. Если ссылка внешняя, то полная ссылка. Если дровер, то часть ссылки */
  link?: string;
}

/** Сведения об общих требованиях валидации при переходе по флоу */
export interface INotification {
  /**
   * Тип ошибки. Используется для отображения ошибки на фронте. Возможные значения:
   *   - error - ошибка обработки данных
   *   - warning
   *   - info
   *   - success - уведомление об успешном выполнении действия.
   */
  notificationType?: string;
  /** Код ошибки. В зависимости от переданного кода ошибки на фронте могут быть выполнены дополнительные действия (например, перезапрашиваются данные с новыми параметрами). Необязательное поле */
  code?: string;
  title?: string;
  /** Текст ошибки */
  text?: string;
  /** действия (кнопки) */
  actions?: IAction[];
}

export interface IViewMessagesProps {
  className?: string;
  items?: INotification[];
  onClose?: (value: number) => void;
  onClick?: (a: IAction, n?: INotification) => void;
}
