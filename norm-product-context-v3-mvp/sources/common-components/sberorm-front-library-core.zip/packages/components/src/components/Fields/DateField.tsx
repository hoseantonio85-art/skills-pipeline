import { DatePicker, MarkdownViewer } from '@sber-orm/ui-kit';
import dayjs from 'dayjs';
import en from 'dayjs/locale/en';
import ru from 'dayjs/locale/ru';
import { useEffect, useMemo, useState } from 'react';
import { formatDate } from '../../utils';

import { IEditFieldProps } from './types';

dayjs.locale({
  ...ru,
  weekStart: 1,
  weekdaysShort: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
});
dayjs.locale({
  ...en,
  weekStart: 1,
});

export const DateField = ({
  className,
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<string | null>) => {
  const title = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const initialValue = useMemo<dayjs.Dayjs | null>(() => {
    const date = String(field?.value);
    const dateValid = dayjs(date).isValid();

    return dateValid ? dayjs(date) : null;
  }, [field?.value]);

  const [value, setValue] = useState<dayjs.Dayjs | null>(initialValue);

  const helpText = String(fieldConfig?.extras?.help || '');

  const handleChange = (newValue: unknown) => {
    setValue(newValue as dayjs.Dayjs | null);
    onChange((newValue as dayjs.Dayjs | null)?.toISOString() || null);
    onTrack?.(
      fieldName!,
      newValue
        ? formatDate((newValue as dayjs.Dayjs)?.toISOString())
        : undefined,
    );
  };

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  if (raw) {
    return value ? formatDate(value?.toISOString()) : null;
  }

  return (
    <DatePicker
      className={className}
      value={value}
      label={title}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      required={!!required}
      disabled={!editable}
      size='L'
      fullWidth
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
