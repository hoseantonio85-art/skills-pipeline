import { Button, Icon, Row, Text } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React, { createContext, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Portal } from '../PortalDialog';
import classes from './styles.module.scss';

export const ModalContext = createContext({
  openChat: () => {},
});

interface IChatIconComponentProps {
  dumb?: boolean;
  className?: string;
  onClick?: () => void;
}

interface IChatComponentProps {
  hideCreatingForm?: boolean;
  onClose?: () => void;
}

export interface IModalLayoutProps {
  onOpenPrevious?: () => void;
  onOpenNext?: () => void;
  onClose?: () => void;
  onBack?: () => void;
  openChat?: boolean;
  contentClassName?: string;
  children: React.ReactNode;
  chatState?: 'small' | 'icon' | 'fullScreen';
  ChatIconComponent?: React.ComponentType<IChatIconComponentProps>;
  ChatComponent?: React.ComponentType<IChatComponentProps>;
}

export const ModalLayout = (props: IModalLayoutProps) => {
  const {
    onBack,
    onClose,
    onOpenNext,
    onOpenPrevious,
    openChat,
    contentClassName,
    children,
    chatState,
    ChatComponent,
    ChatIconComponent,
  } = props;

  const { t } = useTranslation('common');

  const [isChatOpen, setIsChatOpen] = useState(openChat);

  return (
    <Portal id='modal-container' visible>
      <div
        className={cn(classes.wrapper, {
          [classes.wrapperChatOpen]: isChatOpen,
          [classes.wrapperChatRight]: chatState === 'small',
        })}
      >
        <div className={classes.flex}>
          {onOpenPrevious && (
            <Icon
              onClick={onOpenPrevious}
              className={classes.navigationButton}
              width={40}
              height={40}
              name='previousLarge'
            />
          )}
        </div>

        <div className={cn(classes.content, contentClassName)}>
          <ModalContext.Provider
            value={{ openChat: () => setIsChatOpen(true) }}
          >
            <Row className={classes.buttons} gutter={16}>
              {onBack && (
                <>
                  <Button
                    variant='ellipse'
                    size='S'
                    icon='previousLarge'
                    onClick={onBack}
                  >
                    <Text size='lg' bold className={classes.buttonsText}>
                      {t('back')}
                    </Text>
                  </Button>
                  {onClose && <div className={classes.buttonsDivider} />}
                </>
              )}
              {onClose && (
                <Button
                  variant='ellipse'
                  size='S'
                  icon='cross'
                  iconOnly
                  onClick={onClose}
                  data-testid='risks-form-close'
                />
              )}
            </Row>
            {children}
          </ModalContext.Provider>

          {!isChatOpen && ChatIconComponent && (
            <ChatIconComponent
              dumb
              className={classes.chatIcon}
              onClick={() => setIsChatOpen(true)}
            />
          )}
        </div>
        {isChatOpen && ChatComponent && (
          <ChatComponent
            hideCreatingForm
            onClose={() => setIsChatOpen(false)}
          />
        )}

        <div className={classes.flex}>
          {onOpenNext && (
            <Icon
              onClick={onOpenNext}
              className={classes.navigationButton}
              width={40}
              height={40}
              name='nextLarge'
            />
          )}
        </div>
      </div>
    </Portal>
  );
};
