import { useCallback, useContext, useEffect, useMemo, useRef } from 'react';
import { dispatchTrackingEvent } from './dispatchTrackingEvent';
import { TrackingContext } from './TrackingContext';
import { IOptions, TProperties, TPushData } from './types';
import { deepmerge } from './utils';

export function useTrackingImpl(
  trackingData: TPushData | (() => TPushData),
  options: IOptions<TPushData>,
) {
  const { tracking } = useContext(TrackingContext);

  const latestData = useRef(trackingData);
  const latestOptions = useRef(options);

  useEffect(() => {
    // store the latest data & options in a mutable ref to prevent
    // dependencies from changing when the consumer passes in non-memoized objects
    // same approach that we use for props in withTrackingComponentDecorator
    latestData.current = trackingData;
    latestOptions.current = options;
  }, [trackingData, options]);

  const {
    dispatch = dispatchTrackingEvent,
    dispatchOnMount = false,
    process,
  } = useMemo(() => latestOptions.current || {}, []);

  const getProcessFunction = useCallback(
    () => tracking && tracking.process,
    [tracking],
  );

  const getOwnTrackingData = useCallback(() => {
    const data = latestData.current;
    const ownTrackingData = typeof data === 'function' ? data() : data;

    return ownTrackingData || {};
  }, []);

  const getTrackingDataFunction = useCallback(() => {
    const contextGetTrackingData =
      (tracking && tracking.getTrackingData) || getOwnTrackingData;

    return () =>
      contextGetTrackingData === getOwnTrackingData
        ? getOwnTrackingData()
        : deepmerge(
            contextGetTrackingData(),
            getOwnTrackingData(),
            (latestOptions.current || {}).mergeOptions,
          );
  }, [getOwnTrackingData, tracking]);

  const getTrackingDispatcher = useCallback(() => {
    const contextDispatch = (tracking && tracking.dispatch) || dispatch;
    const contextProcess = getProcessFunction();

    return (data: TPushData, props?: TProperties) =>
      contextDispatch(
        deepmerge(
          getOwnTrackingData(),
          data || {},
          contextProcess?.(getOwnTrackingData()) || {},
        ),
        props,
      );
  }, [getOwnTrackingData, tracking, dispatch, getProcessFunction]);

  const trackEvent = useCallback(
    (data = {}) => {
      getTrackingDispatcher()(data);
    },
    [getTrackingDispatcher],
  );

  useEffect(() => {
    const contextProcess = getProcessFunction();
    const getTrackingData = getTrackingDataFunction();

    if (contextProcess && process) {
      console.error(
        '[react-tracking] options.process should be defined once on a top-level component',
      );
    }

    if (
      typeof contextProcess === 'function' &&
      typeof dispatchOnMount === 'function'
    ) {
      trackEvent(
        deepmerge(
          contextProcess(getOwnTrackingData()) || {},
          dispatchOnMount(getTrackingData()) || {},
          (latestOptions.current || {}).mergeOptions,
        ),
      );
    } else if (typeof contextProcess === 'function') {
      const processed = contextProcess(getOwnTrackingData());

      if (processed && dispatchOnMount === true) {
        trackEvent(processed);
      }
    } else if (typeof dispatchOnMount === 'function') {
      trackEvent(dispatchOnMount(getTrackingData()));
    } else if (dispatchOnMount === true) {
      trackEvent();
    }
  }, [
    getOwnTrackingData,
    getProcessFunction,
    getTrackingDataFunction,
    trackEvent,
    dispatchOnMount,
    process,
  ]);

  return useMemo(
    () => ({
      tracking: {
        dispatch: getTrackingDispatcher(),
        getTrackingData: getTrackingDataFunction(),
        process: getProcessFunction() || process,
      },
    }),
    [
      getTrackingDispatcher,
      getTrackingDataFunction,
      getProcessFunction,
      process,
    ],
  );
}
