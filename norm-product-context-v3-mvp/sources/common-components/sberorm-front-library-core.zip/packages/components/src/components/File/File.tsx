import { Col, Icon, Row, Text } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React from 'react';

import { FileActions, FileIcon } from './components';
import classes from './styles.module.scss';
import { IFileProperties } from './types';
import {
  convertBytesToMB,
  KILO_BYTES_PER_BYTE,
  MEGA_BYTES_PER_BYTE,
} from './utils';

export const File = React.memo<IFileProperties>((properties) => {
  const {
    author,
    error = false,
    errorText = '',
    extension,
    filename,
    loading,
    mb = 0,
    progress = 0,
    size = 0,
  } = properties;

  const convertedSize = convertBytesToMB(size);
  let sizeUnit = size < KILO_BYTES_PER_BYTE && 'bytes';

  if (!sizeUnit) {
    sizeUnit = size < MEGA_BYTES_PER_BYTE ? 'KB' : 'MB';
  }

  return (
    <div className={classes.wrapper}>
      <Row
        direction='column'
        align='stretch'
        justify='center'
        className={cn(classes.file, { [classes.error]: !!error })}
        mb={error ? 4 : mb}
      >
        <Row gutter={8} align='middle'>
          <FileIcon extension={extension} error={error} />

          <div className={classes.fileInfo}>
            <Text mb={4}>{filename}</Text>
            <Text size='sm'>{author}</Text>
          </div>
          <Col style={{ marginLeft: 'auto', maxWidth: 200 }}>
            <Row gutter={16} justify='end'>
              <div className={classes.size}>
                {convertedSize}&nbsp;{sizeUnit}
              </div>

              <FileActions {...properties} />
            </Row>
          </Col>
        </Row>

        {loading && (
          <div
            className={cn(
              classes.progress,
              classes[`width-percentage-${progress}`],
            )}
          />
        )}
      </Row>

      {error && errorText && (
        <div className={cn(classes.messageWrapper, classes[`mb-${mb}`])}>
          <Icon width={16} height={16} name='error' />
          <div className={classes.error}>
            <Text size='sm' mb={0}>
              {errorText}
            </Text>
          </div>
        </div>
      )}
    </div>
  );
});

File.displayName = 'File';
