import {
  Button,
  EIconName,
  Icon,
  Row,
  type TButtonSizes,
  useComponentVisible,
} from '@sber-orm/ui-kit';
import cn from 'classnames';
import React from 'react';
import { WorkflowAction } from '../../../../@types/api';
import classes from './styles.module.scss';
import type { IContextActionsProps } from './types';

export const ContextActions = React.memo((props: IContextActionsProps) => {
  const {
    actions,
    dropdownButtonSize = 'xlg',
    loading,
    onActionClick,
    testId,
  } = props;

  const { isComponentVisible, setIsComponentVisible, visibleRef } =
    useComponentVisible(false);

  const handleClick = () => {
    setIsComponentVisible(!isComponentVisible);
  };

  const handleClickAction = (action: WorkflowAction) => {
    onActionClick(action);
    handleClick();
  };

  return (
    <div
      className={classes.wrapper}
      ref={(reference) => (visibleRef.current = reference)}
    >
      <Button
        size={dropdownButtonSize as TButtonSizes}
        variant='secondary'
        onClick={handleClick}
        loading={loading}
        data-testid={testId ? `${testId}-otherActionsButton` : undefined}
      >
        <Icon className={classes.icon} name={EIconName.meatballMenu} />
      </Button>

      <Row
        direction='column'
        className={cn(classes.modal, {
          [classes.modalClose]: !isComponentVisible,
        })}
      >
        {actions.map((action) => (
          <Button
            key={action.id}
            className={cn(classes.button, {
              [classes.buttonDelete]: action.id === 'delete',
            })}
            size={(action.params?.size as TButtonSizes) ?? 'M'}
            variant='ghost'
            onClick={() => handleClickAction(action as WorkflowAction)}
            data-testid={
              testId ? `${testId}-${action.name || action.id}` : undefined
            }
          >
            {action.title}
          </Button>
        ))}
      </Row>
    </div>
  );
});

ContextActions.displayName = 'ContextActions';
