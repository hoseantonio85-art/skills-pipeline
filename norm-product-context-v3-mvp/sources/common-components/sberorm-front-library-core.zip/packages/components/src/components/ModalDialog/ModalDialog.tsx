import { Icon, Title, useComponentVisible } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React, { useImperativeHandle, useRef } from 'react';

import { Portal } from '../PortalDialog';
import Logo from './img/gradient-logo.svg?react';
import classes from './styles.module.scss';
import { EState, IModalDialogProperties, IModalDialogRef } from './types';

export const ModalDialog = React.forwardRef<
  IModalDialogRef,
  IModalDialogProperties
>((properties, ref) => {
  const {
    classes: classNames,
    disabledClickOutside = false,
    footer,
    fullHeight = false,
    hasLogo = false,
    isOpen,
    logoImg,
    onClose,
    onOpen,
    state = EState.fullScreen,
    title,
    titleProps: titleProperties = { size: 'H800' },
  } = properties;

  const portalRef = useRef<null | HTMLElement>(null);

  /** Обработчик скрытия мдального окна при клике вне контейнера */
  const { isComponentVisible, setIsComponentVisible, visibleRef } =
    useComponentVisible<HTMLDivElement>(
      !!isOpen,
      () => {
        if (disabledClickOutside) {
          setIsComponentVisible(isComponentVisible);
        }

        onClose?.();
      },
      true,
    );

  useImperativeHandle(ref, () => ({
    close: () => setIsComponentVisible(false),
    open: () => setIsComponentVisible(true),
  }));

  if (!isComponentVisible) {
    return null;
  }

  const Img = logoImg ?? Logo;

  return (
    <Portal id='modal-dialog' visible ref={portalRef}>
      <div
        className={cn(classes.wrapper, classNames?.wrapper as string, {
          [classes.wrapper_show]: isComponentVisible,
        })}
      >
        <div
          ref={(ref) => (visibleRef.current = ref)}
          className={cn(classes.container, {
            [classes.fullHeight]: fullHeight,
            [classes.fullScreen]: state === EState.fullScreen,
            [classes.icon]: state === EState.icon,
          })}
        >
          {state === EState.icon ? (
            <Img
              className={classes.logo}
              onClick={() => onOpen?.()}
              role='presentation'
            />
          ) : (
            <>
              <div className={classes.header}>
                {title && (
                  <div className={classes.title}>
                    {hasLogo && <Img />}
                    <Title {...titleProperties}>
                      {!hasLogo && <>&mdash;</>}
                      {title}
                    </Title>
                  </div>
                )}
                {onClose && (
                  <div
                    className={classes.closeButton}
                    onClick={() => onClose?.()}
                    role='presentation'
                  >
                    <Icon width={24} height={24} name='cross' />
                  </div>
                )}
              </div>

              <div className={classes.main}>{properties.children}</div>

              {footer && <div className={classes.footer}>{footer}</div>}
            </>
          )}
        </div>
      </div>
    </Portal>
  );
});

ModalDialog.displayName = 'ModalDialog';
