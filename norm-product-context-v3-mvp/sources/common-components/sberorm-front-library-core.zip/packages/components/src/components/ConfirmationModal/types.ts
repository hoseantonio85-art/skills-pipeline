import type { ComponentType, ReactNode } from 'react';

export interface IConfirmationModalProps {
  title: string;
  handleSubmit: () => void;
  text?: string;
  submitButtonText?: string;
  cancelButtonText?: string;
  img?: ComponentType;
  prefixFooter?: ReactNode;
  testId?: string;
}
