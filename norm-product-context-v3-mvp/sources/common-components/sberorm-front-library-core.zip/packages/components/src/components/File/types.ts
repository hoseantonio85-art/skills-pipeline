export interface IFileAttach {
  /** Идентификатор вложения */
  fileId: string;
  /** Имя вложения */
  filename: string;
  /** Размер вложения */
  size: number;
  /** Расширение вложения */
  extension: string;
}

/** Информация о файле */
export interface IAttachment extends IFileAttach {
  /**
   * Внутренний идентификатор пользователя, выполнившего запрос
   * @example "7172071357486006273"
   */
  author?: string;
  /**
   * Текущие дата и время в UTC+0
   * @format date-time
   * @example "2021-04-29T00:00:00Z"
   */
  createTime?: string;
}

export enum EValidationStatus {
  error = 'error',
  success = 'success',
}

export interface IValidationProperties {
  status: keyof typeof EValidationStatus;
  message?: string;
}

export interface IFileProperties extends IAttachment {
  loading?: boolean;
  error?: boolean;
  errorText?: string;
  progress?: number;
  index?: number;
  source?: File | null;
  validation?: IValidationProperties;
  onDownload?: (fileId: string, fileName: string, index?: number) => void;
  onRemove?: (file: IAttachment, index?: number) => void;
  mb?: number;
}
export type TFileIconProperties = Pick<IFileProperties, 'extension' | 'error'>;

export interface IFileValidation {
  success: boolean;
  error?: string;
}

export interface IFileValidationParameters {
  accepts?: string[];
  maxSize?: number;
  maxLength?: number;
}
