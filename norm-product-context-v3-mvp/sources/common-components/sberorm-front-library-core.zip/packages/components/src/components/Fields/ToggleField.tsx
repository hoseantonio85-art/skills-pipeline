import { MarkdownViewer, Switch } from '@sber-orm/ui-kit';

import { useTranslation } from 'react-i18next';
import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

export const ToggleField = ({
  error,
  fieldName,
  field,
  fieldConfig,
  noLabel,
  raw,
  onChange,
  onTrack,
  testId,
  readonly,
}: IEditFieldProps<boolean>) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const { t } = useTranslation();

  const helpText = String(fieldConfig?.extras?.help || '');
  const hintText = String(fieldConfig?.extras?.hint || '');

  const handleChange = (newValue: boolean) => {
    onChange(newValue);
    onTrack?.(fieldName!, String(newValue));
  };

  if (raw) {
    return field?.value ? t('yes') : t('no');
  }

  return (
    <Switch
      label={label}
      disabled={!editable}
      checked={!!field?.value}
      onChange={() => handleChange(!field?.value)}
      error={typeof error === 'string'}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      helperText={error ?? helpText}
      className={classes.toggle}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
