import { Col, Icon, Row } from '@sber-orm/ui-kit';

import { IFileProperties } from '../../types';
import classes from './styles.module.scss';

export const FileActions = (properties: IFileProperties) => {
  const { onDownload, onRemove, ...fileAttach } = properties;

  if (!!onDownload || !!onRemove) {
    return (
      <Col>
        <Row gutter={8}>
          {!!onDownload && (
            <Icon
              className={classes.icon}
              name='downloadArrow'
              onClick={() =>
                onDownload?.(
                  fileAttach?.fileId as string,
                  fileAttach.filename,
                  fileAttach.index,
                )
              }
            />
          )}

          {!!onRemove && (
            <Icon
              className={classes.icon}
              name='trash'
              onClick={() => onRemove?.(fileAttach, fileAttach.index)}
            />
          )}
        </Row>
      </Col>
    );
  }

  return null;
};
