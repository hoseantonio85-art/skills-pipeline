import { ETextSize, type TTypographyProps } from '@sber-orm/ui-kit';

export type TTitleBlockProperties = TTypographyProps & {
  size?: keyof typeof ETextSize;
  subTitle?: string;
  helpMessage?: string;
  nowrap?: boolean;
};
