import { useEffect, useRef } from 'react';

/**
 * Return root element to insert DOM element.
 * @returns {Document}
 */
function getDocument(element?: HTMLElement) {
  if (element) {
    return element.ownerDocument;
  }

  return window.document;
}

/**
 * Creates DOM element to be used as React root.
 * @param {String} id
 * @param {HTMLElement} anchorElement
 * @returns {HTMLElement}
 */
function createRootElement(id: string, anchorElement?: HTMLElement) {
  const rootContainer = getDocument(anchorElement).createElement('div');

  rootContainer.style.position = 'absolute';
  rootContainer.style.top = '0px';
  rootContainer.style.left = '0px';
  rootContainer.style.width = '100%';
  rootContainer.setAttribute('id', id);

  return rootContainer;
}

/**
 * Appends element as last child of body.
 * @param {HTMLElement} rootElem
 * @param {HTMLElement} anchorElement
 */
const attachParent = (
  rootElement: HTMLElement,
  anchorElement?: HTMLElement,
) => {
  const mountNode: HTMLElement = getDocument(anchorElement).body;

  if (mountNode) {
    mountNode.insertBefore(
      rootElement,
      mountNode.lastElementChild?.nextElementSibling || null,
    );
  }
};

/**
 * Hook to create a React Portal.
 * Automatically handles creating and tearing-down the root elements (no SRR
 * makes this trivial), so there is no need to ensure the parent target already
 * exists.
 * @param {String} id The id of the target container
 * @param {HTMLElement} anchorElement The DOM element to be used as React root
 * @returns {HTMLElement} The DOM node to use as the Portal target.
 */
export function usePortal(id: string, anchorElement?: HTMLElement) {
  const rootElementReference = useRef<HTMLDivElement | null>(null);

  useEffect(
    function setupElement() {
      // Look for existing target dom element to append to
      const existingParent = document.querySelector(`#${id}`) as HTMLElement;

      // Parent is either a new root or the existing dom element
      const parentElement =
        existingParent || createRootElement(id, anchorElement);

      // If there is no existing DOM element, add a new one.
      if (!existingParent) {
        attachParent(parentElement, anchorElement);
      }

      // Add the detached element to the parent
      if (rootElementReference.current) {
        parentElement.append(rootElementReference.current);
      }

      return function removeElement() {
        rootElementReference.current?.remove();
        if (!parentElement.childElementCount) {
          parentElement.remove();
        }
      };
    },
    [id, anchorElement],
  );

  /**
   * The ref to consistently point to the same DOM element and only ever run once.
   * @returns {HTMLElement}
   */
  function getRootElement() {
    if (!rootElementReference.current) {
      rootElementReference.current = document.createElement('div');
    }

    return rootElementReference.current;
  }

  return getRootElement();
}
