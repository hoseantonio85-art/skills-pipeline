import { TTextProps } from '@sber-orm/ui-kit';
import {
  ClassifierLevel,
  FormField,
  ObjectField,
  SearchResponseEntry,
} from '../../@types/api';

export interface IEditFieldProps<T = ObjectField['value']> {
  error?: string;
  fallbackField?: ObjectField;
  fallbackFieldConfig?: FormField;
  fallbackFieldName?: string;
  className?: string;
  field?: ObjectField;
  fieldConfig?: FormField;
  fieldName?: string;
  onChange(value: T, fallbackFieldValue?: T): void;
  textProps?: Pick<
    TTextProps,
    'tooltip' | 'code' | 'size' | 'medium' | 'bold' | 'nowrap' | 'className'
  >;
  noLabel?: boolean;
  onTrack?: (fieldName: string, value?: string) => void;
  raw?: boolean;
  required?: boolean;
  loadStructure: (
    dictionary: string,
    key?: string,
  ) => Promise<{ levels?: ClassifierLevel[] }>;
  onSearchStructure?: (
    searchValue: string,
    dictionary: string,
  ) => Promise<{ items?: SearchResponseEntry[] }> | undefined;
  classes?: TEditFieldClasses;
  testId?: string;
  readonly?: boolean;
  withReset?: boolean;
}

type TEditFieldClasses = { container?: string } & Record<string, string>;
