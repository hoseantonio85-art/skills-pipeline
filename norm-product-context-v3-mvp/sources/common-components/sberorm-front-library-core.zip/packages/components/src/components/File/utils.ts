export const KILO_BYTES_PER_BYTE = 1024;
export const MEGA_BYTES_PER_BYTE = 1024 * 1024;

// eslint-disable-next-line sonarjs/no-inverted-boolean-check
export const bytesMoreOneMB = (bytes: number) => !(bytes < MEGA_BYTES_PER_BYTE);

// eslint-disable-next-line sonarjs/no-inverted-boolean-check
export const bytesMoreOneKB = (bytes: number) => !(bytes < KILO_BYTES_PER_BYTE);

export const convertBytesToMB = (bytes: number) => {
  if (bytesMoreOneMB(bytes)) {
    return Math.round(bytes / MEGA_BYTES_PER_BYTE);
  }
  if (bytesMoreOneKB(bytes)) {
    return Math.round(bytes / KILO_BYTES_PER_BYTE);
  }

  return Math.round(bytes);
};
