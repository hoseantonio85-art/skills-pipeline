import {
  Button,
  Row,
  type TButtonSizes,
  type TButtonVariants,
} from '@sber-orm/ui-kit';
import cn from 'classnames';
import React, { useMemo } from 'react';
import { I18nextProvider } from 'react-i18next';

import { WorkflowAction, WorkflowActionBody } from '../../@types/api';
import i18next from '../../i18n';
import {
  ModalFactory,
  ModalProvider,
  useModalManager,
  useModalQueue,
} from '../ModalFactory';

import { ContextActions } from './components';
import { CommentModal, MessageModal } from './components/ModalAction';

import workflow from './locales/ru/workflow.json';
import classes from './styles.module.scss';
import type { IWorkflowActionsProps } from './types';

type TWorkflowActionState = WorkflowAction & WorkflowActionBody;

const DROPDOWN_BUTTONS_TYPE = 'context';

const i18nResource = i18next('ru', 'workflow', workflow);

const WorkflowActionsContent = (props: IWorkflowActionsProps) => {
  const {
    actions,
    className,
    loading,
    localStorageKey,
    onTrack,
    onUpdate,
    testId,
  } = props;

  const { createModal } = useModalManager();
  const { getQueueState } = useModalQueue();

  const contextActions = useMemo(
    () =>
      actions.filter((action) => action.params?.type === DROPDOWN_BUTTONS_TYPE),
    [actions],
  );

  const standardActions = useMemo(
    () =>
      actions
        .filter((action) => action.params?.type !== DROPDOWN_BUTTONS_TYPE)
        .sort((a, b) =>
          (a.params?.type as string) > (b.params?.type as string) ? -1 : 1,
        ),
    [actions],
  );

  if (actions.length === 0) {
    return null;
  }

  const handleActionClick = async (
    action: WorkflowAction,
    comment?: string,
  ) => {
    onTrack?.(action);

    const modalQueue = [];
    if (action.params?.comment) {
      modalQueue.push(createModal(CommentModal, { localStorageKey }));
    }
    if (action.params?.confirmMsg) {
      const { confirmMsgTitle, confirmMsgText, confirmMsgBtn } = action.params;
      modalQueue.push(
        createModal(MessageModal, {
          msgTitle: confirmMsgTitle,
          description: confirmMsgText,
          btnText: confirmMsgBtn,
        }),
      );
    }

    if (modalQueue.length) {
      const onSubmitCallback = handleModalSubmit(action);

      for (const modalAction of modalQueue) {
        modalAction.open({
          title: action?.title,
          onSubmit: onSubmitCallback,
          testId: testId
            ? `${testId}-${(action?.name || action?.id) as string}`
            : undefined,
          ...(action.params ?? {}),
        });
      }
    } else {
      await onUpdate(action, comment);
    }
  };

  const handleModalSubmit =
    (selectedAction: TWorkflowActionState) => (params?: WorkflowActionBody) => {
      const state = getQueueState();
      if (!state.waitingInQueue) {
        const { comment, ...action } = selectedAction;
        onUpdate(action as WorkflowAction, params?.comment || comment);
      } else {
        selectedAction = { ...selectedAction, ...params };
      }
    };

  return (
    <Row
      className={cn(classes.wrapper, {
        [className as string]: !!className,
      })}
      gutter={16}
    >
      {contextActions.length > 0 && (
        <ContextActions
          actions={contextActions}
          dropdownButtonSize={
            (standardActions[0].params?.size as TButtonSizes) ?? 'L'
          }
          loading={loading}
          onActionClick={handleActionClick}
          testId={testId}
        />
      )}
      {standardActions.map((action) => (
        <Button
          key={action.id}
          className={classes[action.params?.type as string]}
          size={(action.params?.size as TButtonSizes) ?? 'L'}
          variant={(action.params?.type as TButtonVariants) ?? 'secondary'}
          onClick={() => handleActionClick(action as WorkflowAction)}
          loading={loading}
          fullWidth
          data-testid={
            testId ? `${testId}-${action.name || action.id}` : undefined
          }
        >
          {action.title}
        </Button>
      ))}
    </Row>
  );
};

export const WorkflowActions = React.memo((props: IWorkflowActionsProps) => {
  return (
    <I18nextProvider i18n={i18nResource}>
      <ModalProvider>
        <WorkflowActionsContent {...props} />
        <ModalFactory />
      </ModalProvider>
    </I18nextProvider>
  );
});
WorkflowActions.displayName = 'WorkflowActions';
