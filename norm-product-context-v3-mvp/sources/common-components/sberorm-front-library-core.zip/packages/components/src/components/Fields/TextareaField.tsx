import {
  type ITextareaProperties,
  MarkdownViewer,
  Textarea,
  useComponentDidMount,
  useDebounce,
} from '@sber-orm/ui-kit';
import { useEffect, useState } from 'react';

import { IEditFieldProps } from './types';

export interface ITextareaFieldProps
  extends IEditFieldProps<string | undefined> {
  textareaProps?: Omit<
    ITextareaProperties,
    | 'label'
    | 'value'
    | 'required'
    | 'onChange'
    | 'tooltip'
    | 'error'
    | 'helperText'
    | 'disabled'
    | 'canClear'
    | 'classes'
    | 'labelledClasses'
    | 'description'
    | 'title'
  >;
}

export const TextareaField = ({
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
  textareaProps = {},
}: ITextareaFieldProps) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const [value, setValue] = useState<string>(String(field?.value || ''));

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const trackValue = useDebounce(value, 1000);
  const isComponentMounted = useComponentDidMount();

  const handleChange = (newValue: string) => {
    setValue(newValue);
    onChange(newValue || undefined);
  };

  useEffect(() => {
    isComponentMounted && onTrack?.(fieldName!, trackValue);
  }, [trackValue]);

  useEffect(() => {
    setValue(String(field?.value || ''));
  }, [field?.value]);

  if (raw) {
    return value || null;
  }

  return (
    <Textarea
      labelInside
      fullWidth
      label={label}
      value={value}
      required={!!required}
      onChange={handleChange}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      canClear={editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
      size='L'
      {...textareaProps}
    />
  );
};
