import {
  Button,
  EIconName,
  Icon,
  MarkdownViewer,
  Row,
  Text,
  Title,
  useCopyToClipboard,
} from '@sber-orm/ui-kit';
import cn from 'classnames';
import React from 'react';
import { I18nextProvider, useTranslation } from 'react-i18next';
import i18n from '../../../../i18n';
import { EState, ModalDialog } from '../../../ModalDialog';
import resource from '../../locales/ru/errors.json';
import { IErrorPageWrapProps } from '../../types';
import { reloadPage } from '../../utils';
import classes from './styles.module.scss';

interface IWrapperProps {
  modal?: boolean;
  className?: string;
  children: React.ReactNode | React.ReactNode[];
}

const Wrapper = ({ modal, className, children }: IWrapperProps) => {
  if (modal) {
    return (
      <ModalDialog
        isOpen
        disabledClickOutside
        state={EState.small}
        classes={{ wrapper: cn(className, classes.wrapperBackdrop) }}
      >
        {children}
      </ModalDialog>
    );
  }
  return <div className={className}>{children}</div>;
};

const ErrorPageWrapInner = ({
  IconComponent,
  center,
  errorText,
  modal,
  subTitle,
  title,
  withButton = true,
  onMainPageClick = () => (window.location.href = '/'),
  withCopy = false,
  withRefresh = false,
  addNotification,
  supportLink,
}: IErrorPageWrapProps) => {
  const { t } = useTranslation(['errors']);

  const copyAction = useCopyToClipboard();

  const handleErrorCopy = async () => {
    const result = await copyAction(errorText as string);

    if (result) {
      addNotification?.(t('successCopy'), {
        type: 'success',
      });
    } else {
      addNotification?.(t('notCopied'), {
        type: 'error',
      });
    }
  };

  return (
    <Wrapper className={classes.wrapper} modal={modal}>
      <div
        className={cn(classes.container, { [classes.containerCenter]: center })}
      >
        <IconComponent />
        <div
          className={cn(classes.content, { [classes.contentCenter]: center })}
        >
          <Title className={classes.title} size='H900'>
            {t(title) ?? ''}
          </Title>
          <Title className={classes.subTitle} size='H700' thin>
            <MarkdownViewer markdown={t(subTitle) ?? ''} />
            {supportLink ? (
              <div className={classes.supportLink}>{supportLink}</div>
            ) : withCopy ? (
              <span className={classes.blue}>{t('mail')}</span>
            ) : null}
          </Title>
        </div>
        {errorText && (
          <div className={classes.errorWrapper}>
            <Title className={classes.gray} size='H500' mb={8}>
              {t('errorMessageTitle')}
            </Title>
            <div className={classes.error}>
              <Text title={errorText} className={classes.errorText} size='md'>
                {errorText}
              </Text>
              {withCopy && (
                <Icon
                  name={EIconName.copy}
                  className={classes.icon}
                  onClick={handleErrorCopy}
                />
              )}
            </div>
          </div>
        )}
        <Row className={classes.buttons} justify='start' gutter={8}>
          {withRefresh && (
            <Button
              size='L'
              variant='primary'
              title={t('common:refreshPage') ?? ''}
              onClick={reloadPage}
            >
              {t('common:refreshPage') ?? ''}
            </Button>
          )}
          {withButton && (
            <Button
              size='L'
              variant='secondary'
              title={t('toMainPage') ?? ''}
              onClick={onMainPageClick}
            >
              {t('toMainPage') ?? ''}
            </Button>
          )}
        </Row>
      </div>
    </Wrapper>
  );
};

const i18nData = i18n('ru', 'errors', resource);

export const ErrorPageWrap = (props: IErrorPageWrapProps) => (
  <I18nextProvider i18n={i18nData}>
    <ErrorPageWrapInner {...props} />
  </I18nextProvider>
);
ErrorPageWrap.displayName = 'ErrorPageWrap';
