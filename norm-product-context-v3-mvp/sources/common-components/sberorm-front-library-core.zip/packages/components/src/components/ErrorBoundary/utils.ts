import imgCrashed from './images/error_crashed.svg?react';
import img401 from './images/error-401.svg?react';
import img403 from './images/error-403.svg?react';
import img404 from './images/error-404.svg?react';
import img408 from './images/error-408.svg?react';
import imgAdmission from './images/error-admission.svg?react';
import {
  ErrorCodes,
  type IErrorInstanceType,
  IErrorPageWrapProps,
} from './types';

export const reloadPage = () => {
  window.location.reload();
};

export const getErrorComponentProps = (
  error: IErrorInstanceType & Partial<Pick<IErrorPageWrapProps, 'supportLink'>>,
): IErrorPageWrapProps => {
  const supportLink = 'supportLink' in error ? error.supportLink : undefined;

  switch (error.code) {
    case ErrorCodes.PAGE_NOT_FOUND: {
      return {
        IconComponent: img404,
        subTitle: 'pageNotFoundSubTitle',
        title: 'pageNotFoundTitle',
        supportLink,
      };
    }
    case ErrorCodes.REQUEST_TIMEOUT: {
      return {
        IconComponent: img408,
        subTitle: 'pageRequestTimeoutSubTitle',
        title: 'pageRequestTimeoutTitle',
        withRefresh: true,
        supportLink,
      };
    }
    case ErrorCodes.UNAUTHIRIZED: {
      return {
        IconComponent: img401,
        subTitle: 'sessionTimeoutSubTitle',
        title: 'sessionTimeoutTitle',
        center: true,
        withRefresh: true,
        withButton: false,
        modal: true,
        supportLink,
      };
    }
    case ErrorCodes.BAD_REQUEST:
    case ErrorCodes.SERVICE_UNAVAILABLE:
    case ErrorCodes.GATEWAY_TIMEOUT: {
      return {
        IconComponent: img404,
        errorText: error?.text,
        subTitle: 'pageBadRequestSubTitle',
        title: 'pageBadRequestTitle',
        withRefresh: true,
        supportLink,
      };
    }
    case ErrorCodes.FORBIDDEN: {
      return {
        IconComponent: img403,
        subTitle: 'forbiddenSubTitle',
        title: 'forbiddenTitle',
        withRefresh: false,
        supportLink,
      };
    }
    case ErrorCodes.BUSINESS: {
      return {
        IconComponent: imgAdmission,
        subTitle: error?.text || '',
        title: error?.title || '',
        supportLink,
      };
    }
    case ErrorCodes.PROGRAM_CRASHED: {
      return {
        IconComponent: imgCrashed,
        errorText: error?.text || '',
        subTitle: 'pageProgramCrashedSubTitle',
        title: 'pageBadRequestTitle',
        withRefresh: true,
        withCopy: true,
        supportLink,
      };
    }
    default: {
      return {
        IconComponent: img404,
        errorText: error?.exception ?? error?.text,
        subTitle: 'pageAppDefaultSubTitle',
        title: 'pageBadRequestTitle',
        withCopy: true,
        withRefresh: true,
        ...error,
      };
    }
  }
};
