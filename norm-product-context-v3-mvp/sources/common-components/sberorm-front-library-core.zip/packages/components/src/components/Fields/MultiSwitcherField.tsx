import {
  CheckboxChips,
  EComponentColors,
  EIconName,
  Icon,
  Row,
} from '@sber-orm/ui-kit';
import { useMemo } from 'react';

import { DictionaryItem } from '../../@types/api';
import { IEditFieldProps } from './types';

export const MultiSwitcherField = ({
  error,
  field,
  fieldName,
  fieldConfig,
  itemClassBuilder,
  noLabel = false,
  onChange,
  raw = false,
  required = false,
  testId,
  readonly,
}: IEditFieldProps<string[]> & {
  itemClassBuilder?(item: DictionaryItem): string;
}) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const helpText = String(fieldConfig?.extras?.help || '');

  const value = (field?.value as string[]) || [];

  const handleChange = (newValue: string[]) => {
    onChange(newValue);
  };

  const items = useMemo(
    () =>
      fieldConfig?.availableItems?.map((item) => ({
        color: EComponentColors.outlined,
        id: item.id,
        title:
          String(item?.extras?.icon || '') in EIconName ? (
            <Row gutter={4} noFlex className={itemClassBuilder?.(item)}>
              <Icon
                name={String(item?.extras?.icon || '') as EIconName}
                height={20}
                width={20}
              />
              {item.value}
            </Row>
          ) : (
            item.value
          ),
      })) || [],
    [fieldConfig?.availableItems, itemClassBuilder],
  );

  if (raw) {
    return value
      ? fieldConfig?.availableItems
          ?.filter((item) => value.includes(item.id))
          ?.map((item) => item.value)
          .join(', ')
      : null;
  }

  return (
    <CheckboxChips
      kind='primary'
      label={label}
      items={items}
      value={value}
      required={!!required}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={error ?? helpText}
      disabled={!editable}
      wrap
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
