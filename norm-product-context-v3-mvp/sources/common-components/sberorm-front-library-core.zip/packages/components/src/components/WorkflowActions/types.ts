import { WorkflowAction } from '../../@types/api';

export interface IWorkflowActionsProps {
  actions: WorkflowAction[];
  onUpdate: (action: WorkflowAction, comment?: string) => void;
  /** Имя класса */
  className?: string | undefined;
  onTrack?: (action: WorkflowAction) => void;
  /**
   * @description Ключ используется для сохранения значения комментария в localStorage. Очищается снаружи самостоятельно (например при успешном переходе по workflow). Нужен для предотвращения потери данных пользователя при закрытии окна ввода комментария.
   */
  localStorageKey?: string;
  loading?: boolean;
  testId?: string;
}
