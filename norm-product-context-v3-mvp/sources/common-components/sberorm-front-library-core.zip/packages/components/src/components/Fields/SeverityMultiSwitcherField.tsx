import cn from 'classnames';

import { MultiSwitcherField } from './MultiSwitcherField';
import styles from './styles.module.scss';
import { IEditFieldProps } from './types';

export const SeverityMultiSwitcherField = (
  props: IEditFieldProps<string[]>,
) => {
  const { classes, ...rest } = props;

  return (
    <MultiSwitcherField
      {...rest}
      itemClassBuilder={(item) =>
        cn(classes?.[item.id], styles.severity, classes?.container)
      }
    />
  );
};
