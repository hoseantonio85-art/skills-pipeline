import { Alert, IAlertProperties, MarkdownViewer, Row } from '@sber-orm/ui-kit';
import cn from 'classnames';
import React from 'react';

import classes from './styles.module.scss';
import { INotification, IViewMessagesProps } from './types';

const Message = ({ item }: { item: INotification }) => {
  if (item.title) {
    return (
      <>
        <span className={classes.title}>{item.title}</span>&nbsp;
        <MarkdownViewer markdown={item.text} />
      </>
    );
  }

  return <MarkdownViewer markdown={item.text} />;
};

export const ViewMessages = React.forwardRef<
  HTMLDivElement,
  IViewMessagesProps
>(({ className, items, onClick, onClose }, ref) => {
  if (items?.length === 0) {
    return null;
  }

  return (
    <>
      <Row
        direction='column'
        gutter={16}
        className={cn(classes.root, className)}
        ref={ref}
      >
        {items?.map((n, index) => (
          <Alert
            key={n.text}
            status={n.notificationType as IAlertProperties['status']}
            message={<Message item={n} />}
            onClose={onClose ? () => onClose(index) : undefined}
            actions={n.actions?.map((action) => ({
              onClick: () => onClick?.(action, n),
              title: action.title,
            }))}
          />
        ))}
      </Row>
    </>
  );
});
ViewMessages.displayName = 'ViewMessages';
