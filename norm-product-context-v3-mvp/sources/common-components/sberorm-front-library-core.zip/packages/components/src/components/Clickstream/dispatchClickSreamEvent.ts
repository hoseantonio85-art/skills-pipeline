import {
  type BaseItem,
  sendEvent,
  sendSensitiveEvent,
  sendTechEvent,
  setConfig,
  setMeta,
  setProfile,
  setSessionId,
} from '@sbol/clickstream-agent';

import { TPushData, TTrackingProfile } from './tracking';
import { EEventType, IDispatchEventProps, TEventType } from './types';

const sendEventFunction = {
  [EEventType.business]: sendEvent,
  [EEventType.sensitive]: sendSensitiveEvent,
  [EEventType.technical]: sendTechEvent,
};

let timer: Record<string, NodeJS.Timeout> = {};

const hashCode = (string_: string) => {
  let hash = 0;

  for (let index = 0; index < string_.length; ++index) {
    hash = Math.imul(31, hash) + (string_.codePointAt(index) as number);
  }

  return Math.trunc(hash);
};

export const setTrackingConfig = (
  profile: TTrackingProfile = {} as TTrackingProfile,
) => {
  const {
    clickStreamEnabled,
    clickStreamKey,
    clickStreamUrl,
    sessionKey,
    ...rest
  } = profile;

  if (clickStreamEnabled) {
    setConfig({
      bufferSize: 10,
      reportUrl: clickStreamUrl,
    });
    setMeta({
      apiKey: clickStreamKey,
    });

    if (profile) {
      setProfile({
        ...rest,
      });
    }

    if (sessionKey) {
      setSessionId(hashCode(sessionKey).toString(16).padStart(2, '0'));
    }
  }
};

async function dispatchEvent(
  type: TEventType,
  data: TPushData,
  clickStreamEnabled: boolean,
) {
  if (clickStreamEnabled) {
    await sendEventFunction[type]?.(data as BaseItem);
  }
}

async function debounceEvent(
  delay: number,
  hash: number,
  sendEventFunction_: () => void,
) {
  if (timer[hash]) {
    const { [hash]: clearTimer, ...rest } = timer;

    clearTimeout(clearTimer);
    timer = rest || {};
  }
  timer[hash] = setTimeout(() => {
    sendEventFunction_();

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { [hash]: clearTimer, ...rest } = timer;

    timer = rest || {};
  }, delay);
}

export function dispatchTrackingEvent(
  data: TPushData,
  props: IDispatchEventProps = {},
  clickStreamEnabled: boolean,
) {
  const { delay, eventType = 'business' } = props;

  if (delay) {
    const { eventAction = '', eventCategory = '', eventType: type = '' } = data;
    const keyEventAction = hashCode(eventAction + eventCategory + type);

    debounceEvent(delay, keyEventAction, () => {
      dispatchEvent(eventType as TEventType, data, clickStreamEnabled);
    });
  } else {
    dispatchEvent(eventType as TEventType, data, clickStreamEnabled);
  }
}
