import {
  Button,
  Chips,
  EIconName,
  IChipsItem,
  Icon,
  MarkdownViewer,
  Row,
  Text,
  Tooltip,
} from '@sber-orm/ui-kit';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { DictionaryItem } from '../../@types/api';
import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

export const SwitcherField = ({
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  itemClassBuilder,
  onChange,
  onTrack,
  raw,
  required,
  readonly,
  testId,
  withReset,
}: IEditFieldProps<string> & {
  itemClassBuilder?(item: DictionaryItem): string;
}) => {
  const { t } = useTranslation();

  const label = noLabel ? undefined : fieldConfig?.title;
  const value = (field?.value as string) || '';

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');
  const HintTextComponent = <MarkdownViewer markdown={hintText} />;
  const HelpTextComponent = <MarkdownViewer markdown={helpText} />;

  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const items: IChipsItem[] = useMemo(
    () =>
      fieldConfig?.availableItems?.map((item) => ({
        id: item.id,
        title:
          String(item?.extras?.icon || '') in EIconName ? (
            <Row gutter={4} noFlex className={itemClassBuilder?.(item)}>
              <Icon
                name={String(item?.extras?.icon || '') as EIconName}
                height={20}
                width={20}
              />
              {item.value}
            </Row>
          ) : (
            item.value
          ),
      })) || [],
    [fieldConfig?.availableItems],
  );

  const handleChange = (id: string) => {
    onChange?.(id);
    onTrack?.(
      fieldName!,
      (items.find((item) => item.id === id)?.title || '') as string,
    );
  };

  if (raw) {
    return value ? items.find((item) => item.id === value)?.title : null;
  }

  return (
    <Row direction='column' justify='start' align='top' gutter={8}>
      {label && (
        <Row gutter={4} noFlex>
          <Text size='lg' tooltip>
            {label}
            {required && <span className={classes.required}>*</span>}
          </Text>
          {!!hintText && (
            <Tooltip
              placement='top-end'
              content={HintTextComponent}
              fallbackPlacements={['left-start']}
            >
              <span className={classes.tooltipIcon}>
                <Icon width={16} height={16} name='infoOutlined' />
              </span>
            </Tooltip>
          )}
        </Row>
      )}
      <Row gutter={4} wrap>
        {items?.map((chips) => (
          <Chips
            key={chips.id}
            item={chips}
            selected={value === chips.id}
            onChange={handleChange}
            size='S'
            disabled={!editable}
            testId={testId ? `${testId}-${fieldName}` : undefined}
          />
        ))}
        {withReset && !!value && (
          <Button
            onClick={() => handleChange('')}
            size='XXS'
            variant='function'
          >
            {t('reset')}
          </Button>
        )}
      </Row>
      {!!error && (
        <div className={classes.errorText}>
          <Icon width={16} height={16} name='errorRounded' />
          {error}
        </div>
      )}
      {!error && !!helpText && (
        <Text size='sm' tooltip>
          {HelpTextComponent}
        </Text>
      )}
    </Row>
  );
};
