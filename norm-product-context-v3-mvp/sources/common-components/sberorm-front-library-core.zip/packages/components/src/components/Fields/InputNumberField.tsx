import {
  type IInputNumberProperties,
  InputNumber,
  MarkdownViewer,
  useComponentDidMount,
  useDebounce,
} from '@sber-orm/ui-kit';
import { useEffect, useState } from 'react';

import { IEditFieldProps } from './types';

export interface IInputNumberFieldProps
  extends IEditFieldProps<number | undefined> {
  inputNumberProps?: Omit<
    IInputNumberProperties,
    | 'label'
    | 'value'
    | 'required'
    | 'onChange'
    | 'tooltip'
    | 'error'
    | 'helperText'
    | 'disabled'
    | 'canClear'
    | 'classes'
    | 'labelledClasses'
    | 'description'
    | 'title'
  >;
}

export const InputNumberField = ({
  className,
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  inputNumberProps = {
    precision: 0,
  },
}: IInputNumberFieldProps) => {
  const label = noLabel ? undefined : fieldConfig?.title;
  const editable = fieldConfig?.editable ?? true;

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const [value, setValue] = useState<number | null>(Number(field?.value || 0));

  const trackValue = useDebounce(value, 1000);
  const isComponentMounted = useComponentDidMount();

  const handleChange = (newValue: number | null) => {
    let inputValue = newValue;

    if (typeof inputValue === 'number' && inputValue < 0) {
      inputValue = Math.abs(inputValue);
    }
    setValue(inputValue);
    onChange(inputValue ?? undefined);
  };

  useEffect(() => {
    isComponentMounted && onTrack?.(fieldName!, String(trackValue));
  }, [trackValue]);

  useEffect(() => {
    setValue(Number(field?.value || 0));
  }, [field?.value]);

  if (raw) {
    return value || 0;
  }

  return (
    <InputNumber
      labelInside
      className={className}
      fullWidth
      required={!!required}
      size='L'
      label={label}
      value={value}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
      {...inputNumberProps}
    />
  );
};
