import {
  Button,
  EIconName,
  Row,
  ScrollBar,
  Title,
  type TScrollBarRef,
} from '@sber-orm/ui-kit';
import cn from 'classnames';
import React, {
  forwardRef,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';

import classes from './styles.module.scss';

export type TDrawerPosition = 'absolute' | 'fixed';

interface IDrawerProps {
  open?: boolean;
  title?: string | React.ReactNode;
  width?: number;
  minWidth?: number;
  inModal?: boolean;
  backdropClasses?: string;
  footerClasses?: string;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  onClose?: () => void;
  position?: TDrawerPosition;
  headerRevert?: boolean;
  notMountIfClosed?: boolean;
  fullHeight?: boolean;
  contentRef?: React.ForwardedRef<HTMLDivElement>;
}

export const Drawer = forwardRef<HTMLDivElement, IDrawerProps>(
  (
    {
      children,
      footer,
      fullHeight,
      backdropClasses,
      footerClasses,
      headerRevert = false,
      inModal,
      notMountIfClosed,
      onClose,
      open,
      position = 'fixed',
      title,
      width = 550,
      minWidth = 256,
      contentRef,
    },
    ref,
  ) => {
    const onContentClick = useCallback((event: React.MouseEvent) => {
      event.stopPropagation();
    }, []);

    const scrollRef = useRef<TScrollBarRef | null>(null);
    const [visible, setVisible] = useState(false);

    useEffect(() => {
      scrollRef.current?.recalculate();
    });

    useEffect(() => {
      requestAnimationFrame(() => {
        setVisible(!!open);
      });
    }, [open]);

    const titleComponent =
      typeof title === 'string' ? <Title size='H800'>{title}</Title> : title;

    if (notMountIfClosed && !open) {
      return null;
    }

    return (
      <div
        className={cn(classes.root, classes[position], backdropClasses, {
          [classes.containerInModal]: inModal,
          [classes.rootClose]: !visible,
        })}
        onClick={onClose}
        role='presentation'
      >
        <Row
          direction='column'
          className={cn(classes.container, {
            [classes.containerClose]: !visible,
            [classes.containerInModal]: inModal,
          })}
          style={{
            maxWidth: `${width}px`,
            width: `${width}px`,
            minWidth: `${minWidth}px`,
          }}
          gutter={30}
          ref={ref}
          align='stretch'
          onClick={onContentClick}
        >
          <Row
            className={cn(classes.header, {
              [classes.headerRevert]: headerRevert,
            })}
            align='middle'
            justify='start'
            gutter={16}
          >
            <Button
              icon={headerRevert ? EIconName.cross : EIconName.previousLarge}
              iconOnly
              className={classes.closeButton}
              onClick={onClose}
              variant='ellipse'
              size='S'
            />
            {title && titleComponent}
          </Row>
          {children && (
            <ScrollBar
              ref={scrollRef}
              className={cn(classes.scrollbar, {
                [classes.scrollbarFullHeight]: fullHeight,
              })}
            >
              <div
                className={cn(classes.content, {
                  [classes.fullHeight]: fullHeight,
                })}
                ref={contentRef}
              >
                {children}
              </div>
            </ScrollBar>
          )}
          {footer && (
            <div className={cn(classes.footer, footerClasses)}>{footer}</div>
          )}
        </Row>
      </div>
    );
  },
);
