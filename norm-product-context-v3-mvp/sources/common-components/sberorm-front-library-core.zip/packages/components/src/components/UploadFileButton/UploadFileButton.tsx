import { Button, Text } from '@sber-orm/ui-kit';
import React, { useEffect, useMemo, useRef, useState } from 'react';

import {
  File as FileComponent,
  FileValidation,
  IValidationProperties,
} from '../File';
import classes from './styles.module.scss';
import type {
  IFileProgress,
  IUploadButtonProperties,
  TErrorMessage,
  TFileAttach,
} from './types';

/**
 * UploadFileButton - компонент для загрузки и отправки файлов
 * @param properties
 * @constructor
 */
export const UploadFileButton: React.FC<IUploadButtonProperties> = (
  properties,
) => {
  const {
    accepts,
    addButtonText,
    author,
    autoUpload = false,
    fileInfos,
    multiple = false,
    onDownload,
    onRemove,
    onUpload,
    uploadButtonText,
    helpText,
  } = properties;
  const fileInputFieldRef = useRef<null | HTMLInputElement>(null);

  const [isLoading, setIsLoading] = useState(false);
  /** Информация о ходе выполнения (процент) загрузки файлов */
  const [progressInfos, setProgressInfos] = useState<
    Record<string, IFileProgress>
  >({});
  /** Сообщения об ошибках при загрузке файлов */
  const [messages, setMessages] = useState<
    Record<string, IValidationProperties>
  >({});
  /** Список выбранных файлов */
  const [selectFiles, setSelectFiles] = useState<TFileAttach[]>([]);

  const acceptExtension = useMemo(() => accepts?.join(', ') ?? '', [accepts]);

  const setLoading = (start: boolean) => {
    setIsLoading(start);
    setProgressInfos({});
  };

  useEffect(
    () => () => {
      setSelectFiles([]);
      setProgressInfos({});
      setMessages({});
      setLoading(false);
    },
    [],
  );

  /** Получаем информацию о файлах и назначаем результат, который представляет собой массив объектов */
  useEffect(() => {
    if (Array.isArray(fileInfos)) {
      const files = fileInfos.map(
        (file) =>
          ({
            extension: file.name.split('.').pop() as string,
            fileId: file.name,
            filename: file.name,
            size: file.size,
          }) as TFileAttach,
      );

      setSelectFiles(files);
    }
  }, [fileInfos]);

  /** Сбрасываем значение у элемента <input type="file" /> */
  const resetFileInput = () => {
    if (fileInputFieldRef.current) {
      fileInputFieldRef.current.value = '';
    }
  };

  /** Вызываем окно выбора файлов */
  const handleUploadButtonClick = () => {
    fileInputFieldRef.current?.click();
  };

  /** Удаление информации о файле */
  const handleClean = (removeFile: TFileAttach) => {
    setSelectFiles((previousState) =>
      previousState.filter((file) => file.fileId !== removeFile.fileId),
    );

    setMessages((previousState) => {
      if (previousState[removeFile.fileId]) {
        return (
          Object.keys(previousState)
            .filter((key) => key !== removeFile.fileId)
            // eslint-disable-next-line unicorn/prefer-object-from-entries
            .reduce<Record<string, IValidationProperties>>(
              (accumulator, key) => ({
                ...accumulator,
                [key]: previousState[key],
              }),
              {},
            )
        );
      }

      return previousState;
    });
  };

  /** Отправка файла с вызовом callback onUpload */
  const uploadFile = async (file: TFileAttach) => {
    const progressInfoList: Record<string, IFileProgress> = {
      ...progressInfos,
    };

    try {
      await onUpload(file.source!, (fileId: string, value: number) => {
        if (fileId && progressInfoList[fileId]) {
          progressInfoList[fileId].percentage = value;
          setProgressInfos((previousState) => ({
            ...previousState,
            ...progressInfoList,
          }));
        }
      });

      handleClean(file);
      // biome-ignore lint/suspicious/noExplicitAny: reason
    } catch (error: any) {
      if (progressInfoList[file.fileId]) {
        progressInfoList[file.fileId].percentage = 0;
        setProgressInfos((previousState) => ({
          ...previousState,
          ...progressInfoList,
        }));
      }

      setMessages((previousState) => ({
        ...previousState,
        [file.fileId]: {
          message: error.message,
          status: 'error',
        } as IValidationProperties,
      }));
    }
  };

  /** Загрузка текущих выбранных файлов. Каждый файл имеет соответствующую информацию о прогрессе (процент) и индекс в массиве progressInfos.  */
  const handleUpload = async (selectedFiles: TFileAttach[]) => {
    setLoading(true);

    const progressInfoList: Record<string, IFileProgress> = {};

    for (const selectFile of selectedFiles) {
      progressInfoList[selectFile.fileId] = {
        fileName: selectFile.filename,
        percentage: 0,
      };
    }
    setProgressInfos(progressInfoList);

    try {
      for (const selectFile of selectedFiles) {
        await uploadFile(selectFile);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (event: React.MouseEvent) => {
    event.preventDefault();
    handleUpload(selectFiles);
  };

  /** Сохраняем выбранные файлы в текущее состояние */
  const handleNewFileUpload = (newFiles: FileList) => {
    const fileCheck = new FileValidation({ ...(accepts ? { accepts } : {}) });

    if (newFiles.length > 0) {
      setMessages({});

      const nextSelectFiles = [...selectFiles];

      for (const file of newFiles) {
        const checkStatus = fileCheck.validate(file);

        if (!checkStatus.success) {
          setMessages((previousState) => ({
            ...previousState,
            [file.name]: { message: checkStatus.error, status: 'error' },
          }));
        }

        const fileName = file.name;
        const extension = fileName.split('.').pop() as string;

        const uploadedFile: TFileAttach = {
          extension,
          fileId: file.name,
          filename: file.name,
          size: file.size,
          source: file,
        };

        nextSelectFiles.push(uploadedFile);
      }

      setSelectFiles(nextSelectFiles);

      if (autoUpload) {
        handleUpload(nextSelectFiles);
      }
    }
    resetFileInput();
  };

  /** Удаляем файл с вызовом callback onRemove */
  const handleRemoveFile = (removeFile: TFileAttach) => {
    handleClean(removeFile);
    onRemove?.(removeFile);
  };

  /** Получаем существующую ошибку для файла */
  const handleGetErrorMessage = (file: TFileAttach): TErrorMessage => {
    if (messages[file.fileId]) {
      return {
        error: true,
        errorText: messages[file.fileId].message,
      };
    }

    return {} as TErrorMessage;
  };

  return (
    <div className={classes.row}>
      {selectFiles?.length === 0 && (
        <>
          <Button
            size='L'
            onClick={handleUploadButtonClick}
            icon='plus'
            variant='tertiary'
            fullWidth
          >
            {addButtonText ?? 'Add'}
          </Button>

          {helpText && (
            <Text size='sm' tooltip>
              {helpText}
            </Text>
          )}
        </>
      )}
      {selectFiles.map((fileAttach) => (
        <FileComponent
          key={fileAttach.fileId}
          {...fileAttach}
          {...handleGetErrorMessage(fileAttach)}
          loading={isLoading}
          onRemove={handleRemoveFile}
          onDownload={onDownload}
          progress={
            isLoading && progressInfos[fileAttach.fileId]
              ? progressInfos[fileAttach.fileId].percentage
              : 0
          }
          author={author}
          mb={16}
        />
      ))}
      <input
        ref={fileInputFieldRef}
        className={classes.hiddenField}
        type='file'
        multiple={multiple}
        accept={acceptExtension}
        onChange={(event) => {
          handleNewFileUpload(event.target.files || new FileList());
        }}
        title=''
        value=''
      />
      {!autoUpload &&
        selectFiles?.length > 0 &&
        Object.keys(messages).length === 0 && (
          <Button onClick={handleSubmit} size='L' variant='primary' fullWidth>
            {uploadButtonText ?? 'Upload'}
          </Button>
        )}
    </div>
  );
};
