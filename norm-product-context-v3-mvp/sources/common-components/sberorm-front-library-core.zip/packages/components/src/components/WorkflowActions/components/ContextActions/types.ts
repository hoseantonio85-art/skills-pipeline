import type { TButtonSizes } from '@sber-orm/ui-kit';
import { WorkflowAction } from '../../../../@types/api';

export interface IContextActionsProps {
  onActionClick: (value: WorkflowAction, comment?: string) => void;
  actions: WorkflowAction[];
  dropdownButtonSize?: TButtonSizes;
  loading?: boolean;
  testId?: string;
}
