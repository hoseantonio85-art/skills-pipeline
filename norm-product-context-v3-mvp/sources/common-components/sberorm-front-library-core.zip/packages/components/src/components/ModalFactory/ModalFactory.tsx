import React, { useCallback } from 'react';

import { useModal } from './provider';

const ModalFactoryComponent = () => {
  const { currentModal, isModalOpen, closeModal, closeAllModals } = useModal();

  const handleModalClose = useCallback(() => {
    if (currentModal) {
      closeModal(currentModal.id);
    }
  }, [currentModal, closeModal]);

  const handleModalCancel = useCallback(() => {
    closeAllModals();
  }, [closeAllModals]);

  if (!currentModal) {
    return null;
  }

  const ModalComponent = currentModal?.component;

  return (
    <ModalComponent
      isOpen={isModalOpen}
      onClose={handleModalClose}
      onCancel={handleModalCancel}
      {...currentModal.props}
    />
  );
};

export const ModalFactory = React.memo(ModalFactoryComponent);
ModalFactory.displayName = 'ModalFactory';
