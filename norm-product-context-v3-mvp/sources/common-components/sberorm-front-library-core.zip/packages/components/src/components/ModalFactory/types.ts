import { WorkflowActionBody } from '../../@types/api';

export interface IModalActionProps {
  title?: string;
  testId?: string;
  onSubmit: (props?: WorkflowActionBody) => void;
}

export interface IModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCancel: () => void;
  [key: string]: unknown;
}

export interface IModalConfig {
  id: string;
  component: React.ComponentType<IModalProps>;
  props?: Omit<IModalProps, 'isOpen' | 'onClose'>;
}

export interface IModalQueueItem {
  id: string;
  component: React.ComponentType<IModalProps>;
  props?: Omit<IModalProps, 'isOpen' | 'onClose'>;
}

export interface IModalActionContextType {
  openModal: <T extends IModalProps>(
    id: string,
    component: React.ComponentType<T>,
    props?: Omit<T, 'isOpen' | 'onClose'>,
  ) => void;
  closeModal: (id: string) => void;
  closeAllModals: () => void;
  currentModal: IModalQueueItem | null;
  queue: IModalQueueItem[];
  isModalOpen: boolean;
}
