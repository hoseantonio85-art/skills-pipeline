import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import img403 from './images/error-403.svg?react';
import img404 from './images/error-404.svg?react';
import img408 from './images/error-408.svg?react';
import imgAdmission from './images/error-admission.svg?react';
import imgCrashed from './images/error_crashed.svg?react';
import { ErrorCodes, type IErrorInstanceType } from './types';
import { getErrorComponentProps, reloadPage } from './utils';

describe('getErrorComponentProps', () => {
	it('returns correct props for PAGE_NOT_FOUND', () => {
		const error = { code: ErrorCodes.PAGE_NOT_FOUND };
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			subTitle: 'pageNotFoundSubTitle',
			title: 'pageNotFoundTitle',
		});
	});
	it('returns correct props for REQUEST_TIMEOUT', () => {
		const error = { code: ErrorCodes.REQUEST_TIMEOUT };
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img408,
			subTitle: 'pageRequestTimeoutSubTitle',
			title: 'pageRequestTimeoutTitle',
			withRefresh: true,
		});
	});
	it('returns correct props for BAD_REQUEST', () => {
		const error = { code: ErrorCodes.BAD_REQUEST, text: 'Bad Request' };
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: 'Bad Request',
			subTitle: 'pageBadRequestSubTitle',
			title: 'pageBadRequestTitle',
			withRefresh: true,
		});
	});
	it('returns correct props for FORBIDDEN', () => {
		const error = { code: ErrorCodes.FORBIDDEN, text: 'Forbidden' };
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img403,
			subTitle: 'forbiddenSubTitle',
			title: 'forbiddenTitle',
			withRefresh: false,
		});
	});
	it('returns correct props for SERVICE_UNAVAILABLE', () => {
		const error = {
			code: ErrorCodes.SERVICE_UNAVAILABLE,
			text: 'Service Unavailable',
		};
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: 'Service Unavailable',
			subTitle: 'pageBadRequestSubTitle',
			title: 'pageBadRequestTitle',
			withRefresh: true,
		});
	});
	it('returns correct props for GATEWAY_TIMEOUT', () => {
		const error = {
			code: ErrorCodes.GATEWAY_TIMEOUT,
			text: 'Gateway Timeout',
		};
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: 'Gateway Timeout',
			subTitle: 'pageBadRequestSubTitle',
			title: 'pageBadRequestTitle',
			withRefresh: true,
		});
	});
	it('returns correct props for BUSINESS with custom text and title', () => {
		const error = {
			code: ErrorCodes.BUSINESS,
			text: 'Business Error',
			title: 'Business Title',
		};
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: imgAdmission,
			subTitle: 'Business Error',
			title: 'Business Title',
		});
	});
	it('returns correct props for PROGRAM_CRASHED with exception and text', () => {
		const error = {
			code: ErrorCodes.PROGRAM_CRASHED,
			text: 'Program Crashed',
		};
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: imgCrashed,
			errorText: 'Program Crashed',
			subTitle: 'pageProgramCrashedSubTitle',
			title: 'pageBadRequestTitle',
			withRefresh: true,
			withCopy: true,
		});
	});

	it('returns default props for unknown error code', () => {
		const error = {
			code: 'UNKNOWN_CODE',
			exception: 'Unknown Error',
			text: 'Unknown Text',
		};
		const result = getErrorComponentProps(error as IErrorInstanceType);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: 'Unknown Error',
			subTitle: 'pageAppDefaultSubTitle',
			title: 'pageBadRequestTitle',
			withCopy: true,
			withRefresh: true,
			...error,
		});
	});

	it('returns default props when error code is missing', () => {
		const error = { exception: 'No Code Provided', text: 'No Code Text' };
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: 'No Code Provided',
			subTitle: 'pageAppDefaultSubTitle',
			title: 'pageBadRequestTitle',
			withCopy: true,
			withRefresh: true,
			...error,
		});
	});

	it('returns default props when error object is empty', () => {
		const error = {};
		const result = getErrorComponentProps(error);
		expect(result).toEqual({
			IconComponent: img404,
			errorText: undefined,
			subTitle: 'pageAppDefaultSubTitle',
			title: 'pageBadRequestTitle',
			withCopy: true,
			withRefresh: true,
		});
	});
});

describe('reloadPage', () => {
	// Мокаем window.location.reload
	const original = window.location;

	beforeAll(() => {
		Object.defineProperty(window, 'location', {
			configurable: true,
			value: { reload: vi.fn() },
		});
	});

	afterAll(() => {
		Object.defineProperty(window, 'location', {
			configurable: true,
			value: original,
		});
	});

	it('calls window.location.reload', () => {
		reloadPage();
		expect(window.location.reload).toHaveBeenCalled();
	});
});
