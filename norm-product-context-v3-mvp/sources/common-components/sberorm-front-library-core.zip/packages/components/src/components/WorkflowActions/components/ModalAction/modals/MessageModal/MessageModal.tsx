import { Button, Row, Text, Title } from '@sber-orm/ui-kit';
import React from 'react';
import { useTranslation } from 'react-i18next';

import { Drawer } from '../../../../../Drawer';
import type {
  IModalActionProps,
  IModalProps,
} from '../../../../../ModalFactory/types';
import Logo from '../../images/norm-chat-violet-logo.svg?react';
import classes from './styles.module.scss';

interface IMessageModalProps extends IModalActionProps, IModalProps {
  msgTitle?: string;
  description?: string;
  btnText?: string;
}

export const MessageModal = React.memo<IMessageModalProps>((props) => {
  const {
    btnText,
    description,
    msgTitle,
    onSubmit,
    testId,
    isOpen,
    onClose,
    onCancel,
  } = props;

  const { t } = useTranslation('workflow');

  const handleCancel = () => {
    onCancel();
  };

  const handleSubmit = () => {
    onSubmit();
    onClose();
  };

  const drawerFooter = (
    <Row gutter={16}>
      <Button
        size='L'
        variant='secondary'
        onClick={handleCancel}
        fullWidth
        data-testid={testId ? `${testId}-messageModal-cancel` : undefined}
      >
        {t('common:cancel')}
      </Button>
      <Button
        size='L'
        variant='primary'
        onClick={handleSubmit}
        fullWidth
        data-testid={testId ? `${testId}-messageModal-submit` : undefined}
      >
        {btnText ?? t('common:continue')}
      </Button>
    </Row>
  );

  return (
    <Drawer
      position='absolute'
      open={isOpen}
      onClose={handleCancel}
      footer={drawerFooter}
      inModal
    >
      <Row
        direction='column'
        justify='center'
        gutter={24}
        className={classes.container}
      >
        <Logo width={100} height={100} />
        {msgTitle && <Title size='H700'>{msgTitle}</Title>}
        {description && (
          <Text size='lg' tooltip>
            {description}
          </Text>
        )}
      </Row>
    </Drawer>
  );
});

MessageModal.displayName = 'MessageModal';
