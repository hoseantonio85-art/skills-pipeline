import {
  MarkdownViewer,
  MoneyInput,
  useComponentDidMount,
  useDebounce,
  useMoneyFormatter,
} from '@sber-orm/ui-kit';
import { useCallback, useEffect, useMemo } from 'react';

import { IEditFieldProps } from './types';

export const CurrencyField = ({
  error,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<number | undefined>) => {
  const label = useMemo(
    () => (noLabel ? undefined : fieldConfig?.title),
    [noLabel, fieldConfig?.title],
  );
  const editable = (fieldConfig?.editable ?? true) && !readonly;

  const value = useMemo<number | null>(
    () => (field?.value as number) ?? null,
    [field?.value],
  );

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const formatter = useMoneyFormatter('ru-RU', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 2,
  });
  const trackValue = useDebounce(value, 1000);
  const isComponentMounted = useComponentDidMount();

  const handleChange = useCallback(
    (newValue: number | null | undefined) => {
      let inputValue = newValue;

      if (typeof inputValue === 'number' && inputValue < 0) {
        inputValue = Math.abs(inputValue);
      }
      onChange(inputValue ?? undefined);
    },
    [onChange],
  );

  useEffect(() => {
    isComponentMounted &&
      onTrack?.(fieldName!, trackValue ? String(trackValue) : undefined);
  }, [trackValue]);

  if (raw) {
    return formatter.format(value as number).replace(/,/g, '.');
  }

  return (
    <MoneyInput
      labelInside
      fullWidth
      size='L'
      label={label}
      canClear
      value={value}
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      decimalSeparator='.'
      precision={2}
      required={!!required}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      data-testid={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
