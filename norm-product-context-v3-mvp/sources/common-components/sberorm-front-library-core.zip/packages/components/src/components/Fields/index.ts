import { ArrayListField } from './ArrayListField';
import { BooleanSwitcher } from './BooleanSwitcher';
import { CheckboxField } from './CheckboxField';
import { CurrencyField } from './CurrencyField';
import { CurrencyRangeField } from './CurrencyRangeField';
import { DateField } from './DateField';
import { DateRangeField } from './DateRangeField';
import { DeadlineStagesField } from './DeadlineStagesField';
import { InputField } from './InputField';
import { InputListField } from './InputListField';
import { InputNumberField } from './InputNumberField';
import { ListField } from './ListField';
import { MultiSwitcherField } from './MultiSwitcherField';
import { MultiTreeField } from './MultiTreeField';
import { NewDateRangeField } from './NewDateRangeField';
import { SeverityField } from './SeverityField';
import { SeverityMultiSwitcherField } from './SeverityMultiSwitcherField';
import { SwitcherField } from './SwitcherField';
import { TextareaField } from './TextareaField';
import { ToggleField } from './ToggleField';
import { TogglerMogglerField } from './TogglerMogglerField';
import { TreeField } from './TreeField';

export const fields = {
  arrayList: ArrayListField,
  booleanSwitcher: BooleanSwitcher,
  checkbox: CheckboxField,
  currency: CurrencyField,
  currencyRange: CurrencyRangeField,
  date: DateField,
  dateRange: NewDateRangeField, // Работает с одинм полем, значение - массив ISO строк
  datetime: DateRangeField, // Работает с двумя полями, fieldName и fallbackFieldName
  deadlineStagesField: DeadlineStagesField,
  input: InputField,
  inputList: InputListField,
  inputNumber: InputNumberField,
  list: ListField,
  multiSwitcher: MultiSwitcherField,
  multiTree: MultiTreeField,
  severity: SeverityField,
  severityMultiSwitcher: SeverityMultiSwitcherField,
  switcher: SwitcherField,
  textarea: TextareaField,
  toggle: ToggleField,
  togglerMoggler: TogglerMogglerField,
  tree: TreeField,
};

export * from './types';

export {
  ArrayListField,
  BooleanSwitcher,
  CurrencyField,
  CurrencyRangeField,
  DateField,
  NewDateRangeField,
  DateRangeField,
  InputField,
  InputNumberField,
  ListField,
  MultiSwitcherField,
  MultiTreeField,
  SeverityField,
  SeverityMultiSwitcherField,
  SwitcherField,
  TextareaField,
  ToggleField,
  TreeField,
};
