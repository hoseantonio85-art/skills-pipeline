import React, { useEffect } from 'react';

import {
  dispatchTrackingEvent,
  setTrackingConfig,
} from './dispatchClickSreamEvent';
import { IOptions, TPushData, TTrackingProfile, useTracking } from './tracking';
import type { IClickStreamProviderProps, IDispatchEventProps } from './types';

export const ClickStreamProvider = (
  props: React.PropsWithChildren<IClickStreamProviderProps>,
) => {
  const {
    appBlockName,
    children,
    clickStreamEnabled,
    clickStreamKey,
    clickStreamUrl,
    disabled,
    tenantId,
    userInfo,
  } = props;

  useEffect(() => {
    if (userInfo?.personalNumber && !disabled) {
      const sessionId =
        userInfo.personalNumber +
        (userInfo.lastName || '') +
        (userInfo.firstName || '') +
        (userInfo.middleName || '');

      setTrackingConfig({
        appVersion: '1.0.0',
        clickStreamEnabled,
        clickStreamKey,
        clickStreamUrl,
        clientBlock: appBlockName,
        hashUserLoginId: userInfo.personalNumber,
        sessionKey: sessionId,
      } as TTrackingProfile);
    }
  }, [
    appBlockName,
    clickStreamEnabled,
    clickStreamKey,
    clickStreamUrl,
    tenantId,
    userInfo,
  ]);

  const { Track } = useTracking({}, {
    dispatch: (data, props: IDispatchEventProps = {}) => {
      const { eventType, properties = [] } = data;

      dispatchTrackingEvent(
        {
          ...data,
          properties: properties?.concat(
            eventType ? [{ key: 'eventType', value: eventType }] : [],
          ),
        },
        props,
        clickStreamEnabled,
      );
    },
    process: function () {
      const properties = [{ key: 'appId', value: appBlockName }];

      if (userInfo?.personalNumber) {
        properties.push({
          key: 'personalNumber',
          value: userInfo.personalNumber,
        });
      }
      if (userInfo?.userType) {
        properties.push({
          key: 'userType',
          value: userInfo.userType,
        });
      }
      if (tenantId) {
        properties.push({
          key: 'tenantId',
          value: tenantId,
        });
      }

      return {
        properties,
      };
    },
  } as IOptions<TPushData>);

  if (disabled) {
    return <>{children}</>;
  }

  return <Track>{children}</Track>;
};
