import {
  INotificationOptions,
  Text,
  useCopyToClipboard,
} from '@sber-orm/ui-kit';
import { useEffect, useState } from 'react';
import { I18nextProvider, useTranslation } from 'react-i18next';

import i18n from '../../i18n';
import { ErrorBoundaryContext } from './ErrorBoundaryContext';
import { ErrorComponent } from './ErrorComponent';
import resource from './locales/ru/errors.json';
import {
  EBusinessErrorTypes,
  ERESTErrorEvents,
  ErrorCodes,
  type IErrorBoundaryProperties,
  type IErrorInstanceType,
  type IErrorMessage,
  type IPageErrorComponentProperties,
} from './types';

export const ErrorBoundary = (props: IErrorBoundaryProperties) => {
  const { children, pathName, notificationCallback, supportLink } = props;

  const { t } = useTranslation(['errors']);

  const copyAction = useCopyToClipboard();

  const [state, setState] = useState<IPageErrorComponentProperties>({
    error: null,
    pathName,
  });

  function setError(error: IErrorInstanceType) {
    setState({
      ...state,
      error,
    });
  }

  function renderErrorComponent() {
    if (!state.error) {
      return null;
    }

    return (
      <ErrorComponent
        {...state.error}
        addNotification={notificationCallback}
        supportLink={supportLink}
      />
    );
  }

  function handleHttpError(event: CustomEvent) {
    setState({
      ...state,
      error: {
        code: event?.detail?.request?.status,
      },
    });
  }

  function handleBusinessError(event: CustomEvent) {
    if (event.defaultPrevented) {
      return;
    }

    const errorMessage: IErrorMessage = event.detail;

    const handleCopy = async () => {
      await copyAction(errorMessage?.exception as string, {
        addNotification: notificationCallback,
        errorMessage: t('notCopied'),
        successMessage: t('successCopy'),
      });
    };

    const errorAction = (
      <I18nextProvider i18n={i18n('ru', 'errors', resource)}>
        <Text medium link onClick={handleCopy}>
          {t('copyErrorCode')}
        </Text>
      </I18nextProvider>
    );

    switch (errorMessage.code) {
      case EBusinessErrorTypes.business: {
        setState({
          ...state,
          error: {
            code: ErrorCodes.BUSINESS,
            text: errorMessage.text,
            title: errorMessage.title,
          },
        });
        break;
      }
      case EBusinessErrorTypes.warning: {
        notificationCallback?.(
          (errorMessage?.text ?? errorMessage?.title) as string,
          {
            actions: errorAction,
            title: errorMessage?.title,
            type: 'error',
          } as INotificationOptions,
        );
        break;
      }
      case EBusinessErrorTypes.notification: {
        notificationCallback?.(
          (errorMessage?.text ?? errorMessage?.title) as string,
          {
            title: errorMessage?.title,
            type: 'error',
          } as INotificationOptions,
        );
        break;
      }
      case undefined:
      case '':
      case null:
      case EBusinessErrorTypes.critical: {
        setState({
          ...state,
          error: {
            code: ErrorCodes.APP_ERROR,
            text: errorMessage.exception,
          },
        });
        break;
      }
    }
  }

  function resetState() {
    setState({
      error: null,
      pathName,
    });
  }

  useEffect(() => {
    resetState();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathName]);

  useEffect(() => {
    window?.addEventListener(
      ERESTErrorEvents.http as string,
      handleHttpError as EventListener,
    );
    window?.addEventListener(
      ERESTErrorEvents.business as string,
      handleBusinessError as EventListener,
    );

    return () => {
      window?.removeEventListener(
        ERESTErrorEvents.http as string,
        handleHttpError as EventListener,
      );
      window?.removeEventListener(
        ERESTErrorEvents.business as string,
        handleBusinessError as EventListener,
      );
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <ErrorBoundaryContext.Provider
        value={{
          setApplicationError: setError,
        }}
      >
        {state.error ? renderErrorComponent() : children}
      </ErrorBoundaryContext.Provider>
    </>
  );
};
