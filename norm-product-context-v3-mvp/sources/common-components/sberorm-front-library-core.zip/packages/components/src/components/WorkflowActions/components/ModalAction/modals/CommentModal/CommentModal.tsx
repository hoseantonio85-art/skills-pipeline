import {
  Button,
  EIconName,
  Icon,
  type ITextareaProperties,
  Row,
  Textarea,
  useStorageData,
} from '@sber-orm/ui-kit';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { Drawer } from '../../../../../Drawer';
import type {
  IModalActionProps,
  IModalProps,
} from '../../../../../ModalFactory/types';
import classes from './styles.module.scss';

interface ICommentModalProps extends IModalActionProps, IModalProps {
  localStorageKey?: string;
  requiredComment?: boolean;
}

export const CommentModal = React.memo<ICommentModalProps>((props) => {
  const {
    title,
    requiredComment,
    localStorageKey,
    onSubmit,
    testId,
    isOpen,
    onClose,
    onCancel,
  } = props;

  const { t } = useTranslation('workflow');

  const { setStorageData, storage } = useStorageData<string>(
    localStorageKey ?? '',
  );

  const [comment, setComment] = useState<string>(storage || '');
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setComment(storage || '');
    }
  }, [storage, isOpen]);

  const handleReset = () => {
    setError(false);
    setComment('');
  };

  const handleCancel = () => {
    onCancel();
    handleReset();
  };

  const handleChange = (value: string) => {
    setComment(value);
    localStorageKey && setStorageData(value);
    error && setError(false);
  };

  const handleSubmit = () => {
    if (requiredComment && !comment?.trim?.()) {
      setError(true);
    } else {
      onSubmit({ comment: comment.trim() });

      onClose();
      handleReset();
    }
  };

  const drawerFooter = (
    <Row gutter={16}>
      <Button
        size='L'
        variant='secondary'
        onClick={handleCancel}
        fullWidth
        data-testid={testId ? `${testId}-cancel` : undefined}
      >
        {t('common:cancel')}
      </Button>
      <Button
        size='L'
        variant='primary'
        onClick={handleSubmit}
        fullWidth
        data-testid={testId ? `${testId}-submit` : undefined}
      >
        {t('common:send')}
      </Button>
    </Row>
  );

  return (
    <Drawer
      title={title}
      position='absolute'
      open={isOpen}
      onClose={handleCancel}
      footer={drawerFooter}
      inModal
    >
      <div className={classes.container}>
        <Textarea
          {...({
            error,
            fullWidth: true,
            helperText: error ? t('validationError') : undefined,
            label: t('comment') || '',
            labelInside: true,
            onChange: handleChange,
            required: !!requiredComment,
            suffix: !!comment && (
              <Icon
                className={classes.suffix}
                onClick={() => setComment('')}
                name={EIconName.cross}
              />
            ),
            maxLength: 2000,
            value: comment,
          } as ITextareaProperties)}
        />
      </div>
    </Drawer>
  );
});

CommentModal.displayName = 'CommentModal';
