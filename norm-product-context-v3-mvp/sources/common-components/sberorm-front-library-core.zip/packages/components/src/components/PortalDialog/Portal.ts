import React, { forwardRef, useImperativeHandle } from 'react';
import ReactDOM from 'react-dom';

import { usePortal } from './hooks';
import { IPortalProperties } from './types';

export type TPortalRef = HTMLElement;

export const Portal = forwardRef(
  (
    properties: IPortalProperties,
    reference: React.ForwardedRef<TPortalRef>,
  ) => {
    const { children, getContainer, id, visible } = properties;

    const container = usePortal(id, getContainer?.());

    // Ref return nothing, only for wrapper check exist
    useImperativeHandle(reference, () => container as HTMLDivElement);

    if (container && visible) {
      return ReactDOM.createPortal(children, container);
    }
  },
);

Portal.displayName = 'Portal';
