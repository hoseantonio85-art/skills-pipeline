import { DateRangePicker, MarkdownViewer } from '@sber-orm/ui-kit';
import dayjs from 'dayjs';
import isBetween from 'dayjs/plugin/isBetween';
import { useState } from 'react';
import { formatDate } from '../../utils';

import classes from './styles.module.scss';
import { IEditFieldProps } from './types';

dayjs.extend(isBetween);

export const DateRangeField = ({
  error,
  fallbackField,
  fallbackFieldConfig,
  fallbackFieldName,
  field,
  fieldConfig,
  fieldName,
  noLabel,
  onChange,
  onTrack,
  raw,
  required,
  testId,
  readonly,
}: IEditFieldProps<string | undefined>) => {
  const startLabel = noLabel ? undefined : fieldConfig?.title;
  const endLabel = noLabel ? undefined : fallbackFieldConfig?.title;
  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const endRequired = fallbackFieldConfig?.required ?? false;

  const helpText = String(fieldConfig?.extras?.help || '');

  const getDefaultValue = (): [dayjs.Dayjs | null, dayjs.Dayjs | null] => {
    const date1 = String(field?.value);
    const date2 = String(fallbackField?.value) || 'error';
    const date1Valid = dayjs(date1).isValid();
    const date2Valid = dayjs(date2).isValid();

    return [
      date1Valid ? dayjs(date1) : null,
      date2Valid
        ? dayjs(date2).hour(23).minute(59).second(59).millisecond(999)
        : null,
    ];
  };
  const [value, setValue] = useState<[dayjs.Dayjs | null, dayjs.Dayjs | null]>(
    getDefaultValue(),
  );

  if (raw) {
    return value
      .map((date) => date?.format('DD.MM.YYYY'))
      .filter(Boolean)
      .join(' - ');
  }

  const handleChange = (values: [unknown, unknown]) => {
    const isFieldChanged = values[0] !== value[0];
    const isFallbackFieldChanged = values[1] !== value[1];

    setValue(values as [dayjs.Dayjs | null, dayjs.Dayjs | null]);
    const dateFrom = values[0] as null | dayjs.Dayjs;
    const dateTo = (values[1] as null | dayjs.Dayjs)
      ?.hour(23)
      .minute(59)
      .second(59)
      .millisecond(999);

    onChange(dateFrom?.toISOString(), dateTo?.toISOString());
    isFieldChanged &&
      onTrack?.(
        fieldName!,
        dateFrom ? formatDate(dateFrom?.toISOString()) : undefined,
      );
    isFallbackFieldChanged &&
      onTrack?.(
        fallbackFieldName!,
        dateTo ? formatDate(dateTo?.toISOString()) : undefined,
      );
  };

  return (
    <DateRangePicker
      value={value}
      startLabel={startLabel}
      endLabel={endLabel}
      className={classes.dateRangePicker}
      onChange={handleChange}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      required={!!required}
      endRequired={!!endRequired}
      disabled={!editable}
      size='L'
      fullWidth
      datePanelStyle='single'
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
