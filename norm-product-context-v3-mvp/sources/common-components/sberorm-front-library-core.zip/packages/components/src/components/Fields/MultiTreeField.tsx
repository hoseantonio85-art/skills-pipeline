import {
  ComboboxEvent,
  MarkdownViewer,
  Select,
  TreeItem,
  TSelectProperties,
} from '@sber-orm/ui-kit';
import { Key, useCallback, useEffect, useMemo, useState } from 'react';

import { Item, SearchResponseEntry } from '../../@types/api';
import { IEditFieldProps } from './types';

interface ITreeFieldItem extends TreeItem {
  value?: string;
  leaf?: boolean;
}

export interface IMultiTreeFieldProps extends IEditFieldProps<string[]> {
  selectProps?: TSelectProperties;
}

type TTreeSelectModeType = Exclude<
  NonNullable<TSelectProperties['treeProps']>['selectMode'],
  undefined
>;

const addChildrenToNode = (
  nodeKey: Key,
  children: ITreeFieldItem[],
  tree: ITreeFieldItem[],
) => {
  for (const item of tree) {
    if (item.key === nodeKey) {
      item.children = children;
      item.loadable = false;
      return tree;
    }
    if (item.children) {
      addChildrenToNode(nodeKey, children, item.children as ITreeFieldItem[]);
    }
  }

  return tree;
};

const findSelectedValues = (
  options: ITreeFieldItem[],
  value: string[],
): ITreeFieldItem[] => {
  if (value.length === 0) {
    return [];
  }

  const selectedValues: ITreeFieldItem[] = [];
  const valueSet = new Set(value);

  const traverse = (nodes: ITreeFieldItem[]) => {
    for (const node of nodes) {
      if (valueSet.has(String(node.key))) {
        selectedValues.push(node);

        if (selectedValues.length === valueSet.size) {
          return;
        }
      }

      if (node.children) {
        traverse(node.children as ITreeFieldItem[]);

        if (selectedValues.length === valueSet.size) {
          return;
        }
      }
    }
  };

  traverse(options);
  return selectedValues;
};

const mapItemsToTree = (items: Item[]): ITreeFieldItem[] =>
  items.map((item) => ({
    key: item.id!,
    label: item.name!,
    leaf: item.leaf,
    loadable: !item.leaf,
    value: item.id!,
  }));

const mapSearchResultsToOptions = (
  searchEntries: SearchResponseEntry[],
): ITreeFieldItem[] => {
  const optionsMap = new Map<string, ITreeFieldItem>();

  searchEntries.forEach((entry) => {
    const fullPath = entry.path;
    if (fullPath && fullPath.length === 0) {
      return;
    }

    const lastItem = fullPath?.[fullPath.length - 1];
    if (!lastItem?.id) {
      return;
    }

    // TODO если нужно будет выводить путь до найденного элемента
    // const label = fullPath
    //   .map((item) => item.name || item.id)
    //   .filter(Boolean)
    //   .join(' / ');

    optionsMap.set(lastItem.id, {
      key: lastItem.id,
      label: lastItem.name || lastItem.id,
      leaf: lastItem.leaf,
      value: lastItem.id,
    });
  });

  return Array.from(optionsMap.values());
};

export const MultiTreeField = (props: IMultiTreeFieldProps) => {
  const {
    error,
    field,
    fieldConfig,
    fieldName,
    noLabel,
    onChange,
    raw,
    required,
    selectProps,
    loadStructure,
    onSearchStructure,
    testId,
    readonly,
  } = props;
  const label = noLabel ? undefined : fieldConfig?.title;

  const value = useMemo(
    () => (field?.value as string[]) || [],
    [field, (field?.value as string[])?.length],
  );

  const editable = (fieldConfig?.editable ?? true) && !readonly;
  const dictionary = fieldConfig?.extras?.['dictionary'] as string;

  const validation = fieldConfig?.validation || [];

  const hintText = String(fieldConfig?.extras?.hint || '');
  const helpText = String(fieldConfig?.extras?.help || '');

  const [options, setOptions] = useState<ITreeFieldItem[]>([]);
  const [selectedValue, setSelectedValue] = useState<ITreeFieldItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const selectMode = useMemo<TTreeSelectModeType>(
    () =>
      validation.some((valid) => valid.type === 'onlyLeaf')
        ? 'strict'
        : 'directory',
    [validation],
  );

  const selectOptions = useMemo(() => selectProps, [selectProps]);

  const onSelect = useCallback(
    (
      newValue: string[],
      _event: ComboboxEvent,
      newOptions: ITreeFieldItem[],
    ) => {
      setSelectedValue(newOptions);

      onChange(newValue);
    },
    [onChange],
  );

  const onLoadData = useCallback(
    async (option: ITreeFieldItem) => {
      const { levels } = await loadStructure(dictionary, String(option.key));

      const items = levels?.pop()?.items || [];
      const children = mapItemsToTree(items);

      setOptions((prev) => {
        return addChildrenToNode(option.key, children, [...prev]);
      });
    },
    [dictionary, loadStructure],
  );

  const handleInputChange = useCallback(
    async (searchValue: string) => {
      if (!onSearchStructure || !searchValue.trim()) {
        const { levels } = await loadStructure(dictionary);

        const items = levels?.pop()?.items || [];
        setOptions(mapItemsToTree(items));

        setIsSearching(false);
        return;
      }

      setIsSearching(true);
      try {
        const result = await onSearchStructure(searchValue.trim(), dictionary);
        if (!result) {
          return;
        }

        const searchEntries = result?.items || [];

        if (searchEntries.length > 0) {
          const searchOptions = mapSearchResultsToOptions(searchEntries);
          setOptions(searchOptions);
        } else {
          setOptions([]);
        }
      } catch {
        setOptions([]);
      }
    },
    [onSearchStructure, dictionary, value, options],
  );

  const treeProps = useMemo(
    () => ({
      onLoadData,
      selectMode,
    }),
    [onLoadData, selectMode],
  );

  useEffect(() => {
    if (raw || !editable) {
      const pathItems = fieldConfig?.pathItems || [];

      const newOptions = value.map((val) => ({
        key: val,
        label: pathItems.find((pathItem) => pathItem.id === val)?.value,
        value: val,
      }));

      setOptions(newOptions);
      setSelectedValue(findSelectedValues(newOptions, value));

      return;
    }

    if (isSearching) {
      return;
    }

    const load = async () => {
      const { levels } = await loadStructure(dictionary);
      const items = levels?.pop()?.items || [];
      const newOptions = mapItemsToTree(items);

      setOptions(newOptions);
      setSelectedValue(findSelectedValues(newOptions, value));
    };

    load();
  }, []);

  useEffect(() => {
    if (!isSearching && options.length > 0) {
      setSelectedValue(findSelectedValues(options, value));
    }
  }, [value?.length]);

  if (raw) {
    const labels = selectedValue?.map((item) => item.label);
    return <>{labels.length > 0 ? labels.join(', ') : null}</>;
  }

  return (
    <Select
      options={options}
      label={label}
      tree
      treeProps={treeProps}
      placeholder=''
      multiple
      value={selectedValue}
      required={!!required}
      onChange={onSelect}
      onMenuClose={() => {
        if (isSearching && !!onSearchStructure) {
          handleInputChange('');
        }
      }}
      labelInside
      size='L'
      canClear
      tooltip={hintText ? <MarkdownViewer markdown={hintText} /> : undefined}
      error={typeof error === 'string'}
      helperText={
        error ?? (helpText ? <MarkdownViewer markdown={helpText} /> : undefined)
      }
      disabled={!editable}
      useCustomSearch={!!onSearchStructure}
      showOptionSearch={!!onSearchStructure}
      onInputChange={onSearchStructure ? handleInputChange : undefined}
      {...selectOptions}
      testId={testId ? `${testId}-${fieldName}` : undefined}
    />
  );
};
