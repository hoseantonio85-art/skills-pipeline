import React, {
  createContext,
  useCallback,
  useContext,
  useReducer,
} from 'react';
import {
  IModalActionContextType,
  IModalProps,
  IModalQueueItem,
} from '../types';

const ModalActionContext = createContext<IModalActionContextType | undefined>(
  undefined,
);

interface IModalActionState {
  queue: IModalQueueItem[];
  currentModal: IModalQueueItem | null;
  isModalOpen: boolean;
}

type TModalActionType =
  | { type: 'OPEN_MODAL'; payload: IModalQueueItem }
  | { type: 'CLOSE_MODAL'; payload: string }
  | { type: 'CLOSE_CURRENT_MODAL' }
  | { type: 'CLOSE_ALL_MODALS' };

const modalReducer = (
  state: IModalActionState,
  action: TModalActionType,
): IModalActionState => {
  switch (action.type) {
    case 'OPEN_MODAL': {
      const existingIndex = state.queue.findIndex(
        (modal) => modal.id === action.payload.id,
      );
      const existingInCurrent = state.currentModal?.id === action.payload.id;

      if (existingInCurrent || existingIndex >= 0) {
        return state;
      }

      const newQueue = [...state.queue, action.payload];

      if (!state.currentModal && newQueue.length > 0) {
        return {
          queue: newQueue.slice(1),
          currentModal: newQueue[0],
          isModalOpen: true,
        };
      }

      return {
        ...state,
        queue: newQueue,
      };
    }

    case 'CLOSE_CURRENT_MODAL':
      if (state.queue.length > 0) {
        return {
          queue: state.queue.slice(1),
          currentModal: state.queue[0],
          isModalOpen: true,
        };
      } else {
        return {
          queue: [],
          currentModal: null,
          isModalOpen: false,
        };
      }

    case 'CLOSE_MODAL':
      if (state.currentModal?.id === action.payload) {
        return modalReducer(state, { type: 'CLOSE_CURRENT_MODAL' });
      } else {
        const filteredQueue = state.queue.filter(
          (item) => item.id !== action.payload,
        );
        return {
          ...state,
          queue: filteredQueue,
        };
      }

    case 'CLOSE_ALL_MODALS':
      return {
        queue: [],
        currentModal: null,
        isModalOpen: false,
      };

    default:
      return state;
  }
};

const initialState: IModalActionState = {
  queue: [],
  currentModal: null,
  isModalOpen: false,
};

export const ModalProvider: React.FC<React.PropsWithChildren<{}>> = ({
  children,
}) => {
  const [state, dispatch] = useReducer(modalReducer, initialState);

  const openModal = <T extends IModalProps>(
    id: string,
    component: React.ComponentType<T>,
    props?: Omit<T, 'isOpen' | 'onClose'>,
  ) => {
    dispatch({
      type: 'OPEN_MODAL',
      payload: {
        id,
        component: component as React.ComponentType<IModalProps>,
        props,
      },
    });
  };

  const closeModal = useCallback((id: string) => {
    dispatch({ type: 'CLOSE_MODAL', payload: id });
  }, []);

  const closeAllModals = useCallback(() => {
    dispatch({ type: 'CLOSE_ALL_MODALS' });
  }, []);

  return (
    <ModalActionContext.Provider
      value={{
        openModal,
        closeModal,
        closeAllModals,
        currentModal: state.currentModal,
        queue: state.queue,
        isModalOpen: state.isModalOpen,
      }}
    >
      {children}
    </ModalActionContext.Provider>
  );
};

export const useModal = (): IModalActionContextType => {
  const context = useContext(ModalActionContext);
  if (!context) {
    throw new Error('useModal must be used within a ModalProvider');
  }
  return context;
};
