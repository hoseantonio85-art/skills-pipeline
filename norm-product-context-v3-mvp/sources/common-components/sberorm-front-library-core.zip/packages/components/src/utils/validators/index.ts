import { ObjectField } from '../../@types/api';
import dateInPast from './dateInPastValidator';
import equalsValue from './equalsValueValidator';
import fileAcceptExtensions from './fileAcceptExtensionsValidator';
import fileMaxSize from './fileMaxSizeValidator';
import fileNameMaxLength from './fileNameMaxLengthValidator';
import fileNotEmpty from './fileNotEmptyValidator';
import maxExclusive from './maxExclusiveValidator';
import maxLength from './maxLengthValidator';
import maxValue from './maxValueValidator';
import minExclusive from './minExclusiveValidator';
import minValue from './minValueValidator';
import isNil from './nilValidator';
import regexp from './regexValidator';
import required from './requiredValidator';

export interface IFieldValidator {
  message?: string;
  valid: boolean;
}

export interface IValidationProps {
  value: ObjectField['value'];
  errorMessage?: string;
}

type TValidOverload = {
  (value: ObjectField['value']): IFieldValidator;
  (value: ObjectField['value'], errorMessage?: string): IFieldValidator;
  (
    value: ObjectField['value'],
    pattern: string,
    errorMessage?: string,
  ): IFieldValidator;
  (
    value: ObjectField['value'],
    min: number,
    errorMessage?: string,
  ): IFieldValidator;
  (
    value: ObjectField['value'],
    max: number,
    errorMessage?: string,
  ): IFieldValidator;
};

export type TValidators = Record<string, TValidOverload>;

export const validatorsSchema = {
  dateInPast: (value: ObjectField['value'], errorMessage?: string) => ({
    message: errorMessage,
    valid: dateInPast(value),
  }),
  maxExclusive: (
    value: ObjectField['value'],
    condition: number,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || maxExclusive(value, condition),
  }),
  maxLength: (
    value: ObjectField['value'],
    condition: number,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || maxLength(value, condition),
  }),
  maxValue: (
    value: ObjectField['value'],
    condition: number,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || maxValue(value, condition),
  }),
  minExclusive: (
    value: ObjectField['value'],
    condition: number,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || minExclusive(value, condition),
  }),
  minValue: (
    value: ObjectField['value'],
    condition: number,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || minValue(value, condition),
  }),
  regex: (
    value: ObjectField['value'],
    condition: string,
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: !required(value) || regexp(value, condition),
  }),
  required: (value: ObjectField['value']) => ({
    message: 'Field is required',
    valid: !isNil(value) && value !== '' ? required(value) : false,
  }),
  notEquals: (
    value: ObjectField['value'],
    condition: ObjectField['value'],
    errorMessage?: string,
  ) => ({
    message: errorMessage,
    valid: equalsValue(value, condition) !== 0,
  }),
  // oneOf: (value: ObjectField['value']) => ({
  //   message: 'Поле обязательно для заполнения',
  //   valid: !isNil(value) && value !== '' ? required(value) : false,
  // }),
  gtThan: (
    value: ObjectField['value'],
    condition: ObjectField['value'],
    errorMessage?: string,
  ) => {
    const compareValue = equalsValue(value, condition);

    return {
      message: errorMessage,
      valid: compareValue > 0,
    };
  },
  gteThan: (
    value: ObjectField['value'],
    condition: ObjectField['value'],
    errorMessage?: string,
  ) => {
    const compareValue = equalsValue(value, condition);

    return {
      message: errorMessage,
      valid: compareValue >= 0,
    };
  },
  // onlyLeaf: (value: ObjectField['value']) => ({
  //   message: 'Поле обязательно для заполнения',
  //   valid: !isNil(value) && value !== '' ? required(value) : false,
  // }),

  fileAcceptExtensions: (value: string, condition?: string[]) => ({
    message: 'File extensions not supported',
    valid: fileAcceptExtensions(value, condition),
  }),
  fileMaxSize: (value: number, condition?: number) => ({
    message: 'File is too big',
    valid: fileMaxSize(value, condition),
  }),
  fileNameMaxLength: (value: string, condition?: number) => ({
    message: 'File name more then characters',
    valid: fileNameMaxLength(value, condition),
  }),
  fileNotEmpty: async (value: File) => ({
    message: 'File is empty',
    valid: await fileNotEmpty(value),
  }),
};

export type TValidatorSchema = typeof validatorsSchema;
export type TValidatorKeys = keyof TValidatorSchema;
