import { Filter as FilterParam, FormField, ObjectField } from '../@types/api';

export const fieldNotEmpty = (field?: ObjectField) => {
  const fieldValue = field?.value;

  return !(
    fieldValue === undefined ||
    fieldValue === null ||
    (Array.isArray(fieldValue) &&
      fieldValue.every(
        (value) => value === undefined || value === null || value === '',
      )) ||
    fieldValue === ''
  );
};

export const convertToSearchPayload = (fields: Record<string, FormField>) => {
  const result = [] as FilterParam[];

  for (const [fieldName, field] of Object.entries(fields)) {
    const { value, extras } = field;

    if (!fieldNotEmpty({ value } as ObjectField)) {
      continue;
    }

    if (
      typeof extras?.format === 'string' &&
      [
        'checkbox',
        'booleanSwitcher',
        'togglerMoggler',
        'overdueSwitcher',
      ].includes(extras?.format)
    ) {
      result.push({
        fieldId: String(fieldName),
        operator: 'eq',
        value: Boolean(field.value),
      });
    } else if (extras?.format === 'currencyRange') {
      const amountFrom = (field.value as number[])?.[0];
      const amountTo = (field.value as number[])?.[1];

      if (amountFrom) {
        result.push({
          fieldId: String(fieldName),
          operator: 'gte',
          value: amountFrom,
        });
      }
      if (amountTo) {
        result.push({
          fieldId: String(fieldName),
          operator: 'lte',
          value: amountTo,
        });
      }
    } else if (extras?.format === 'dateRange') {
      const dateFrom = (field.value as string[])?.[0];
      const dateTo = (field.value as string[])?.[1];

      if (dateFrom) {
        result.push({
          fieldId: String(fieldName),
          operator: 'gte',
          value: dateFrom,
        });
      }
      if (dateTo) {
        result.push({
          fieldId: String(fieldName),
          operator: 'lte',
          value: dateTo,
        });
      }
    } else if (fieldNotEmpty({ value } as ObjectField)) {
      result.push({
        fieldId: String(fieldName),
        operator: 'in',
        value: Array.isArray(field.value) ? field.value : [field.value],
      });
    }
  }

  return result;
};
