import { describe, it, expect } from 'vitest';
import regexValidator from './regexValidator';

describe('regexValidator', () => {
  it('should return true for valid string matching the regex', () => {
    expect(regexValidator('test@example.com', '^\\S+@\\S+\\.\\S+$')).toBe(true);
  });

  it('should return false for invalid string not matching the regex', () => {
    expect(regexValidator('invalid-email', '^\\S+@\\S+\\.\\S+$')).toBe(false);
  });

  it('should return false for non-string value', () => {
    expect(regexValidator(12345, '^\\S+@\\S+\\.\\S+$')).toBe(false);
  });

  it('should return false for empty string', () => {
    expect(regexValidator('', '^\\S+@\\S+\\.\\S+$')).toBe(false);
  });

  it('should return true for string matching a different regex', () => {
    expect(regexValidator('123-456-7890', '^\\d{3}-\\d{3}-\\d{4}$')).toBe(true);
  });
});
