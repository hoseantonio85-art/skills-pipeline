import { MAX_FILE_NAME_LENGTH } from '../const';

const fileNameMaxLengthValidator = (
  fileName: string,
  maxLength = MAX_FILE_NAME_LENGTH,
) => fileName.length < maxLength;

export default fileNameMaxLengthValidator;
