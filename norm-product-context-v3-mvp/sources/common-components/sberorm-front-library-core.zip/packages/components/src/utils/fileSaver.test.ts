import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { fileSaver } from './fileSaver';

describe('fileSaver', () => {
    beforeEach(() => {
        document.body.innerHTML = '';

        vi.useFakeTimers(); // Включаем фейковые таймеры
    });

    afterEach(() => {
        vi.restoreAllMocks();
        vi.useRealTimers();
    });

    describe('saveAs', () => {
        it('should save a file with the specified name and MIME type', () => {
            const blob = new Blob(['Hello, world!'], { type: 'text/plain' });
            fileSaver.saveAs(blob, 'text/plain', 'test.txt');

            const link = document.querySelector('a');
            expect(link?.download).toBe('test.txt');
        });

        it('should save a file with the default name if no filename is provided', () => {
            const blob = new Blob(['Hello, world!'], { type: 'text/plain' });
            fileSaver.saveAs(blob, 'text/plain');

            const link = document.querySelector('a'); // Находим созданный элемент <a>
            expect(link?.download).toBe('download');
        });

        it('should save a file with the default MIME type if no type is provided', () => {
            const blob = new Blob(['Hello, world!']);
            fileSaver.saveAs(blob, '', 'test.txt');

            const link = document.querySelector('a');
            const normalizedHref = link?.href.replace(/\/$/, '');
            expect(normalizedHref).toContain('blob:');
        });

        it('should save a file from an array of BlobPart', () => {
            const blobParts = [new Blob(['Hello']), new Blob(['world!'])];
            fileSaver.saveAs(blobParts, 'text/plain', 'test.txt');

            const link = document.querySelector('a');
            expect(link?.download).toBe('test.txt');
        });

        it('should create and remove a link element', () => {
            const blob = new Blob(['Hello, world!'], { type: 'text/plain' });
            fileSaver.saveAs(blob, 'text/plain', 'test.txt');

            setTimeout(() => {
                const link = document.querySelector('a');
                expect(link).toBeNull();
            }, 10);
        });

        it('should set target="_blank" for Safari', () => {
            // Переопределяем свойство download как undefined (как в Safari)
            Object.defineProperty(HTMLAnchorElement.prototype, 'download', {
                get: () => undefined,
                configurable: true, // Позволяет переопределять свойство
            });

            vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(vi.fn());

            const blob = new Blob(['Hello, world!'], { type: 'text/plain' });
            fileSaver.saveAs(blob, 'text/plain', 'test.txt');

            const link = document.querySelector('a'); // Находим созданный элемент <a>
            expect(link?.getAttribute('target')).toBe('_blank');
        });
    });

    describe('saveFileInstanceAs', () => {
        it('should call saveAs with correct arguments', async () => {
            const mockFile = new File(['file content'], 'test.txt', { type: 'text/plain' });

            // Мокаем функцию saveAs
            const saveAsSpy = vi.spyOn(fileSaver, 'saveAs').mockImplementation(() => {});

            await fileSaver.saveFileInstanceAs(mockFile);

            expect(saveAsSpy).toHaveBeenCalledWith(expect.any(Blob), 'text/plain', 'test.txt');

            saveAsSpy.mockRestore();
        });

        it('should handle errors when reading a file', async () => {
            const mockFile = new File(['file content'], 'test.txt', { type: 'text/plain' });

            vi.spyOn(mockFile, 'arrayBuffer').mockRejectedValue(new Error('Failed to read file'));

            const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

            await expect(fileSaver.saveFileInstanceAs(mockFile)).rejects.toThrow('Failed to read file');

            expect(consoleErrorSpy).toHaveBeenCalledWith('Failed to save file:', expect.any(Error));
        });
    });

    describe('exportToCsv', () => {
        it('should generate correct CSV content and call saveAs', () => {
            // Мокаем saveAs
            const saveAsSpy = vi.spyOn(fileSaver, 'saveAs').mockImplementation(() => {});

            // Тестовые данные
            const data = [
                { values: ['Name', 'Age', 'City'] },
                { values: ['John', '30', 'New York'] },
                { values: ['Anna', '22', 'London'] },
            ];
            const fileName = 'test.csv';

            // Вызываем функцию
            fileSaver.exportToCsv(data, fileName);

            // Проверяем, что saveAs была вызвана с правильными аргументами
            expect(saveAsSpy).toHaveBeenCalledWith(
                ['\ufeff', 'Name;Age;City\nJohn;30;New York\nAnna;22;London'], // Ожидаемый CSV-контент
                'text/csv;charset=UTF-8', // MIME-тип
                'test.csv' // Имя файла
            );

            // Восстанавливаем оригинальную реализацию
            saveAsSpy.mockRestore();
        });

        it('should handle empty data', () => {
            // Мокаем saveAs
            const saveAsSpy = vi.spyOn(fileSaver, 'saveAs').mockImplementation(() => {});

            // Пустые данные
            const data: Array<{ values: string[] }> = [];
            const fileName = 'empty.csv';

            // Вызываем функцию
            fileSaver.exportToCsv(data, fileName);

            // Проверяем, что saveAs была вызвана с пустым CSV-контентом
            expect(saveAsSpy).toHaveBeenCalledWith(
                ['\ufeff', ''], // Пустой CSV-контент
                'text/csv;charset=UTF-8', // MIME-тип
                'empty.csv' // Имя файла
            );

            // Восстанавливаем оригинальную реализацию
            saveAsSpy.mockRestore();
        });

        it('should handle error in saveAs', () => {
            // Мокаем saveAs, чтобы она выбрасывала ошибку
            const saveAsSpy = vi.spyOn(fileSaver, 'saveAs').mockImplementation(() => {
                throw new Error('Failed to save file');
            })

            // Тестовые данные
            const data = [
                { values: ['Name', 'Age', 'City'] },
                { values: ['John', '30', 'New York'] },
            ];
            const fileName = 'test.csv';

            // Перехватываем ошибку
            const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

            // Вызываем функцию
            expect(() => fileSaver.exportToCsv(data, fileName)).toThrow('Failed to save file');

            // Проверяем, что ошибка была залогирована
            expect(consoleErrorSpy).toHaveBeenCalledWith('Failed to save file:', expect.any(Error));

            // Восстанавливаем оригинальную реализацию
            saveAsSpy.mockRestore();
            consoleErrorSpy.mockRestore();
        });
    });
});
