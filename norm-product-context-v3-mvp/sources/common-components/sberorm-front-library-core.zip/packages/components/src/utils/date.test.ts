import { describe, expect, it } from 'vitest';
import { formatDate } from './date';

const date = '2021-04-29T00:00:00';

describe('formatDate', () => {
  it('valid date', () => {
    expect(formatDate(date)).toEqual('29.04.2021');
  });

  it('format', () => {
    expect(formatDate(date, true, 'YYYY-MM-DD')).toEqual('2021-04-29');
    expect(formatDate(date, true, 'DD/MM/YYYY')).toEqual('29/04/2021');
  });

  it('not valid date', () => {
    expect(formatDate('string')).toEqual('Invalid Date');
  });

  it('not keepLocalTime', () => {
    expect(formatDate(date, false)).toEqual('28.04.2021');
    expect(formatDate(date, false, 'YYYY-MM-DD')).toEqual('2021-04-28');
  });
});
