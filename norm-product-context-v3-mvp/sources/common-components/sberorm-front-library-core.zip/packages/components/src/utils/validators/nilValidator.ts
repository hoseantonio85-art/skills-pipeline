import { ObjectField } from '../../@types/api';

const nilValidator = (value: ObjectField['value']) => value === null;

export default nilValidator;
