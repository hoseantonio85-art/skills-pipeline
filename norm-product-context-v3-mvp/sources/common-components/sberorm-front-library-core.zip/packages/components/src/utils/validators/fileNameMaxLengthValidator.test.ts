import { describe, it, expect } from 'vitest';
import { Attachment } from '../../@types/api';
import fileNameMaxLengthValidator from './fileNameMaxLengthValidator';

describe('fileAcceptExtensionsValidator', () => {
    const MAX_FILE_NAME_LENGTH = 100;

    it('should return true for a filename shorter than the maximum length', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(true);
    });

    it('should return false for a filename equal to the maximum length', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(MAX_FILE_NAME_LENGTH), // Exactly 100 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(false);
    });

    it('should return false for a filename longer than the maximum length', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(MAX_FILE_NAME_LENGTH + 1), // 101 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(false);
    });

    it('should work with a custom maximum length', () => {
        const customMaxLength = 50;
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(49), // 49 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename, customMaxLength);
        expect(result).toBe(true);
    });

    it('should return false for a filename exceeding the custom maximum length', () => {
        const customMaxLength = 50;
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(51), // 51 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename, customMaxLength);
        expect(result).toBe(false);
    });

    it('should return true for an empty filename', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: '', // Empty filename
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(true);
    });

    it('should return true for a filename with exactly one character', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a', // 1 character
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(true);
    });

    it('should return false for a filename with invalid length (negative logic)', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(MAX_FILE_NAME_LENGTH + 10), // 110 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(false);
    });

    it('should handle filenames with special characters correctly', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: '!@#$%^&*()_+'.repeat(8), // 96 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(true);
    });

    it('should handle filenames at the boundary of maximum length minus one character', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'a'.repeat(MAX_FILE_NAME_LENGTH - 1), // 99 characters
            size: 1024,
            extension: 'txt',
        };

        const result = fileNameMaxLengthValidator(fileInput.filename);
        expect(result).toBe(true);
    });
});