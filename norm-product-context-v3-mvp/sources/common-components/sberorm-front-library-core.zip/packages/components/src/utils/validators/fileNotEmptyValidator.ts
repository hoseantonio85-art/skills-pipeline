import { strFromU8, unzipSync } from 'fflate';

const fileNotEmptyValidator = async (file: File): Promise<boolean> => {
  if (file.size === 0) {
    return false;
  }

  const name = file.name.toLowerCase();

  // Текстовые файлы
  if (
    file.type.startsWith('text/') ||
    name.match(/\.(txt|json|csv|md|xml|js|ts|html|css|yaml)$/i)
  ) {
    const content = await file.text();
    return content.trim().length > 0;
  }

  // DOCX / XLSX / PPTX (Office Open XML formats)
  if (
    name.endsWith('.docx') ||
    name.endsWith('.xlsx') ||
    name.endsWith('.pptx')
  ) {
    try {
      const buffer = await file.arrayBuffer();
      const zip = unzipSync(new Uint8Array(buffer));

      // DOCX: проверяем word/document.xml
      if (name.endsWith('.docx')) {
        const docPath = Object.keys(zip).find(
          (p) =>
            p.toLowerCase() === 'word/document.xml' ||
            p.toLowerCase().endsWith('document.xml'),
        );

        if (!docPath || !zip[docPath]) {
          return false; // 👈 DOCX без document.xml = пустой/битый
        }

        const xml = strFromU8(zip[docPath]);
        const textContent =
          xml
            .match(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)
            ?.map((tag) => tag.replace(/<[^>]+>/g, '').trim())
            .join(' ') || '';

        return textContent.trim().length > 0;
      }

      // XLSX: проверяем наличие worksheets
      if (name.endsWith('.xlsx')) {
        // Можно добавить парсинг <v> или <t> тегов для проверки контента
        return Object.keys(zip).some((p) =>
          p.toLowerCase().match(/xl\/worksheets\/sheet\d+\.xml$/),
        );
      }

      // PPTX: проверяем наличие slides
      if (name.endsWith('.pptx')) {
        return Object.keys(zip).some((p) =>
          p.toLowerCase().match(/ppt\/slides\/slide\d+\.xml$/),
        );
      }

      return false; // Неизвестный тип Office-файла
    } catch (e) {
      console.warn('Failed to parse Office file:', e);
      return false;
    }
  }

  // PDF: проверяем минимальный размер и наличие сигнатуры
  if (name.endsWith('.pdf') || file.type === 'application/pdf') {
    if (file.size < 1024) {
      return false; // Слишком мал для валидного PDF
    }
    const header = await file.slice(0, 5).arrayBuffer();
    const sig = new TextDecoder().decode(new Uint8Array(header));

    return sig.startsWith('%PDF');
  }

  // Остальные бинарные файлы: размер > 0 = не пустой
  return true;
};

export default fileNotEmptyValidator;
