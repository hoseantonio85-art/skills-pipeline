import { describe, it, expect } from 'vitest';
import requiredValidator from './requiredValidator';

describe('requiredValidator', () => {
  it('should return true for non-empty string', () => {
    expect(requiredValidator('test')).toBe(true);
  });

  it('should return false for empty string', () => {
    expect(requiredValidator('')).toBe(false);
  });

  it('should return true for non-empty array', () => {
    expect(requiredValidator([1, 2, 3])).toBe(true);
  });

  it('should return false for empty array', () => {
    expect(requiredValidator([])).toBe(false);
  });

  it('should return true for non-undefined value', () => {
    expect(requiredValidator(42)).toBe(true);
  });

  it('should return false for undefined value', () => {
    expect(requiredValidator(undefined)).toBe(false);
  });
});
