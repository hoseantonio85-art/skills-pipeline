import { ObjectField } from '../../@types/api';

const maxExclusiveValidator = (value: ObjectField['value'], max: number) =>
  !Number.isNaN(value) && +value! < +max!;

export default maxExclusiveValidator;
