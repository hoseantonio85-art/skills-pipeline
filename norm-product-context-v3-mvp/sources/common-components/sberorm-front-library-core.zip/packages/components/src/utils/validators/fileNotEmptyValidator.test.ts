import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import fileNotEmptyValidator from './fileNotEmptyValidator';

// Мокаем fflate перед импортом функции
vi.mock('fflate', () => ({
  strFromU8: vi.fn(),
  unzipSync: vi.fn(),
}));

import { strFromU8, unzipSync } from 'fflate';

// Хелпер для создания мокового File
const createMockFile = (options: {
  name: string;
  size: number;
  type?: string;
  textContent?: string;
  arrayBuffer?: ArrayBuffer;
  slice?: (start: number, end: number) => Blob;
}): File => {
  const { name, size, type = '', textContent = '', arrayBuffer, slice } = options;

  return {
    name,
    size,
    type,
    lastModified: Date.now(),
    webkitRelativePath: '',
    text: vi.fn(async () => textContent),
    arrayBuffer: vi.fn(async () => arrayBuffer || new ArrayBuffer(0)),
    slice: vi.fn(slice || (() => new Blob())),
  } as unknown as File;
};

describe('fileNotEmptyValidator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ─────────────────────────────────────────────────────────────
  // Общие случаи: пустой файл
  // ─────────────────────────────────────────────────────────────
  describe('Empty file checks', () => {
    it('возвращает false для файла с размером 0', async () => {
      const file = createMockFile({ name: 'empty.txt', size: 0 });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // Текстовые файлы
  // ─────────────────────────────────────────────────────────────
  describe('Text files validation', () => {
    const textExtensions = ['txt', 'json', 'csv', 'md', 'xml', 'js', 'ts', 'html', 'css', 'yaml'];

    it.each(textExtensions)('проверяет содержимое файла .%s с текстом', async (ext) => {
      const file = createMockFile({
        name: `file.${ext}`,
        size: 100,
        type: 'text/plain',
        textContent: 'Hello, world!',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it.each(textExtensions)('возвращает false для файла .%s с пустым содержимым', async (ext) => {
      const file = createMockFile({
        name: `empty.${ext}`,
        size: 10,
        type: 'text/plain',
        textContent: '   \n\t  ',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    it('распознаёт текстовые файлы по MIME-типу text/*', async () => {
      const file = createMockFile({
        name: 'unknown.xyz',
        size: 50,
        type: 'text/x-custom',
        textContent: 'Some content',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('игнорирует регистр расширения при проверке', async () => {
      const file = createMockFile({
        name: 'FILE.JSON',
        size: 30,
        textContent: '{"key": "value"}',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // Office файлы (DOCX / XLSX / PPTX)
  // ─────────────────────────────────────────────────────────────
  describe('Office Open XML files validation', () => {

    // 📝 DOCX тесты (проверяем word/document.xml)

    it('возвращает true для валидного .docx с текстом в document.xml', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'word/document.xml': new Uint8Array(Buffer.from('<w:p><w:t>Sample text</w:t></w:p>')),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);
      vi.mocked(strFromU8).mockReturnValue('<w:p><w:t>Sample text</w:t></w:p>');

      const file = createMockFile({
        name: 'document.docx',
        size: 2048,
        arrayBuffer: new ArrayBuffer(2048),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
      expect(unzipSync).toHaveBeenCalled();
    });

    it('возвращает false для .docx с пустым document.xml', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'word/document.xml': new Uint8Array(),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);
      vi.mocked(strFromU8).mockReturnValue('<w:p><w:t>   </w:t></w:p>');

      const file = createMockFile({
        name: 'empty.docx',
        size: 1024,
        arrayBuffer: new ArrayBuffer(1024),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    // 📊 XLSX тесты (проверяем xl/worksheets/sheet*.xml)

    it('возвращает true для валидного .xlsx с worksheet', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'xl/worksheets/sheet1.xml': new Uint8Array(Buffer.from('<worksheet><sheetData><row><c><v>123</v></c></row></sheetData></worksheet>')),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);

      const file = createMockFile({
        name: 'spreadsheet.xlsx',
        size: 2048,
        arrayBuffer: new ArrayBuffer(2048),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает false для .xlsx без worksheets', async () => {
      const mockZip: Record<string, Uint8Array> = {
        '[Content_Types].xml': new Uint8Array(),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);

      const file = createMockFile({
        name: 'empty.xlsx',
        size: 1024,
        arrayBuffer: new ArrayBuffer(1024),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    // 🎞️ PPTX тесты (проверяем ppt/slides/slide*.xml)

    it('возвращает true для валидного .pptx со слайдом', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'ppt/slides/slide1.xml': new Uint8Array(Buffer.from('<p:sld><p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>Slide content</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>')),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);

      const file = createMockFile({
        name: 'presentation.pptx',
        size: 3000,
        arrayBuffer: new ArrayBuffer(3000),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает false для .pptx без слайдов', async () => {
      const mockZip: Record<string, Uint8Array> = {
        '[Content_Types].xml': new Uint8Array(),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);

      const file = createMockFile({
        name: 'empty.pptx',
        size: 1024,
        arrayBuffer: new ArrayBuffer(1024),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    // 🔄 Общие тесты

    it('обрабатывает DOCX с document.xml в любом регистре пути', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'WORD/DOCUMENT.XML': new Uint8Array(Buffer.from('<w:t>Content</w:t>')),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);
      vi.mocked(strFromU8).mockReturnValue('<w:t>Content</w:t>');

      const file = createMockFile({
        name: 'report.DOCX',
        size: 1500,
        arrayBuffer: new ArrayBuffer(1500),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает false при ошибке распаковки Office-файла', async () => {
      vi.mocked(unzipSync).mockImplementation(() => {
        throw new Error('Invalid ZIP');
      });

      const consoleWarnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

      const file = createMockFile({
        name: 'corrupted.docx',
        size: 500,
        arrayBuffer: new ArrayBuffer(500),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
      expect(consoleWarnSpy).toHaveBeenCalledWith(
        'Failed to parse Office file:',
        expect.any(Error),
      );
      consoleWarnSpy.mockRestore();
    });

    it('возвращает false если document.xml не найден в .docx', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'other/file.xml': new Uint8Array(),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);

      const file = createMockFile({
        name: 'nodec.docx',
        size: 1024,
        arrayBuffer: new ArrayBuffer(1024),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // PDF файлы
  // ─────────────────────────────────────────────────────────────
  describe('PDF files validation', () => {
    it('возвращает true для валидного PDF с корректной сигнатурой', async () => {
      const pdfBuffer = new ArrayBuffer(2048);
      const headerBuffer = new ArrayBuffer(5);
      new Uint8Array(headerBuffer).set([0x25, 0x50, 0x44, 0x46, 0x2d]); // %PDF-

      const file = createMockFile({
        name: 'document.pdf',
        size: 2048,
        type: 'application/pdf',
        arrayBuffer: pdfBuffer,
        slice: (start: number, end: number) => ({
          arrayBuffer: async () => (start === 0 && end === 5 ? headerBuffer : new ArrayBuffer(0)),
        } as Blob),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает false для файла с размером < 1024 байт', async () => {
      const file = createMockFile({
        name: 'tiny.pdf',
        size: 512,
        type: 'application/pdf',
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    it('возвращает false для файла без валидной сигнатуры %PDF', async () => {
      const headerBuffer = new ArrayBuffer(5);
      new Uint8Array(headerBuffer).set([0x00, 0x00, 0x00, 0x00, 0x00]);

      const file = createMockFile({
        name: 'fake.pdf',
        size: 2048,
        arrayBuffer: new ArrayBuffer(2048),
        slice: (start: number, end: number) => ({
          arrayBuffer: async () => (start === 0 && end === 5 ? headerBuffer : new ArrayBuffer(0)),
        } as Blob),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    it('распознаёт PDF по расширению, даже если MIME-тип не указан', async () => {
      const headerBuffer = new ArrayBuffer(5);
      new Uint8Array(headerBuffer).set([0x25, 0x50, 0x44, 0x46, 0x2d]);

      const file = createMockFile({
        name: 'file.pdf',
        size: 1500,
        type: '', // пустой MIME
        arrayBuffer: new ArrayBuffer(1500),
        slice: (start: number, end: number) => ({
          arrayBuffer: async () => (start === 0 && end === 5 ? headerBuffer : new ArrayBuffer(0)),
        } as Blob),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // Другие бинарные файлы
  // ─────────────────────────────────────────────────────────────
  describe('Other binary files', () => {
    it('возвращает true для любого файла с размером > 0, не попавшего в другие категории', async () => {
      const file = createMockFile({
        name: 'image.png',
        size: 1024,
        type: 'image/png',
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает true для архивов, исполняемых файлов и т.д.', async () => {
      const extensions = ['.zip', '.rar', '.exe', '.dmg', '.apk'];

      for (const ext of extensions) {
        const file = createMockFile({
          name: `file${ext}`,
          size: 500,
        });
        await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
      }
    });
  });

  // ─────────────────────────────────────────────────────────────
  // Edge cases и безопасность
  // ─────────────────────────────────────────────────────────────
  describe('Edge cases & security', () => {
    it('корректно обрабатывает файл с точкой в начале имени', async () => {
      const file = createMockFile({
        name: '.gitignore',
        size: 20,
        textContent: 'node_modules/',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('не падает при отсутствии textContent у текстового файла', async () => {
      const file = createMockFile({
        name: 'empty.txt',
        size: 0,
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });

    it('обрабатывает файл с очень длинным именем', async () => {
      const longName = 'a'.repeat(500) + '.txt';
      const file = createMockFile({
        name: longName,
        size: 10,
        textContent: 'test',
      });
      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
    });

    it('возвращает false если strFromU8 вернёт некорректные данные', async () => {
      const mockZip: Record<string, Uint8Array> = {
        'word/document.xml': new Uint8Array([0xff, 0xfe]),
      };

      vi.mocked(unzipSync).mockReturnValue(mockZip);
      vi.mocked(strFromU8).mockReturnValue(''); // пустая строка после декодирования

      const file = createMockFile({
        name: 'broken.docx',
        size: 1000,
        arrayBuffer: new ArrayBuffer(1000),
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(false);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // Производительность: проверка что не читаем весь файл для PDF
  // ─────────────────────────────────────────────────────────────
  describe('Performance considerations', () => {
    it('для PDF читает только первые 5 байт через slice', async () => {
      const sliceMock = vi.fn((_start: number, _end: number) => {
        const buffer = new ArrayBuffer(5);
        new Uint8Array(buffer).set([0x25, 0x50, 0x44, 0x46, 0x2d]);
        return {
          arrayBuffer: async () => buffer,
        } as Blob;
      });

      const file = createMockFile({
        name: 'large.pdf',
        size: 10_000_000, // 10MB
        arrayBuffer: new ArrayBuffer(10_000_000),
        slice: sliceMock,
      });

      await expect(fileNotEmptyValidator(file)).resolves.toBe(true);
      expect(sliceMock).toHaveBeenCalledWith(0, 5);
      // Важно: arrayBuffer всего файла не должен вызываться для проверки сигнатуры
    });
  });
});
