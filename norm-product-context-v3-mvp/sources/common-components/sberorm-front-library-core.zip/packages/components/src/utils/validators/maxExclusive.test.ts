import { describe, it, expect } from 'vitest';
import maxExclusiveValidator from './maxExclusiveValidator';

describe('maxExclusiveValidator', () => {
  it('should return true for value less than max', () => {
    expect(maxExclusiveValidator(5, 10)).toBe(true);
  });

  it('should return false for value equal to max', () => {
    expect(maxExclusiveValidator(10, 10)).toBe(false);
  });

  it('should return false for value greater than max', () => {
    expect(maxExclusiveValidator(15, 10)).toBe(false);
  });

  it('should return false for NaN value', () => {
    expect(maxExclusiveValidator(NaN, 10)).toBe(false);
  });

  it('should return false for undefined value', () => {
    expect(maxExclusiveValidator(undefined, 10)).toBe(false);
  });

  it('should return true for negative value less than max', () => {
    expect(maxExclusiveValidator(-5, 0)).toBe(true);
  });

  it('should return false for negative value equal to max', () => {
    expect(maxExclusiveValidator(0, 0)).toBe(false);
  });
});
