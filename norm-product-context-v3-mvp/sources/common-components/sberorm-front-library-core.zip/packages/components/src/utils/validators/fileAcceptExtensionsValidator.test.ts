import { describe, it, expect } from 'vitest';
import { Attachment } from '../../@types/api';
import fileAcceptExtensionsValidator from './fileAcceptExtensionsValidator';

describe('fileAcceptExtensionsValidator', () => {
    const ALLOWED_EXTENSIONS =  [
        '.xls',
        '.xlsx',
        '.csv',
        '.doc',
        '.docx',
        '.txt',
        '.rtf',
        '.png',
        '.jpeg',
        '.jpg',
        '.pdf',
        '.bmp',
        '.tif',
        '.rar',
        '.zip',
    ];

    it('should return true for a file with an allowed extension', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.xlsx',
            size: 1024,
            extension: 'xlsx',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(true);
    });

    it('should return false for a file with a forbidden extension', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.exe',
            size: 1024,
            extension: 'exe',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(false);
    });

    it('should ignore case for extensions (all uppercase)', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.XLSX',
            size: 1024,
            extension: 'XLSX',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(true);
    });

    it('should ignore case for extensions (mixed case)', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.PdF',
            size: 1024,
            extension: 'PdF',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(true);
    });

    it('should return false for a file without an extension', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example',
            size: 1024,
            extension: '',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(false);
    });

    it('should return false for a file with an empty name', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: '',
            size: 1024,
            extension: '',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(false);
    });

    it('should work with a custom list of allowed extensions', () => {
        const customAllowedExtensions = ['.jpg', '.png'];
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'image.jpg',
            size: 1024,
            extension: 'jpg',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, customAllowedExtensions);
        expect(result).toBe(true);
    });

    it('should return false for a file not matching the custom list of allowed extensions', () => {
        const customAllowedExtensions = ['.jpg', '.png'];
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'document.pdf',
            size: 1024,
            extension: 'pdf',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, customAllowedExtensions);
        expect(result).toBe(false);
    });

    it('should correctly handle filenames with multiple dots', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'my.file.name.xlsx',
            size: 1024,
            extension: 'xlsx',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(true);
    });

    it('should return false for a file with invalid characters after the extension', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.xlsx?',
            size: 1024,
            extension: 'xlsx?',
        };

        const result = fileAcceptExtensionsValidator(fileInput.filename, ALLOWED_EXTENSIONS);
        expect(result).toBe(false);
    });
});