import { MAX_FILE_SIZE } from '../const';

const fileMaxSizeValidator = (value: number, maxSize = MAX_FILE_SIZE) =>
  value >= 0 && value <= maxSize;

export default fileMaxSizeValidator;
