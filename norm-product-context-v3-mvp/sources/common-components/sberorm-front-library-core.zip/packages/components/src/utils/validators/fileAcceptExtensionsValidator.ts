import { ALLOWED_EXTENSIONS } from '../const';

const fileAcceptExtensionsValidator = (
  fileName: string,
  accepts = ALLOWED_EXTENSIONS,
) => {
  const allowedExtensionsReg = new RegExp(
    '(' + accepts.join('|').replace(/\./g, '\\.') + ')$',
    'i',
  );

  return allowedExtensionsReg.test(fileName);
};

export default fileAcceptExtensionsValidator;
