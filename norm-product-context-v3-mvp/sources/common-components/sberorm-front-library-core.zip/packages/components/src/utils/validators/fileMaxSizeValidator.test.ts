import { describe, it, expect } from 'vitest';
import { Attachment } from '../../@types/api';
import fileMaxSizeValidator from './fileMaxSizeValidator';

describe('fileMaxSizeValidator', () => {
    const MAX_FILE_SIZE = 10 * 1024 * 1024;

    it('should return true for a file smaller than the maximum size', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 5 * 1024 * 1024, // 5 MB
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(true);
    });

    it('should return true for a file equal to the maximum size', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: MAX_FILE_SIZE, // 10 MB
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(true);
    });

    it('should return false for a file larger than the maximum size', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 15 * 1024 * 1024, // 15 MB
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(false);
    });

    it('should work with a custom maximum size', () => {
        const customMaxSize = 5 * 1024 * 1024; // 5 MB
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 4 * 1024 * 1024, // 4 MB
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size, customMaxSize);
        expect(result).toBe(true);
    });

    it('should return false for a file exceeding the custom maximum size', () => {
        const customMaxSize = 5 * 1024 * 1024; // 5 MB
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 6 * 1024 * 1024, // 6 MB
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size, customMaxSize);
        expect(result).toBe(false);
    });

    it('should return true for a file with a size of 0 bytes', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 0, // 0 bytes
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(true);
    });

    it('should return false for a file with a negative size (if such a case is possible)', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: -1, // -1 byte
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(false);
    });

    it('should return false for a file exceeding the maximum safe integer value in JavaScript', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: Number.MAX_SAFE_INTEGER + 1, // Exceeding the maximum safe integer
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(false);
    });

    it('should correctly handle the boundary value of 1 byte', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: 1, // 1 byte
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(true);
    });

    it('should correctly handle the boundary value of maximum size minus 1 byte', () => {
        const fileInput: Attachment = {
            fileId: '123',
            filename: 'example.txt',
            size: MAX_FILE_SIZE - 1, // 10 MB - 1 byte
            extension: 'txt',
        };

        const result = fileMaxSizeValidator(fileInput.size);
        expect(result).toBe(true);
    });
});