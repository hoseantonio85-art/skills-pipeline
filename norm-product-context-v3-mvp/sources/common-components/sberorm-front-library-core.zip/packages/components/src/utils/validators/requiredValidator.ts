import { ObjectField } from '../../@types/api';

const requiredValidator = (value: ObjectField['value']) => {
  if (Array.isArray(value) || typeof value === 'string') {
    return value.length > 0;
  }

  return value !== undefined;
};

export default requiredValidator;
