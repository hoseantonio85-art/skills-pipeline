import { ObjectField } from '../../@types/api';

const regexValidator = (value: ObjectField['value'], regexp: string) =>
  typeof value === 'string' && new RegExp(regexp)!.test(value as string);

export default regexValidator;
