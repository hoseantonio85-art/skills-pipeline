import dayjs from 'dayjs';
import 'dayjs/locale/ru';
import duration from 'dayjs/plugin/duration';
import relativeTime from 'dayjs/plugin/relativeTime';
import utc from 'dayjs/plugin/utc';

const thresholds = [{ d: 'days', l: 'dd', r: 100_000 }];
const localeObject = {
  name: 'ru',
  relativeTime: {
    d: '1 день',
  },
};

dayjs.extend(duration);
dayjs.extend(relativeTime, { thresholds });
dayjs.extend(utc);

dayjs.locale('ru-settings', localeObject);

export const humanizeDays = (value: number) =>
  dayjs.duration({ days: value }).locale('ru').humanize();

export const formatDate = (
  date: string,
  keepLocalTime = true,
  format = 'DD.MM.YYYY',
): string => (date ? dayjs(date).utc(keepLocalTime).format(format) : date);
