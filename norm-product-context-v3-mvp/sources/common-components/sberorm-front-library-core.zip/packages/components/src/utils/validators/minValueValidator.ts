import { ObjectField } from '../../@types/api';

const minValueValidator = (value: ObjectField['value'], min: number) =>
  !Number.isNaN(value) && +value! >= +min!;

export default minValueValidator;
