/**
 * Сохраняет файл на стороне клиента.
 * @param blob Содержимое файла.
 * @param mime Тип файла (по умолчанию 'application/octet-stream').
 * @param fileName Имя файла (по умолчанию 'download').
 */
export const saveAs = (
  blob: BlobPart | BlobPart[],
  mime = '',
  fileName = 'download',
) => {
  const link = document.createElement('a');

  try {
    if (!blob || (Array.isArray(blob) && blob.length === 0)) {
      throw new Error('Blob is empty or invalid');
    }

    const blobInstance = new Blob(Array.isArray(blob) ? blob : [blob], {
      type: mime || 'application/octet-stream',
    });
    const url = URL.createObjectURL(blobInstance);

    link.href = url;
    link.download = fileName;

    // Fix for Safari
    if (typeof link.download === 'undefined') {
      link.setAttribute('target', '_blank');
    }

    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      if (document.body.contains(link)) {
        URL.revokeObjectURL(url);
        document.body.removeChild(link);
      }
    }, 0);
  } catch (error) {
    console.error('Error in saveAs:', error);
    throw error;
  }
};

/**
 * Сохраняет экземпляр файла на стороне клиента.
 * @param file Экземпляр объекта File.
 */
export const saveFileInstanceAs = async (file: File) => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const blob = new Blob([new Uint8Array(arrayBuffer)], { type: file.type });
    fileSaver.saveAs(blob, file.type, file.name);
  } catch (error) {
    console.error('Failed to save file:', error);
    throw error;
  }
};

/**
 * Экспортирует данные в CSV и сохраняет файл.
 * @param data Массив объектов с полем `values`.
 * @param fileName Имя файла.
 */
export const exportToCsv = (
  data: Array<{ values: string[] }>,
  fileName: string,
) => {
  try {
    const csvContent = data.map((row) => row.values.join(';')).join('\n');
    // Добавляем BOM для корректного отображения в Excel
    const csvBlob = ['\ufeff', csvContent];

    fileSaver.saveAs(csvBlob, 'text/csv;charset=UTF-8', fileName);
  } catch (error) {
    console.error('Failed to save file:', error);
    throw error;
  }
};

export const fileSaver = {
  saveAs,
  saveFileInstanceAs,
  exportToCsv,
};
