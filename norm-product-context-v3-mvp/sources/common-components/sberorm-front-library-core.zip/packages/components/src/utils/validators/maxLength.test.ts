import { describe, it, expect } from 'vitest';
import maxLengthValidator from './maxLengthValidator';

describe('maxLengthValidator', () => {
  it('should return true for a string with length less than max', () => {
    expect(maxLengthValidator('test', 5)).toBe(true);
  });

  it('should return true for a string with length equal to max', () => {
    expect(maxLengthValidator('test', 4)).toBe(true);
  });

  it('should return false for a string with length greater than max', () => {
    expect(maxLengthValidator('testing', 5)).toBe(false);
  });

  it('should return false for a non-string value', () => {
    expect(maxLengthValidator(123, 5)).toBe(false);
  });

  it('should return false for undefined value', () => {
    expect(maxLengthValidator(undefined, 5)).toBe(false);
  });
});
