import { describe, it, expect } from 'vitest';
import maxValueValidator from './maxValueValidator';

describe('maxValueValidator', () => {
  it('should return true for a value less than max', () => {
    expect(maxValueValidator(5, 10)).toBe(true);
  });

  it('should return false for a value equal to max', () => {
    expect(maxValueValidator(10, 10)).toBe(true);
  });

  it('should return false for a value greater than max', () => {
    expect(maxValueValidator(15, 10)).toBe(false);
  });

  it('should return false for NaN value', () => {
    expect(maxValueValidator(NaN, 10)).toBe(false);
  });

  it('should return false for undefined value', () => {
    expect(maxValueValidator(undefined, 10)).toBe(false);
  });

  it('should return true for a negative value less than max', () => {
    expect(maxValueValidator(-5, 10)).toBe(true);
  });

  it('should return false for a negative value greater than max', () => {
    expect(maxValueValidator(-15, -10)).toBe(true);
  });
});
