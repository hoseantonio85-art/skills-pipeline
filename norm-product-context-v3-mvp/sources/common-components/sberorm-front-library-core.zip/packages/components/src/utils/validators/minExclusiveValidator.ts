import { ObjectField } from '../../@types/api';

const minExclusiveValidator = (value: ObjectField['value'], min: number) =>
  !Number.isNaN(value) && +value! > +min!;

export default minExclusiveValidator;
