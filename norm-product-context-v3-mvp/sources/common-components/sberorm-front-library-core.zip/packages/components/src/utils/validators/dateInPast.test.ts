import { describe, it, expect } from 'vitest';
import dateInPastValidator from './dateInPastValidator';

describe('dateInPastValidator', () => {
  it('should return true for undefined value', () => {
    expect(dateInPastValidator(undefined)).toBe(true);
  });

  it('should return true for non-empty string', () => {
    expect(dateInPastValidator('string')).toBe(true);
  });

  it('should return true for a date string in the past', () => {
    expect(dateInPastValidator('2020-01-01')).toBe(true);
  });

  it('should return false for a date string in the future', () => {
    expect(dateInPastValidator(new Date(Date.now() + 10000).toISOString())).toBe(false);
  });

  it('should return true for an invalid date string', () => {
    expect(dateInPastValidator('invalid-date')).toBe(true);
  });

  it('should return true for an empty string', () => {
    expect(dateInPastValidator('')).toBe(true);
  });
});
