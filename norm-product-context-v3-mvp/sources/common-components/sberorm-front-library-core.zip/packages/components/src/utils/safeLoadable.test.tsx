import { render } from '@testing-library/react';
import React from 'react';
import { beforeEach, describe, expect, it, type Mock, vi } from 'vitest';
import { safeLoadable } from './safeLoadable';

// Моковый компонент для тестирования
const MockComponent = ({ someProp }: { someProp: string }) => (
  <div>MyComponent with prop: {someProp}</div>
);

// Моковая функция import
const mockImport = vi.fn(() =>
  Promise.resolve({ default: MockComponent }),
) as Mock<() => Promise<{ default: React.ComponentType<unknown> }>>;

describe('safeLoadable', () => {
  let MyComponent: typeof MockComponent;

  beforeEach(() => {
    mockImport.mockReset();
    // Создаем загружаемый компонент для тестов
    MyComponent = safeLoadable(mockImport, {
      fallback: <div>Loading...</div>,
      errorComponent: () => <div>Error loading component</div>,
    }) as typeof MockComponent;
  });

  it('should render the component when loaded successfully', async () => {
    const { container } = render(<MyComponent someProp='value' />);

    // Проверяем, что fallback отображается во время загрузки
    expect(container.textContent).toContain('Loading...');

    // Ждем, пока компонент загрузится
    await vi.waitFor(() => {
      expect(container.textContent).toContain('MyComponent with prop: value');
    });

    // Проверяем, что fallback исчез после загрузки
    expect(container.textContent).not.toContain('Loading...');
  });

  it('should render fallback while loading', async () => {
    // Задержка для симуляции загрузки
    const delayedImport = vi.fn(
      () =>
        new Promise((resolve) =>
          setTimeout(() => resolve({ default: MockComponent }), 100),
        ),
    ) as () => Promise<{ default: React.ComponentType<unknown> }>;
    const DelayedComponent = safeLoadable(() => delayedImport(), {
      fallback: <div>Loading...</div>,
    }) as typeof MockComponent;

    const { container } = render(<DelayedComponent someProp='value' />);

    // Проверяем, что fallback отображается
    expect(container.textContent).toContain('Loading...');

    // Ждем, пока компонент загрузится
    await vi.waitFor(() => {
      expect(container.textContent).toContain('MyComponent with prop: value');
    });

    // Проверяем, что fallback исчез после загрузки
    expect(container.textContent).not.toContain('Loading...');
  });

  it('should render error component if loading fails', async () => {
    // Симуляция ошибки загрузки
    const failingImport = vi.fn(() =>
      Promise.reject(new Error('Failed to load')),
    );
    const FailingComponent = safeLoadable(failingImport, {
      fallback: <div>Loading...</div>,
      errorComponent: () => <div>Error loading component</div>,
    }) as typeof MockComponent;

    const { container } = render(<FailingComponent someProp='value' />);

    // Проверяем, что fallback отображается во время загрузки
    expect(container.textContent).toContain('Loading...');

    // Ждем, пока отобразится компонент ошибки
    await vi.waitFor(() => {
      expect(container.textContent).toContain('Error loading component');
    });

    // Проверяем, что fallback исчез
    expect(container.textContent).not.toContain('Loading...');
  });

  it('should retry loading the specified number of times', async () => {
    // Симуляция ошибки загрузки
    const failingImport = vi.fn(() =>
      Promise.reject(new Error('Failed to load')),
    );
    const retryCount = 3;
    const RetryComponent = safeLoadable(failingImport, {
      fallback: <div>Loading...</div>,
      errorComponent: () => <div>Error loading component</div>,
      retryCount,
    }) as typeof MockComponent;

    render(<RetryComponent someProp='value' />);

    // Ждем, пока все попытки будут исчерпаны
    await vi.waitFor(() => {
      expect(failingImport).toHaveBeenCalledTimes(retryCount + 1); // +1 из-за первоначальной попытки
    });

    // Проверяем, что отобразился компонент ошибки
    const { container } = render(<RetryComponent someProp='value' />);
    expect(container.textContent).toContain('Error loading component');
  });

  it('should pass props to the loaded component', async () => {
    const { container } = render(<MyComponent someProp='test value' />);

    // Проверяем, что fallback отображается во время загрузки
    expect(container.textContent).toContain('Loading...');

    // Ждем, пока компонент загрузится
    await vi.waitFor(() => {
      expect(container.textContent).toContain(
        'MyComponent with prop: test value',
      );
    });

    // Проверяем, что fallback исчез после загрузки
    expect(container.textContent).not.toContain('Loading...');
  });

  it('should handle multiple instances of LoadableComponent', async () => {
    const loader1 = vi.fn(() =>
      Promise.resolve({ default: () => <div>Component 1</div> }),
    );
    const loader2 = vi.fn(() =>
      Promise.resolve({ default: () => <div>Component 2</div> }),
    );
    const LoadableComponent1 = safeLoadable(loader1, {
      fallback: <div>Loading...</div>,
    });
    const LoadableComponent2 = safeLoadable(loader2, {
      fallback: <div>Loading...</div>,
    });

    const { container } = render(
      <>
        <LoadableComponent1 />
        <LoadableComponent2 />
      </>,
    );

    // Проверяем, что fallback отображается для обоих компонентов
    expect(container.textContent).toContain('Loading...');

    // Ждем, пока оба компонента загрузятся
    await vi.waitFor(() => {
      expect(container.textContent).toContain('Component 1');
      expect(container.textContent).toContain('Component 2');
    });

    // Проверяем, что fallback исчез
    expect(container.textContent).not.toContain('Loading...');
  });
});
