import { describe, it, expect } from 'vitest';
import minValueValidator from './minValueValidator';

describe('minValueValidator', () => {
  it('should return true for value greater than min', () => {
    expect(minValueValidator(10, 5)).toBe(true);
  });

  it('should return true for value equal to min', () => {
    expect(minValueValidator(5, 5)).toBe(true);
  });

  it('should return false for value less than min', () => {
    expect(minValueValidator(3, 5)).toBe(false);
  });

  it('should return false for NaN value', () => {
    expect(minValueValidator(NaN, 5)).toBe(false);
  });

  it('should return false for undefined value', () => {
    expect(minValueValidator(undefined, 5)).toBe(false);
  });
});
