import React, { ComponentType, Suspense } from 'react';

type TLoaderCallback<TElement extends ComponentType<unknown>> = Promise<{
  /* Force a default module export type */
  default: TElement;
}>;

type TLoaderFunction<TElement extends ComponentType<unknown>> =
  () => TLoaderCallback<TElement>;

/**
 * Options for the lazy loaded component
 */
export interface ILoadableOptions {
  /* Fallback UI element to use when loading the component */
  fallback?: React.ReactNode;
  /* Error UI element to use when loading the component */
  errorComponent?: ComponentType<{}>;
  /* Retry times max */
  retryCount?: number;
}

// biome-ignore lint/suspicious/noExplicitAny: reason
export function safeLoadable<TElement extends ComponentType<any>>(
  importFunction: TLoaderFunction<TElement>,
  options: ILoadableOptions = {},
): ComponentType<React.ComponentPropsWithRef<TElement>> {
  const { errorComponent, fallback = null, retryCount = 3 } = options;

  // Функция для попытки импорта компонента
  const tryImport = async (retries: number): TLoaderCallback<TElement> => {
    try {
      return await importFunction();
    } catch (error) {
      if (retries > 0) {
        return tryImport(retries - 1);
      }
      throw error;
    }
  };

  // Lazy-компонента с обработкой ошибок
  const LazyComponent = React.lazy(() =>
    tryImport(retryCount).catch(() => ({
      default: (errorComponent as unknown as TElement) ?? (() => null),
    })),
  );

  const LoadableComponent = React.forwardRef<
    HTMLElement,
    React.ComponentPropsWithRef<TElement>
  >((props, ref) => (
    <Suspense fallback={fallback}>
      {React.createElement(
        LazyComponent as unknown as ComponentType<{}>,
        {
          ...props,
          ref,
        } as React.Attributes & { ref?: React.ForwardedRef<HTMLElement> },
      )}
    </Suspense>
  ));

  LoadableComponent.displayName = 'LoadableComponent';

  return LoadableComponent as ComponentType<
    React.ComponentPropsWithRef<TElement>
  >;
}
