import { describe, expect, it } from 'vitest';
import { fieldNotEmpty, convertToSearchPayload } from './field';

import { FormField, ObjectField } from '../@types/api';

describe('fieldNotEmpty', () => {
  it('should return true for non-empty string value', () => {
    const field: ObjectField = { value: 'test' };
    expect(fieldNotEmpty(field)).toBe(true);
  });

  it('should return true for numeric value', () => {
    const field: ObjectField = { value: 42 };
    expect(fieldNotEmpty(field)).toBe(true);
  });

  it('should return false for empty string', () => {
    const field: ObjectField = { value: '' };
    expect(fieldNotEmpty(field)).toBe(false);
  });

  it('should return false for undefined field', () => {
    expect(fieldNotEmpty(undefined)).toBe(false);
  });

  it('should return false for field with undefined value', () => {
    const field: ObjectField = {};
    expect(fieldNotEmpty(field)).toBe(false);
  });

  it('should return false for null value', () => {
    const field: ObjectField = { value: null };
    expect(fieldNotEmpty(field)).toBe(false);
  });

  it('should return true for non-empty array', () => {
    const field: ObjectField = { value: ['item1', 'item2'] };
    expect(fieldNotEmpty(field)).toBe(true);
  });

  it('should return false for array with all empty values', () => {
    const field: ObjectField = { value: ['', null] };
    expect(fieldNotEmpty(field)).toBe(false);
  });

  it('should return true for array with at least one non-empty value', () => {
    const field: ObjectField = { value: ['', 'valid', null] };
    expect(fieldNotEmpty(field)).toBe(true);
  });

  it('should return true for boolean false (valid non-empty value)', () => {
    const field: ObjectField = { value: false };
    expect(fieldNotEmpty(field)).toBe(true);
  });
});

describe('convertToSearchPayload', () => {
  it('should return empty array for all empty fields', () => {
    const fields: Record<string, FormField> = {
      emptyString: { value: '' },
      nullField: { value: null },
      undefinedField: {},
      emptyArray: { value: [] },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([]);
  });

  it('should convert simple string field to search payload', () => {
    const fields: Record<string, FormField> = {
      name: { value: 'John Doe' },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'name',
        operator: 'in',
        value: ['John Doe'],
      },
    ]);
  });

  it('should handle checkbox format correctly', () => {
    const fields: Record<string, FormField> = {
      isActive: { value: true, extras: { format: 'checkbox' } },
      isArchived: { value: false, extras: { format: 'checkbox' } },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'isActive',
        operator: 'eq',
        value: true,
      },
      {
        fieldId: 'isArchived',
        operator: 'eq',
        value: false,
      },
    ]);
  });

  it('should handle booleanSwitcher format correctly', () => {
    const fields: Record<string, FormField> = {
      isActive: { value: true, extras: { format: 'booleanSwitcher' } },
      isArchived: { value: false, extras: { format: 'booleanSwitcher' } },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'isActive',
        operator: 'eq',
        value: true,
      },
      {
        fieldId: 'isArchived',
        operator: 'eq',
        value: false,
      },
    ]);
  });

  it('should handle togglerMoggler format correctly', () => {
    const fields: Record<string, FormField> = {
      isActive: { value: true, extras: { format: 'togglerMoggler' } },
      isArchived: { value: false, extras: { format: 'togglerMoggler' } },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'isActive',
        operator: 'eq',
        value: true,
      },
      {
        fieldId: 'isArchived',
        operator: 'eq',
        value: false,
      },
    ]);
  });

  it('should handle overdueSwitcher format correctly', () => {
    const fields: Record<string, FormField> = {
      isActive: { value: true, extras: { format: 'overdueSwitcher' } },
      isArchived: { value: false, extras: { format: 'overdueSwitcher' } },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'isActive',
        operator: 'eq',
        value: true,
      },
      {
        fieldId: 'isArchived',
        operator: 'eq',
        value: false,
      },
    ]);
  });

  it('should convert currencyRange format to two conditions', () => {
    const fields: Record<string, FormField> = {
      amount: { 
        value: [1000, 5000], 
        extras: { format: 'currencyRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'amount',
        operator: 'gte',
        value: 1000,
      },
      {
        fieldId: 'amount',
        operator: 'lte',
        value: 5000,
      },
    ]);
  });

  it('should handle partial currencyRange values', () => {
    const fields: Record<string, FormField> = {
      amount: { 
        value: [1000], 
        extras: { format: 'currencyRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'amount',
        operator: 'gte',
        value: 1000,
      },
    ]);
  });

  it('should handle null currencyRange values', () => {
    const fields: Record<string, FormField> = {
      amount: { 
        value: [null, 1000], 
        extras: { format: 'currencyRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'amount',
        operator: 'lte',
        value: 1000,
      },
    ]);
  });

  it('should convert dateRange format to two conditions', () => {
    const fields: Record<string, FormField> = {
      dateRange: { 
        value: ['2024-01-01', '2024-12-31'], 
        extras: { format: 'dateRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'dateRange',
        operator: 'gte',
        value: '2024-01-01',
      },
      {
        fieldId: 'dateRange',
        operator: 'lte',
        value: '2024-12-31',
      },
    ]);
  });

  it('should handle partial dateRange values', () => {
    const fields: Record<string, FormField> = {
      dateRange: { 
        value: ['2024-01-01'], 
        extras: { format: 'dateRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'dateRange',
        operator: 'gte',
        value: '2024-01-01',
      },
    ]);
  });

  it('should handle empty dateRange values', () => {
    const fields: Record<string, FormField> = {
      dateRange: { 
        value: ['', '2024-12-31'], 
        extras: { format: 'dateRange' } 
      },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'dateRange',
        operator: 'lte',
        value: '2024-12-31',
      },
    ]);
  });

  it('should handle array values with "in" operator', () => {
    const fields: Record<string, FormField> = {
      categories: { value: ['cat1', 'cat2', 'cat3'] },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'categories',
        operator: 'in',
        value: ['cat1', 'cat2', 'cat3'],
      },
    ]);
  });

  it('should skip empty fields and include only valid ones', () => {
    const fields: Record<string, FormField> = {
      name: { value: 'John' },
      age: { value: null }, // Should be skipped
      email: { value: 'john@example.com' },
      empty: { value: '' }, // Should be skipped
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'name',
        operator: 'in',
        value: ['John'],
      },
      {
        fieldId: 'email',
        operator: 'in',
        value: ['john@example.com'],
      },
    ]);
  });

  it('should handle numeric values correctly', () => {
    const fields: Record<string, FormField> = {
      id: { value: 123 },
      price: { value: 99.99 },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'id',
        operator: 'in',
        value: [123],
      },
      {
        fieldId: 'price',
        operator: 'in',
        value: [99.99],
      },
    ]);
  });

  it('should process multiple fields with different formats', () => {
    const fields: Record<string, FormField> = {
      name: { value: 'John' },
      active: { value: true, extras: { format: 'checkbox' } },
      amount: { value: [100, 500], extras: { format: 'currencyRange' } },
      emptyField: { value: '' },
    };

    const result = convertToSearchPayload(fields);
    expect(result).toEqual([
      {
        fieldId: 'name',
        operator: 'in',
        value: ['John'],
      },
      {
        fieldId: 'active',
        operator: 'eq',
        value: true,
      },
      {
        fieldId: 'amount',
        operator: 'gte',
        value: 100,
      },
      {
        fieldId: 'amount',
        operator: 'lte',
        value: 500,
      },
    ]);
  });
});