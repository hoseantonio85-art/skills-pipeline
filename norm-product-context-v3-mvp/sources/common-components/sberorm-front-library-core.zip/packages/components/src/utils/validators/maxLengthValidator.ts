import { ObjectField } from '../../@types/api';

const maxLengthValidator = (value: ObjectField['value'], max: number) =>
  typeof value === 'string' && (value as string).length <= +max!;

export default maxLengthValidator;
