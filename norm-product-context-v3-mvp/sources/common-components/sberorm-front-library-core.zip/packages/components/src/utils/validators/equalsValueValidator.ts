import { ObjectField } from '../../@types/api';

const equalsValueValidator = (
  value: ObjectField['value'],
  equalValue: ObjectField['value'],
) => {
  if (value === undefined || equalValue === undefined) {
    if (value === undefined && equalValue !== undefined) {
      return -1;
    } else if (value === undefined && equalValue === undefined) {
      return 0;
    } else {
      return 1;
    }
  }

  if (typeof value === 'string' && typeof equalValue === 'string') {
    if (
      !Number.isNaN(Date.parse(value)) &&
      !Number.isNaN(Date.parse(equalValue))
    ) {
      return new Date(value).getTime() - new Date(equalValue).getTime();
    }

    if (value.length !== equalValue.length) {
      return value.length - equalValue.length;
    }

    return value.localeCompare(equalValue);
  }

  if (Array.isArray(value) && Array.isArray(equalValue)) {
    const valueSet1 = new Set(value);
    const valueSet2 = new Set(equalValue);

    if (valueSet1.size !== valueSet2.size) {
      return valueSet1.size - valueSet2.size;
    }

    for (const item of valueSet1) {
      valueSet1.delete(item);
      if (valueSet2.has(item)) {
        valueSet2.delete(item);
      }
    }

    return valueSet1.size - valueSet2.size;
  }

  return Number(value) - Number(equalValue);
};

export default equalsValueValidator;
