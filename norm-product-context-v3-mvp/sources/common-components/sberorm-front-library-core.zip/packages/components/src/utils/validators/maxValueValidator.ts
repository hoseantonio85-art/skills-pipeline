import { ObjectField } from '../../@types/api';

const maxValueValidator = (value: ObjectField['value'], max: number) =>
  !Number.isNaN(value) && +value! <= +max!;

export default maxValueValidator;
