import { describe, it, expect } from 'vitest';
import equalsValueValidator from './equalsValueValidator';

describe('equalsValueValidator', () => {
  it('should return 0 if both values are undefined', () => {
    const result = equalsValueValidator(undefined, undefined);
    expect(result).toBe(0);
  });

  it('should return -1 if first value is undefined and second is defined', () => {
    const result = equalsValueValidator(undefined, 'someValue');
    expect(result).toBe(-1);
  });

  it('should return 1 if first value is defined and second is undefined', () => {
    const result = equalsValueValidator('someValue', undefined);
    expect(result).toBe(1);
  });

  it('should compare strings by length if they have different lengths', () => {
    const result = equalsValueValidator('abc', 'abcd');
    expect(result).toBe(-1);
  });

  it('should compare strings lexicographically if they have same length', () => {
    const result = equalsValueValidator('abc', 'abd');
    expect(result).toBe(-1);
  });

  it('should compare dates if both values are valid date strings', () => {
    const result = equalsValueValidator('2023-01-01T00:00:00Z', '2023-01-02T00:00:00Z');
    expect(result).toBe(-86400000); // Difference in milliseconds between the two dates
  });

  it('should compare arrays by their sizes if they have different sizes', () => {
    const result = equalsValueValidator([1, 2], [1, 2, 3]);
    expect(result).toBe(-1);
  });

  it('should compare arrays by their unique elements if they have same size', () => {
    const result = equalsValueValidator([1, 2], [1, 3]);
    expect(result).toBe(-1); // Both sets have the same size after removing common elements
  });

  it('should compare numbers', () => {
    const result = equalsValueValidator(5, 10);
    expect(result).toBe(-5);
  });
});
