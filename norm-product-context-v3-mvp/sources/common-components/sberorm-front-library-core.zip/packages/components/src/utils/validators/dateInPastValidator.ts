import { ObjectField } from '../../@types/api';

const dateInPastValidator = (value: ObjectField['value']) => {
  if (value === undefined || typeof value !== 'string') {
    return true;
  }

  const currentDate = new Date(value as string).getTime();

  if (Number.isNaN(currentDate)) {
    return true;
  }

  return typeof value === 'string' && currentDate <= Date.now();
};

export default dateInPastValidator;
