import { describe, it, expect } from 'vitest';
import minExclusiveValidator from './minExclusiveValidator';

describe('minExclusiveValidator', () => {
  it('should return false for NaN value', () => {
    expect(minExclusiveValidator(NaN, 5)).toBe(false);
  });

  it('should return false for value equal to min', () => {
    expect(minExclusiveValidator(5, 5)).toBe(false);
  });

  it('should return true for value greater than min', () => {
    expect(minExclusiveValidator(6, 5)).toBe(true);
  });

  it('should return false for value less than min', () => {
    expect(minExclusiveValidator(4, 5)).toBe(false);
  });

  it('should return false for string representation of NaN', () => {
    expect(minExclusiveValidator('not a number', 5)).toBe(false);
  });

  it('should return true for string representation of a number greater than min', () => {
    expect(minExclusiveValidator('6', 5)).toBe(true);
  });

  it('should return false for string representation of a number equal to min', () => {
    expect(minExclusiveValidator('5', 5)).toBe(false);
  });

  it('should return false for string representation of a number less than min', () => {
    expect(minExclusiveValidator('4', 5)).toBe(false);
  });
});
