import { describe, it, expect } from 'vitest';
import nilValidator from './nilValidator';

describe('nilValidator', () => {
  it('should return false for undefined value', () => {
    expect(nilValidator(undefined)).toBe(false);
  });

  it('should return false for empty string', () => {
    expect(nilValidator('')).toBe(false);
  });

  it('should return false for non-null values', () => {
    expect(nilValidator(0)).toBe(false);
    expect(nilValidator(false)).toBe(false);
    expect(nilValidator('test')).toBe(false);
    expect(nilValidator([])).toBe(false);
  });
});
