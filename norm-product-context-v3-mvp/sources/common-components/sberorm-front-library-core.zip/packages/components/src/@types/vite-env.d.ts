/// <reference types="vite-plugin-svgr/client" />
/// <reference types="@sbol/clickstream-agent" />

declare module '*.scss' {
  const content: Record<string, string>;
  export default content;
}
