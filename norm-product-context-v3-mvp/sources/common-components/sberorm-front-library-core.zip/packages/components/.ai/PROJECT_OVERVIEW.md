# 📦 PROJECT_OVERVIEW: @sber-orm/components

## 📌 Основная информация

- **Название проекта:** `@sber-orm/components`
- **Тип проекта:** React UI Component Library (библиотека компонентов)
- **Версия:** 0.228.0
- **Описание:** Библиотека общих компонентов СберОРМ для сборки пользовательских интерфейсов
- **Репозиторий:** https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core.git

---

## 🛠️ Технологический стек

### Основные зависимости (Runtime)
```json
{
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "dayjs": "1.11.13",
  "i18next": "^23.11.5",
  "react-i18next": "^11.8.15"
}
```

### Зависимости для разработки
```json
{
  "typescript": "*",
  "vite": "^6.0.0-alpha.18",
  "tsup": "^8.0.2",
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "@types/react": "^18.3.3",
  "@types/react-dom": "^18.3.0",
  "@vitejs/plugin-react-swc": "^3.7.0",
  "esbuild-sass-plugin": "^3.2.0",
  "sass": "^1.77.8",
  "storybook": "^8.2.6",
  "@storybook/react": "^8.2.5",
  "@storybook/react-vite": "^8.2.4",
  "@storybook/addon-controls": "^8.2.5",
  "vitest": "^3.0.4",
  "@testing-library/react": "^16.2.0",
  "vite-plugin-svgr": "^4.2.0",
  "@svgr/plugin-jsx": "^8.1.0",
  "@svgr/plugin-svgo": "^8.1.0",
  "vite-plugin-checker": "0.12.0",
  "happy-dom": "^16.6.0",
  "biome": "2.3.11",
  "express": "5.0.0-beta.1",
  "cors": "2.8.5"
}
```

### Ключевые технологии
- **React 18.3.1** — основной UI-фреймворк
- **TypeScript** — строгая типизация
- **Vite 6.0.0-alpha.18** — сборщик и dev-сервер
- **Storybook 8.2.6** — инструмент для разработки компонентов
- **TSUP** — сборка ESM-пакетов
- **Sass/SCSS** — препроцессор стилей
- **Vitest** — unit-тестирование
- **Biome** — линтинг и форматирование кода

---

## 🚀 Инструкции по запуску

### Установка зависимостей
```bash
npm install
# или
yarn install
```

### Запуск Storybook (локальный dev-сервер)
```bash
npm run storybook
# или
npm start
```
**Порт:** 6006

### Сборка проекта
```bash
npm run build
```
Создает файлы в папке `dist/`:
- `dist/index.js` — основной ESM-пакет
- `dist/index.css` — CSS-стили
- `dist/components/` — индивидуальные компоненты

### Типизация
```bash
npm run build:types
# или отдельно:
npm run lint:ts
```

---

## 🔍 Тестирование

```bash
# Unit-тесты
npm run test

# UI-тесты (Storybook + E2E)
npm run test:ui
```

---

## 📁 Переменные окружения

В проекте отсутствует файл `.env.example`. Переменные окружения не используются.

---

## 📦 Экспорты

### Основной экспорт (`src/index.ts`)
```typescript
export * from './components';
export * from './utils';
```

### Доступные компоненты
- `Clickstream` — трекинг событий
- `ConfirmationModal` — модальное окно подтверждения
- `Drawer` — выдвижная панель
- `ErrorBoundary` — обработка ошибок рендеринга
- `Fields` — поля форм (Input, Number, Date, Currency, Tree, List и др.)
- `File` — компонент работы с файлами
- `ModalDialog` — модальное окно
- `ModalFactory` — фабрика модальных окон
- `ModalLayout` — макет модального окна
- `PortalDialog` — диалог через Portal
- `Search` — поиск
- `TitleBlock` — блок заголовка
- `UploadFileButton` — кнопка загрузки файла
- `ViewMessages` — отображение уведомлений
- `WorkflowActions` — действия по workflow

### Доступные утилиты
- `validators` — валидаторы полей (required, max, min, regex, dateInPast и др.)
- `date` — работа с датами
- `field` — конвертация полей для фильтрации
- `fileSaver` — сохранение файлов
- `safeLoadable` — ленивая загрузка компонентов с retry
- `const` — константы (MAX_FILE_SIZE, ALLOWED_EXTENSIONS и др.)

---

## 🎨 Стили и темы

Импорт стилей:
```scss
@import "@sber-orm/components/src/colors.module.scss";
@import "@sber-orm/components/style.css";
```

---

## 🛡️ Конфигурационные файлы

| Файл | Назначение |
|------|-----------|
| `vite.config.ts` | Конфигурация сборки (Vite) |
| `tsup.config.ts` | Конфигурация сборки ESM-пакетов |
| `tsconfig.json` | Настройки TypeScript |
| `biome.json` | Настройки линтинга (extends @sber-orm/biome-config) |
| `.lintstagedrc.json` | Хуки Git pre-commit |
| `.release-it.cjs` | Настройки автоматического релиза |
| `README.md` | Основная документация |

---

## 📝 Сценарии (scripts)

```json
{
  "build": "vite build && tsup && npm run build:types",
  "build:types": "mkdir -p types/dist && cp dist/index.d.ts types/dist",
  "clean": "rm -rf .turbo && rm -rf node_modules",
  "debug:release": "release-it --ci -VV --dry-run",
  "format": "biome format --write",
  "release": "release-it --ci -VV && npm run release:types",
  "release:types": "cd types && npm run release",
  "lint": "biome check --write .",
  "lint:ts": "tsc --noEmit",
  "start": "storybook dev -p 6006",
  "storybook": "storybook dev -p 6006",
  "storybook:build": "storybook build",
  "test": "vitest run && npm run test:ui",
  "test:ui": "npm run storybook:build && node utils/uiTest.js"
}
```

---

## 🏗️ Структура сборки

### Vite (для Storybook)
- Точка входа: `src/index.ts`
- Отдельные entry-points для каждого компонента
- Внешние зависимости: `react`, `react-dom`, `react/jsx-runtime`

### TSUP (для ESM-пакета)
- Entry: `src/index.ts`
- Output: `dist/index.js` + `dist/index.d.ts`
- Формат: ESM
- Поддержка SCSS через esbuild-sass-plugin

### Типизация
- Генерация `.d.ts` в `dist/`
- Копирование в `types/dist/` для публикации

---

## 🔗 Взаимодействие с API

Проект использует TypeScript-типы, сгенерированные из Swagger-спецификации:
```typescript
// Источник: https://github.com/acacode/swagger-typescript-api
import { FormComponent, FormField, FilterParam } from './@types/api';
```

Ключевые API-интерфейсы:
- `BaseResponse` — базовый ответ сервера
- `FormComponent` — компонент формы
- `FormField` — поле формы
- `FilterParam` — параметр фильтрации
- `WorkflowActionBody` — действие workflow
- `ObjectField` — объект поля данных

---

**Генерировано автоматически на основе анализа исходного кода.**
