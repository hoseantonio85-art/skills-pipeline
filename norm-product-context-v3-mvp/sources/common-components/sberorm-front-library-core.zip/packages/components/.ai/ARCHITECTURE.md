# 🏗️ ARCHITECTURE: @sber-orm/components

## 📂 Структура папок (дерево проекта)

```
src/
├── @types/                          # TypeScript-типы и декларации
│   ├── api.ts                       # Автогенерированные типы из Swagger API
│   └── vite-env.d.ts              # Декларации Vite (SVGR, SCSS)
│
├── components/                      # 📦 UI-компоненты (основная папка)
│   ├── Clickstream/                 # 📊 Система трекинга событий
│   │   ├── ClickStreamProvider.tsx  # Provider для контекста трекинга
│   │   ├── tracking/                # Утилиты трекинга
│   │   │   ├── types.ts             # Типы TPushData, TTrackingProfile, IOptions
│   │   │   ├── TrackingContext.ts   # React Context для данных трекинга
│   │   │   ├── dispatchTrackingEvent.ts
│   │   │   ├── useTracking.tsx      # Хук для подписки на события
│   │   │   ├── useTrackingImpl.tsx  # Реализация трекинга
│   │   │   └── utils.ts
│   │   ├── types.ts                 # Типы IClickStreamProviderProps
│     └── dispatchClickSreamEvent.ts
│   │
│   ├── ConfirmationModal/           # ✅ Модальное окно подтверждения
│   │   ├── ConfirmationModal.tsx    # Компонент модального окна
│   │   ├── types.ts                 # Типы IConfirmationModalProps
│   │   └── index.ts
│   │
│   ├── Drawer/                      # 📤 Выдвижная панель
│   │   ├── Drawer.tsx               # Компонент Drawer
│   │   └── index.ts
│   │
│   ├── ErrorBoundary/               # ⚠️ Обработка ошибок рендеринга
│   │   ├── classes/                 # Классы ошибок
│   │   │   ├── index.ts
│   │   │   ├── BadRequestError.ts
│   │   │   ├── PageNotFoundError.ts
│   │   │   └── RequestTimeoutError.ts
│   │   ├── components/              # Вспомогательные компоненты
│   │   │   ├── index.ts
│   │   │   └── ErrorPageWrap/       # Обертка для страницы ошибки
│   │   │       ├── ErrorPageWrap.tsx
│   │   │       └── index.ts
│   │   ├── ErrorBoundary.tsx        # Основной компонент ErrorBoundary
│   │   ├── ErrorBoundaryContext.ts  # Контекст ошибки
│   │   ├── ErrorComponent.tsx       # Компонент отображения ошибки
│   │   ├── ErrorBoundaryContext.ts
│   │   ├── utils.ts                 # Утилиты обработки ошибок
│   │   ├── types.ts                 # Типы TErrorCodeValues, IErrorInstanceType
│   │   └── index.ts
│   │
│   ├── Fields/                      # 📝 Поля форм (22 компонента)
│   │   ├── ArrayListField.tsx       # Массив текстовых полей
│   │   ├── BooleanSwitcher.tsx      # Переключатель булево (два значения)
│   │   ├── CheckboxField.tsx        # Чекбокс
│   │   ├── CurrencyField.tsx        # Поле валюты
│   │   ├── CurrencyRangeField.tsx   # Диапазон валюты
│   │   ├── DateField.tsx            # Поле даты
│   │   ├── DateRangeField.tsx       # Диапазон дат (старый)
│   │   ├── DeadlineStagesField.tsx  # Сроки выполнения
│   │   ├── index.ts                 # Экспорт и карта компонентов
│   │   ├── InputField.tsx           # Текстовое поле
│   │   ├── InputListField.tsx       # Список текстовых полей
│   │   ├── InputNumberField.tsx     # Числовое поле
│   │   ├── ListField.tsx            # Список (dropdown)
│   │   ├── MultiSwitcherField.tsx   # Мульти-переключатель
│   │   ├── MultiTreeField.tsx       # Мульти-дерево
│   │   ├── NewDateRangeField.tsx    # Диапазон дат (новый)
│   │   ├── SeverityField.tsx        # Уровень серьезности
│   │   ├── SeverityMultiSwitcherField.tsx # Мульти выбор серьезности
│   │   ├── SwitcherField.tsx        # Переключатель (true/false)
│   │   ├── TextareaField.tsx        # Многострочное текстовое поле
│   │   ├── ToggleField.tsx          # Тумблер
│   │   ├── TogglerMogglerField.tsx  # Сложный переключатель
│   │   ├── TreeField.tsx            # Дерево справочника
│   │   └── types.ts                 # Типы IEditFieldProps
│   │
│   ├── File/                        # 📁 Работа с файлами
│   │   ├── components/              # Дочерние компоненты
│   │   │   ├── index.ts
│   │   │   └── FileActions/         # Действия с файлом (удалить, скачать)
│   │   │   │   ├── FileActions.tsx
│   │   │   │   └── index.ts
│   │   │   └── FileIcon/            # Иконка файла по расширению
│   │   │       ├── FileIcon.tsx
│   │   │       ├── index.ts
│   │   │       └── utils.ts
│   │   ├── File.tsx                 # Основной компонент отображения файла
│   │   ├── const.ts                 # Константы (MAX_FILE_SIZE, ALLOWED_EXTENSIONS)
│   │   ├── types.ts                 # Типы IFileProperties
│   │   ├── utils.ts                 # Утилиты (конвертация байтов)
│   │   ├── validate.ts              # Класс FileValidation (валидация файлов)
│   │   └── index.ts
│   │
│   ├── ModalDialog/                 # 💬 Модальное окно (базовое)
│   │   ├── ModalDialog.tsx          # Базовый компонент модального окна
│   │   ├── types.ts                 # Типы IModalDialogProperties, EState
│   │   └── index.ts
│   │
│   ├── ModalFactory/                # 🏭 Фабрика модальных окон
│   │   ├── hooks/                   # Пользовательские хуки
│   │   │   ├── index.ts
│   │   │   ├── useModalFactoryManager.ts  # Управление созданием модальных окон
│   │   │   └── useModalQueue.ts           # Работа с очередью модальных окон
│   │   ├── ModalFactory.tsx         # Компонент фабрики
│   │   ├── provider/                # Provider контекста
│   │   │   └── index.tsx            # ModalProvider с useReducer
│   │   ├── types.ts                 # Типы IModalActionProps, IModalConfig
│   │   └── index.ts
│   │
│   ├── ModalLayout/                 # 📐 Макет модального окна
│   │   ├── ModalLayout.tsx          # Компонент с навигацией и чатом
│   │   └── index.ts
│   │
│   ├── PortalDialog/                # 🚪 Компонент Portal
│   │   ├── Portal.ts                # React Portal wrapper
│   │   ├── hooks.ts                 # usePortal hook
│   │   ├── types.ts                 # Типы IPortalProperties
│   │   └── index.ts
│   │
│   ├── Search/                      # 🔍 Компонент поиска
│   │   ├── Search.tsx               # Поле поиска с иконкой
│   │   ├── types.ts                 # Типы ISearchProps
│   │   └── index.ts
│   │
│   ├── TitleBlock/                  # 📌 Блок заголовка
│   │   ├── TitleBlock.tsx           # Заголовок с подзаголовком и help-сообщением
│   │   ├── types.ts                 # Типы TTitleBlockProperties
│   │   └── index.ts
│   │
│   ├── UploadFileButton/            # 📤 Кнопка загрузки файлов
│   │   ├── UploadFileButton.tsx     # Компонент загрузки файлов (множественная)
│   │   ├── types.ts                 # Типы IUploadButtonProperties
│   │   └── index.ts
│   │
│   ├── ViewMessages/                # 📢 Отображение уведомлений
│   │   ├── ViewMessages.tsx         # Компонент отображения уведомлений (Alert)
│   │   ├── types.ts                 # Типы IViewMessagesProps, INotification
│   │   └── index.ts
│   │
│   ├── WorkflowActions/             # 🔄 Действия по workflow
│   │   ├── components/              # Вспомогательные компоненты
│   │   │   ├── index.ts
│   │   │   ├── ContextActions/      # Контекстные действия (drop-down)
│   │   │   │   ├── ContextActions.tsx
│   │   │   │   ├── types.ts
│   │   │   │   └── index.ts
│   │   │   └── ModalAction/         # Действия с модальным окном
│   │   │       ├── index.ts
│   │   │       ├── modals/          # Встроенные модальные окна
│   │   │       │   ├── index.ts
│   │   │       │   ├── CommentModal/   # Модальное окно комментария
│   │   │       │   │   ├── CommentModal.tsx
│   │   │       │   │   └── index.ts
│   │   │       │   └── MessageModal/   # Модальное окно сообщения
│   │   │       │       ├── MessageModal.tsx
│   │   │       │       └── index.ts
│   │   ├── WorkflowActions.tsx      # Основной компонент действий
│   │   ├── types.ts                 # Типы IWorkflowActionsProps
│   │   └── index.ts
│   │
│   └── index.ts                     # Глобальный экспорт всех компонентов
│
├── i18n/                            # 🌐 Локализация (i18next)
│   ├── locales/                     # Файлы переводов
│   │   └── ru/                      # Русский язык
│   │       └── common.json          # Общие переводы
│   ├── config.ts                    # Конфигурация i18next (resourses, language)
│   ├── index.ts                     # Инициализация i18n
│   └── index.ts
│
├── utils/                           # 🛠️ Утилиты (без состояния)
│   ├── validators/                  # Валидаторы полей
│   │   ├── index.ts                 # Схема валидаторов
│   │   ├── dateInPastValidator.ts
│   │   ├── equalsValueValidator.ts
│   │   ├── fileAcceptExtensionsValidator.ts
│   │   ├── fileMaxSizeValidator.ts
│   │   ├── fileNameMaxLengthValidator.ts
│   │   ├── maxExclusiveValidator.ts
│   │   ├── maxLengthValidator.ts
│   │   ├── maxValueValidator.ts
│   │   ├── minExclusiveValidator.ts
│   │   ├── minValueValidator.ts
│   │   ├── nilValidator.ts
│   │   ├── regexValidator.ts
│   │   ├── requiredValidator.ts
│   │   └── *.test.ts                # Тесты всех валидаторов
│   ├── const.ts                     # Константы (MAX_FILE_SIZE, MAX_FILE_NAME_LENGTH, ALLOWED_EXTENSIONS)
│   ├── date.ts                      # Утилиты работы с датами
│   ├── date.test.ts                 # Тесты дат
│   ├── field.ts                     # Конвертация полей для API (convertToSearchPayload)
│   ├── field.test.ts                # Тесты полей
│   ├── fileSaver.ts                 # Сохранение файлов
│   ├── fileSaver.test.ts            # Тесты сохранения файлов
│   ├── index.ts                     # Экспорт утилит
│   ├── safeLoadable.tsx             # Ленивая загрузка компонентов с retry
│   ├── safeLoadable.test.tsx        # Тесты safeLoadable
│   └── index.ts
│
├── stories/                         # 📖 Storybook-истории (81 файл)
│   ├── *.stories.tsx                # Story для каждого компонента
│   └── utils.tsx                    # Вспомогательные утилиты для сторис
│
├── @types/                          # Типы (повтор для структуры)
│   ├── api.ts                       # Типы API (автогенерированные)
│   └── vite-env.d.ts              # Декларации Vite
│
└── index.ts                         # 📦 Осевой экспорт: components + utils
```

---

## 🎯 Распределение ролей

### 1. **Component Layer** (Компоненты)
Расположение: `src/components/`

Каждый компонент имеет свой каталог с:
- `index.ts` — экспорт компонента и подсоставляющих
- `*.tsx` — основной компонент
- `types.ts` — TypeScript-интерфейсы
- `styles.module.scss` — модульные стили (в каждом компоненте)

**Архитектура:** Компоненты не зависят друг от друга, используют `@sber-orm/ui-kit` как базу.

### 2. **Utility Layer** (Утилиты)
Расположение: `src/utils/`

Предоставляет чистые функции для:
- **Валидации** (`validators/`) — правила валидации полей (required, max, min, regex, dateInPast и др.)
- **Форматирования** (`field.ts`) — конвертация полей в payload для API
- **Работы с файлами** (`fileSaver.ts`) — сохранение и валидация файлов
- **Дат** (`date.ts`) — форматирование и обработка дат
- **Логирования** (`safeLoadable.tsx`) — ленивая загрузка с retry-логикой

### 3. **I18n Layer** (Локализация)
Расположение: `src/i18n/`

Использует `i18next` с `react-i18next`:
- `locales/ru/common.json` — переводы на русском
- `config.ts` — конфигурация ресурсов
- `index.ts` — инициализация экземпляра i18n

### 4. **API Types Layer** (Типы данных)
Расположение: `src/@types/api.ts`

Автогенерированные TypeScript-типы из Swagger-спецификации:
- `BaseResponse` — базовый ответ сервера
- `FormComponent`, `FormField` — компоненты и поля формы
- `WorkflowActionBody` — тело действия workflow
- `ObjectField`, `FilterParam` — объекты данных и фильтрации
- `EmployeeInfo`, `DictionaryItem` — справочники

### 5. **State Management Patterns** (Паттерны управления состоянием)

#### Context API
- `ClickStreamProvider` — контекст трекинга событий
- `TrackingContext` — передача данных трекинга по дереву
- `ModalProvider` — управление очередью модальных окон (useReducer)
- `ErrorBoundaryContext` — состояние ошибки

#### Хуки
- `useTracking()` — работа с трекингом
- `useModalManager()` — менеджер создания модальных окон
- `useModalQueue()` — работа с очередью
- `usePortal()` — управление Portal

---

## ⚙️ Конфигурация

### TypeScript (`tsconfig.json`)
```json
{
  "extends": "@sber-orm/tsconfig-config/tsconfig.base.json",
  "compilerOptions": {
    "rootDir": "./src",
    "outDir": "./dist/",
    "esModuleInterop": true,
    "jsx": "react-jsx"
  },
  "include": ["./src/**/*"],
  "exclude": ["dist", "build", "node_modules", "utils"]
}
```

### Vite (`vite.config.ts`)
**Назначение:** Сборка для Storybook и многоточечная сборка компонентов

**Ключевые настройки:**
- Точка входа: `src/index.ts`
- Индивидуальные entry-points для каждого компонента
- Внешние зависимости: `react`, `react-dom`, `react/jsx-runtime`
- Режимы: `development` (dev-сервер на порту 6006), `production`
- Оптимизация:
  - `vendor-react` — React и ReactDOM
  - `vendor-dayjs` — dayjs
  - `vendor-utils` — classnames
  - `vendor-other` — остальные node_modules
  - `shared-utils` — `src/utils/`
- TS-проверка через `vite-plugin-checker`

### TSUP (`tsup.config.ts`)
**Назначение:** Сборка ESM-пакета для публикации

```typescript
export default defineConfig({
  sourcemap: false,
  entry: ['src/index.ts'],
  dts: { resolve: true, only: true },
  tsconfig: './tsconfig.json',
  outDir: './dist',
  format: 'esm',
  esbuildPlugins: [sassPlugin()],
});
```

### Storybook (`.storybook/main.ts`)
```typescript
export default {
  stories: ['../src/stories/**/*.stories.@(js|jsx|mjs|ts|tsx)'],
  addons: ['@storybook/addon-controls'],
  framework: {
    name: '@storybook/react-vite',
    options: {
      builder: { viteConfigPath: './vite.config.ts' },
    },
  },
  typescript: {
    reactDocgen: true,
    reactDocgenTypescriptOptions: {
      shouldExtractLiteralValuesFromEnum: true,
      propFilter: (prop) => prop.parent ? !/node_modules/.test(prop.parent.fileName) : true,
    },
  },
  staticDirs: ['../static'],
};
```

### Biome (`biome.json`)
```json
{
  "root": false,
  "extends": ["@sber-orm/biome-config"]
}
```
Используется для линтинга и форматирования (ESLint/ Prettier замена).

---

## 🔄 Потоки данных

### 1. Отображение формы (Form Rendering)

```
API → Типы (@types/api) → Компоненты Fields → User
```

1. Сервер возвращает `FormComponent` с `fields: Record<string, FormField>`
2. `Fields/index.ts` выбирает правильный компонент по `fieldConfig.extras.format`
3. Компонент отображает поле с валидацией и обработкой изменений

### 2. Workflow Actions

```
WorkflowActions → ContextActions / ModalAction → onSubmit → API
```

1. `WorkflowActions` получает массив `actions: WorkflowAction[]`
2. При нажатии открывается `ModalAction` с формой ввода
3. `onSubmit` отправляет `WorkflowActionBody` на сервер

### 3. Модальные окна (Modal Flow)

```
Consumer → useModalManager → ModalProvider → ModalFactory → User
```

1. `createModal(component, props)` добавляет в очередь
2. `ModalProvider` использует `useReducer` для управления состоянием
3. `ModalFactory` рендерит текущее модальное окно через `Portal`

### 4. File Upload

```
UploadFileButton → FileValidation → API → User
```

1. `UploadFileButton` принимает массив `File`
2. `FileValidation` проверяет расширение, размер, длину имени
3. `onUpload` отправляет файл на сервер

### 5. Tracking Events

```
User Action → useTracking() → TrackingContext → dispatchTrackingEvent()
```

1. Компонент использует `@track()` или `useTracking()`
2. Данные собираются из контекста и передаются в `dispatch`
3. `dispatchTrackingEvent()` отправляет данные в clickstream-agent

---

## 🧩 Модульная структура

| Модуль | Назначение | Основные файлы |
|--------|-----------|---------------|
| `fields` | 22 компонента для отображения и редактирования полей | `Fields/*.tsx` |
| `modals` | Универсальные модальные окна и фабрика | `ModalDialog`, `ModalFactory` |
| `workflow` | Действия по бизнес-процессу | `WorkflowActions`, `ContextActions` |
| `file` | Работа с файлами (загрузка, отображение, валидация) | `File`, `UploadFileButton` |
| `tracking` | Система кликстрима | `ClickStreamProvider`, `useTracking` |
| `error` | Обработка и отображение ошибок | `ErrorBoundary`, `ErrorPageWrap` |
| `i18n` | Локализация | `i18n/config.ts`, `index.ts` |
| `utils` | Чистые функции для валидации и форматирования | `validators/`, `field.ts`, `date.ts` |

---

## 📦 Экспорты

### Глобальный (`src/index.ts`)
```typescript
export * from './components';
export * from './utils';
```

### Компоненты
```typescript
// Доступны по именам:
import { InputField, DateField, ModalDialog, ErrorBoundary } from '@sber-orm/components';
import { fields } from '@sber-orm/components'; // Карта компонентов
```

### Утилиты
```typescript
import { validatorsSchema, fieldNotEmpty, convertToSearchPayload } from '@sber-orm/components';
import { safeLoadable } from '@sber-orm/components';
```

---

## 🧪 Тестирование

**Инструменты:**
- `vitest` — unit-тесты
- `happy-dom` — окружение браузера
- Storybook + `utils/uiTest.js` — UI-тесты (построение Storybook + E2E)

**Тестовые файлы:**
- `src/utils/**/*.test.ts(x)` — тесты утилит
- `src/stories/*.stories.tsx` — storybook-истории
- `src/components/**/*test.ts(x)` — интеграционные тесты компонентов

---

**Генерировано автоматически на основе анализа исходного кода.**
