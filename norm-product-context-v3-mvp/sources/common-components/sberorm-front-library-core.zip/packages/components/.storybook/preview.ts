import '@sber-orm/ui-kit/index.css';
