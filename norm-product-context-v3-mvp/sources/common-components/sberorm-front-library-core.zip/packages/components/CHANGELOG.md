# Changelog

## 0.245.0 (2026-06-04)

* feat(types__components): released version v1.21.0 ([fd1137c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/fd1137c))

## 0.244.0 (2026-06-02)

* feat: [RSCLD-2042] Add icon ([98e67a5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/98e67a5))
* feat(types__components): released version v1.20.0 ([c78bdd3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c78bdd3))

## 0.243.0 (2026-06-01)

* Pull request #475: feat: [RSCLD-2224] Remove themes ([5fdc139](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5fdc139)), closes [#475](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/475)
* feat(types__components): released version v1.19.0 ([46b28f6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/46b28f6))

## 0.242.0 (2026-06-01)

* feat: [RSCLD-2224] Add prop ([7f37fe2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/7f37fe2))
* feat(types__components): released version v1.18.0 ([1c4adb9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1c4adb9))

## 0.241.0 (2026-05-29)

* feat(biome-config): released version v0.241.0 ([5238c0f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5238c0f))
* feat(types__components): released version v1.17.0 ([655bec8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/655bec8))
* Pull request #474: feat: [RSCLD-2224] Support change email to content ([5dad57e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5dad57e)), closes [#474](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/474)

## 0.240.0 (2026-05-20)

* feat(types__components): released version v1.16.0 ([9b4fd45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9b4fd45))

## 0.239.0 (2026-05-06)

* feat(types__components): released version v1.15.0 ([15ad467](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/15ad467))

## 0.238.0 (2026-04-22)

* feat(types__components): released version v1.14.0 ([bbe0bcd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bbe0bcd))

## 0.237.0 (2026-04-22)

* feat: [RSCLD-2144] Add fileNotEmptyValidator and new icon ([73365c3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/73365c3))
* feat(types__components): released version v1.13.0 ([f20852f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f20852f))

## 0.236.0 (2026-04-15)

* Pull request #469: Feature/GMRT-1292 Drawer title type ([4f53e64](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4f53e64)), closes [#469](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/469)
* feat(types__components): released version v1.12.0 ([7d3dae8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/7d3dae8))

## 0.235.0 (2026-04-14)

* feat(types__components): released version v1.11.0 ([985c087](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/985c087))

## 0.234.0 (2026-04-13)

* feat: [GMRT-131] Switch dataRange to multiselect ([1336949](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1336949))
* feat(types__components): released version v1.10.0 ([385ff84](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/385ff84))

## 0.233.0 (2026-04-07)

* Pull request #468: Feature/GMRT-1292 TogglerMogglerField ([518c70b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/518c70b)), closes [#468](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/468)
* feat(types__components): released version v1.9.0 ([d236fbf](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d236fbf))

## 0.232.0 (2026-04-06)

* feat(types__components): released version v1.8.0 ([642d049](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/642d049))

## 0.231.0 (2026-04-03)

* feat(types__components): released version v1.7.0 ([ae89242](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ae89242))

## 0.230.0 (2026-04-03)

* feat(types__components): released version v1.6.0 ([bb57347](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bb57347))

## 0.229.0 (2026-04-03)

* feat(types__components): released version v1.5.0 ([69f9a99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/69f9a99))

## 0.228.0 (2026-03-26)

* feat: [GMRT-131] Revert types build ([0d87f38](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0d87f38))
* feat(types__components): released version v1.4.0 ([bb91cc6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bb91cc6))

## 0.227.0 (2026-03-26)

* feat(types__components): released version v1.3.0 ([d78acbf](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d78acbf))

## 0.226.0 (2026-03-26)

* Pull request #462: Feature/GMRT-131/npm package type ([72d36de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/72d36de)), closes [#462](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/462)

## 0.225.0 (2026-03-25)

* feat: [GMRT-131] Add build types ([8c3020e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8c3020e))
* feat(types__components): released version v1.1.0 ([f6967c0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f6967c0))

## 0.224.0 (2026-03-25)

* feat: [GMRT-131] Add releasing components ([87d0b7b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/87d0b7b))

## 0.223.0 (2026-03-25)

* Pull request #461: feat: [GMRT-131] New npm package ([c962b19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c962b19)), closes [#461](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/461)

## 0.222.0 (2026-03-25)

## 0.221.0 (2026-03-23)

* feat(biome-config): released version v0.221.0 ([9a27f53](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9a27f53))
* Pull request #460: Feature/RSCLD-2027 inputNumber ([106d928](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/106d928)), closes [#460](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/460)

## 0.220.0 (2026-03-03)

* feat(biome-config): released version v0.220.0 ([dad3652](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/dad3652))
* Pull request #458: Feature/RSCLD-1699_SwitcherField ([353d7a0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/353d7a0)), closes [#458](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/458)

## 0.219.0 (2026-02-25)

## 0.218.0 (2026-02-25)

## 0.217.0 (2026-02-24)

* feat: [RSCLD-1815] Add ability to disable clickstream ([e3a209a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e3a209a))

## 0.216.0 (2026-02-24)

## 0.215.0 (2026-02-24)

* Pull request #450: feat: [RSCLD-1815] Fix UI tests ([355a0ff](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/355a0ff))
* Pull request #451: Feature/RSCLD-1834 convertToSearchPayload ([c979a83](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c979a83)), closes [#451](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/451)

## 0.214.0 (2026-02-19)

* Pull request #449: Feature/RSCLD-1815 useMarkdown ([53ef2ea](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/53ef2ea)), closes [#449](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/449)

## 0.213.0 (2026-02-17)

* feat(biome-config): released version v0.213.0 ([9c798d0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9c798d0))
* Pull request #445: feat: [GMRT-1163] Accordion styles ([b8834dc](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b8834dc)), closes [#445](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/445)

## 0.212.0 (2026-02-16)

## 0.211.0 (2026-02-16)

## 0.210.0 (2026-02-12)

## 0.209.0 (2026-02-11)

* Pull request #441: Feature/GMRT-1147 search MultiTreeField ([938a2ac](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/938a2ac)), closes [#441](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/441)

## 0.208.0 (2026-02-11)

* Pull request #440: Feature/GMRT-1147 search MultiTreeField ([f3f1b6c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f3f1b6c)), closes [#440](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/440)

## 0.207.0 (2026-02-10)

* feat(biome-config): released version v0.207.0 ([c637bf7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c637bf7))
* Pull request #439: feat: [RSCLD-1564] Add icon, support icons in multiSwitcher and switcher ([0880a5d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0880a5d)), closes [#439](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/439)

## 0.206.0 (2026-02-10)

* Pull request #438: Feature/GMRT-1147 search MultiTreeField ([b67fcfd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b67fcfd)), closes [#438](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/438)

## 0.205.0 (2026-02-10)

* feat: [RSCLD-1707] Fix close button in drawer ([5784bbd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5784bbd))

## 0.204.0 (2026-02-09)

## 0.203.0 (2026-02-09)

* Pull request #436: Feature/GMRT-1147 search MultiTreeField ([22afa6b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/22afa6b)), closes [#436](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/436)

## 0.202.0 (2026-02-05)

* Pull request #435: feat: [GMRT-1147] Fix search in MultiTreeField ([95d6b2a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/95d6b2a))

## 0.201.0 (2026-02-03)

* Pull request #433: feat: [GMRT-1123] Add a new textareaProps property for TextareaField component ([f4c5a33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f4c5a33)), closes [#433](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/433)

## 0.200.0 (2026-02-03)

* Pull request #432: Feature/RSCLD-1720 TextareaField ([8aaf2b9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8aaf2b9)), closes [#432](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/432)

## 0.199.0 (2026-02-02)

## 0.198.0 (2026-01-28)

## 0.197.0 (2026-01-26)

* Pull request #429: Feature/GMRT-1123 remove Loader ([b866466](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b866466)), closes [#429](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/429)

## 0.196.0 (2026-01-23)

* Pull request #428: feat: [GMRT-1123] Remove Loader from components package ([e1ac867](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e1ac867)), closes [#428](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/428)

## 0.195.0 (2026-01-19)

* Pull request #427: feat: [RSCLD-1619] Add new icon, example in storybook with Toggler ([95d1192](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/95d1192)), closes [#427](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/427)

## 0.194.0 (2026-01-16)

* Pull request #426: feat:[STELLAR-1712] Big uikit update ([ea7949e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ea7949e)), closes [#426](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/426)

## 0.193.0 (2026-01-12)

## 0.192.0 (2025-12-17)

* Pull request #424: Feature/GMRT-1083 add util to field ([22aeb1f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/22aeb1f)), closes [#424](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/424)

## 0.191.0 (2025-12-16)

* Pull request #423: Feature/GMRT-1083 add util to field ([adf3a10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/adf3a10)), closes [#423](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/423)

## 0.190.0 (2025-12-15)

* Pull request #422: feat: [GMRT-1083] Add convertToSearchPayload util and test ([fc18d8a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/fc18d8a)), closes [#422](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/422)

## 0.189.0 (2025-12-11)

* Pull request #420: feat: [STELLAR-1686] Minify bundle ([fe4b354](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/fe4b354)), closes [#420](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/420)

## 0.188.0 (2025-12-11)

## 0.187.0 (2025-12-10)

## 0.186.0 (2025-12-08)

## 0.185.0 (2025-12-01)

* Pull request #418: feat: [GMRT-1056] Add Modal factory for WorkflowActions component ([5495c23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5495c23)), closes [#418](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/418)

## 0.184.0 (2025-11-28)

* feat: [RSCLD-1423] Add class for drawer backdrop ([fe7aa17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/fe7aa17))

## 0.183.0 (2025-11-28)

* feat: [RSCLD-1423] Add class for drawer backdrop ([ad07b2b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ad07b2b))

## 0.182.0 (2025-11-12)

* feat: [RSCLD-1349] Change CurrencyField raw output ([c8cdfaa](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c8cdfaa))

## 0.181.0 (2025-10-29)

* Pull request #416: fix: [GMRT-1010] Fix dateInPast validator whrn invalid date ([97c40e8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/97c40e8))

## 0.180.0 (2025-10-29)

* feat: [RSCLD-1210] Fix build ([2ad384b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2ad384b))
* feat: [RSCLD-1210] FIx TogglerMoggler field ([a4f180a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a4f180a))

## 0.179.0 (2025-10-27)

## 0.178.0 (2025-10-27)

* Pull request #415: feat: [GMRT-951] Add hint tooltip to Switch component ([41329a2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/41329a2)), closes [#415](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/415)

## 0.177.0 (2025-10-24)

## 0.176.0 (2025-10-22)

## 0.175.0 (2025-10-22)

## 0.174.0 (2025-10-22)

* feat: [RSCLD-1261] Add TogglerMogglerField ([4a27d5c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4a27d5c))
* feat: [RSCLD-1261] Fix condition ([d138a8e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d138a8e))
* feat(biome-config): released version v0.174.0 ([e969174](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e969174))

## 0.173.0 (2025-10-22)

* feat: [RSCLD-1180] Fix drawer ([1522e3a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1522e3a))

## 0.172.0 (2025-10-21)

* feat: [RSCLD-1180] Fix drawer ([785cc20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/785cc20))

## 0.171.0 (2025-10-21)

## 0.170.0 (2025-10-21)

* feat: [RSCLD-1180] Rename prop ([4aa9fae](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4aa9fae))

## 0.169.0 (2025-10-20)

* Pull request #410: Feature/RSCLD-1180 SwitcherField ([4a5ab1f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4a5ab1f)), closes [#410](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/410)

## 0.168.0 (2025-10-17)

* Pull request #409: feat: [RSCLD-1163] Add refs to Drawer ([07bf82e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/07bf82e)), closes [#409](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/409)

## 0.167.0 (2025-10-16)

* Pull request #407: fix: [GMRT-972] Change readonly to disabled ([5b46c97](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5b46c97)), closes [#407](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/407)

## 0.166.0 (2025-10-15)

* feat: [RSCLD-1180] Add BooleanSwitcher and icon ([d89b7e8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d89b7e8))
* feat(biome-config): released version v0.166.0 ([a0b0cc5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a0b0cc5))

## 0.165.0 (2025-10-14)

## 0.164.0 (2025-10-13)

## 0.163.0 (2025-10-13)

## 0.162.0 (2025-10-10)

* feat(biome-config): released version v0.162.0 ([e5d2e44](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e5d2e44))
* Pull request #404: Feature/RSCLD-1192 ModalLayout ([21a6c07](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/21a6c07)), closes [#404](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/404)

## 0.161.0 (2025-10-08)

* Pull request #403: feat: [RSCLD-1069] Add readonly prop for all fields ([c45c666](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c45c666)), closes [#403](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/403)

## 0.160.0 (2025-10-08)

* Pull request #401: feat: [RSCLD-1182] Add tooltip for deadlineChanges component ([fce46f2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/fce46f2)), closes [#401](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/401)
* Pull request #402: feat: [GMRT-937] Add to handle error E004 ([16c2bdb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/16c2bdb)), closes [#402](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/402)

## 0.159.0 (2025-10-02)

## 0.158.0 (2025-10-01)

## 0.157.0 (2025-09-23)

## 0.156.0 (2025-09-18)

## 0.155.0 (2025-09-17)

## 0.154.0 (2025-09-17)

## 0.153.0 (2025-09-15)

## 0.152.0 (2025-09-12)

* Pull request #392: fix: [GMRT-803] Change set value to CurrencyField component ([78f99ab](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/78f99ab)), closes [#392](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/392)

## 0.151.0 (2025-09-12)

## 0.150.0 (2025-09-11)

* Pull request #391: Feature/RSCLD-983 deadline stages field ([a550167](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a550167)), closes [#391](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/391)

## 0.149.0 (2025-09-09)

* Pull request #390: feat: [GMRT-791] Add a helpText property to fields components ([c94067c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c94067c)), closes [#390](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/390)

## 0.148.0 (2025-09-09)

## 0.147.0 (2025-09-03)

## 0.146.0 (2025-09-03)

* Pull request #388: fix: [GMRT-764] Fix maxLength property to textarea by WorkflowActions component ([0d1b255](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0d1b255))

## 0.145.0 (2025-09-02)

## 0.144.0 (2025-08-26)

* Pull request #387: fix: [GMRT-510] Fix view label of comment to workflow ([87bee0d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/87bee0d))

## 0.143.0 (2025-08-25)

## 0.142.0 (2025-08-21)

## 0.141.0 (2025-08-20)

* Pull request #384: Feature/RSCLD-770 testId ([e0c4b48](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e0c4b48)), closes [#384](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/384)

## 0.140.0 (2025-08-19)

* Pull request #383: Feature/RSCLD-770 testId ([de54170](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/de54170)), closes [#383](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/383)

## 0.139.0 (2025-08-19)

## 0.138.0 (2025-08-18)

* Pull request #382: fix: [GMRT-701] Add endRequired property to DateRangePicker component ([d56771f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d56771f)), closes [#382](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/382)

## 0.137.0 (2025-08-18)

## 0.136.0 (2025-08-18)

## 0.135.0 (2025-08-18)

## 0.134.0 (2025-08-13)

## 0.133.0 (2025-08-12)

* Pull request #379: feat: [GMRT-672] Fix date field ([c44a0d5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c44a0d5))

## 0.132.0 (2025-08-12)

* feat: [RSCLD-770] Update biome packages ([21f82e1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/21f82e1))

## 0.131.0 (2025-08-08)

## 0.130.0 (2025-08-05)

## 0.129.0 (2025-08-01)

* Pull request #375: Feature/RSCLD-555 CurrencyRange ([88bc9fe](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/88bc9fe)), closes [#375](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/375)
* Pull request #376: Feature/RSCLD-789 WorkflowActions ([6ee1581](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6ee1581)), closes [#376](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/376)

## 0.128.0 (2025-07-24)

## 0.127.0 (2025-07-23)

* Pull request #374: Feature/RSCLD-739 RadioChips ([2776dfb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2776dfb)), closes [#374](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/374)

## 0.126.0 (2025-07-22)

## 0.125.0 (2025-07-21)

* feat: [RSCLD-725] Update API types ([56bbf4a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/56bbf4a))

## 0.124.0 (2025-07-21)

* feat: [RSCLD-725] Update API types ([1349c5e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1349c5e))

## 0.123.0 (2025-07-18)

* Pull request #373: Feature/RSCLD-725 InputListField ([12e5fe7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/12e5fe7)), closes [#373](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/373)

## 0.122.0 (2025-07-17)

* feat: [RSCLD-725] Add InputListField ([bdde4f8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/bdde4f8))
* feat: [RSCLD-725] Fix default value and remove addButtonText property ([e16ac03](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e16ac03))

## 0.121.0 (2025-07-17)

* feat: [RSCLD-725] Remove addButtonText prop from field ([0cb2acc](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0cb2acc))
* feat(biome-config): released version v0.121.0 ([932adbb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/932adbb))

## 0.120.0 (2025-07-17)

* feat(biome-config): released version v0.120.0 ([b5d82ac](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b5d82ac))
* Pull request #372: Feature/RSCLD-725 InputListField ([6772c36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6772c36)), closes [#372](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/372)

## 0.119.0 (2025-07-16)

## 0.118.0 (2025-07-15)

## 0.117.0 (2025-07-14)

* Pull request #369: Feature/RSCLD-590 DatePicker ([ab1ab96](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ab1ab96)), closes [#369](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/369)

## 0.116.0 (2025-07-07)

* Pull request #367: Feature/RSCLD-590 DatePicker ([1e7f42a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1e7f42a)), closes [#367](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/367)
* Pull request #368: feat: [RSCLD-601] Fix moneyInput, fix currencyField ([4243f01](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4243f01))

## 0.115.0 (2025-07-03)

## 0.114.0 (2025-07-02)

## 0.113.0 (2025-07-02)

## 0.112.0 (2025-06-30)

* feat: [RSCLD-583] Fix currency fields, change readonly to disabled ([1beb952](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1beb952))

## 0.111.0 (2025-06-26)

## 0.110.0 (2025-06-26)

* Pull request #365: feat: [GMRT-511] Add support markdown text on error page ([c6c0a10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c6c0a10)), closes [#365](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/365)

## 0.109.0 (2025-06-26)

* feat: [RSCLD-552] Fix Drawer width ([b0fbc73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b0fbc73))

## 0.108.0 (2025-06-24)

* feat: [RSCLD-552] Fix label in search ([409284c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/409284c))

## 0.107.0 (2025-06-23)

* feat: [RSCLD-552] Extends ErrorPageWrap props ([376ede3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/376ede3))

## 0.106.0 (2025-06-23)

## 0.105.0 (2025-06-23)

* Pull request #364: Feature/RSCLD-552 fields ([9b7325c](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9b7325c)), closes [#364](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/364)

## 0.104.0 (2025-06-23)

* feat: [RSCLD-552] Add forbidden screen ([d126c37](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d126c37))
* feat: [RSCLD-552] Fix tests ([55543de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/55543de))

## 0.103.0 (2025-06-20)

* feat: [RSCLD-568] Fix tooltip arrow ([73fbd08](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/73fbd08))

## 0.102.0 (2025-06-19)

* feat: [RSCLD-515] Fix fields ([b6cb1de](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b6cb1de))

## 0.101.0 (2025-06-19)

* feat: [RSCLD-515] Add transition to progressbar ([48d9c99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/48d9c99))

## 0.100.0 (2025-06-19)

## 0.99.0 (2025-06-18)

## 0.98.0 (2025-06-18)

## 0.97.0 (2025-06-18)

* feat: [RSCLD-535] Add nowrap prop to title ([2f19b01](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2f19b01))

## 0.96.0 (2025-06-17)

## 0.95.0 (2025-06-17)

## 0.94.0 (2025-06-11)

## 0.93.0 (2025-06-10)

## 0.92.0 (2025-06-10)

* feat: [ORMCORE-673] Change textarea test ([500aa28](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/500aa28))
* feat: [ORMCORE-673] Format drawer ([3050575](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/3050575))
* feat: [ORMCORE-673] Update test ([e159207](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e159207))
* feat: [RSCLD-493] Add search to ArrayListField ([35a74ab](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/35a74ab))
* feat: [RSCLD-493] Add search to ListField ([4f7097b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4f7097b))

## 0.91.0 (2025-06-10)

* Pull request #360: Feature/GMRT-360 changes confirm model ([8cfb7cb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8cfb7cb)), closes [#360](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/360)

## 0.90.0 (2025-06-09)

## 0.89.0 (2025-06-09)

## 0.88.0 (2025-06-06)

## 0.87.0 (2025-06-06)

* Pull request #356: feat: [GMRT-360] Add footer prefix node to confirm model ([372ca6d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/372ca6d))

## 0.86.0 (2025-06-05)

* feat: [RSCLD-486] Change scrollbar in Select component and Drawer ([5653059](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5653059))

## 0.85.0 (2025-06-02)

* feat: [RSCLD-446] Fix comment initial value ([19c5d1e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/19c5d1e))
* feat: [RSCLD-446] Up versions ([b9a9df0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b9a9df0))
* Pull request #354: Feature/RSCLD-446 comments ([206f892](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/206f892)), closes [#354](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/354)

## 0.82.0 (2025-05-30)

* Pull request #353: Feature/RSCLD-446_comments ([8daff73](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8daff73)), closes [#353](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/353)

## 0.81.0 (2025-05-30)

## 0.80.0 (2025-05-23)

## 0.79.0 (2025-05-22)

* Pull request #351: Feature/GMRT-68 scroll component ([6d37f0a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6d37f0a)), closes [#351](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/351)

## 0.78.0 (2025-05-14)

* Pull request #350: feat: [STELLAR-500] Extend TreeField, optionRenderLimit, maxWidth for droplist ([e7bf5ba](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e7bf5ba)), closes [#350](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/350)

## 0.77.0 (2025-05-14)

## 0.76.0 (2025-05-14)

## 0.75.0 (2025-04-29)

* Pull request #346: Feature/RSCLD-359_Notice ([f5f4445](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f5f4445)), closes [#346](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/346)
* feat: [RSCLD-203] Update styles ([4dc7a5e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4dc7a5e))
* feat: [RSCLD-203] Update styles ([a2147a7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a2147a7))

## 0.74.0 (2025-04-29)

* feat: [RSCLD-203] Update styles ([71670fd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/71670fd))
* feat: [RSCLD-359] Add Notice ([a139c4a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a139c4a))
* feat: [RSCLD-359] Fix build ([0cb8c5b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0cb8c5b))
* feat: [RSCLD-359] Fix screens ([8d6fbd2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8d6fbd2))
* feat: [RSCLD-359] Fix storybook config ([b31b5cb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b31b5cb))
* feat: [RSCLD-359] Fix styles ([873e26b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/873e26b))
* feat: [RSCLD-359] Fix styles ([19e6767](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/19e6767))
* feat: [RSCLD-359] Update screens ([3e43377](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/3e43377))
* feat: [RSCLD-359] Update screens ([a08aafc](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a08aafc))

## 0.73.0 (2025-04-29)

* feat: [RSCLD-203] Add checkbox field ([9559308](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9559308))

## 0.72.0 (2025-04-28)

## 0.71.0 (2025-04-28)

## 0.70.0 (2025-04-28)

## 0.69.0 (2025-04-25)

* Pull request #344: Feature/RSCLD-372/Replace markdown library ([485a507](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/485a507)), closes [#344](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/344)

## 0.68.0 (2025-04-23)

## 0.67.0 (2025-04-22)

* Pull request #341: Feature/RSCLD-361_TitleBlock ([2ddd5fd](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2ddd5fd)), closes [#341](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/341)
* Pull request #342: Feature/RSCLD-361_Buttons ([f44f87a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f44f87a)), closes [#342](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/342)

## 0.66.0 (2025-04-22)

* Pull request #340: fix: [GMRT-280] Fix clear value to search field ([e72525b](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e72525b))

## 0.65.0 (2025-04-21)

## 0.64.0 (2025-04-21)

## 0.63.0 (2025-04-21)

* feat: [RSCLD-344] Fix tooltip styles ([03b7ba0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/03b7ba0))

## 0.62.0 (2025-04-18)

* Pull request #334: Feature/ORMCORE-673 notification ([a26d9ec](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a26d9ec)), closes [#334](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/334)
* Pull request #337: Feature/STELLAR-339_buttons ([d40e709](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d40e709)), closes [#337](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/337)

## 0.61.0 (2025-04-17)

## 0.60.0 (2025-04-17)

* Pull request #336: feat: [RSCLD-344] Support tooltips in fields ([0b8e380](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b8e380)), closes [#336](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/336)

## 0.59.0 (2025-04-16)

* Pull request #331: Feature/STELLAR-14 ui kit select ([e446a82](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/e446a82)), closes [#331](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/331)

## 0.58.0 (2025-04-11)

## 0.57.0 (2025-04-11)

* Pull request #332: feat: [RSCLD-222] Popover, Tooltip ([c6aa509](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/c6aa509)), closes [#332](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/332)

## 0.56.0 (2025-04-09)

* Pull request #329: feat: [RSCLD-310] New components: badge, level ([528dff0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/528dff0)), closes [#329](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/329)

## 0.55.0 (2025-04-03)

* Pull request #325: Feature/GMRT-241 update validate a File ([87570c1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/87570c1)), closes [#325](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/325)

## 0.54.0 (2025-04-02)

* Pull request #319: Feature/RSCLD-192_Alert ([4865c5f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4865c5f)), closes [#319](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/319)

## 0.53.0 (2025-03-26)

## 0.52.0 (2025-03-26)

## 0.51.0 (2025-03-21)

## 0.50.0 (2025-03-21)

* Pull request #321: Feature/GMRT-181 file item component ([6566f0a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/6566f0a)), closes [#321](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/321)

## 0.49.0 (2025-03-18)

* feat(biome-config): released version v0.48.0 ([4aab190](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4aab190))
* Pull request #318: Feature/ORMCORE-673 radio button, switch ([4114d61](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4114d61)), closes [#318](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/318)
* Pull request #320: Feature/GMRT-181 file item component ([edab781](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/edab781)), closes [#320](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/320)

## 0.48.0 (2025-03-13)

* Pull request #315: feat: [GMRT-181] Add FileItem component ([5bd6556](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5bd6556)), closes [#315](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/315)

## 0.47.0 (2025-03-13)

## 0.46.0 (2025-03-11)

* Pull request #312: feat: [RSCLD-178] Add MD and SM search sizes ([4afc516](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4afc516)), closes [#312](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/312)

## 0.45.0 (2025-03-10)

## 0.44.0 (2025-03-10)

## 0.43.0 (2025-03-10)

* Pull request #309: Feature/RSCLD-177_Input ([1dc2f68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1dc2f68)), closes [#309](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/309)

## 0.42.0 (2025-03-06)

* Pull request #302: Feature/RSCLD-112_Button ([d0d4a66](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d0d4a66)), closes [#302](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/302)

## 0.41.0 (2025-03-03)

* Pull request #307: feat: [GMRT-177] Remove validation from tree fields ([efc2736](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/efc2736)), closes [#307](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/307)

## 0.40.0 (2025-03-03)

## 0.39.0 (2025-02-28)

* Pull request #304: fix: [GMRT-144] Fix validation inside the component ([68e3f45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/68e3f45))
* Pull request #305: feat: [RSCLD-130] Extends Error component ([5306b99](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/5306b99)), closes [#305](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/305)
* Pull request #306: Bugfix/RSCLD-131_Combobox ([8cbc5eb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/8cbc5eb)), closes [#306](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/306)
* feat: [RSCLD-130] Up versions ([1cfeffb](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1cfeffb))

## 0.34.0 (2025-02-28)

* Pull request #303: bugfix: [GMRT-143] Expand to item by open a tree field in edit form ([b248c4f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b248c4f)), closes [#303](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/303)

## 0.33.0 (2025-02-26)

* Pull request #301: feat: [RSCLD-102] Add validators ([3490a2f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/3490a2f)), closes [#301](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/301)

## 0.32.0 (2025-02-26)

* Pull request #299: feat: [RSCLD-44] Try enable ui test ([7e04b1a](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/7e04b1a)), closes [#299](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/299)
* Pull request #300: Feature/GMRT-76 new colors unknown ([4f26b2f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4f26b2f)), closes [#300](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/300)

## 0.31.0 (2025-02-24)

* Pull request #298: Feature/GMRT-76 classes property for component ([986cb68](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/986cb68)), closes [#298](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/298)

## 0.30.0 (2025-02-24)

* Pull request #297: feat: [RSCLD-111] Fix ErrorBoundary ([34fb533](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/34fb533))

## 0.29.0 (2025-02-24)

## 0.28.0 (2025-02-24)

* Pull request #295: feat: [RSCLD-111] Add 401 Error boundary ([9dae8b8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/9dae8b8)), closes [#295](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/295)

## 0.27.0 (2025-02-21)

* Pull request #294: feat: [RSCLD-55] Add raw to ToggleField ([2cf9d07](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/2cf9d07)), closes [#294](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/294)

## 0.26.0 (2025-02-21)

* Pull request #293: Feature/GMRT-76 export fields ([1d543f4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1d543f4)), closes [#293](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/293)

## 0.25.0 (2025-02-19)

* Pull request #292: Feature/RSCLD-88_popover ([b344047](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/b344047)), closes [#292](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/292)

## 0.24.0 (2025-02-19)

* feat: [RSCLD-40] Fix tree pathItems order ([08f8046](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/08f8046))

## 0.23.0 (2025-02-19)

* Pull request #290: Bugfix: [GMRT-57] Fix validate to tree components ([78e68f9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/78e68f9))

## 0.22.0 (2025-02-19)

* Pull request #291: feat: [RSLCD-40] Fix CurrencyRangeField ([1f74395](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/1f74395))

## 0.21.0 (2025-02-18)

* feat: [RSCLD-40] Fix CurrencyRangeField ([ea91bd4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/ea91bd4))

## 0.20.0 (2025-02-18)

* feat: [RSCLD-40] Fix view message react error ([321a3ec](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/321a3ec))

## 0.19.0 (2025-02-18)

* MultiTreeField.tsx edited online with Bitbucket ([d026f3f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d026f3f))
* TreeField.tsx edited online with Bitbucket ([3d4d4d0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/3d4d4d0))

## 0.18.0 (2025-02-18)

## 0.17.0 (2025-02-18)

* Pull request #289: Bugfix/GMRT-78 hook use markdown ([0b7143d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/0b7143d)), closes [#289](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/289)

## 0.16.0 (2025-02-18)

* Pull request #288: feat: [RLCLD-85] Fix tree pathItems ([44387d7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/44387d7))

## 0.15.0 (2025-02-18)

* Pull request #287: feat: [RSCLD-85] Fix types in safeLoadeble ([452a177](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/452a177))

## 0.14.0 (2025-02-18)

* Pull request #286: Feature/GMRT-78 hook use markdown ([74a7223](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/74a7223)), closes [#286](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/286)

## 0.13.0 (2025-02-17)

## 0.12.0 (2025-02-17)

* Pull request #284: Feature/GMRT-78 hook use markdown ([512da33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/512da33)), closes [#284](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/284)

## 0.11.0 (2025-02-14)

* feat: [RSCLD-24] Fix CurrencyRange field. remove null, use undefined ([f103a81](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/f103a81))

## 0.10.0 (2025-02-14)

* Pull request #283: Feature/RSCLD-81_colors ([a326985](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/a326985)), closes [#283](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/283)

## 0.9.0 (2025-02-13)

* Pull request #282: feat: [RSCLD-81] Fix trees ([694753d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/694753d))

## 0.8.0 (2025-02-13)

* Pull request #281: Feature/RSCLD-38_metrics ([813a06d](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/813a06d)), closes [#281](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/281)

## 0.7.0 (2025-02-13)

* Pull request #280: feat: [GMRT-118] Add notificationCallback property to ErrorBoundary ([4a2bdc3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/4a2bdc3)), closes [#280](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/280)

## 0.6.0 (2025-02-12)

* Pull request #277: Feature/SBRORMCLD-1209 set NotificationContainer to errorBoundary ([d97766e](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/d97766e)), closes [#277](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/issues/277)

## 0.5.0 (2025-02-11)

* feat: [SBRORMCLD-1209] Component ErrorBoundary set NotificationContainer ([cfc26ec](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commits/cfc26ec))

## 0.4.0 (2025-02-11)

## [0.3.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.3.1...@sber-orm/components-v0.3.2) (2025-02-11)

## [0.3.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.3.0...@sber-orm/components-v0.3.1) (2025-02-11)

## [0.3.0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.27...@sber-orm/components-v0.3.0) (2025-02-11)


### Features

* [SBRORMCLD-1195] Fix Tree field ([3c34d71](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/3c34d7121903005ac6619c9ee6c5f417c6579b96))

## [0.2.27](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.26...@sber-orm/components-v0.2.27) (2025-02-10)

## [0.2.26](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.25...@sber-orm/components-v0.2.26) (2025-02-07)

## [0.2.25](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.24...@sber-orm/components-v0.2.25) (2025-02-07)

## [0.2.24](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.23...@sber-orm/components-v0.2.24) (2025-02-07)

## [0.2.23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.22...@sber-orm/components-v0.2.23) (2025-02-07)

## [0.2.22](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.21...@sber-orm/components-v0.2.22) (2025-02-07)

## [0.2.21](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.20...@sber-orm/components-v0.2.21) (2025-02-07)

## [0.2.20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.19...@sber-orm/components-v0.2.20) (2025-02-06)

## [0.2.19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.18...@sber-orm/components-v0.2.19) (2025-02-06)

## [0.2.18](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.17...@sber-orm/components-v0.2.18) (2025-02-05)

## [0.2.17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.16...@sber-orm/components-v0.2.17) (2025-02-05)

## [0.2.16](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.15...@sber-orm/components-v0.2.16) (2025-02-04)

## [0.2.15](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.14...@sber-orm/components-v0.2.15) (2025-02-03)

## [0.2.14](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.13...@sber-orm/components-v0.2.14) (2025-02-03)

## [0.2.13](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.12...@sber-orm/components-v0.2.13) (2025-02-03)

## [0.2.12](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.11...@sber-orm/components-v0.2.12) (2025-01-31)

## [0.2.11](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.10...@sber-orm/components-v0.2.11) (2025-01-31)

## [0.2.10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.9...@sber-orm/components-v0.2.10) (2025-01-31)

## [0.2.9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.8...@sber-orm/components-v0.2.9) (2025-01-30)

## [0.2.8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.7...@sber-orm/components-v0.2.8) (2025-01-30)

## [0.2.7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.6...@sber-orm/components-v0.2.7) (2025-01-30)

## [0.2.6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.5...@sber-orm/components-v0.2.6) (2025-01-29)

## [0.2.5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.4...@sber-orm/components-v0.2.5) (2025-01-29)

## [0.2.4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.3...@sber-orm/components-v0.2.4) (2025-01-29)

## [0.2.3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.2...@sber-orm/components-v0.2.3) (2025-01-29)

## [0.2.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.1...@sber-orm/components-v0.2.2) (2025-01-29)

## [0.2.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.2.0...@sber-orm/components-v0.2.1) (2025-01-28)

## [0.2.0](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.45...@sber-orm/components-v0.2.0) (2025-01-24)


### Features

* **components:** released version v0.1.45 ([7baeb80](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/7baeb8078664183223869169599317cfdbf7fef0))

## [0.1.45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.45...@sber-orm/components-v0.1.45) (2025-01-23)

## [0.1.45](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.44...@sber-orm/components-v0.1.45) (2025-01-21)

## [0.1.44](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.43...@sber-orm/components-v0.1.44) (2025-01-17)

## [0.1.43](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.42...@sber-orm/components-v0.1.43) (2025-01-16)

## [0.1.42](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.41...@sber-orm/components-v0.1.42) (2025-01-15)

## [0.1.41](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.40...@sber-orm/components-v0.1.41) (2025-01-15)

## [0.1.40](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.39...@sber-orm/components-v0.1.40) (2025-01-15)

## [0.1.39](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.38...@sber-orm/components-v0.1.39) (2025-01-14)

## [0.1.38](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.37...@sber-orm/components-v0.1.38) (2025-01-14)

## [0.1.37](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.36...@sber-orm/components-v0.1.37) (2025-01-13)

## [0.1.36](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.35...@sber-orm/components-v0.1.36) (2025-01-13)

## [0.1.35](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.34...@sber-orm/components-v0.1.35) (2025-01-10)

## [0.1.34](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.33...@sber-orm/components-v0.1.34) (2024-12-20)

## [0.1.33](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.32...@sber-orm/components-v0.1.33) (2024-12-20)

## [0.1.32](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.31...@sber-orm/components-v0.1.32) (2024-12-20)

## [0.1.31](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.30...@sber-orm/components-v0.1.31) (2024-12-19)

## [0.1.30](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.29...@sber-orm/components-v0.1.30) (2024-12-18)

## [0.1.29](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.28...@sber-orm/components-v0.1.29) (2024-12-18)

## [0.1.28](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.27...@sber-orm/components-v0.1.28) (2024-12-17)

## [0.1.27](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.26...@sber-orm/components-v0.1.27) (2024-12-16)

## [0.1.26](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.25...@sber-orm/components-v0.1.26) (2024-12-16)

## [0.1.25](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.24...@sber-orm/components-v0.1.25) (2024-12-16)

## [0.1.24](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.23...@sber-orm/components-v0.1.24) (2024-12-13)

## [0.1.23](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.22...@sber-orm/components-v0.1.23) (2024-12-13)

## [0.1.22](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.21...@sber-orm/components-v0.1.22) (2024-12-13)

## [0.1.21](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.20...@sber-orm/components-v0.1.21) (2024-12-10)

## [0.1.20](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.19...@sber-orm/components-v0.1.20) (2024-12-09)

## [0.1.19](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.18...@sber-orm/components-v0.1.19) (2024-12-06)

## [0.1.18](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.17...@sber-orm/components-v0.1.18) (2024-12-05)

## [0.1.17](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.16...@sber-orm/components-v0.1.17) (2024-12-04)

## [0.1.16](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.15...@sber-orm/components-v0.1.16) (2024-12-04)

## [0.1.15](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.14...@sber-orm/components-v0.1.15) (2024-12-03)

## [0.1.14](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.13...@sber-orm/components-v0.1.14) (2024-12-03)

## [0.1.13](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.12...@sber-orm/components-v0.1.13) (2024-12-03)

## [0.1.12](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.11...@sber-orm/components-v0.1.12) (2024-12-03)

## [0.1.11](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.10...@sber-orm/components-v0.1.11) (2024-12-03)

## [0.1.10](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.9...@sber-orm/components-v0.1.10) (2024-12-02)

## [0.1.9](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.8...@sber-orm/components-v0.1.9) (2024-12-02)

## [0.1.8](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.7...@sber-orm/components-v0.1.8) (2024-12-02)

## [0.1.7](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.6...@sber-orm/components-v0.1.7) (2024-11-28)

## [0.1.6](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.5...@sber-orm/components-v0.1.6) (2024-11-28)

## [0.1.5](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.4...@sber-orm/components-v0.1.5) (2024-11-27)

## [0.1.4](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.3...@sber-orm/components-v0.1.4) (2024-11-27)

## [0.1.3](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.2...@sber-orm/components-v0.1.3) (2024-11-26)

## [0.1.2](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.1...@sber-orm/components-v0.1.2) (2024-11-25)

## [0.1.1](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/compare/@sber-orm/components-v0.1.0...@sber-orm/components-v0.1.1) (2024-11-20)

## 0.1.0 (2024-11-19)

### Features

- [ORMCORE-163] Add components/styles package ([19f149f](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/19f149f9a6215e6cc642c687f3a70c75ceec0e32))
- [ORMCORE-237] Add eslint, tsconfig, prettier packages ([fc41d54](https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core/commit/fc41d545f3e1e94e983ce196731ac578ef4d2d6c))
