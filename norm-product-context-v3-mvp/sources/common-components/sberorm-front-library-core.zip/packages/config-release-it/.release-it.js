import changelogConfig from './conventional-changelog';

const version = '${version}';
const packageName = process.env.npm_package_name;
const scope = packageName.split('/')[1];

module.exports = {
  plugins: {
    ...changelogConfig,
  },
  git: {
    push: true,
    tagName: `${packageName}-v${version}`,
    commitsPath: '.',
    commitMessage: `feat(${scope}): released version v${version}`,
    requireUpstream: false,
    requireCleanWorkingDir: false,
  },
  npm: {
    skipChecks: true,
    versionArgs: ['--workspaces false'],
  },
  hooks: {
    'before:git:release': 'git add --all',
  },
};
