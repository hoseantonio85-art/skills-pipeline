# @sber-orm/config-release-it

Общий конфиг для release-it.

## установка

`$ npm i -D @sber-orm/config-release-it`

## использование

`.release-it.js`

```js
module.exports = require("@sber-orm/config-release-it");
```
