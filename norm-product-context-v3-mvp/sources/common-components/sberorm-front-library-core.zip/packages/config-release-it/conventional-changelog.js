module.exports = {
  '@release-it/conventional-changelog': {
    path: '.',
    infile: 'CHANGELOG.md',
    preset: 'conventionalcommits',
    type: [
      { type: 'feat', section: 'Features' },
      { type: 'fix', section: 'Bug Fixes' },
    ],
    gitRawCommitsOpts: {
      path: '.',
    },
  },
};
