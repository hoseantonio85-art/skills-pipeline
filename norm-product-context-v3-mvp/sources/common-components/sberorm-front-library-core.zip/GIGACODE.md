# SberORM Front Library Core

## Project Overview

**SberORM Front Library Core** — это monorepo-проект на базе npm workspaces, содержащий компонентную библиотеку и набор конфигурационных пакетов для проектов на стеке React/TypeScript.

### Архитектура

Проект представляет собой систему из 7 пакетов, организованных в иерархическую структуру зависимостей:

```
packages/
├── biome-config          # Базовая конфигурация Biome (форматтер и линтер)
├── eslint-config         # Комплексная конфигурация ESLint (использует eslint-plugin)
├── eslint-plugin         # Кастомный ESLint плагин
├── prettier-config       # Конфигурация Prettier
├── typescript-config     # Общая конфигурация TypeScript
├── ui-kit                # Базовая UI-библиотека на Platform V
└── components            # Общие компоненты СберОРМ (зависит от ui-kit)
```

### Основные технологии

- **JavaScript/TypeScript** — основной язык разработки
- **React 18.3.1** — UI-фреймворк
- **Vite** + **SWC** — сборщик и транспайлер
- **Biome** — единый инструмент для форматирования и линтинга (заменил ESLint + Prettier)
- **Storybook 8.2.6** — документация и изолированная разработка компонентов
- **Vitest** — unit-тестирование
- **release-it** — автоматизация релизов
- **Jenkins** — CI/CD pipeline

### Стек зависимостей UI-библиотеки

- `@v-uik/*` — компоненты Platform V (кнопки, инпуты, модалки и т.д.)
- `i18next` + `react-i18next` — интернационализация
- `dayjs` — работа с датами
- `react-imask` — маскирование полей ввода
- `simplebar-react` — кастомный скроллбар

## Building and Running

### Установка зависимостей

```bash
npm run init        # Полная переустановка (clean + install)
npm i               # Обычная установка
```

### Сборка проекта

```bash
npm run build       # Сборка всех пакетов monorepo
npm run build:storybook  # Сборка Storybook для всех пакетов + сборка dist
```

### Запуск в режиме разработки

```bash
npm run dev         # Режим разработки для всех пакетов
npm run start       # Запуск Storybook на порту 6006 (в корне или в пакете)
```

### Линтинг и форматирование

```bash
npm run lint        # Линтинг всех пакетов
npm run format      # Форматирование кода через Biome
npm run lint:syncpack  # Проверка согласованности версий
npm run lint:syncpack:fix  # Исправление несоответствий
```

### Тестирование

```bash
npm run test        # Юнит-тесты всех пакетов
npm run test:ui     # UI-тестирование (Storybook + визуальные тесты)
```

### Релизы

```bash
npm run release              # Релиз корневого пакета
npm run release:workspaces   # Релиз всех пакетов monorepo
npm run publish-packages     # Полный цикл публикации
npm run publish-packages:preRelease  # Pre-release (rc-версии)
npm run debug:release        # Dry-run релиза
```

## Development Conventions

### Git Workflow

- **Commit messages** подчиняются conventional commits:
  - `feat` — новые функции
  - `fix` — исправления багов
  - `wip` — в работе
  - `merge` — слияния
  - `docs` — документация
  - `test` — тесты
  - `refactor` — рефакторинг
  - `build` — сборка
  - `chore` — технические задачи

- **Максимальная длина заголовка коммита**: 150 символов
- **Хуки Husky**:
  - `pre-commit`: lint-staged + проверка согласованности зависимостей
  - `commit-msg`: проверка формата commit message через commitlint
  - `pre-push`: запуск тестов

- **Release-it** настроен на:
  - Автоматическое создание тегов с именем `{packageName}-v{version}`
  - Публикация в npm (publish: false в корневом конфиге — возможно, для внутреннего использования)
  - Пуш с `--follow-tags --force`

### Code Style

- **Форматтер**: Biome (команда `biome format --write`)
- **Линтер**: Biome + ESLint с комплексной конфигурацией `@sber-orm/eslint-config`
- **Типизация**: TypeScript 5.2.2+ с общим tsconfigом `@sber-orm/tsconfig-config`
- **Файлы CSS/HTML/JSON**: форматируются Biome, но не линтятся

### Структура пакетов

Каждый пакет имеет:
- `package.json` с метаданными и зависимостями
- Скрипты: `build`, `lint`, `format`, `test`, `release`, `clean`
- Поддержку `--workspaces` в корневых скриптах
- Публикацию в public-доступ (`publishConfig.access: "public"`)

### CI/CD

**Jenkins Pipeline** (`Jenkinsfile`):
- Использует библиотеку `sberorm_ci@master`
- Функция `pipelineFrontLibDeploy()` для деплоя
- Поддержка архитектуры с сервисной папкой `.`

**Дополнительные Jenkinsfile**:
- `Jenkinsfile_argocd` — ArgoCD деплой
- `Jenkinsfile_mb` — возможно, microservices build
- `Jenkinsfile_storybook` — сборка и деплой Storybook

### SonarQube

Конфигурация в `sonar-project.properties`:
- Project Key: `sber-orm-core`
- Sources: `packages/components/src`
- Язык: JavaScript

## Именованные конфигурации

| Пакет | Назначение | Основные зависимости |
|-------|-----------|---------------------|
| `@sber-orm/biome-config` | Базовая конфигурация Biome | — |
| `@sber-orm/eslint-config` | ESLint конфиг | @typescript-eslint, eslint-plugin-* |
| `@sber-orm/eslint-plugin` | Кастомные правила ESLint | — |
| `@sber-orm/prettier-config` | Prettier настройки | — |
| `@sber-orm/tsconfig-config` | TypeScript настройки | typescript |
| `@sber-orm/ui-kit` | Базовая UI-библиотека | @v-uik/*, react |
| `@sber-orm/components` | Общие компоненты | @sber-orm/ui-kit |

## Типичные задачи

### Добавить новый компонент в ui-kit

```bash
# Создать файл в packages/ui-kit/src/
# Написать компонент с использованием @v-uik/* базы
npm run build        # Сборка
npm run test:ui      # Запуск UI-тестов
```

### Обновить зависимости

```bash
npm run lint:syncpack:fix  # Исправить несоответствия версий
npm install <package>@<version>  # Обновить конкретный пакет
```

### Запустить Storybook для конкретного пакета

```bash
cd packages/ui-kit && npm start
# или
cd packages/components && npm start
```

### Релиз конкретного пакета

```bash
cd packages/ui-kit && npm run release
cd packages/components && npm run release
```

## Важные замечания

1. **Node.js**: Требуется версия `>=18.16.1` (указано в peerDependencies)
2. **Релизы**: Используется `release-it` с кастомной конфигурацией
3. **Vite**: Используется alpha-версия (`^6.0.0-alpha.18`) — возможны breaking changes
4. **SWC**: Активно используется как замена Babel (`@swc/core`, `@vitejs/plugin-react-swc`)
5. **UI-тесты**: Используется комбинация Storybook + Puppeteer + pixelmatch для визуального регрессионного тестирования

## Ссылки

- **Git Repository**: `https://stash.sigma.sbrf.ru/scm/sberorm/sberorm-front-lib-core.git`
- **Автор**: Ivan Rubtsov (rubtsov.i.y@sberbank.ru)
- **License**: ISC / MIT (зависит от пакета)
