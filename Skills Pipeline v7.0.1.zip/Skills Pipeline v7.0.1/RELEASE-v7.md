# Изменения версии 7

Дата: 08.10.2026. Основа: исходный Skills Pipeline v4 + проверенное обновление NORM Visual Foundation 4.0.1. Версии 5/6 не использовались как основа: отдельный актуальный дистрибутив этих версий в задаче не выбран.

- Обновление встроено в build-visual-html-prototype и manifest loading.for_visual_html_prototype.
- Добавлены три слоя Foundation: Visual DNA, Composition DNA, reusable prototype components.
- Перед HTML обязателен внутренний composition preflight; default NORM и выбор другого контекста сохранены.
- Доступны Product Fidelity и Concept Exploration без изменения публичных pipeline artifacts.
- При доступном browser renderer обязателен visual QA; метрики C/P/U/F и95% goal разделены.
- Исправлены конфликт размещения статуса и YAML frontmatter третьего скилла.
- Starter основного context и fallback скилла синхронизированы.
- Package version7.0.0 и context version7 согласованы в manifest и context registries. Schema versions не менялись.
- Контекстный packaging script использует текущий Python interpreter и работает на Windows.

Проверки компонентов в исходном обновлении:22/22 geometry,25/25 scenario/adaptation,0 browser page errors. В релизе v7 код этих компонентов не изменён; браузерные результаты не объявляются новым GigaCode A/B. Контекст и skill проверяются заново при упаковке v7.
