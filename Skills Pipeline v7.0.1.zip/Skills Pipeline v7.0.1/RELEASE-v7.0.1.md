# Версия 7.0.1 — исправления по ревью

Основа: 7.0.0. Context version: 7. Manifest schema: 8. Публичные этапы и имена артефактов сохранены.

- Исправлен YAML frontmatter четырёх скиллов; смысл инструкций не изменён.
- Согласованы Visual DNA, runtime patterns и organisms: rail320, gap Event8/Risk16, палитра, выбор Object Modal/Drawer.
- Исправлены четыре reference ID, приоритет исторических HTML-примеров и неподтверждённый lifecycle current.
- Общий lifecycle modal/form/drawer: contained scope, Escape, focus, inert, scroll preservation, доступные заголовки.
- Исправлены Empty recovery, скрытый активный поиск, demo pressed state, тексты error/queued и доступное сообщение применённых фильтров.
- Уточнены границы исполняемых вариантов и engineering-only checklist пунктов. Добавлен foundation/starter-contract.md.
- Валидатор проверяет prototype routing, source IDs, starter assets/order, fallback parity, YAML duplicates и skill/agent headers.

Финальный browser QA: 25/25 сценарных/адаптивных проверок, 19/19 геометрических измерений выбранных зон, 0 JS errors. Семь дефектов воспроизведены на исходной 7.0.0. Quick validation: 6/6 skills; validator mutation checks: 6/6. Это не оценка product fidelity и не полный end-to-end запуск GigaCode.

Подробное ревью и screenshots поставляются отдельно в pipeline-v7-review, чтобы не загружать отчёты в runtime context. Предыдущий RELEASE-v7.md описывает исторический релиз 7.0.0.
