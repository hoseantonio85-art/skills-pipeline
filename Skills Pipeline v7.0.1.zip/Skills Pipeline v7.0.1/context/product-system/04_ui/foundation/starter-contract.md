# Starter: границы реализации и адаптация

`references/html/starter` — исполняемый пример Event/AI registry. Это не универсальный генератор всех сервисов. `data-scenario="event"` включает события; `ai` — историю запусков. Fixtures и подписи в prototype.js адаптируются по утверждённому UX Solution. Даты фиксированы для воспроизводимого сравнения, загрузка и анализ имитируются.

## Файлы

- styles.css: базовая структура и optional form primitives.
- norm-components.css: единственный слой продуктовых tokens и текущей геометрии; подключается после styles.css. Адаптация должна менять существующее правило, не накапливать overrides в конце файла.
- norm-components.js: экранирование текста, карточка event/AI, фильтрация, общий lifecycle поверхностей.
- prototype.js: сценарий, fixtures, связь контролов и данных.
- index.html: shell и слоты. Все пять файлов обязательны; fallback скилла должен совпадать побайтно.

## Поверхности

`Norm.open(html, trigger, {type:'object'})` — самостоятельный объект без общего Footer. `type:'form'` — короткая create/edit форма с Footer. `Norm.drawer(html, trigger, {scope:'container'})` — подчинённая задача; при наличии родителя перекрывает весь его shell, иначе открывается от viewport. Явный `scope:'viewport'` доступен по UX-решению. История и помощь — Drawer; связанный самостоятельный объект — Object Modal.

Один менеджер обслуживает focus trap, inert, Escape, scroll lock, возврат фокуса и восстановление родителя. Закрывается только верхний слой. Если trigger карточки заменён при render, фокус ищет ту же запись по data-id, затем основной CTA. Dialog получает доступное имя из h2. Контент без кнопок фокусирует сам dialog. Не добавлять отдельные document-level Escape handlers в сценарий.

## Состояние

Scope AND search AND advanced filters; быстрые статусы внутри группы связаны OR. Drawer редактирует draft: Reset очищает draft; Apply коммитит; Close/Escape отбрасывает. Непустой поиск остаётся раскрытым, пока запрос не очищен. Empty recovery очищает query и возвращает demo mode default; error retry сохраняет query. Demo controls доступны через `?demo=1`, их active/aria-pressed отражают состояние.

## Покрытие

Norm.card реализует Event/AI slots. Measure, Risk, knowledge и campaign описаны contracts, но требуют отдельной адаптации — наличие варианта в индексе не означает готовый widget. Источник документа в примере — representative destination, не PDF renderer. Полная доменная форма, dirty guard, серверная загрузка, permissions и точные icon/font assets реализуются по задаче. Не объявлять их готовыми возможностями starter.

Мобильное скрытие sidebar и breakpoints — гипотеза prototype. Если acceptance требует навигацию между сервисами на mobile, добавить доступный navigation entry; текущий пример проверяет одну рабочую поверхность.
