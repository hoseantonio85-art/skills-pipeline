# Composition contract: analytics / navigation / workflow

Применение определяется задачей. Risks attention summary — три meaningful zones после controls перед cards, каждая может вести к query. Width408 при total1240/gap8, radius24, pad24; first screen y176–294, list starts326. Нельзя переносить этот ряд в события автоматически.

AI history compact overview отвечает «какая доля завершена и что требует восстановления»: общие count + distribution bar + clickable errors. Scope подписан «Обзор всех запусков», не фильтрованная статистика. Набор и chart type — новая hypothesis, сохраняет visual roles; право на chart не ограничивается набором existing components.

Knowledge-primary: category/grid + contextual train-AI prompt; Knowledge-secondary: compact document list с filename/date/size/author, без event/risk metrics. Limit campaign: workflow main column872 + right stages rail, contextual AI explanation/limits; не превращать в обычный registry. Эти variants описывают relationships, а не неизменяемые страницы.

Обязательные связи: overview имеет смысловой вопрос, не KPI-декор; интерактивный segment согласован с result query; navigation cards ведут на real destination; workflow действия соответствуют текущему этапу. Variation: размер и тип visual по данным, новые секции разрешены с rationale. Ошибки: равные цветные KPI boxes вместо истории/графика, clipboard-like toast вместо destination, same card for files/categories/decisions.

Эталоны: risks-list #100_43420/#100_43444/#100_43456; limitnaya-kampaniya #185_70731/#185_70732; Assistant Knowledge-primary/secondary exports. Реализация overview — лёгкий prototype primitive; полноценные графики и workflow widgets подключать по новой задаче без bulk context.
