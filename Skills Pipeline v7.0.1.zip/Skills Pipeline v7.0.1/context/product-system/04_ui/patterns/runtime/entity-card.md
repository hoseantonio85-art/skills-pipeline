# Entity Card — runtime pattern

## Intent

Сканируемый preview сущности в registry. Это shell, а не универсальная схема полей.

## Shared shell

```txt
EntityCard
├─ status/meta row
├─ title / identity
├─ key metrics / attributes
├─ optional divider
└─ secondary description / ownership / related info
```

## Geometry

NORM evidence:

- radius `16px`;
- padding около `24px`;
- neutral 1px border / inset border;
- hover — мягкая elevation/background change;
- карточка целиком может быть clickable, если внутри нет конфликтующих independent actions.

## Rules

- Не пытаться уравнять Risk, Measure и Event card по внутренним колонкам.
- Сохранять общий shell, hierarchy и density; service profile определяет content slots.
- Самый важный смысл — в верхней половине карточки.
- Technical ID вторичен.
- Не превращать карточку в мини-детальную страницу.

## Service profile examples

- Risk: risk level/status → title → losses/strategy → related recommendations/measures → owner path.
- Measure: status/date → title → planned/actual dates and feature → ID/description/responsible unit.
- Event: использовать отдельный profile по screenshots/repo evidence; не копировать Risk fields.


## Measured Foundation refinement (4.0.1)
For NORM stage 03, read product-system/04_ui/foundation/composition-index.json (path relative to provider context root) and the selected contract. Exact comparable geometry/color roles come from foundation/visual-dna.md and source-policy.md; approximate MVP numbers above remain fallback only. Event export uses 8px card gap; Risk uses 16px. A status row above title is valid; a compulsory status-leading column is not.
