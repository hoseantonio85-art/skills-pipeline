# Skills Pipeline v7 — installation layout

The distribution has only three top-level directories:

```text
skills/   # copy skill folders individually into GigaCode skills
agents/   # copy agent markdown files into GigaCode agents
context/  # keep as one folder and register its absolute path as the NORM provider root
```

No skill or agent is allowed to depend on loose files at the distribution root.
