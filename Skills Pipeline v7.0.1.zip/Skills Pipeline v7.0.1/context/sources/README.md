# Evidence sources

Эта директория содержит только те source/evidence материалы, которые реально нужны рабочему pipeline, но не входят в automatic context payload.

- `ui-kit/` — exact package `@sber-orm/ui-kit` для проверки exports/types и standalone engineering;
- `frontend-rules/` — нормативные frontend rules для stages 05–07;
- `analytical-specs/` — domain/capability specifications, выбираемые через `analytical-specs/index.yaml`.

Правило: сначала использовать нормализованный `product-system/`; evidence читать только по конкретной причине. Analytical specs нельзя bulk-load: сначала выбрать 1–3 релевантных capability sources.

Исторические source archives, которые не участвуют в runtime или текущей проверке, в Skills Pipeline v7 не пакетируются.
