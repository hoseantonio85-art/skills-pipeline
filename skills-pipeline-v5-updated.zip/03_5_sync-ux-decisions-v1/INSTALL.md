# Install: sync-ux-decisions

Скопируйте каталог `skill/sync-ux-decisions` в `.gigacode/skills/` проекта или в пользовательский каталог skills GigaCode. После установки/обновления выполните `/clear`, чтобы GigaCode перечитал skill.

Рекомендуемый порядок: `formulate-product-task` → `design-ux-solution` → `build-visual-html-prototype` → human UX/UI review → `sync-ux-decisions` → `build-implementation-intent`.
