---
name: sync-ux-decisions
description: Этап 03.5 продуктового pipeline: после человеческой проверки HTML-прототипа синхронизирует подтверждённые UX-уточнения и изменения обратно в канонический 02_ux_solution.md. Сравнивает Product Task Brief, UX Solution и 03_visual_prototype.md/исходники прототипа, отделяет visual-only изменения от UX decisions и блокирует попытки прототипа изменить business rules. Используй после build-visual-html-prototype и до build-implementation-intent.
---

# Sync UX Decisions

## Назначение

Это короткий gate между проверенным прототипом и implementation intent. Не проектируй новый UX и не переписывай Solution целиком. Твоя задача — сделать один канонический UX-источник после прототипирования и оставить trace того, что изменилось.

## Input gate

Начинай, если доступны:

- `01_product_brief.md` со статусом `READY_FOR_UX` или эквивалентным утверждённым статусом;
- `02_ux_solution.md` со статусом `READY_FOR_PROTOTYPE`;
- `03_visual_prototype.md`;
- исходники утверждаемого прототипа, если handoff недостаточен для проверки расхождения;
- явный запрос пользователя синхронизировать UX после просмотра прототипа.

Если прототип ещё не был просмотрен человеком и пользователь не просит принять его изменения, не финализируй UX: верни `NEEDS_UX_REVIEW`. Если `03_visual_prototype.md` имеет `NEEDS_VISUAL_FIX`, сначала требуется исправление прототипа.

## Source authority

Используй источники по их назначению:

1. **Product Task Brief** — intended business truth внутри инкремента: проблема, scope, роли, бизнес-правила, ограничения. Утверждения, помеченные в brief как assumption/unknown/needs-review, не повышай до факта.
2. **Продуктовый контекст** — существующие product facts и ограничения согласно его `source_authority`. Если подтверждённый product fact конфликтует с owner-stated brief, не выбирай сторону молча: зафиксируй конфликт.
3. **UX Solution** — текущая UX truth до синхронизации.
4. **Approved prototype** — evidence конкретизации и проверки UX, но не источник новых business rules и не доказательство production backend-поведения.

Demo fixtures, hardcoded значения, mock retry, временные роли, локальные JS-проверки и технические упрощения не являются продуктовым решением сами по себе.

## Процесс

1. Прочитай brief, UX Solution и `Differences from UX Solution` из `03_visual_prototype.md`.
2. Только при недостаточном handoff проверь соответствующие HTML/CSS/JS участки прототипа. Не анализируй весь код без причины.
3. Для каждого расхождения проверь исходную формулировку UX Solution и источник, на который она опиралась.
4. Классифицируй расхождение: `Visual-only` / `UX clarification` / `UX change` / `Potential product-rule conflict`. Исправь неверную классификацию прототипа, если evidence это подтверждает.
5. `Visual-only` оставь только в prototype handoff; UX Solution не меняй.
6. Подтверждённые `UX clarification` и `UX change` внеси минимальным diff в соответствующие разделы `02_ux_solution.md`: journey, surfaces, states, rationale, acceptance criteria и handoff должны снова быть непротиворечивы.
7. Не переноси в UX Solution demo/mock implementation details, если они не являются UX decision.
8. Если изменение требует поменять business rule, scope, роль/permission, расчёт или подтверждённый product fact, останови финализацию со статусом `NEEDS_PRODUCT_DECISION`. Не переписывай brief автоматически.
9. Проведи consistency check финального UX Solution.
10. Добавь/обнови `Revision trace` в `02_ux_solution.md` и создай короткий `03_ux_sync.md`.

## Минимальный diff

Не переписывай документ ради единообразия стиля. Меняй только места, которые затронуты принятым UX decision, плюс зависимые acceptance criteria/handoff. Сохраняй исходную доказательность: assumption остаётся assumption, unknown остаётся unknown, пока новый authoritative source его не закрыл.

## Формат `03_ux_sync.md`

```markdown
# UX Decision Sync

## Sources
- Product Brief:
- UX Solution:
- Prototype handoff/source:

## Accepted UX changes
- <что изменено и где в 02_ux_solution.md>

## Visual-only changes
- <оставлены только в prototype>

## Rejected / prototype-only assumptions
- <mock/demo details, которые не стали UX truth>

## Product conflicts
- <нет | список конфликтов и требуемое решение>

## Revision trace
- <краткий список обновлённых разделов UX Solution>

## Status
`APPROVED_UX`, `NEEDS_PRODUCT_DECISION`, `NEEDS_UX_REVIEW` или `BLOCKED_BY_CONTEXT`
```

## Quality gate

`APPROVED_UX` допустим только если:

- human review прототипа состоялся или пользователь явно поручил синхронизацию как принятого решения;
- все UX deviations классифицированы;
- visual-only правки не загрязнили UX Solution;
- prototype/mock behavior не повышен до business/production truth;
- конфликтов с Product Brief или source-confirmed product facts нет;
- journey, surfaces, states, rationale, UX acceptance criteria и structural handoff после изменений непротиворечивы;
- `02_ux_solution.md` имеет финальный статус `APPROVED_UX`;
- создан `03_ux_sync.md`.

Используй статусы:

- `APPROVED_UX` — канонический UX синхронизирован и готов для Intent;
- `NEEDS_PRODUCT_DECISION` — прототип/UX требует изменения business truth или есть конфликт authoritative sources;
- `NEEDS_UX_REVIEW` — человеческое решение по UX deviations ещё не принято;
- `BLOCKED_BY_CONTEXT` — не хватает обязательного источника для безопасной синхронизации.

## Запрещено

- считать факт реализации в HTML/JS доказательством production-правила;
- менять Product Brief;
- добавлять API, frontend architecture или компоненты UI Kit;
- переносить все визуальные детали прототипа в UX Solution;
- создавать четвёртую версию UX путём смешивания несовместимых источников.
