# Skills Pipeline v5

Основной путь от продуктовой постановки до входа в Business/System Analysis.

```text
01 formulate-product-task
        ↓
02 design-ux-solution
        ↓
03 build-visual-html-prototype
        ↓
   Human UX/UI review
        ↓
03.5 sync-ux-decisions
        ↓
04 build-implementation-intent
        ↓
   Business/System Analysis
        ↓
   Production Frontend / Backend
```

## Контракты этапов

| Этап | Основной результат | Успешный статус | Следующий этап |
|---|---|---|---|
| 01 | `01_product_brief.md` | `READY_FOR_UX` | 02 |
| 02 | `02_ux_solution.md` | `READY_FOR_PROTOTYPE` | 03 |
| 03 | HTML/CSS/JS + `03_visual_prototype.md` | `READY_FOR_UX_REVIEW` | Human review / 03.5 |
| 03.5 | обновлённый `02_ux_solution.md` + `03_ux_sync.md` | `APPROVED_UX` | 04 |
| 04 | `04_intent.md` | `READY_FOR_ANALYSIS` | Business/System Analysis |

## Authority model

- Product Brief: intended problem, scope, roles, business rules and constraints.
- Product context: current product facts according to its source authority.
- Final UX Solution: approved flow, surfaces, states, actions, hierarchy and feedback.
- Approved visual prototype: executable UX/visual evidence; not a production backend/API contract.
- Intent: normalized implementation contract for analysis, not a replacement for UX Solution.

Если authoritative sources конфликтуют, pipeline обязан зафиксировать конфликт и остановить соответствующий gate, а не смешивать версии решения.
