---
name: build-implementation-intent
description: Этап 04 продуктового pipeline: компилирует утверждённые Product Task Brief, финальный UX Solution и проверенный прототип в implementation intent для Business/System Analysis. Формализует scope, бизнес-правила, Given/When/Then acceptance criteria, DoD, конфликты и технические gaps; не превращает mock/prototype behavior в production truth и не придумывает API. Используй после sync-ux-decisions и до системного/бизнес-анализа и production frontend.
---

# Build Implementation Intent

## Назначение

Intent — граница между design truth и engineering analysis. Это не ещё один UX-документ и не техническая спецификация API. Собери уже принятые продуктовые и UX-решения в проверяемый implementation contract, а то, чего источники не подтверждают, явно передай следующему аналитическому этапу.

## Input gate

Обязательны:

- `01_product_brief.md` — утверждённый Product Task Brief;
- `02_ux_solution.md` со статусом `APPROVED_UX`;
- `03_visual_prototype.md`;
- `03_ux_sync.md` со статусом `APPROVED_UX`;
- prototype source только там, где handoff нужен для проверки конкретного поведения;
- выбранный product context/Context trace;
- `references/intent-template.md`.

Если UX ещё не синхронизирован, верни `BLOCKED_BY_UX_SYNC`. Если есть `NEEDS_PRODUCT_DECISION`, не маскируй конфликт техническим TBD.

## Source authority

Не смешивай источники по принципу «самый подробный победил».

### Business truth

Approved Product Task Brief задаёт intended scope, роли, business rules, ограничения и целевой результат инкремента. Сохраняй его внутреннюю доказательность: `source-confirmed`, `owner-stated`, `assumption`, `unknown`, `needs-review` не равны друг другу.

Существующие product facts из продуктового контекста применяй согласно его `source_authority`. Если source-confirmed current product противоречит intended requirement brief, зафиксируй conflict/change dependency вместо тихого выбора.

### UX truth

Финальный `02_ux_solution.md` после `sync-ux-decisions` является authoritative для flow, surfaces, actions, states, hierarchy, feedback и UX edge cases.

### Prototype evidence

Прототип подтверждает, что конкретный UX можно пройти и визуально/интерактивно проверить. Он не является authority для:

- backend validation;
- API contract;
- persistence/audit schema;
- permission source;
- concurrency;
- production enums/role IDs, если они не подтверждены brief/context;
- hardcoded limits/fixtures;
- мгновенных mock retries и других demo shortcuts.

## Процесс

1. Прочитай template Intent и зафиксируй требуемый формат.
2. Из Brief возьми проблему, TO BE, scope/out of scope, роли, business rules, ограничения и доказательность. Не копируй предложенный UI как business requirement, если он был только hypothesis.
3. Из Final UX возьми утверждённые действия, flow, состояния, feedback, edge cases и обязательные surfaces, если тип surface сам является частью принятого UX.
4. Используй prototype handoff для подтверждения сценарной полноты и обнаружения implementation-visible states. Читай исходный HTML/CSS/JS только точечно.
5. Построй функциональные блоки Intent по пользовательским/доменным возможностям, а не автоматически по визуальным секциям страницы.
6. Сформулируй rules/business logic отдельно от UI presentation.
7. Преобразуй happy path, альтернативы, состояния и UX acceptance criteria в Given/When/Then. Каждый AC должен быть наблюдаемым и не требовать знания внутренней реализации, если эта реализация не подтверждена business rule.
8. Сформируй DoD по трём слоям шаблона: UI/UX artifacts, business logic/calculations, integrations/API. Для неподтверждённой интеграционной конкретики используй `[ТРЕБУЕТ УТОЧНЕНИЯ]`, а не выдуманный контракт.
9. Выполни conflict/gap pass: business conflict, UX conflict, prototype-only behavior, system-analysis gap.
10. Сохрани `04_intent.md` и status.

## Как превращать UX в Acceptance Criteria

Используй принцип:

`предусловие/состояние → действие/событие → наблюдаемый результат`.

Пример:

UX: «при исчерпанном лимите активация платного пользователя не происходит и показывается локальное объяснение».

Intent:

- Given: лимит активных платных пользователей исчерпан;
- When: пользователь с правом изменения пытается активировать пользователя, учитываемого в лимите;
- Then: статус не изменяется, пользователь получает предусмотренный UX Solution feedback.

Не добавляй «backend возвращает 409» или конкретный endpoint, если этого нет в authoritative system source.

## Conflict and gap taxonomy

Перед финалом явно различай:

- **Business conflict** — Brief/context противоречат друг другу по факту, scope или правилу;
- **UX conflict** — Final UX всё ещё внутренне противоречив или не соответствует Brief;
- **Prototype-only behavior** — поведение есть только в demo/mock реализации; не переносить в SHALL;
- **System-analysis gap** — для production реализации потребуется решение по данным, API, auth/permissions, audit, concurrency, errors, persistence или интеграции.

Если gap не мешает сформулировать пользовательский контракт, пометь `[ТРЕБУЕТ УТОЧНЕНИЯ]` и продолжай. Если без него невозможно определить бизнес-результат или AC, статус `NEEDS_ANALYSIS_DECISION`.

## Формат результата

Используй структуру `references/intent-template.md` как обязательный каркас. Допустимо добавить после DoD два компактных раздела, если они содержат реальную информацию:

```markdown
## 5. Требует уточнения на Business/System Analysis
- ...

## 6. Traceability и конфликты
- Brief → Intent:
- UX → Intent:
- Prototype-only, не перенесённое в requirements:
- Конфликты: нет | ...
```

Не раздувай Intent UX-rationale, визуальными деталями, описанием каждого компонента и копией всего journey.

## Quality gate

`READY_FOR_ANALYSIS` допустим, если:

- business scope и rules не взяты из prototype;
- Final UX имеет `APPROVED_UX`;
- каждый ключевой пользовательский outcome покрыт AC;
- критические альтернативы и ограничения покрыты AC или явно вынесены в analysis gaps;
- mock behavior не оформлен как production SHALL;
- неизвестные интеграции/API не придуманы;
- противоречия перечислены, а не скрыты;
- Intent соответствует шаблону и пригоден как вход Business/System Analysis.

Используй статусы:

- `READY_FOR_ANALYSIS` — Intent достаточно определён для следующей аналитической стадии;
- `NEEDS_ANALYSIS_DECISION` — отсутствует решение, без которого невозможно сформулировать корректный implementation contract;
- `BLOCKED_BY_UX_SYNC` — UX не финализирован после прототипа;
- `BLOCKED_BY_CONTEXT` — недоступен обязательный authoritative source.

## Запрещено

- придумывать endpoint, DTO, HTTP codes, DB schema, audit fields или auth-механику;
- считать код прототипа production contract;
- возвращать visual design decisions обратно в business scope;
- скрывать conflicts выбором «самого свежего» файла без проверки его роли;
- превращать Intent в повтор UX Solution или frontend specification.
