# Install: build-implementation-intent

Скопируйте каталог `skill/build-implementation-intent` в `.gigacode/skills/` проекта или в пользовательский каталог skills GigaCode. После установки/обновления выполните `/clear`.

Запускайте после `sync-ux-decisions`, когда `02_ux_solution.md` и `03_ux_sync.md` имеют статус `APPROVED_UX`. Результат: `04_intent.md` со статусом `READY_FOR_ANALYSIS` либо явным блокирующим статусом.
