# Product Visual Audit — NORM / vertical slice v1

Статус: working canonicalization input  
Дата источников: 09.2026

## 1. Классификация источников

| Источник | Роль |
|---|---|
| Risks production repo | фактическая структура и геометрия текущего продукта |
| Measures production repo | второй production evidence для поиска повторяемых композиций |
| Risks/Measures/Events screenshots | визуальная проверка повторяемости между сервисами |
| UI Kit Modal | shared shell geometry и component-level behavior |
| Drawer/Modal screenshots | shared surface references |
| TO-BE `risk-Modals.png` | целевое решение для unified action/meta zone |
| Contragents registry screenshot | evidence для situational overview: semantic summary + distribution visualization + detailed list |
| AI guidance / assistant screenshots | evidence для contextual AI states, assistant modal и assistant entry inside object rail |

## 2. Карта shared / NORM-specific / legacy / TO-BE

| Область | Evidence | Решение |
|---|---|---|
| Modal shell | Risks + Measures используют почти одинаковый `ModalLayout`; max-width 1320, radius 24, viewport padding 24 | **NORM profile** поверх shared Modal pattern |
| Object View grid | Risks: `minmax(0,1fr) 280px`, gap 32; Measures: `auto 280px`, gap 80 | **Shared composition**, NORM default aside = 280; gap — profile/layout-dependent |
| Right metadata blocks | Risks/Measures имеют sticky `Info`, History и linked-object action | **Canonical basis** для action/meta zone |
| Workflow actions снизу | `WorkflowActions` остаются в нижней области production view | **Legacy for Object View**; переносим в action/meta zone |
| Lifecycle actions в TO-BE footer | TO-BE screenshot оставляет `Удалить / В архив` внизу | **Superseded** новым canonical Object View: footer отсутствует; lifecycle/destructive идут в action/meta zone / more-actions |
| Object Create/Edit footer | формы используют bottom completion actions | **Canonical**: create/edit завершаются fixed Footer |
| Registry controls | Risks и Measures: quick filters слева; search + filter справа; search раскрывается второй строкой | **Canonical NORM organism candidate** |
| Advanced filter | оба repo используют Drawer, section reset, общий Reset + Apply footer | **Shared interaction pattern** |
| Entity card shell | radius 16, ~24 padding, status/meta → title → KPIs/content | **Shared card pattern + service profile** |
| Card internal layout | Risk и Measure сильно различаются | **Не нормализовать в один жёсткий organism** |
| Floating create/chat surface | Risks/Measures: ширина около 600, radius 32, bottom 16 | **NORM-specific reference**, пока не shared |
| Page visual density | светлый canvas, белые surfaces, мягкие gray secondary blocks, semantic chips, sparse page + denser cards | **NORM visual DNA** |
| Situational analytics | Contragents: summary tiles + distribution ring + detailed registry | **Pattern candidate**: meaningful analytics may precede/mediate list; chart type remains task-dependent |
| AI guidance states | progress / choose / create fallback; contextual assistant card in Object Modal | **Pattern evidence** for future AI guidance/assistant normalization; не загружается runtime автоматически |

## 3. Подтверждённая геометрия

### NORM Object Modal

Из `src/components/ModalLayout/styles.module.scss` в обоих production repo:

- viewport padding: `24px`;
- modal max-width: `1320px`;
- min-width desktop: `600px`;
- surface radius: `24px`;
- scrim: `rgba(36, 40, 43, 0.56)`;
- close/back group: `top: 32px`, `right: 40px`;
- chat-aware shell сохраняется как продуктовая интеграция, не как universal Modal contract.

### UI Kit Modal

Из `ui-kit-0.283.0`:

- surface radius: `24px`;
- header padding: `32px 40px`;
- title: `28px / 40px`;
- close: `top 32px / right 40px`;
- footer padding: `40px`;
- border footer опционален.

### Risk Entity Card

- padding: `24px`;
- radius: `16px`;
- default border через inset token;
- hover: небольшая elevation shadow.

### Measure Entity Card

- padding: `23px` (считаем локальной реализацией 24px rhythm);
- radius: `16px`;
- border: `1px solid var(--borderDefault)`;
- desktop: `minmax(512px,660px) / divider / auto`;
- <=1440: одна колонка.

## 4. Повторяемая NORM visual DNA

1. Page canvas светлый и почти плоский; depth создаётся surfaces, borders и редкими shadows.
2. Основная белая поверхность не должна превращаться в «карточку ради карточки» — многие page areas остаются на canvas.
3. Entity cards плотнее страницы: около 24px padding, radius 16, тонкая граница.
4. Object Modal — крупный workspace: radius 24, широкая main area + узкая sticky rail.
5. Внутренние informational/action blocks rail — secondary background + radius 16.
6. Зеленый — основной action accent; красный/желтый/голубой применяются семантически, а не декоративно.
7. Chips/tags компактные, преимущественно pill geometry.
8. Typographic hierarchy строится не огромными display-заголовками, а контрастом weight/size + большим page whitespace.
9. Secondary metadata заметно тише основного контента.
10. AI presence встроен как продуктовый элемент, но не должен заставлять каждый экран выглядеть как чат.

## 5. Что пока нельзя считать универсальным

- floating bottom create/chat surface — подтверждён NORM, ORM пока неизвестен;
- конкретная ширина gap между main/aside — Risks и Measures расходятся;
- внутренняя анатомия Risk/Measure/Event cards;
- набор quick filters и порядок статусов;
- AI insight cards сверху Risk list — service-specific composition, не registry shell;
- chat behavior внутри ModalLayout — NORM integration, не shared Modal core.

## 6. Canonical decisions v1

1. Object View = main content + action/meta zone; общий Footer отсутствует.
2. Все object-level workflow/lifecycle actions просмотра собираются справа.
3. Create/Edit = form workspace + fixed Footer.
4. Advanced filter = Drawer, не Modal.
5. Registry page controls оформляются отдельным organism-контрактом.
6. Entity card нормализуется как shell/pattern, но не как единый универсальный компонент для всех сущностей.
7. Shared core всегда отделяется от product profile (`norm`, позже `orm`).
8. Existing UI patterns — strong defaults, а не жёсткие screen templates; invariants отделяются от optional composition и visual references.
9. Registry/monitoring UX должен явно проверять необходимость situational overview; meaningful distribution/trend/attention view не заменяется механически списком карточек.
