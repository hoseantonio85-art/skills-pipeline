# Organism: Registry Page Controls

Status: NORM-confirmed, shared-candidate

## Problem

В Risks и Measures фактически повторяется одна композиция управления registry. Организм фиксирует композицию, но не бизнес-набор фильтров.

## Anatomy

```txt
RegistryPageControls
├─ Left cluster
│  ├─ SectionNavigation / RadioChips, optional
│  └─ QuickFilters / CheckboxChips, optional
├─ Right cluster
│  ├─ Search trigger (tertiary icon)
│  └─ Filter trigger (tertiary icon + label + active indicator)
└─ ExpandableSearchRow, optional
```

Filter trigger → `AdvancedFilterDrawer`.

## Behavior

- Quick filters применяются сразу.
- Search trigger toggles second row; при открытии input получает focus.
- Search может быть debounced; runtime behavior зависит от продукта/API.
- Filter active state обозначается маленьким status indicator, а не полной перекраской toolbar.
- Advanced filters применяются осознанно через Drawer Footer.
- Сброс Drawer возвращает расширенные фильтры; связь с quick filters задаётся service contract.

## Slots / data

```ts
interface RegistryPageControlsModel {
  sections?: ChoiceItem[];
  quickFilters?: ChoiceItem[];
  search?: { value: string; placeholder: string };
  advancedFilters?: FilterSection[];
  hasActiveAdvancedFilters: boolean;
}
```

Это concept contract, не production React API.

## Do not

- не делать отдельный `RiskFilters`/`MeasureFilters` shell при той же композиции;
- не помещать все advanced filters в page toolbar;
- не открывать Filter Modal;
- не фиксировать конкретные названия фильтров в organism.
