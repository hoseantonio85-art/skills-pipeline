# Drawer — runtime pattern

## Intent

Подчинённая задача поверх Page/Modal с сохранением родительского контекста.

## Decision

- самостоятельный объект → Object Modal / Page;
- подчинённая задача → Drawer;
- следующий уровень той же задачи → replace content;
- независимая связанная задача → второй Drawer только когда это действительно необходимо.

## Shared system sizes

- S: 608
- M: 720
- L: 840
- XL: 1184

Размер выбирается по структуре задачи, не под конкретный макет.

## Scope

- `viewport` — от края viewport;
- `container` — внутри родительской Modal, перекрывает её Header/Body/Footer.

## Shell

```txt
Drawer
├─ Header: Back? + title + Close
├─ Body: only main scroll area
└─ Footer? fixed actions
```

## Registry filter profile

- обычно S/M;
- sections с title + optional local reset;
- общий Footer: `Сбросить` + `Применить`;
- закрытие без apply не должно незаметно менять выдачу, если не используется live filtering.

## Object View profile

История, выбор связи, источник, комментарий и другие secondary tasks открываются Drawer без разрушения Object Modal state.
