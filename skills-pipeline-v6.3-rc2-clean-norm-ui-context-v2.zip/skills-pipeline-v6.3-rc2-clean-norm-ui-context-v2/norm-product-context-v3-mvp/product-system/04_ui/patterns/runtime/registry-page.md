# Registry Page — runtime pattern

## Intent

Рабочая страница со списком однотипных сущностей. Пользователь должен быстро понять scope выдачи, переключить сегмент, найти сущность, уточнить фильтры и открыть объект.

## Canonical composition

```txt
Page
├─ Title + total/context
├─ Optional service-specific insight / situational overview
├─ RegistryPageControls
│  ├─ Section / quick filters
│  ├─ Search trigger
│  ├─ Advanced filter trigger
│  └─ Expandable search
├─ Optional filter-coupled situational overview / interactive analytics
├─ Entity list
│  └─ EntityCard × N
└─ Optional NORM floating create/chat surface
```

## Rules

- Search и Filter находятся в одном control row; search может раскрываться отдельной строкой под ним.
- Quick filters отражают частые срезы; расширенные поля не выносятся все на страницу.
- Filter открывает Drawer.
- Page не оборачивать целиком в большую white card: registry должен сохранять ощущение workspace/canvas.
- Список должен иметь один устойчивый vertical rhythm.
- На каждой registry/monitoring page явно проверь, нужен ли `situational-overview`: распределение, динамика, концентрация или другой aggregate story может дать понимание ситуации быстрее, чем один список.
- Если analytics и list используют общий filter/query state, situational overview можно ставить после controls и перед list. Если overview описывает весь domain, он может быть выше list controls.
- Service-specific insights допустимы между controls/title и list, но не становятся частью universal registry shell; конкретный chart type не фиксируется этим pattern.
- Bare card list не должен быть механическим default, если meaningful analytics реально помогает принять решение.

## States

- loading: skeleton/list loader, controls не прыгают;
- empty: объяснение + следующий шаг;
- filtered empty: отличать от системного empty;
- error: recoverable retry;
- search expanded/collapsed;
- filters active indicator.

## NORM profile

- spacious top area;
- entity cards radius 16 / ~24px padding;
- bottom floating create/chat surface допустим как NORM-specific behavior;
- reference: `norm-vertical-slice.html#registry`.
