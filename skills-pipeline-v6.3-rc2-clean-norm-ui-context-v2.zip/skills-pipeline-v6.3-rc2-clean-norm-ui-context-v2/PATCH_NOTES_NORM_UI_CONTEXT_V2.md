# NORM UI Context v2 — patch notes

## Why this patch

The previous integration correctly moved Object View actions into the unified right action/meta zone, but the product-scoped starter no longer demonstrated a standard Create/Edit Modal with a fixed Footer. This patch restores that capability in the correct mode and clarifies that product patterns are not rigid screen templates.

## Restored starter capability

`references/html/starter/` and legacy skill fallback now include:

- Default / Loading / Empty / Error demo states;
- Registry controls + expandable search;
- Object Modal / View with right action/meta zone and **no Footer**;
- separate Standard/Create/Edit Modal with **fixed Footer: secondary + primary**;
- scrim / Close / Escape behavior for both modal examples.

No prior starter interaction was intentionally removed.

## Composition flexibility

Added `product-system/04_ui/visual/composition-adaptation.md`.

The context now distinguishes:

1. **Invariants** — hard product/surface contracts;
2. **Strong defaults** — proven patterns that may be adapted;
3. **References** — visual/composition evidence, never mandatory DOM/templates.

New compositions are explicitly allowed as `composition-adaptation` or `new-pattern-candidate` when the user task/data shape benefits, provided product invariants and Visual DNA are preserved and the rationale is recorded.

Stage 02, Stage 03, frontend planner, implementer and reviewer were aligned with this policy.

## Situational overview / analytics

Added an explicit rule that registry/monitoring pages must consider whether the situation should be shown through aggregate analytics before relying on a card list alone.

New files:

- `patterns/situational-overview.md`;
- `patterns/runtime/situational-overview.md`;
- `references/html/situational-overview/index.html`.

The runtime pattern supports both:

- `filters → analytics → list` when analytics and list share query state;
- `overview → list controls → list` when overview represents the whole domain.

Analytics must answer a real question and lead to filter/drill-down/action; decorative KPI walls remain prohibited.

## New screenshot evidence

Stored under `04_ui/audit/screenshots/2026-09/` and excluded from default runtime loading:

- counterparties registry with semantic summary + distribution visualization;
- counterparties object modal and drawer;
- AI guidance states;
- assistant modal;
- contextual assistant entry in an Object Modal rail;
- assistant icon state exploration.

Textual observations were extracted into runtime/audit documents so the model does not need to load the image files during ordinary tasks.

## Context loading

`context-manifest.yaml` now loads the compact composition-adaptation policy in UX/prototype/planning profiles and exposes `situational_overview` as an on-demand reference scene. Full screenshots remain audit evidence only.
