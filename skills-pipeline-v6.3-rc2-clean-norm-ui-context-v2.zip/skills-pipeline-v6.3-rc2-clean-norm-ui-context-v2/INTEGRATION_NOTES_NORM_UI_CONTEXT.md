# Integration mock — NORM UI Context → skills-pipeline v6.3-rc2-clean

Статус: integration mock, без изменения публичной версии pipeline.

## Цель

Встроить новый NORM visual/pattern context в существующий product context так, чтобы:

- существующий pipeline 01–07 не менялся по смыслу;
- старые context files и pattern paths не исчезали;
- Stage 02 видел compact pattern index, но не visual/pixel context;
- Stage 03 получал product-scoped Visual DNA, registry, selected runtime patterns/organisms и HTML starter/reference;
- Stages 05–07 не теряли выбранные product patterns при переходе к frontend implementation;
- full authoring specs/audit/UI Kit не bulk-load в каждую задачу;
- архитектура сразу поддерживала второй product profile `orm` без копирования NORM context.

## No-loss result

Проверка против исходного `skills-pipeline-v6.3-rc2-clean`:

- исходных файлов: 132;
- удалено исходных файлов: **0**;
- добавлено новых файлов до этого integration note: 19;
- изменено существующих файлов: 19;
- старый skill-local `assets/norm-html-starter` сохранён и остаётся backward-compatible fallback;
- предыдущий подробный `large-entity-modal.md` сохранён как `product-system/04_ui/audit/legacy/large-entity-modal-v0.1.0.md`;
- pipeline/package version не менялась.

## Целевая структура

```text
norm-product-context-v3-mvp/
└─ product-system/
   ├─ 03_ux/
   │  └─ ux_principles.md                 # updated Object View action placement
   └─ 04_ui/
      ├─ audit/
      │  ├─ product-visual-audit.md
      │  └─ legacy/
      │     └─ large-entity-modal-v0.1.0.md
      ├─ visual/
      │  ├─ ... existing visual rules
      │  └─ norm-visual-dna.md             # compact product profile
      ├─ patterns/
      │  ├─ ... existing authoring patterns preserved
      │  ├─ pattern-registry.yaml          # existing registry + runtime overlay
      │  ├─ runtime/
      │  │  ├─ registry-page.md
      │  │  ├─ entity-card.md
      │  │  ├─ object-modal-view.md
      │  │  └─ drawer.md
      │  └─ specs/
      │     ├─ modal.md                    # full shared shell spec
      │     └─ drawer.md                   # full shared shell spec
      ├─ organisms/
      │  ├─ organism-registry.yaml
      │  ├─ registry-page-controls.md
      │  └─ object-action-meta-zone.md
      └─ references/html/
         ├─ starter/                       # product-scoped starter
         │  ├─ index.html
         │  ├─ styles.css
         │  └─ prototype.js
         └─ norm-vertical-slice/
            └─ index.html                  # on-demand visual reference
```

## Context loading

### Stage 02 — UX

Default profile получает:

- business/product context;
- UX principles/patterns;
- `pattern-registry.yaml`.

Не получает по умолчанию:

- Visual DNA;
- HTML references;
- UI Kit API;
- full UI authoring specs.

Full Modal/Drawer specs читаются только при реально спорном surface/stack decision.

### Stage 03 — visual HTML prototype

Default profile получает:

- существующие visual rules;
- `norm-visual-dna.md`;
- pattern registry;
- organism registry.

Дальше работает index-first:

```text
UX surfaces
→ pattern registry
→ selected runtime patterns
→ selected organisms
→ optional HTML reference scene
→ product-scoped starter
```

Manifest теперь содержит `prototype.starter`, `prototype.reference_scenes` и `prototype.routing`. Skill-local NORM starter сохранён только как fallback для старых manifests.

### Stage 05 — frontend planning

Planner разрешает product context, читает compact registries и Visual DNA, затем выбирает только runtime patterns/organisms затронутых surfaces. В `05_frontend_plan.md` добавлен раздел `Product patterns and organisms`.

### Stage 06 — implementation

Implementer читает только patterns/organisms, указанные для выбранного engineering increment. Product pattern задаёт composition/interaction semantics; target repo и actual UI Kit остаются implementation truth.

### Stage 07 — review

Reviewer проверяет сохранение утверждённой product composition semantics только в scope reviewed increment. HTML/DOM prototype не становится production contract.

## Canonical Object Modal rule

### View

```text
Object Modal / View
├─ Header / Object Header
└─ Body
   ├─ Main content
   └─ Right action/meta zone
```

- общий Footer отсутствует;
- metadata, history/service navigation и object-level workflow/lifecycle actions находятся справа;
- rare/destructive actions могут быть в More;
- local content actions остаются у своего блока.

### Create / Edit

- form workspace;
- fixed Footer с completion actions;
- dirty guard.

TO-BE `risk-Modals.png` принят как evidence для unified right action/meta zone. Его нижний lifecycle footer не переносится в canonical rule.

## Shared / product profile model

Shared:

- Modal shell;
- Drawer shell;
- entity-card shell;
- registry concepts;
- action/meta-zone semantics.

NORM profile:

- Object Modal 1320;
- overlay-workspace perception;
- 280px target action/meta rail;
- NORM Visual DNA;
- NORM HTML starter/reference;
- floating create/chat surface как supported reference.

ORM profile зарезервирован в registry:

- Object Modal 1424;
- near-fullscreen perception;
- shared action/meta-zone semantics;
- остальные visual/pattern differences пока `unknown` и не копируются из NORM автоматически.

## Что намеренно НЕ сделано

- не добавлен ORM evidence/content;
- не перенесены все старые pattern files в новые директории;
- не удалён legacy skill starter;
- не bulk-load production repositories/screenshots;
- не превращены HTML references в React/UI Kit contract;
- не изменены Intent/Brief/SDD stages ради visual context.
