const demoStates = ['default', 'loading', 'empty', 'error'];

function showDemo(state) {
  demoStates.forEach((name) => {
    document.getElementById(`state-${name}`).hidden = name !== state;
  });
  document.querySelectorAll('[data-demo]').forEach((button) => {
    button.classList.toggle('active', button.dataset.demo === state);
  });
}

document.querySelectorAll('[data-demo]').forEach((button) => {
  button.addEventListener('click', () => showDemo(button.dataset.demo));
});

document.querySelectorAll('.chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach((item) => item.classList.remove('active'));
    chip.classList.add('active');
  });
});

const objectModal = document.getElementById('object-modal');
const formModal = document.getElementById('form-modal');

function openOverlay(overlay) {
  if (overlay) overlay.hidden = false;
}
function closeOverlay(overlay) {
  if (overlay) overlay.hidden = true;
}

document.querySelectorAll('[data-open-modal]').forEach((button) => {
  button.addEventListener('click', () => openOverlay(objectModal));
});
document.querySelectorAll('[data-close-modal]').forEach((button) => {
  button.addEventListener('click', () => closeOverlay(objectModal));
});
document.querySelectorAll('[data-open-form-modal]').forEach((button) => {
  button.addEventListener('click', () => openOverlay(formModal));
});
document.querySelectorAll('[data-close-form-modal]').forEach((button) => {
  button.addEventListener('click', () => closeOverlay(formModal));
});
[objectModal, formModal].forEach((overlay) => {
  overlay?.addEventListener('click', (event) => {
    if (event.target === overlay) closeOverlay(overlay);
  });
});
document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  if (formModal && !formModal.hidden) return closeOverlay(formModal);
  if (objectModal && !objectModal.hidden) closeOverlay(objectModal);
});

showDemo('default');

const searchToggle = document.querySelector('[data-toggle-search]');
const searchRow = document.querySelector('[data-search-row]');
if (searchToggle && searchRow) {
  searchToggle.addEventListener('click', () => {
    const nextHidden = !searchRow.hidden;
    searchRow.hidden = nextHidden;
    searchToggle.setAttribute('aria-expanded', String(!nextHidden));
    if (!nextHidden) searchRow.querySelector('input')?.focus();
  });
}
