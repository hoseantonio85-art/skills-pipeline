import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NormPrototype from './components/NormPrototype';

const basename = import.meta.env.BASE_URL.replace(/\/$/, '');

export default function App() {
  return (
    <BrowserRouter basename={basename}>
      <Routes>
        <Route path='/' element={<NormPrototype />} />
      </Routes>
    </BrowserRouter>
  );
}
