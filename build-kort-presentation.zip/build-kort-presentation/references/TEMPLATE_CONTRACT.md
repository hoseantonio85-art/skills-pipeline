# KORT Presentation Template Contract

## 1. Что считается protected shell

Protected shell — всё, что обеспечивает системность и runtime презентации:

- canonical CSS внутри `<style>`;
- `.deck-shell`;
- `main#deck` как контейнер слайдов;
- controls после deck: `.help`, `.nav`, `.overview`, `#fileInput`;
- core `<script>`;
- print behavior;
- фиксированная сцена 1600×900 и scale logic.

Protected shell нельзя переписывать при обычной генерации презентации.

## 2. Разрешённая единица тиражирования

Единица тиражирования — полный блок:

```html
<section class="slide ..." data-theme="..." data-title="..." data-purpose="...">
  ...
</section>
```

Клонируй section целиком. Не собирай его заново из фрагментов.

## 3. Что можно менять в canonical clone

- текст внутри `[contenteditable="true"]`;
- `data-title`;
- `data-purpose`;
- `background-image` у предусмотренного media slot;
- порядок slide sections;
- наличие/отсутствие clone в deck;
- `active` — только первый slide;
- browser `<title>`.

## 4. Что нельзя менять в canonical clone

- структуру DOM;
- имена layout classes;
- наличие `contenteditable`;
- grid/flex structure;
- число карточек/шагов/людей/KPI внутри конкретного образца;
- semantic media slot attributes;
- base selectors в CSS.

Если структура контента не подходит — выбери другой template slide.

## 5. Custom extensions

Допустимы как редкое исключение.

Правила:

1. CSS только append-only после canonical CSS.
2. Все selectors scoped новым slide class.
3. Никаких правок существующих selectors.
4. Core JS неизменен.
5. Slide помечен `data-custom="true"`.
6. Пользовательский текст остаётся contenteditable.
7. Validator запускается с `--allow-custom`.

## 6. Почему contenteditable — часть контракта

HTML-шаблон рассчитан не только на показ, но и на последующее ручное редактирование прямо в браузере.
Удаление `contenteditable="true"` превращает reusable presentation system в статичный результат и считается регрессией.

## 7. Стратегия исправления overflow

Порядок обязателен:

1. сократить copy;
2. разделить смысл;
3. сменить pattern;
4. custom extension только как последнее средство.

Не уменьшай системную типографику локально, пока не исчерпаны первые три шага.
