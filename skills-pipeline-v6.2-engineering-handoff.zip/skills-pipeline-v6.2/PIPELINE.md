# Skills Pipeline v6.2 — Engineering Handoff

```text
raw request / product idea
          ↓
01 formulate-product-intent-and-brief
   ├─ 00_intent.md
   └─ 01_product_brief.md
          ↓
02 design-ux-solution  ← selective domain evidence when relevant
   └─ 02_ux_solution.md
          ↓
03 build-visual-html-prototype
   ├─ 03_visual_prototype.md
   └─ runnable HTML/CSS/JS
          ↓
human UX/UI review
          ↓
03.5 sync-ux-decisions ← domain consistency check when relevant
   ├─ final 02_ux_solution.md
   └─ 03_5_ux_sync.md
          ↓
04 build-sdd-specification
   └─ 04_sdd_specification.md  (observable product behavior)
          ↓
──────── product / engineering boundary ────────
          ↓
05 frontend-planner  [subagent, read-only]
   └─ 05_frontend_plan.md
          ↓
06 frontend-implementer  [subagent, edit + execution]
   ├─ production frontend code
   ├─ tests
   └─ 06_frontend_implementation.md
          ↓
07 frontend-reviewer  [subagent, independent review]
   └─ 07_frontend_review.md
          ↓
   PASS ───────────────→ VERIFIED_FRONTEND
    │
    └─ FIX_REQUIRED → 06 frontend-implementer (narrow fix scope)
                              ↓
                         07 re-review
```

## Knowledge layers

- **Product context** — stable product/domain knowledge, UX principles and guardrails.
- **Analytical specs** — on-demand domain/system evidence: lifecycle, states, business rules, permissions, validation, errors, integrations. Stored under `sources/analytical-specs/` and routed by `index.yaml`; never bulk-loaded by default.
- **Frontend standards** — engineering-only rules and target-repository evidence. They are intentionally unavailable to stages 01–04 and first become normative after `APPROVED_FOR_ENGINEERING`.
- **Repository/contracts** — implementation truth used after Stage 04 for engineering planning, coding and review.
- **Task artifacts** — Intent, Brief, UX Solution, prototype, SDD, frontend plan, implementation handoff and review for the current increment.

## Artifact authority

- `00_intent.md`: why, Why Now, expected outcome, success and guardrails. Stable across UX iterations.
- `01_product_brief.md`: detailed product truth for UX discovery.
- `02_ux_solution.md`: approved user experience, scenarios, states and design rationale.
- HTML prototype: executable UX evidence, never a production implementation contract.
- `03_5_ux_sync.md`: review decision and deviations; cannot change Intent.
- `04_sdd_specification.md`: **product behavior contract** — scope, actors/permissions, states, scenarios, business rules, GWT, errors/edge cases, observable consistency and dependencies. It intentionally contains no implementation design.
- `05_frontend_plan.md`: **engineering translation contract** for the target repository: affected surfaces, reuse map, component/state boundaries, UI Kit mapping, data/contracts, scenario-state coverage, tests and ordered increments. It may not change product behavior.
- Production code + `06_frontend_implementation.md`: implementation evidence for exactly one or more explicitly enumerated engineering increments. Code is authoritative for what was implemented, not for silently changing product intent.
- `07_frontend_review.md`: independent conformance verdict against SDD + frontend plan + target repo + frontend standards. It does not redesign the UX or silently fix broad product behavior.
- Product context: stable product/domain knowledge and architecture/UX guardrails only.
- Analytical specs: reference/constraint source; technical details must be translated into observable behavior before entering SDD.
- Frontend standards: reusable engineering rules; target repository remains higher authority for actual stack, APIs and local conventions.

## Stage 04 boundary

Stage 04 отвечает на:

- что система должна делать;
- какие сценарии и состояния существуют;
- какие действия/permissions действуют;
- какие business rules и validation влияют на поведение;
- какие ошибки и edge cases надо обработать;
- какой observable outcome считается принятым.

Stage 04 **не отвечает** на API/DTO/storage, frontend/backend architecture, component/store design, transport topology, caching/locking mechanism или implementation task breakdown. Эти решения начинаются после `APPROVED_FOR_ENGINEERING`.

## Engineering workflow principles

1. **Plan before code for non-trivial frontend work.** Stage 05 is read-only and target-first.
2. **Prototype is evidence, not source code.** HTML/CSS/JS may clarify hierarchy and interaction, but Stage 05 must map behavior to real repository patterns and UI Kit instead of translating prototype code literally.
3. **One implementation context = one engineering increment.** Stage 06 receives a bounded slice from `05_frontend_plan.md`; large features are implemented incrementally.
4. **Plan deviation is explicit.** If repository truth invalidates the plan, implementation records `PLAN_DEVIATION` instead of silently inventing a new architecture or product rule.
5. **Review is independent.** Stage 07 starts from the diff and approved artifacts, not from the implementer's reasoning history.
6. **Reviewer does not become the implementer.** Broad fixes return to Stage 06. Reviewer may only make local mechanical fixes when explicitly requested; default pipeline mode is review-only.
7. **Frontend standards are shared knowledge, not a role.** Planner, implementer and reviewer read the same `.gigacode/skills/frontend-standards/` package; each subagent keeps a narrow responsibility.
8. **Target repo wins implementation disputes.** `AGENTS.md`, actual package versions, UI Kit exports, runtime integration and established local patterns outrank generic guidance.

## Stage responsibilities

### 05 frontend-planner

Answers: **How can the approved product behavior be implemented safely in this target frontend repository?**

Required inputs:
- `04_sdd_specification.md` with `APPROVED_FOR_ENGINEERING`;
- final `02_ux_solution.md` and `03_5_ux_sync.md`;
- approved prototype as UX evidence when available;
- target repository and accessible contracts;
- frontend standards skill.

Must not edit production code.

### 06 frontend-implementer

Answers: **Can this bounded engineering increment be implemented according to the approved plan and repository rules?**

Required inputs:
- approved `05_frontend_plan.md`;
- selected increment ID(s);
- `04_sdd_specification.md`;
- target repository;
- frontend standards skill.

It may edit code and run permitted checks. It must not broaden scope by itself.

### 07 frontend-reviewer

Answers: **Does the resulting diff conform to product behavior, approved engineering plan, repository contracts and frontend standards?**

Required inputs:
- `git diff` / changed files;
- `04_sdd_specification.md`;
- `05_frontend_plan.md`;
- `06_frontend_implementation.md` when present;
- target repository;
- frontend standards skill.

Default mode is read-only. Findings are `blocker | major | recommendation` and produce `PASS | FIX_REQUIRED | BLOCKED`.

## Status contracts

See `STATUS_CONTRACTS.md`. A later stage may read earlier outputs and on-demand evidence, but must not silently upgrade status or overwrite source authority.
