# Pipeline status contracts

| Stage | Ready status | Blocking / return statuses | Required next-stage input |
|---|---|---|---|
| 01 Intent + Brief | `READY_FOR_UX` | `NEEDS_CLARIFICATION`, `NEEDS_DECOMPOSITION`, `BLOCKED_BY_CONTEXT` | Both `00_intent.md` and `01_product_brief.md` share the ready status/revision |
| 02 UX Solution | `READY_FOR_PROTOTYPE` | `NEEDS_UX_DECISION`, `NEEDS_PRODUCT_ALIGNMENT`, `BLOCKED_BY_CONTEXT` | Intent + Brief + UX Solution |
| 03 Visual prototype | `PASS` or explicit human-approved `READY_WITHOUT_VISUAL_REVIEW` | `BLOCKED_BY_UX_HANDOFF`, `BLOCKED_BY_CONTEXT`, `BLOCKED_BY_VISUAL_CONTEXT`, `NEEDS_VISUAL_FIX` | Runnable prototype + `03_visual_prototype.md` |
| 03.5 UX Sync | `READY_FOR_SDD` | `NEEDS_UX_REVIEW`, `NEEDS_UX_DECISION`, `REQUIRES_INTENT_REVIEW` | Final UX Solution + approved prototype + deviations record |
| 04 Product SDD | `READY_FOR_SPEC_REVIEW` / `APPROVED_FOR_ENGINEERING` | `NEEDS_PRODUCT_RULE`, `BLOCKED_BY_UX_SYNC`, `CONFLICTING_SOURCES` | Product behavior contract + source trace + review state |
| 05 Frontend Plan | `READY_FOR_FRONTEND_IMPLEMENTATION` | `BLOCKED_BY_SDD`, `BLOCKED_BY_REPOSITORY`, `BLOCKED_BY_CONTRACT`, `NEEDS_ENGINEERING_DECISION` | Approved SDD + target repository + `05_frontend_plan.md` |
| 06 Frontend Implementation | `READY_FOR_FRONTEND_REVIEW` | `PLAN_DEVIATION`, `BLOCKED_BY_REPOSITORY`, `BLOCKED_BY_CONTRACT`, `CHECKS_FAILED` | Implemented bounded increment + tests/checks + `06_frontend_implementation.md` |
| 07 Frontend Review | `VERIFIED_FRONTEND` | `FIX_REQUIRED`, `BLOCKED` | Independent review of diff against SDD + plan + repository + frontend standards |

## Invariants

1. Stage 01 produces both artifacts from one discovery session.
2. Intent contains no GWT or implementation-specific details.
3. Stage 03.5 never edits Intent; a changed outcome returns to stage 01 review.
4. Prototype code and parameter names never become production requirements by inference.
5. Analytical specifications are on-demand evidence, not automatic context payload.
6. Stage 04 contains observable product behavior and deliberately excludes implementation design.
7. API/DTO/storage/frontend/backend architecture and implementation decomposition begin after Stage 04.
8. Stage 05 is read-only with respect to production code and may not change observable behavior from Stage 04.
9. Stage 06 implements only explicitly selected increment(s) from the approved frontend plan.
10. A discovered conflict with target repository/contracts is recorded as `PLAN_DEVIATION` or blocker; it is never hidden by silently changing SDD or UX artifacts.
11. Stage 07 is independent from the implementation context and reviews the diff, not the implementer's explanation.
12. `FIX_REQUIRED` returns to Stage 06 with a narrow findings scope; Stage 07 does not become a broad auto-fixer.
13. `VERIFIED_FRONTEND` requires zero blockers and zero unresolved majors for the reviewed scope. Skipped runtime checks must be declared.
