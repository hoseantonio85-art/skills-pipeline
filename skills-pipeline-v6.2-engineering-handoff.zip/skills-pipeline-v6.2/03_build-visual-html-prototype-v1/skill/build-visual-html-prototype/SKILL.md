---
name: build-visual-html-prototype
description: Третий этап продуктового pipeline: создаёт быстрый интерактивный HTML/CSS/JavaScript-прототип по Business Intent, Product Brief и утверждённому UX Solution, обязательно начиная с визуальных правил и HTML-starter выбранного продукта. Используй для проверки UX-концепции и визуальной композиции. Прототип не является production contract: production-архитектура, настоящий UI Kit, API, i18n и строгая типизация здесь не требуются.
---

# Build Visual HTML Prototype

## Input gate

Начинай, если доступны:

- Product Task Brief со статусом `READY_FOR_UX`;
- Business Intent со статусом `READY_FOR_UX`;
- UX Solution со статусом `READY_FOR_PROTOTYPE`;
- выбранный product context;
- visual context и хотя бы базовый HTML starter.

Если UX Solution не определяет основной сценарий, surfaces или информационный приоритет, верни `BLOCKED_BY_UX_HANDOFF`.

## Context loading

Сначала возьми разрешённый контекст и список источников из UX Solution. Если trace неполон, повтори штатный протокол:

1. прочитай `context_id` из `<project>/.gigacode/product-context.yaml`;
2. открой `~/.gigacode/product-contexts.yaml`;
3. найди `contexts[context_id]`;
4. возьми `provider.root` и `provider.manifest`;
5. открой `<provider.root>/<provider.manifest>` и проверь совпадение `context_id`.

Не подменяй этот протокол поиском соседней папки.

Открой manifest и профиль `for_visual_html_prototype`. Для NORM затем прочитай:

1. `04_ui/visual/visual-language.md`;
2. `04_ui/visual/product-likeness.md`;
3. `04_ui/visual/layout-and-density.md`;
4. `04_ui/visual/pattern-selection.md`;
5. `04_ui/visual/modal-and-drawer.md` только при соответствующих surfaces;
6. только релевантные UX patterns и service context.

Если NORM выбран, но manifest и visual profile не открыты, верни `BLOCKED_BY_CONTEXT`; не создавай generic prototype под видом NORM. Не загружай документацию всего UI Kit. На этом этапе не подключай настоящий UI Kit, если пользователь явно не попросил иначе.

## Обязательный starter gate

Для NORM не начинай HTML с пустого файла.

1. Найди `assets/norm-html-starter` внутри активного skill.
2. Прочитай `index.html`, `styles.css` и `prototype.js`, чтобы понять shell, tokens, layout, demo controls и базовые interactions.
3. Скопируй весь starter в целевую директорию прототипа без изменения структуры файлов.
4. Только после копирования адаптируй starter под UX Solution. Сохрани отдельные `index.html`, `styles.css` и `prototype.js`.
5. Используй существующие CSS variables, shell и композиционные primitives starter. Меняй их осознанно и перечисляй существенные отклонения в handoff.

После адаптации проверь происхождение каждого brand/action token. Для NORM запрещено объявлять синий новым brand-цветом: базовые действия должны наследовать зелёный, тёмный нейтральный и мягкие нейтральные стили starter. Если задача не требует иного, не заменяй палитру starter самодельной.

Если starter отсутствует, не читается или не может быть скопирован, верни `BLOCKED_BY_VISUAL_CONTEXT`. Не заменяй его самодельным generic HTML.

## Priorities

1. UX clarity.
2. Product likeness.
3. Visual hierarchy and composition.
4. Scenario completeness.
5. Plausible content.
6. Sufficient prototype code quality.

## Workflow

1. Прочитай Intent, Brief и UX Solution; Intent используй как outcome guardrail, Brief — как product truth. Не меняй flow молча.
2. Выбери минимальный набор product patterns.
3. Выполни обязательный starter gate; не создавай альтернативную заготовку.
4. Составь короткий visual plan: shell, surfaces, hierarchy, density, states, interactions.
5. Выбери из `product-likeness.md` только те узнаваемые приёмы NORM, которые поддерживают UX Solution. Не вставляй dock, attention zones, AI gradient или Object Modal только ради сходства.
6. Создай правдоподобные fixtures на русском языке.
7. Реализуй happy path и критические альтернативные состояния.
8. Добавь только взаимодействия, необходимые для демонстрации решения.
9. Открой прототип в доступном browser/preview и проверь desktop layout.
10. Исправь очевидные проблемы композиции после первого render.
11. Сохрани прототип и короткий handoff.

## Implementation rules

- Предпочитай обычные HTML, CSS и JavaScript; React допустим, если уже есть подходящий starter или сложное состояние.
- Используй CSS variables визуального контекста.
- Допускай локальные prototype-компоненты без имитации API настоящего UI Kit.
- Не называй самодельные компоненты `@sber-orm/ui-kit` и не создавай ложный alias.
- Не добавляй production layers, stores, API clients, i18n и тесты без необходимости.
- Не превращай имена переменных, mock data, DOM structure или demo behavior прототипа в production contract.
- Отделяй demo scenario controls от продуктовой поверхности.
- Не используй изображения как обязательный вход: GigaCode должен работать по текстовым правилам и assets.
- Создавай и изменяй Markdown, HTML, CSS и JavaScript файловыми инструментами редактирования. Не передавай содержимое документов в shell построчно. Shell используй только для запуска, сборки и проверки.
- Не подключай Google Fonts, CDN и другие внешние runtime-зависимости. Используй системный font stack или локальные assets starter.
- Не объединяй starter в один HTML-файл, если пользователь явно не запросил single-file artifact.
- Наличие одного большого HTML с встроенными CSS/JavaScript при доступном starter считается нарушением starter gate, а не допустимым упрощением.

## NORM rules

- Не используй классические таблицы как основной реестр.
- Используй card registry или row-cards с приоритетом, объяснением и действием.
- Dashboard допустим и желателен для обзора, мониторинга или зон внимания, если его агрегаты ведут к drill-down.
- Используй floating action dock, когда основное действие или AI/chat должно оставаться доступным при прокрутке.
- Используй emoji точечно, но не вместо системной визуальной семантики целиком.
- Не делай summary обязательной декоративной секцией: добавляй её, когда она сокращает работу интерпретации.

## Required states

Реализуй default и все состояния, критичные для UX acceptance criteria. Обычно это loading, empty, error и один action progress/success. Не создавай пять декоративных сценариев, если они не проверяют решение.

## Visual quality gate

Перед статусом пройди чек-лист. Не ставь PASS только потому, что страница открылась.

### Семантика и сценарий

- основной сценарий можно пройти от входа до результата;
- активный пункт навигации соответствует странице и заявленной архитектуре;
- объекты, события и состояния не подменяют друг друга;
- повторный запуск или новая версия создаёт новую запись и связь с исходной, а не переписывает историю;
- числа, подписи, счётчики, фильтры и fixtures согласованы между экранами;
- входы в ассистента не дублируются без разных и понятных задач.

### Состояния и взаимодействия

- default, loading, empty и error взаимоисключающие;
- empty state соответствует активным фильтрам и предлагает релевантный следующий шаг;
- кликабельность строк, карточек и переходов читается без угадывания;
- demo controls визуально отделены от продуктовой поверхности;
- modal/drawer открывается и закрывается ожидаемо, сохраняет контекст и выдерживает длинный контент;
- размер surface соответствует UX Solution: большая Object Modal действительно использует доступное пространство;
- floating dock не перекрывает последний контент и действия.
- одинаковый primary CTA не дублируется в header, строках и floating dock без разных задач;

### Композиция и техническая целостность

- первый экран объясняет приоритет и следующий шаг;
- интерфейс использует shell, tokens и primitives starter, а не пересобран по памяти;
- узнаваемые shell, card hover, modal и dock-параметры сверены с `product-likeness.md`, но применены только по сценарию;
- primary, secondary, text и destructive actions визуально различаются; заполненный primary не повторяется в каждой строке реестра;
- NORM не получил самодельный синий brand: action tokens сверены со starter и `visual-language.md`;
- card registry быстро сканируется, строки не избыточно высокие;
- нет наложений, обрезанного текста, прыгающих блоков и недоступных действий на проверенных viewport;
- внешние CDN и подмена UI Kit отсутствуют;
- HTML, CSS и JavaScript загружаются без явных ошибок.
- сохранены отдельные `index.html`, `styles.css` и `prototype.js`; single-file без прямого запроса получает `NEEDS_VISUAL_FIX`.

Если доступен browser/preview, проверь минимум desktop viewport, каждое обязательное состояние и открытые modal/drawer. Если модель не может визуально оценить render, честно используй `READY_WITHOUT_VISUAL_REVIEW`. `PASS` допустим только после фактической визуальной проверки всего чек-листа. При найденных дефектах используй `NEEDS_VISUAL_FIX`, исправь их и повтори проверку.

## Output

Сохрани запускаемый проект и обязательный `03_visual_prototype.md` с разделами: Context trace, реально прочитанные visual sources, путь использованного starter, сохранённые starter-файлы, visual plan, реализованные сценарии, отклонения от UX Solution и starter, результаты чек-листа по группам, проверенные viewport, ограничения и статус. Не заявляй проверки, которые фактически не выполнялись. Без этого файла этап не завершён.
