# Evidence sources

Эта директория входит в один архив для воспроизводимости, но не является автоматическим context payload.

- `ui-kit/` — package для проверки exports/types;
- `common-components/` — полный library source package для будущего анализа;
- `frontend-rules/` — полные нормативные документы, из которых собран compact profile;
- `analytical-specs/` — capability/master specifications аналитиков. Используются **только выборочно** через `analytical-specs/index.yaml` для domain facts, constraints и consistency checks.

Skills должны сначала использовать нормализованные документы из `product-system/` и обращаться сюда только по конкретной причине. Analytical specs нельзя bulk-load: сначала route by capability, затем читать 1–3 релевантных файла.
