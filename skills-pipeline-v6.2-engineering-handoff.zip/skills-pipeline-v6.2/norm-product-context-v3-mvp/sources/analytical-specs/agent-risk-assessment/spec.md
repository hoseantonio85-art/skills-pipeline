# Спецификация рисков ИИ-агентов

## Назначение

Определить регистрацию и версионирование ИИ-агента, подготовку документов, запуск внешней оценки, обработку callback, создание/обновление рисков и рекомендованных мер, а также согласование результата.

## Доменная модель

### `AGENT`

`AGENT` является версионируемым tenant-scoped business object с historic-таблицей `AGENT_HISTORIC`.

| Группа | Поля |
|---|---|
| Идентичность | system UUID, `tenantId`, `businessId`, `businessUiId`, `seafId`, `version` |
| Описание | `agentName`, `agentStage`, `agentDescription`, `agentCriticalityLevel`, `agentEntityType`, `agentBaseModel` |
| Жизненный цикл | `status`, `agentVersionNumber`, `owner`, `verifier`, `timeLastValidated` |
| Расчётные UI-поля | `maxRiskLevel`, `riskManagementStrategy`, `lastEvaluationFailed` |
| Аудит | `actingFrom`, timestamps, updater, update source, `data` |

Default profile требует `agentName` (до 1000), `agentStage`, `agentDescription` (до 4000), `agentEntityType`, `status`, `agentVersionNumber`; остальные требования уточняются активным профилем.

### `AGENT_EVALUATION`

| Поле | Семантика |
|---|---|
| `TASK_ID` | UUID и корреляционный идентификатор оценки, primary key |
| `SYS_OWNERID` | tenant id |
| `AGENT_ID` | business id агента |
| `AGENT_VERSION` | оцениваемая следующая бизнес-версия агента |
| `TASK_STATUS` | `new`, `resolved`, `error` |
| `TASK_DESCRIPTION` | диагностическое описание результата/ошибки |
| `TIME_CREATED` | время создания задачи |
| `ATTEMPTS` | номер предпринятой отправки |

### Вложения

Metadata хранится в `ATTACHMENT`: `fileId`, tenant, `businessId`, `objectVersion`, `objectType=agent`, `fileName`, `attachmentType`, `extension`, `size`, `timeCreated`, `author`, `hash`. Бинарное содержимое принадлежит файловому сервису.

## Требования

### Requirement: Агент создаётся как версионируемый business object

`POST /api/v1/risks/agents/update` ДОЛЖЕН создавать агента с начальным `agentVersionNumber=0`, status `new`, уникальными идентификаторами и audit metadata.

#### Scenario: Создаётся новый агент

- **WHEN** пользователь с `AgentRisks.Create` отправляет валидные поля без существующего businessId
- **THEN** сервис ДОЛЖЕН сохранить current agent и вернуть AgentViewResponse
- **AND** workflow actions ДОЛЖНЫ соответствовать статусу `new`

#### Scenario: Обязательное поле отсутствует

- **WHEN** не заполнены name, description, stage или entity type согласно профилю
- **THEN** сервис ДОЛЖЕН вернуть field-level validation errors без записи

### Requirement: Идентификатор и версия агента неизменяемы клиентом

После создания `businessId`, tenant и системный UUID НЕ ДОЛЖНЫ меняться; `agentVersionNumber` ДОЛЖЕН увеличиваться только после успешной оценки.

#### Scenario: Обычное редактирование описания

- **WHEN** пользователь обновляет metadata без оценки
- **THEN** persistence `version` МОЖЕТ увеличиться
- **AND** `agentVersionNumber` НЕ ДОЛЖЕН увеличиться

### Requirement: Реестр агентов фильтруется по доступу

`POST /api/v1/risks/agents/search` ДОЛЖЕН поддерживать query/profile filters и возвращать только видимых пользователю агентов текущего tenant.

#### Scenario: Пользователь не видит агента по object-level rules

- **WHEN** агент совпадает с query, но visibility запрещена
- **THEN** он НЕ ДОЛЖЕН входить ни в `entities`, ни в `total`

### Requirement: Карточка агента является server-driven

`GET /api/v1/risks/agents/{id}` ДОЛЖЕН возвращать entity, dictionaries, employees, form config, workflow actions, связанные risks/categories/measures и вычисляемые поля.

#### Scenario: Agent approved

- **WHEN** status равен `approved`
- **THEN** карточка ДОЛЖНА показывать `maxRiskLevel`, `riskManagementStrategy` и `timeLastValidated`, когда данные доступны

#### Scenario: Agent не найден в текущем tenant

- **WHEN** id отсутствует или принадлежит другому tenant
- **THEN** сервис ДОЛЖЕН вернуть not found без раскрытия чужих данных

### Requirement: Refresh агента не выполняет commit

`POST /api/v1/risks/agents/refresh` ДОЛЖЕН пересчитать форму, зависимости и ошибки для переданных fields без новой persistence version.

#### Scenario: Изменён agentEntityType

- **WHEN** UI вызывает refresh
- **THEN** dictionaries, validation и зависимые поля ДОЛЖНЫ соответствовать новому типу

### Requirement: Workflow агента соблюдает state machine

| Статус | Action | Target | Допустимые роли |
|---|---|---|---|
| `new` | `estimate` | `inProgress` | risk manager, AI owner, partner |
| `inProgress` | `success` | `review` | автоматическое действие оценки |
| `inProgress` | `error` | `new` | автоматическое действие первичной оценки |
| `inProgress` | `errorReestimate` | `approved` | автоматическое действие переоценки |
| `review` | `takeToWork` | `verification` | partner, regulator |
| `verification` | `approve` | `approved` | owner partner/regulator |
| `approved` | `reestimate` | `inProgress` | risk manager, AI owner, partner |

#### Scenario: Оценка запускается впервые

- **WHEN** `agentVersionNumber=0`, status `new` и старт оценки успешно принят
- **THEN** action `estimate` ДОЛЖЕН перевести агента в `inProgress`

#### Scenario: Approved агент переоценивается

- **WHEN** `agentVersionNumber>0` и старт принят
- **THEN** action `reestimate` ДОЛЖЕН перевести его в `inProgress`

#### Scenario: Верификатор не является owner

- **WHEN** action `approve` настроен с `verifyUserInField=owner`, но пользователь не совпадает с owner
- **THEN** сервис ДОЛЖЕН отклонить action

### Requirement: Workflow actions защищены permission и ролью

View/search требуют `AgentRisks.View`, create/start требуют `AgentRisks.Create`, attachment/save и workflow edit требуют `AgentRisks.Edit` в соответствии с HTTP-контрактом; наличие permission не отменяет role/owner guard.

#### Scenario: Пользователь вручную вызывает success

- **WHEN** неавторизованный внешний пользователь вызывает внутреннее action `success`
- **THEN** сервис ДОЛЖЕН запретить действие как системное

### Requirement: Agent editable field SHALL be computed by new formula

Agent `editable` field SHALL be computed by formula: `(status NOT IN {"review", "inProgress"}) AND hasPermission(AgentRisks.Create)`.

**Было:** `editable` вычислялся как `(status == "approved") AND hasPermission(AgentRisks.Create)`. Только агенты со статусом `approved` могли быть отредактированы.

**Стало:** `editable` вычисляется как `(status NOT IN {"review", "inProgress"}) AND hasPermission(AgentRisks.Create)`. Агенты со статусами `new` и `approved` могут быть отредактированы. Агенты со статусами `review` и `inProgress` не могут быть отредактированы.

#### Scenario: Агент со статусом approved

- **WHEN** статус равен `approved` И пользователь имеет право `AgentRisks.Create`
- **THEN** `config.editable` равен `true`

#### Scenario: Агент со статусом new

- **WHEN** статус равен `new` И пользователь имеет право `AgentRisks.Create`
- **THEN** `config.editable` равен `true`

#### Scenario: Агент со статусом review

- **WHEN** статус равен `review` И пользователь имеет право `AgentRisks.Create`
- **THEN** `config.editable` равен `false`

#### Scenario: Агент со статусом inProgress

- **WHEN** статус равен `inProgress` И пользователь имеет право `AgentRisks.Create`
- **THEN** `config.editable` равен `false`

#### Scenario: Пользователь без права AgentRisks.Create

- **WHEN** статус равен `new` или `approved` И пользователь НЕ имеет права `AgentRisks.Create`
- **THEN** `config.editable` равен `false`

### Requirement: Вложения привязаны к следующей версии агента

Документы для новой оценки ДОЛЖНЫ сохраняться с `businessId=agentId`, `objectType=agent` и `objectVersion=current agentVersionNumber+1`.

#### Scenario: Добавлен документ для переоценки

- **WHEN** approved agent имеет version N
- **THEN** metadata файла ДОЛЖНА получить objectVersion N+1

#### Scenario: Version в path не является ожидаемой

- **WHEN** upload указывает старую/далёкую версию
- **THEN** сервис ДОЛЖЕН отклонить файл или нормализовать к ожидаемой версии до записи

### Requirement: Файл проходит валидацию до сохранения

Upload ДОЛЖЕН проверять fileId, filename, extension, MIME/content signature, размер, attachmentType, hash и разрешённые типы активного AgentProperties/profile.

#### Scenario: Расширение разрешено, содержимое опасно

- **WHEN** content signature не соответствует разрешённому документу
- **THEN** сервис ДОЛЖЕН отклонить upload и удалить временный blob/metadata

#### Scenario: Повторно загружен тот же fileId

- **WHEN** fileId уже принадлежит другому business object или content
- **THEN** сервис ДОЛЖЕН отклонить конфликт

### Requirement: Операции вложений проверяют владельца объекта

List/download/save ДОЛЖНЫ проверять tenant и Agent permission, а download — дополнительно соответствие file metadata запрошенному agentId.

#### Scenario: FileId принадлежит другому агенту

- **WHEN** пользователь подставляет чужой fileId в URL доступного agentId
- **THEN** сервис ДОЛЖЕН вернуть not found/forbidden и не отдавать bytes

### Requirement: Запуск оценки требует документов

`POST /api/v1/risks/agents/{agentId}/start-assessment` ДОЛЖЕН найти поддерживаемые attachments следующей agent version и запретить запуск при пустом/неполном обязательном наборе.

#### Scenario: Документы отсутствуют

- **WHEN** нет ни одного поддерживаемого attachment
- **THEN** оценка НЕ ДОЛЖНА создаваться/отправляться
- **AND** временные attachments версии ДОЛЖНЫ быть очищены по согласованной политике

#### Scenario: Обязательные attachment types присутствуют

- **WHEN** набор валиден
- **THEN** сервис ДОЛЖЕН создать одну `AGENT_EVALUATION` со status `new`, version N+1 и attempts=1

### Requirement: Для оценки формируется безопасный ZIP

Сервис ДОЛЖЕН скачать attachments по metadata/hash, сформировать ZIP без path traversal, duplicate entry ambiguity и zip bomb, соблюдая aggregate size limit.

#### Scenario: Filename содержит путь

- **WHEN** filename равен `../secret.txt` или содержит абсолютный путь
- **THEN** сервис ДОЛЖЕН sanitise имя либо отклонить оценку

#### Scenario: Архив превышает configured maximum

- **WHEN** итоговый ZIP больше лимита
- **THEN** сервис НЕ ДОЛЖЕН отправлять его внешнему агенту
- **AND** task ДОЛЖЕН получить контролируемый error outcome

### Requirement: Внешний запрос оценки коррелируется taskId

Вызов agent evaluation service ДОЛЖЕН содержать `taskId`, `agentId`, `agentVersion` и ZIP; timeout/retry ДОЛЖНЫ быть настроены и наблюдаемы.

#### Scenario: Внешний сервис принял запрос

- **WHEN** отправка успешна
- **THEN** workflow агента ДОЛЖЕН перейти в `inProgress`
- **AND** метрики ДОЛЖНЫ зафиксировать старт и размер архива

#### Scenario: Отправка завершилась ошибкой

- **WHEN** synchronous call не принят
- **THEN** evaluation ДОЛЖНА стать `error`
- **AND** workflow НЕ ДОЛЖЕН оставаться ложно успешно запущенным

### Requirement: Одновременные оценки одного target version запрещены

Для tenant+agentId+agentVersion ДОЛЖНА существовать не более одной активной evaluation.

#### Scenario: Пользователь дважды нажал старт

- **WHEN** evaluation N+1 уже `new`/обрабатывается
- **THEN** второй запрос ДОЛЖЕН вернуть conflict/already started
- **AND** НЕ ДОЛЖЕН создать новую task или повторно увеличить version

### Requirement: Callback оценки аутентифицирован

`POST /api/v1/risks/agents/updateEvaluations` ДОЛЖЕН быть internal-only, проверять service identity, schema и существование taskId до установки TenantContext из сохранённой task.

#### Scenario: Callback подменяет tenant

- **WHEN** callback содержит или подразумевает tenant, отличный от `AGENT_EVALUATION.SYS_OWNERID`
- **THEN** сохранённый tenant ДОЛЖЕН быть источником истины

#### Scenario: TaskId неизвестен

- **WHEN** callback относится к отсутствующей task
- **THEN** сервис ДОЛЖЕН вернуть not found и не создавать task автоматически

### Requirement: Успешный callback валидирует evaluations

Для code `200` каждая evaluation ДОЛЖНА содержать `riskType`, `riskLevel`, `reasoning` длиной не более контракта; каждая рекомендация ДОЛЖНА иметь name, а ids/levels/types — проходить справочники.

#### Scenario: Одна evaluation невалидна

- **WHEN** отсутствует `riskLevel` или `reasoning`
- **THEN** весь callback НЕ ДОЛЖЕН частично применяться
- **AND** task ДОЛЖНА получить наблюдаемую ошибку обработки

### Requirement: Успешный callback обрабатывается асинхронно tenant-aware
**Изменено**: добавлен шаг проверки modelRisk после создания/обновления всех пришедших evaluation.

После первичной валидации сервис ДОЛЖЕН enqueue обработку с tenantId и task payload, не выполняя тяжёлые side effects в callback HTTP thread. После успешной обработки всех evaluation — создать или обновить modelRisk.

#### Scenario: Callback принят, modelRisk отсутствует
- **WHEN** task ещё `new`, payload валиден, и после обработки evaluation не найден modelRisk
- **THEN** сервис ДОЛЖЕН:
  1. Создать все пришедшие evaluation
  2. Создать modelRisk с фиксированными полями (description из справочника, summary — фиксированная строка из messages.properties, riskLevel = null)
  3. Создать связь `riskToAgent`
- **AND** вернуть согласованный успех после создания всех рисков

#### Scenario: Callback принят, modelRisk уже существует
- **WHEN** task ещё `new`, payload валиден, и modelRisk найден
- **THEN** сервис ДОЛЖЕН:
  1. Создать/обновить пришедшие evaluation
  2. Найти modelRisk по `agentId + aiRiskType`
  3. Сбросить `riskLevel` в `null`
  4. Обновить `summary` (из messages.properties), `description` НЕ обновляется из словаря
- **AND** вернуть согласованный успех

### ADDED Requirements

### Requirement: Для каждого агента создаётся не более одного modelRisk

Обработчик ДОЛЖЕН проверять существование modelRisk по `tenantId + agentId + aiRiskType = "modelRisk"` перед созданием.

#### Scenario: Вторая оценка того же агента
- **WHEN** повторная evaluation того же agentId
- **THEN** сервис ДОЛЖЕН найти существующий modelRisk, сбросить `riskLevel` в `null` и обновить `summary`
- **AND** НЕ ДОЛЖЕН создать второй modelRisk

### Requirement: modelRisk не влияет на статус evaluation

Создание/обновление modelRisk ДОЛЖНО выполняться в том же tenant, что и исходная evaluation (из `SYS_OWNERID`).

#### Scenario: modelRisk создан, но evaluation ещё не закончена
- **WHEN** modelRisk создан, но остальные обязательные риски ещё не применены
- **THEN** evaluation ДОЛЖНА оставаться `new` до завершения полного цикла
- **AND** modelRisk — отдельный логический шаг, не блокирующий финализацию

### Requirement: Для каждого AI risk type создаётся или обновляется один риск

Обработчик ДОЛЖЕН найти активные risks, связанные с агентом, по `aiRiskType`; существующий risk обновляется, отсутствующий создаётся как agency risk.

#### Scenario: Новый AI risk type

- **WHEN** активного связанного риска нет
- **THEN** сервис ДОЛЖЕН создать risk с `relatedRisk=agency`, description из `aiRiskType` dictionary, level и reasoning
- **AND** создать `riskToAgent`

#### Scenario: Существующий AI risk type

- **WHEN** risk найден
- **THEN** сервис ДОЛЖЕН обновить `riskLevel` и `summary` через evaluation pipeline
- **AND** сохранить его businessId и историю

### Requirement: Фиксированные риски агента дополняют ответ

Если active configuration задаёт mandatory/fixed risks по `agentEntityType`, сервис ДОЛЖЕН добавить их к evaluations детерминированно и без дублей.

#### Scenario: Внешний ответ уже содержит fixed type

- **WHEN** AI evaluation включает тот же risk type
- **THEN** сервис ДОЛЖЕН разрешить дубль по documented precedence, сохранив один логический risk

### Requirement: Рекомендованные меры создаются как черновики без дублей

Для каждой `aiRiskMeasure` сервис ДОЛЖЕН сравнить AI measure id с уже связанными мерами риска, создать только отсутствующие draft measures и связи `riskToMeasureDraft`.

#### Scenario: Recommendation уже существует

- **WHEN** тот же AI measure id уже связан с risk
- **THEN** новая мера НЕ ДОЛЖНА создаваться

#### Scenario: Name длиннее лимита

- **WHEN** recommendation name превышает configured display max
- **THEN** краткое имя ДОЛЖНО быть безопасно усечено, а полное описание сохранено в предназначенном поле в пределах его лимита

### Requirement: Завершение оценки атомарно с точки зрения lifecycle

Evaluation ДОЛЖНА стать `resolved`, а agent — перейти `inProgress→review` с `agentVersionNumber=target version` только после успешного применения всех обязательных risks/measures/links.

#### Scenario: Создание одной обязательной связи неуспешно

- **WHEN** risks созданы, но link service вернул ошибку
- **THEN** task НЕ ДОЛЖНА становиться `resolved`
- **AND** система ДОЛЖНА иметь retry/compensation, предотвращающие дубли при повторе

### Requirement: AI-агент создаёт меры с предзаполненными Исполнителем и Заказчиком

При создании мер через AI-агент evaluation pipeline (POST `/api/v1/risks/agents/updateEvaluations`) система SHALL предзаполнить поля `ownerDivision` (Заказчик) и `responsibleDepartmentOne` (Исполнитель) значением `managementOrgId` корневого тенанта текущего контекста.

#### Scenario: Создание меры с предзаполненными полями

- **WHEN** AI-агент отправляет оценку (`Evaluation`) с рекомендациями мер (`aiRiskMeasureList`)
- **AND** `tenantProvider.get()` возвращает тенант `tenant-A` с `managementOrgId = "org-123"`
- **THEN** `MeasureEvaluationService.createMeasures()` SHALL вызвать `MeasureInternalApi.createMeasure()` с `RestBusinessObject`, содержащим:
  - `ownerDivision = "org-123"`
  - `responsibleDepartmentOne = "org-123"`
  - `aiRiskMeasureId` — из рекомендации агента
  - `name` — обрезанный до `recommendationMaxNameLength`
  - `description` — полное название рекомендации

#### Scenario: Несколько мер в одной оценке

- **WHEN** AI-агент отправляет 3 меры в одной оценке
- **AND** `tenantProvider.get()` возвращает `managementOrgId = "org-456"`
- **THEN** все 3 меры SHALL содержать `ownerDivision = "org-456"` и `responsibleDepartmentOne = "org-456"`

#### Scenario: Tenant context из задачи

- **WHEN** `AgentInternalController.updateEvaluations()` принимает запрос от задачи с `tenantId = "tenant-B"`
- **THEN** `tenantContext.with(TenantId.valueOf(data.tenantId()), ...)` в `UpdateEvaluationsTask.executeOnce()` SHALL установить `tenantProvider` в `tenant-B`
- **AND** `resolveRootManagementOrg()` SHALL вернуть `managementOrgId` корневого тенанта `tenant-B`

#### Scenario: Существующие меры не меняются

- **WHEN** мера создаётся через UI, Excel upload или batch pipeline
- **THEN** `MeasureEvaluationService.createMeasures()` НЕ ВЫЗЫВАЕТСЯ
- **AND** поля `ownerDivision`/`responsibleDepartmentOne` НЕ ДОЛЖНЫ заполняться автоматически

### Requirement: Ошибочный callback поддерживает ограниченные retries

Для configured retry codes сервис ДОЛЖЕН повторно отправить ту же task и target version, увеличивая `attempts`, но не превышая `maxRetries`.

#### Scenario: Ошибка retryable и лимит не достигнут

- **WHEN** code входит в retryCodes и attempts меньше maxRetries
- **THEN** task ДОЛЖНА вернуться в `new`, attempts увеличиться на один, ZIP пересобраться из тех же version attachments

#### Scenario: Ошибка non-retryable или лимит исчерпан

- **WHEN** retry запрещён
- **THEN** task ДОЛЖНА остаться `error`, attachments target version ДОЛЖНЫ быть очищены
- **AND** первичная оценка должна выполнить `error→new`, переоценка — `errorReestimate→approved`

### Requirement: Ошибка переоценки не уничтожает предыдущую одобренную версию

При terminal failure версии N+1 агент ДОЛЖЕН сохранить `agentVersionNumber=N` и ранее одобренные risks/links; owner ДОЛЖЕН быть восстановлен по history, если workflow временно изменил его.

#### Scenario: Переоценка approved agent неуспешна

- **WHEN** retries исчерпаны
- **THEN** agent status ДОЛЖЕН вернуться в `approved`
- **AND** поле `lastEvaluationFailed` ДОЛЖНО стать истинным для уполномоченных ролей

### Requirement: Зависшие evaluations обрабатываются по timeout

Scheduled handler ДОЛЖЕН находить `new` tasks старше configured timeout, обрабатывать их по retry/fail policy и поддерживать точечный internal вызов по taskId.

#### Scenario: Task зависла

- **WHEN** callback не пришёл за timeoutSeconds
- **THEN** handler ДОЛЖЕН выполнить контролируемый retry либо terminal failure
- **AND** записать metric с task correlation без payload документов

### Requirement: Вычисляемые результаты доступны только нужным ролям

`maxRiskLevel` на `AGENT` и на `AgentRiskCategory` (вложенные dependents с `objectType=category`) является **сохраняемым атрибутом** бизнес-объекта. Значение пересчитывается и сохраняется в JSONB `DATA` колонку через универсальную модель `RestBusinessObject` (секция `fields`) при создании/обновлении связанных рисков через risk pipeline stage. Поле уже определено в `fields/agent.yaml` и `AgentBusinessFields.MAX_RISK_LEVEL`.

Сервис ДОЛЖЕН:
1. При создании или обновлении риска, связанного с агентом (через `riskToAgent` или `riskToAgentCategory`), пересчитывать `maxRiskLevel` для соответствующего агента и/или категории.
2. Сохранять пересчитанное значение в JSONB `DATA` поля агента через Jimmer dirty tracking.
3. Пересчёт выполняется через цепочку stage-ов в risk pipeline: `UpdateAgentStage` (в risk pipeline, после commit) → делегирование в `AgentGenericPipelines.getRecalculatePipeline()` → `AgentRiskLevelStage` (в agent pipeline) → `AgentCategoryService.calculateRiskLevel()`.
4. **Для `AgentRiskCategory` используется поле `MAX_RISK_LEVEL_NAME`** (ранее для категорий использовалось `STATUS_NAME`, что было некорректно).

#### Scenario: Оценка агента завершена и maxRiskLevel сохранён

- **WHEN** callback оценки обрабатывается и риски создаются/обновляются (createEvaluationPipeline)
- **THEN** риск-пайплайн ДОЛЖЕН запустить `UpdateAgentStage` который найдёт агентов через `relatedRiskAgentIdsResolver`
- **AND** делегирует пересчёт в `AgentGenericPipelines.getRecalculatePipeline()` → `AgentRiskLevelStage` → `AgentCategoryService.calculateRiskLevel()`
- **AND** `GET /api/v1/risks/agents/{id}` ДОЛЖЕН возвращать сохранённое значение

#### Scenario: Риск обновлён и maxRiskLevel пересчитан

- **WHEN** `riskLevel` связанного с агентом риска изменяется (пользователем или AI-оценкой)
- **THEN** риск-пайплайн ДОЛЖЕН запустить `UpdateAgentStage`
- **AND** пересчитанный `maxRiskLevel` для агента и категорий ДОЛЖЕН быть сохранён в JSONB `DATA` через Jimmer

#### Scenario: maxRiskLevel отсутствует (legacy agent)

- **WHEN** карточка legacy-агента открывается и в `data.fields.maxRiskLevel` нет значения
- **THEN** поле будет пустым — при следующем обновлении связанного риска пересчёт выполнится и сохранит значение

#### Scenario: Роли и видимость сохранённого поля

- **WHEN** пользователь с `AgentRisks.View` открывает карточку агента
- **THEN** `maxRiskLevel` ДОЛЖЕН быть возвращён в ответе согласно существующей логике видимости (только для `approved` агента на уровне агента; категории — всегда видимы)
- **AND** для неавторизованных ролей поле не ДОЛЖНО содержать чувствительные данные

### Requirement: Логи оценки минимизируют чувствительные данные

Сервис НЕ ДОЛЖЕН логировать bytes ZIP, document content, raw reasoning, полный callback или персональные данные; допустимы taskId, tenant-safe correlation, agentId, version, counts, sizes и error class/code.

#### Scenario: Callback содержит reasoningRaw

- **WHEN** callback обрабатывается
- **THEN** `reasoningRaw` НЕ ДОЛЖЕН попадать в application log

### Requirement: Агент создаёт modelType category при наличии modelRisk

После создания modelRisk (через pipeline `processEvaluation` → `FixedAgentRisks.toEvaluations()`) сервис ДОЛЖЕН проверить наличие категории `categoryType=modelType` в `agent.data.categories`. Если категория отсутствует — создать её с `status=notAssessed`.

**Важно:** создание категории `modelType` происходит в `AgentEvaluationServiceImpl.process()` — после обработки всех evaluations, а не в `FixedAgentRisks.toEvaluations()`. Пайплайн `toEvaluations()` создаёт только сам риск `modelRisk`.

Подробный workflow категории `modelType` описан в capability `agent-model-risk-workflow`.

#### Scenario: Агент получил modelRisk через callback
- **WHEN** modelRisk создан и агент не имеет категории `modelType`
- **THEN** сервис ДОЛЖЕН создать категорию `modelType` в `agent.data.categories`
- **AND** категория ДОЛЖНА иметь `status=notAssessed`

#### Scenario: modelType уже существует
- **WHEN** modelRisk создан/обновлён и категория `modelType` уже существует
- **THEN** сервис НЕ ДОЛЖЕН создавать дубликат

### Requirement: modelRisk участвует в расчёте maxRiskLevel

`modelRisk.riskLevel` ДОЛЖЕН учитываться при расчёте интегрального уровня риска агента (`agent.maxRiskLevel`), наравне с другими agency-рисками агента.

Пересчёт выполняется через `AgentMaxRiskLevelService.recalculate()` при переходе категории `modelType` в статус `assessed` (вызывается из `GenericAgentRiskCategoryWorkflow.onActionApplied()`).

#### Scenario: modelRisk установлен, maxRiskLevel пересчитан
- **WHEN** `modelRisk.riskLevel=high` и остальные риски агента имеют максимальный уровень `medium`
- **THEN** `agent.maxRiskLevel` ДОЛЖЕН быть равен `high`

#### Scenario: modelRisk не задан, maxRiskLevel не меняется
- **WHEN** `modelRisk.riskLevel=null` (начальное состояние)
- **THEN** modelRisk НЕ ДОЛЖЕН влиять на `agent.maxRiskLevel` (должен учитываться только при не-null значении)

### Requirement: Category modelType доступна в статусах review и approved

Actions для категории `modelType` ДОЛЖНЫ быть доступны как в статусе `review`, так и в статусе `approved` агента. Для остальных категорий (`operationalType`, `securityType`, `reliabilityType`) actions доступны только в статусе `review`.

Реализация: `AgentLinkComponentResolver.resolveActions()` проверяет `REVIEW.equals(status) || (APPROVED.equals(status) && MODEL.equals(categoryType))`.

### Requirement: Пересчёт maxRiskLevel через risk pipeline stage

При создании или обновлении риска в любом risk pipeline, после commit, ДОЛЖЕН вызываться `UpdateAgentStage`, который пересчитывает и сохраняет `maxRiskLevel` на всех связанных агентах.

Архитектура пересчёта (rework от 2026-07-31):
```
UpdateAgentStage (RiskCtx)
  ├── relatedRiskAgentIdsResolver.resolve(riskBusinessId)  → List<String> agentIds
  └── agentIds.forEach(agentId → AgentGenericPipelines.getRecalculatePipeline())
        └── AgentRiskLevelStage (AgentCtx)
              └── AgentCategoryService.calculateRiskLevel(agent, risksByCategory)
                    ├── resolveMaxRiskLevel(allRisks) → agent maxRiskLevel
                    └── categories.forEach(cat → resolveMaxRiskLevel(catRisks) → category maxRiskLevel)
```

- `RecalcAgentMaxRiskStage` и `AgentMaxRiskLevelRecalcService` удалены (были в предыдущей итерации).
- `AgentUiFieldsResolver` и `AgentLinkComponentResolver` более не вызываются напрямую — логика пересчёта инкапсулирована в `AgentCategoryServiceImpl`.

#### Scenario: Создание риска через UI pipeline

- **WHEN** `POST /api/v1/risks/create` создаёт новый риск
- **THEN** `UpdateAgentStage` в `createUiPipeline` ДОЛЖЕН найти агентов через `relatedRiskAgentIdsResolver`
- **AND** делегировать пересчёт в `AgentGenericPipelines.getRecalculatePipeline()`
- **AND** `AgentCategoryService.calculateRiskLevel()` сохранит `maxRiskLevel` для каждого агента и его категории

#### Scenario: Пользовательское обновление риска

- **WHEN** `POST /api/v1/risks/update` обновляет существующий риск
- **THEN** `UpdateAgentStage` в `updateUiPipeline` ДОЛЖЕН запустить пересчёт
- **AND** пересчёт выполняется через `AgentCategoryService.calculateRiskLevel()` — инкапсулированная логика с `resolveMaxRiskLevel()`

#### Scenario: Риск не связан с агентами

- **WHEN** риск не имеет связей с агентами через Link-систему
- **THEN** `UpdateAgentStage` ДОЛЖЕН завершиться без действия (no-op) — `relatedRiskAgentIdsResolver.resolve()` вернёт пустой список
- **AND** операция обновления риска завершается успешно без side-эффектов

#### Scenario: Multiple risks update

- **WHEN** `POST /api/v1/risks/upload` создаёт/обновляет N рисков (bulk pipeline)
- **THEN** `UpdateAgentStage` ДОЛЖЕН срабатывать для каждого риска
- **AND** каждый вызов делает отдельный RPC к Link-Service через `relatedRiskAgentIdsResolver`

### Requirement: UpdateSource для агентов при рекалькуляции

При вызове рекалькуляции агента из риск-пайплайна, `UpdateSource` больше не извлекается из `RiskCtx` — он захардкожен в `AUTOREG`.

- **WHEN** `UpdateAgentStage` создаёт `AgentDao` через `agentDaoFactory.create(updateSource, updater)`
- **THEN** `updateSource` ДОЛЖЕН быть `AUTOREG` (поле `UpdateSource` удалено из `GenericCtx`)
- **AND** `updater` берётся из `ctx.getUpdater()`

### Requirement: Backward compatible API response

API response для карточки агента ДОЛЖЕН оставаться обратной совместимым: `maxRiskLevel` в ответе имеет ту же структуру (string, dictionary-backed) независимо от источника значения (persisted vs computed).

#### Scenario: UI запрашивает карточку агента

- **WHEN** UI вызывает `GET /api/v1/risks/agents/{id}`
- **THEN** response содержит `maxRiskLevel` как string в `fields` агента
- **AND** структура ответа НЕ ДОЛЖНА отличаться от текущей

## Публичные операции capability

| Операция | Permission |
|---|---|
| Agent search/view/refresh | `AgentRisks.View` |
| Agent create/update/start assessment | `AgentRisks.Create` |
| Agent workflow | `AgentRisks.Edit` |
| Attachment save | `AgentRisks.Edit` |
| Attachment list/download | `AgentRisks.View` |
| Evaluation callback/hanging handler | доверенный internal service identity |
