# Спецификация реестра рисков

## Назначение

Определить нормативное поведение центрального реестра рисков: модель данных, создание и изменение, поиск, server-driven карточку, финансовые эффекты, КИР, связи, историю и workflow.

## Каноническая модель

### Агрегат Risk

| Группа | Канонические поля |
|---|---|
| Идентичность | `businessId`, `businessUiId`, system UUID, `tenantId`, `version` |
| Описание | `description`, `summary`, `ownerDepartment`, `relatedRisk`, `riskFactors`, `results` |
| Оценка | `probability`, `criticality`, `riskLevel`, `trend`, `strategy`, `riskProfile`, `causeType` |
| Происхождение | `source`, `sourceBusinessId`, `sourceBusinessUiId`, `author`, `authorType`, `assessmentTask` |
| Объект оценки | `assessmentObjectType`, `assessmentObjectName`, `aiRiskType`, `conductRiskType` |
| Жизненный цикл | `status`, `timeCreated`, `lastChangeDate`, `timeUpdated`, `actingFrom`, `actingTo` |
| Расчётные признаки | `isNew`, `onReassessment`, `isHigh`, `isSenate`, `isMeasureLink`, `isLimitExists` |
| Финансовые показатели | `riskLoss`, `riskNearMiss`, `riskCredit`, `riskFactSum`, `riskLosses`, `limitLoss`, `limitNearMiss`, `limitCredit` |
| Технические данные | `semanticVector`, `uiFilter`, `updaterTaskId`, update source |

### Дочерние элементы

| Object type | Поля |
|---|---|
| `effect` | `version`, `riskId`, `finEffectNature`, `assessmentSum`, `factSum`, `projectedAmount`, `limit`, `period`, `lastChangeDate`, utilization fields |
| `kir` | `type`, current/previous percentages and dates, `state`, calculated change fields |

## Требования

### Requirement: Риск создаётся как tenant-scoped агрегат

Сервис ДОЛЖЕН создавать риск только в текущем tenant-контексте, назначать системный UUID, уникальные `businessId`/`businessUiId`, начальную версию, `actingFrom`, автора и источник.

#### Scenario: Пользователь создаёт риск

- **WHEN** пользователь с `Risk.Create` отправляет валидную модель без существующего `businessId`
- **THEN** сервис ДОЛЖЕН создать одну текущую запись `RISK`
- **AND** вернуть полную server-driven карточку созданного риска

#### Scenario: Клиент пытается задать tenant или системный UUID

- **WHEN** входной business object содержит управляемые сервером поля идентичности
- **THEN** сервис ДОЛЖЕН игнорировать их либо отклонить запрос
- **AND** НЕ ДОЛЖЕН записывать клиентское значение вместо server context

### Requirement: Канонические обязательные поля валидируются

Для обычного риска сервис ДОЛЖЕН валидировать обязательность и ограничения полей активного профиля, включая `description`, `author`, `ownerDepartment`, `status` и применимые поля оценки.

#### Scenario: Описание превышает профильный предел

- **WHEN** `description` превышает допустимую длину, равную 150 для default profile
- **THEN** команда ДОЛЖНА быть отклонена field-level ошибкой до commit

#### Scenario: Условно обязательное поле не заполнено

- **WHEN** выбранные `relatedRisk`, `assessmentObjectType` или иное поле делают зависимое поле обязательным
- **THEN** сервис ДОЛЖЕН применить профильную зависимую валидацию

### Requirement: Справочные значения проверяются сервером

Значения `ownerDepartment`, `status`, `probability`, `criticality`, `relatedRisk`, `strategy`, `riskLevel`, `riskSource`, `aiRiskType`, `conductRiskType` и других dictionary-backed полей ДОЛЖНЫ проверяться по актуальному справочнику и selectable policy.

#### Scenario: Передано неизвестное значение справочника

- **WHEN** клиент передаёт значение, отсутствующее или недоступное в активном dictionary branch
- **THEN** сервис ДОЛЖЕН отклонить поле и вернуть допустимые/локализуемые сведения об ошибке

### Requirement: Расчётные поля не принимаются на доверии

`riskLevel`, `trend`, `isHigh`, финансовые итоги, utilization и иные вычисляемые поля ДОЛЖНЫ вычисляться или проверяться сервером согласно активному профилю и источнику операции.

#### Scenario: Клиент подменяет рассчитанный уровень

- **WHEN** команда содержит `riskLevel`, не соответствующий `probability` и `criticality`
- **THEN** сервис ДОЛЖЕН вычислить корректное значение либо отклонить несогласованную модель

### Requirement: Риск обновляется с optimistic locking

Изменение существующего риска ДОЛЖНО требовать актуальную `version`, загружать current revision, проверять edit permission и сохранять historic revision.

#### Scenario: Версия актуальна

- **WHEN** пользователь с `Risk.Create` отправляет допустимое изменение текущей версии
- **THEN** сервис ДОЛЖЕН создать следующую версию и вернуть обновлённую карточку

#### Scenario: Версия устарела

- **WHEN** с момента открытия карточки другой процесс увеличил `version`
- **THEN** сервис ДОЛЖЕН вернуть version collision без потери более нового изменения

### Requirement: Refresh выполняет валидацию без сохранения

`POST /api/v1/risks/refresh` ДОЛЖЕН пересчитать форму, справочники, зависимые поля, видимость и ошибки для переданной модели, не создавая новой версии риска.

#### Scenario: Изменено поле с refresh semantics

- **WHEN** пользователь меняет `probability`, `criticality`, `relatedRisk` или `assessmentObjectType` и вызывает refresh
- **THEN** ответ ДОЛЖЕН содержать пересчитанную модель и форму
- **AND** БД НЕ ДОЛЖНА быть изменена

### Requirement: Карточка риска является server-driven

`GET /api/v1/risks/{id}` ДОЛЖЕН возвращать entity, дочерние `effect`/`kir`, links, attachments, dictionaries, employees, validation metadata, workflow actions и view config, применимые пользователю.

#### Scenario: Карточка открыта на просмотр

- **WHEN** `edit=false` и пользователь имеет `Risk.View`
- **THEN** сервис ДОЛЖЕН вернуть видимые поля и связи без разрешения редактирования

#### Scenario: Карточка открыта на редактирование

- **WHEN** `edit=true`, permission и domain guards допускают изменение
- **THEN** ответ ДОЛЖЕН отметить только реально редактируемые поля

#### Scenario: Нет права на конкретный объект

- **WHEN** общая permission есть, но object-level visibility запрещает доступ
- **THEN** сервис ДОЛЖЕН вернуть запрет, не раскрывая значения объекта

### Requirement: Поиск рисков поддерживает структурированные фильтры

`POST /api/v1/risks/search` ДОЛЖЕН поддерживать текстовый query, boolean filters, dictionary filters, date ranges и amount ranges активного profile section.

#### Scenario: Выполнен комбинированный поиск

- **WHEN** запрос содержит текст, несколько справочных фильтров и диапазон даты
- **THEN** сервис ДОЛЖЕН применить их с документированной AND/OR-семантикой
- **AND** вернуть `total` и ограниченный массив FormComponent

#### Scenario: Передан неизвестный фильтр

- **WHEN** поле не входит в разрешённую filter structure выбранной секции
- **THEN** сервис ДОЛЖЕН отклонить его или безопасно исключить согласно публичному контракту
- **AND** НЕ ДОЛЖЕН интерпретировать поле как произвольный SQL/JSON path

### Requirement: Структура фильтров выдаётся отдельно

`POST /api/v1/risks/filters` и dictionary endpoints ДОЛЖНЫ возвращать доступные поля, типы, formats, operations и значения для текущего профиля и пользователя.

#### Scenario: Профили тенантов различаются

- **WHEN** tenant A и tenant B используют разные risk profile
- **THEN** каждый пользователь ДОЛЖЕН получить только структуру своего профиля

### Requirement: Зона внимания рассчитывается из доступных рисков

Endpoints attention zone ДОЛЖНЫ агрегировать только риски, видимые текущему пользователю и tenant, и возвращать counts/summary/graph в настроенной структуре.

#### Scenario: Пользователь запрашивает зону внимания

- **WHEN** пользователь имеет `Risk.View` или `Home.AttentionZone` для соответствующей операции
- **THEN** агрегаты ДОЛЖНЫ учитывать те же visibility filters, что и реестр

### Requirement: Workflow риска соблюдает state machine

Сервис ДОЛЖЕН поддерживать следующие переходы:

| Текущий статус | Действие | Целевой статус |
|---|---|---|
| `active` | `delete` | `archive` |
| `active` | `decline` | `declined` |
| `active` | `recover` | `active` |
| `archive` | `transfer` | `active` |
| `declined` | `approve` | `active` |
| `inReview` | `accept` | `active` |
| `inReview` | `reject` | `declined` |
| `draft` | `reject` | `deletedDraft` |

#### Scenario: Архивируется обычный активный риск

- **WHEN** пользователь с допустимой ролью вызывает `delete` и guards `notHasLimitCurrent`, `agencyForRoles`, `notConductRisk` проходят
- **THEN** риск ДОЛЖЕН перейти из `active` в `archive`
- **AND** комментарий ДОЛЖЕН быть сохранён в истории, если передан/обязателен

#### Scenario: Риск имеет текущий лимит

- **WHEN** guard запрещает `delete` из-за действующего лимита
- **THEN** действие НЕ ДОЛЖНО выдаваться в карточке и ДОЛЖНО быть отклонено при прямом вызове

#### Scenario: Поведенческий риск пытаются изменить обычным workflow

- **WHEN** `relatedRisk=conduct` и действие имеет guard `notConductRisk`
- **THEN** сервис ДОЛЖЕН запретить действие

### Requirement: Workflow action сохраняет историю перехода

Успешное действие ДОЛЖНО фиксировать исходный и целевой статус, action id, timestamp, инициатора, роли/источник и comment.

#### Scenario: Действие успешно выполнено

- **WHEN** workflow guard и валидация проходят
- **THEN** история `GET /api/v1/risks/{id}/history` ДОЛЖНА содержать переход и field/link changes новой версии

### Requirement: Финансовые эффекты принадлежат версии риска

`effect` ДОЛЖЕН иметь ссылку `riskId`, период, природу финансового эффекта, суммы и собственную version semantics; изменения effects ДОЛЖНЫ согласовываться с версией родителя.

#### Scenario: Обновляется сумма эффекта

- **WHEN** пользователь меняет допустимый effect в составе риска
- **THEN** сервис ДОЛЖЕН валидировать денежный тип, период и `finEffectNature`
- **AND** пересчитать связанные итоги и utilization

#### Scenario: Дублируется effect business key

- **WHEN** два эффекта имеют запрещённую комбинацию `riskId`/`finEffectNature`/`period`
- **THEN** сервис ДОЛЖЕН отклонить агрегат до commit

### Requirement: КИР сохраняет сравнимые значения

Элемент `kir` ДОЛЖЕН хранить тип показателя, новое и предыдущее значение/дату, состояние и вычисленное изменение в сопоставимых единицах.

#### Scenario: Добавлен КИР

- **WHEN** данные содержат корректный dictionary type и percentage/date values
- **THEN** сервис ДОЛЖЕН вычислить UI/change fields и включить элемент в историю версии

### Requirement: Связи риска типизированы

Сервис ДОЛЖЕН разрешать только известные link types и корректное направление, включая `riskToMeasure`, `riskToMeasureDraft`, `riskToAgent`, `riskToAgentCategory`, `riskToProduct`, `riskToProductCategory`, `riskToAssessmentTask` и `riskToInfoFeed`.

#### Scenario: Создаётся связь с мерой

- **WHEN** пользователь выбирает доступную меру через link search
- **THEN** сервис ДОЛЖЕН проверить существование обоих объектов, tenant/access и отсутствие запрещённого дубликата

#### Scenario: Передан неизвестный linkType

- **WHEN** клиент отправляет link type вне настроенного allowlist
- **THEN** сервис ДОЛЖЕН отклонить связь до внешнего вызова

### Requirement: Link search ограничен контекстом

`POST /api/v1/risks/links/search` ДОЛЖЕН искать только поддерживаемый тип объекта по неполному идентификатору/названию, применяя tenant, visibility, status и server limit.

#### Scenario: Поиск не находит доступных объектов

- **WHEN** совпадения существуют только в другом tenant или недоступны пользователю
- **THEN** ответ ДОЛЖЕН вернуть пустой список без раскрытия чужих идентификаторов

### Requirement: Риски от ИИ-источников маркируются

Риск, созданный переоценкой, агентской или поведенческой оценкой, ДОЛЖЕН иметь `source`, `updaterTaskId`/`assessmentTask`, тип происхождения и link к исходному объекту.

#### Scenario: Агент создаёт новый AI risk

- **WHEN** callback оценки создаёт риск по `riskType`
- **THEN** риск ДОЛЖЕН быть связан с агентом и задачей
- **AND** содержать `aiRiskType`, рассчитанные поля и технического автора/источник

### Requirement: Обновление ИИ-риска не создаёт логический дубль

При повторной оценке сервис ДОЛЖЕН находить активный риск данного агента по каноническому AI risk type и обновлять его, если он существует.

#### Scenario: Риск того же типа уже связан с агентом

- **WHEN** новая evaluation содержит существующий `riskType`
- **THEN** сервис ДОЛЖЕН обновить существующий risk businessId
- **AND** НЕ ДОЛЖЕН создать второй активный риск того же логического типа для того же агента

### Requirement: Поведенческие риски доступны по productId

Internal endpoint `GET /api/v1/conduct-risks/{productId}` ДОЛЖЕН возвращать только риски, связанные с указанным продуктом типом `riskToProduct`, в tenant-контексте вызова.

#### Scenario: Продукт не принадлежит tenant

- **WHEN** internal caller передаёт productId другого tenant
- **THEN** сервис ДОЛЖЕН вернуть not found/empty согласно internal contract без чужих данных

### Requirement: Semantic vector управляется асинхронно

Векторизация ДОЛЖНА использовать стабильный ключ tenant+risk businessId, обновлять `semanticVector` только для актуальной версии и быть безопасной при повторном запуске.

#### Scenario: Риск изменился до завершения векторизации

- **WHEN** результат рассчитан для устаревшего текста/версии
- **THEN** сервис ДОЛЖЕН отбросить его или запланировать расчёт для новой версии

### Requirement: Массовая загрузка административно ограничена

`POST /api/v1/risks/upload` ДОЛЖЕН быть доступен только с `Administration.View`, валидировать формат/размер файла и выполнять построчную доменную валидацию.

#### Scenario: Файл частично невалиден

- **WHEN** часть строк не проходит валидацию
- **THEN** сервис ДОЛЖЕН вернуть структурированный отчёт об ошибках
- **AND** применить документированную атомарную или batch semantics без молчаливой потери строк

### Requirement: Реактивация списка рисков контролируема

Internal операция reactivate ДОЛЖНА принимать ограниченный список ids, обрабатывать только допустимые статусы и быть идемпотентной.

#### Scenario: Список содержит активный и архивный риск

- **WHEN** команда повторно активирует оба id
- **THEN** архивный риск ДОЛЖЕН стать активным, а уже активный остаться без дублирующей версии, если данные не менялись

### Requirement: Удаление является логическим

Публичный lifecycle риска НЕ ДОЛЖЕН физически удалять current/historic данные при действиях `delete`, `decline` или `reject`; он ДОЛЖЕН использовать статусы.

#### Scenario: Черновик отклонён

- **WHEN** `draft` получает `reject`
- **THEN** статус ДОЛЖЕН стать `deletedDraft`
- **AND** объект ДОЛЖЕН остаться доступным для аудита согласно retention policy

### Requirement: Под-роли регулятора имеют право редактирования полей Agency-рисков

Сервис ДОЛЖЕН разрешать редактирование полей `riskLevel`, `summary` и `strategy` для пользователей с ролью `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_REGULATOR_UKII` или `ORMCLOUD_REGULATOR_DTN` на Agency-рисках, наравне с `ORMCLOUD_REGULATOR` и `ORMCLOUD_PARTNER`.

#### Scenario: Пользователь с ORMCLOUD_REGULATOR_UMR редактирует riskLevel

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь имеет роль `ORMCLOUD_REGULATOR_UMR` и форму открыта с `edit=true`
- **THEN** поле `riskLevel` ДОЛЖНО иметь `editable: true`

#### Scenario: Пользователь с ORMCLOUD_REGULATOR_UKII редактирует riskLevel

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь имеет роль `ORMCLOUD_REGULATOR_UKII` и форму открыта с `edit=true`
- **THEN** поле `riskLevel` ДОЛЖНО иметь `editable: true`

#### Scenario: Пользователь с ORMCLOUD_REGULATOR_DTN редактирует riskLevel

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь имеет роль `ORMCLOUD_REGULATOR_DTN` и форму открыта с `edit=true`
- **THEN** поле `riskLevel` ДОЛЖНО иметь `editable: true`

#### Scenario: Пользователь с под-ролью регулятора редактирует summary на Agency-риске

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь имеет любую из ролей `ORMCLOUD_REGULATOR`, `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_REGULATOR_UKII`, `ORMCLOUD_REGULATOR_DTN` или `ORMCLOUD_PARTNER` и форму открыта с `edit=true`
- **THEN** поле `summary` ДОЛЖНО иметь `editable: true`

#### Scenario: Пользователь с под-ролью регулятора редактирует strategy на Agency-риске

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь имеет любую из ролей `ORMCLOUD_REGULATOR`, `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_REGULATOR_UKII`, `ORMCLOUD_REGULATOR_DTN` или `ORMCLOUD_PARTNER` и форму открыта с `edit=true`
- **THEN** поле `strategy` ДОЛЖНО иметь `editable: true`

#### Scenario: Пользователь без под-роли не может редактировать поля

- **WHEN** риск имеет `relatedRisk = "Agency"`, пользователь НЕ имеет ни одной из разрешённых ролей и форму открыта с `edit=true`
- **THEN** поля `riskLevel`, `summary` и `strategy` ДОЛЖНЫ иметь `editable: false`

#### Scenario: Под-роли регулятора учитываются при проверке edit-доступа к риску

- **WHEN** риск НЕ является Agency-риском, пользователь имеет роль `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_REGULATOR_UKII` или `ORMCLOUD_REGULATOR_DTN`
- **THEN** метод `resolveEditable()` ДОЛЖЕН возвращать `false` (регулятор не редактирует не-Agency риски)

### Requirement: Обновление riskLevel триггерит пересчёт maxRiskLevel на агентах

При изменении поля `riskLevel` на сущности `Risk` сервис ДОЛЖЕН найти все связанные агенты и категории через Link-систему и пересчитать их интегральный `maxRiskLevel`.

Пересчёт выполняется через `UpdateAgentStage` — stage в риск-пайплайнах, после `commit`.
(См. архитектуру в `specs/agent-risk-assessment/spec.md` — `UpdateAgentStage` делегирует в `AgentGenericPipelines.getRecalculatePipeline()`.)

#### Scenario: Риск обновлён публичным API

- **WHEN** `POST /api/v1/risks/update` изменяет `riskLevel` на существующем риске
- **THEN** `UpdateAgentStage` ДОЛЖЕН найти все `riskToAgent` и `riskToAgentCategory` связи через `relatedRiskAgentIdsResolver`
- **AND** запустить пересчёт `maxRiskLevel` для каждого найденного агента через `AgentGenericPipelines.getRecalculatePipeline()`
- **AND** сохранить результаты через Jimmer dirty tracking

#### Scenario: Риск имеет множественные связи

- **WHEN** один риск связан с 10 агентами через `riskToAgent`
- **THEN** `UpdateAgentStage` ДОЛЖЕН обновить `maxRiskLevel` для всех 10 агентов
- **AND** если пересчёт одного агента завершился ошибкой, остальные должны быть обработаны

#### Scenario: RiskLevel изменён на null

- **WHEN** `riskLevel` установлен в null
- **THEN** сервис ДОЛЖЕН интерпретировать это как "not estimated" и пересчитать
- **AND** если у агента не осталось рисков с populated `riskLevel`, `maxRiskLevel` ДОЛЖЕН стать `null`

### Requirement: Удаление риска триггерит пересчёт maxRiskLevel

При удалении (логическом — смене статуса на `archive`/`deletedDraft`) риска сервис ДОЛЖЕН пересчитать `maxRiskLevel` на всех связанных агентах.

#### Scenario: Риск архивируется

- **WHEN** `POST /api/v1/risks/workflow` с действием `delete` переводит риск в статус `archive`
- **THEN** `UpdateAgentStage` в `workflowPipeline` ДОЛЖЕН найти все `riskToAgent` связи
- **AND** пересчитать `maxRiskLevel` агентов без учёта архивного риска

### Requirement: Создание риска триггерит пересчёт maxRiskLevel

При создании нового риска (через pipeline создания/оценки) сервис ДОЛЖЕН пересчитать `maxRiskLevel` на всех связанных агентах.

#### Scenario: AI-агент создаёт новый риск через оценку

- **WHEN** `RiskEvaluationServiceImpl.create()` создаёт риск с новым `aiRiskType`
- **THEN** `UpdateAgentStage` в `createEvaluationPipeline` ДОЛЖЕН найти `riskToAgent` связи и пересчитать `maxRiskLevel` агента
- **AND** сохранить результат через Jimmer

### Requirement: Batch операций не блокируется пересчётом maxRiskLevel

Пересчёт `maxRiskLevel` выполняется синхронно в рамках того же batch-цикла, но в отдельной DB транзакции для каждого агента.

#### Scenario: Batch upload содержит 500 рисков

- **WHEN** `POST /api/v1/risks/upload` обрабатывает файл с 500 рисками
- **THEN** `UpdateAgentStage` ДОЛЖЕН сработать 500 раз (по одному на риск в updateBulkPipeline)
- **AND** каждый вызов делает отдельный RPC к Link-Service через `relatedRiskAgentIdsResolver`

## Публичные операции capability

| Операция | Permission | Семантика |
|---|---|---|
| `POST /api/v1/risks/search` | `Risk.View` | поиск реестра |
| `GET /api/v1/risks/{id}` | `Risk.View` | карточка просмотра/редактирования |
| `POST /api/v1/risks/update` | `Risk.Create` | create/update с версией |
| `POST /api/v1/risks/refresh` | `Risk.Create` | пересчёт без commit |
| `POST /api/v1/risks/workflow` | `Risk.Create` | workflow action |
| `GET /api/v1/risks/{id}/history` | `Risk.View` | история версий и переходов |
| `POST /api/v1/risks/filters` | `Risk.View` | filter model |
| `POST /api/v1/risks/links/search` | `Risk.View` | поиск объектов для связи |
| `GET /api/v1/risks/attention-zone` | `Risk.View` | агрегаты зоны внимания |
| `GET /api/v1/risks/attention-zone-total` | `Home.AttentionZone` | сводная зона внимания |
| `POST /api/v1/risks/upload` | `Administration.View` | административный импорт |
