# Спецификация MCP-интеграции с агентом

## Назначение

Определить безопасный и стабильный Model Context Protocol interface сервиса `risk-cloud`: discovery, аутентификацию, tenant binding, JSON Schema tools, чтение рисков, создание/обновление риска, создание инфоповода, ошибки, идемпотентность и наблюдаемость.

## Транспорт и capabilities

MCP server реализуется поверх Spring AI MCP Server WebMVC. Точный endpoint/transport ДОЛЖЕН задаваться конфигурацией deployment и публиковаться интеграторам; бизнес-контракт НЕ ДОЛЖЕН зависеть от дефолтного URL конкретной версии библиотеки.

Server публикует только tools. Resources/prompts НЕ СЧИТАЮТСЯ доступными, пока не добавлены отдельной capability-спецификацией.

## Каталог tools

| Tool | Аргументы | Result |
|---|---|---|
| `getAllRisks` | `tenantId: string`, `inn: string` | JSON array business objects |
| `createOrUpdateRisk` | `tenantId: string`, `taskUpdaterId?: string`, `riskEntity: BusinessObject` | `{status, businessId?, message?}` |
| `createInfoFeed` | `tenantId: string`, `taskUpdaterId: string`, `infoFeed: BusinessObject` | `{status, businessId?, message?}` |

## Требования

### Requirement: MCP server поддерживает стандартный handshake

Server ДОЛЖЕН корректно согласовать поддерживаемую версию MCP, объявить server identity/capabilities и отклонить несовместимую protocol version контролируемой protocol error.

#### Scenario: Клиент поддерживает совместимую версию

- **WHEN** MCP client выполняет initialize
- **THEN** server ДОЛЖЕН вернуть согласованную версию и capability `tools`

#### Scenario: Версия несовместима

- **WHEN** общего protocol version нет
- **THEN** server ДОЛЖЕН завершить handshake protocol error без выполнения tools

### Requirement: MCP endpoint требует service authentication

До initialize/tool call ingress ДОЛЖЕН аутентифицировать вызывающего агента через платформенный механизм service identity; anonymous access ДОЛЖЕН быть запрещён.

#### Scenario: Credentials отсутствуют или невалидны

- **WHEN** client обращается к MCP endpoint
- **THEN** transport ДОЛЖЕН отклонить запрос до tool dispatch
- **AND** НЕ ДОЛЖЕН раскрывать tool schemas, tenant existence или business data, если policy запрещает discovery

### Requirement: TenantId связан с identity

`tenantId` tool argument ДОЛЖЕН проверяться по allowlist/claims аутентифицированного service principal; аргумент НЕ ДОЛЖЕН сам по себе давать право переключить tenant.

#### Scenario: Агент запрашивает разрешённый tenant

- **WHEN** tenantId входит в claims/assignment principal
- **THEN** server МОЖЕТ установить TenantContext на время tool call

#### Scenario: Агент подставляет чужой tenantId

- **WHEN** tenantId не разрешён identity
- **THEN** server ДОЛЖЕН вернуть authorization error до доступа к registry/cache

### Requirement: TenantContext ограничен одним tool call

Server ДОЛЖЕН устанавливать TenantContext в scoped конструкции и гарантированно очищать его после success/error/cancellation.

#### Scenario: Последовательные вызовы разных tenants используют один thread

- **WHEN** сначала выполнен call tenant A, затем tenant B
- **THEN** второй call НЕ ДОЛЖЕН видеть context или данные tenant A

### Requirement: Tools discovery содержит точные JSON Schema

`tools/list` ДОЛЖЕН объявлять имена, описания, required arguments, types и вложенную schema `BusinessObject`; schema и фактическая десериализация ДОЛЖНЫ совпадать.

#### Scenario: Клиент получает tools/list

- **WHEN** discovery успешен
- **THEN** `tenantId`, `inn`, `riskEntity`, `taskUpdaterId` requirements ДОЛЖНЫ быть отражены без двусмысленного описания create/update

### Requirement: Tool names и семантика версионируются совместимо

Удаление/переименование tool, аргумента или result field является breaking change и ДОЛЖНО сопровождаться versioned migration period либо новой версией tool.

#### Scenario: Добавлено необязательное поле result

- **WHEN** старый клиент игнорирует неизвестные поля
- **THEN** изменение МОЖЕТ считаться backward compatible

### Requirement: Все результаты сериализуются в валидный JSON

Result converter ДОЛЖЕН использовать единый настроенный ObjectMapper; `void` МОЖЕТ представляться как `Done`, но текущие business tools ДОЛЖНЫ возвращать JSON, соответствующий объявленной result schema.

#### Scenario: Result содержит date-time или enum

- **WHEN** converter сериализует объект
- **THEN** representation ДОЛЖНО совпадать с REST conventions и быть UTF-8 JSON

#### Scenario: Сериализация неуспешна

- **WHEN** result нельзя преобразовать в JSON
- **THEN** server ДОЛЖЕН вернуть tool execution error с correlation id
- **AND** НЕ ДОЛЖЕН возвращать partial JSON

### Requirement: getAllRisks требует tenantId и inn

Tool ДОЛЖЕН отклонить null/blank `tenantId` и `inn`; ИНН ДОЛЖЕН проходить формальную проверку и однозначно находиться в tenant directory.

#### Scenario: ИНН не найден

- **WHEN** tenant cache не содержит организацию с указанным INN
- **THEN** tool ДОЛЖЕН завершиться validation/not-found error без данных

### Requirement: getAllRisks ограничивает организационную область

Tool ДОЛЖЕН найти `managementOrgId` организации по INN, получить его dictionary branch и искать risks, чей `ownerDepartment` входит в ветку или равен корню.

#### Scenario: Организация имеет дочерние подразделения

- **WHEN** risks принадлежат корню и дочерним management org items
- **THEN** оба набора ДОЛЖНЫ войти в выборку при прочих условиях

#### Scenario: Dictionary branch недоступен

- **WHEN** managementOrg dictionary не загружен
- **THEN** tool ДОЛЖЕН вернуть dependency error, а не неограниченный список tenant risks

### Requirement: getAllRisks исключает неподходящие риски

Выборка ДОЛЖНА исключать status `deletedDraft` и `relatedRisk` значений `agency`/`conduct`; остальные status filters ДОЛЖНЫ соответствовать документированному текущему контракту.

#### Scenario: Tenant содержит агентские и поведенческие риски

- **WHEN** tool вызывается для общего risk agent use case
- **THEN** agency/conduct risks НЕ ДОЛЖНЫ возвращаться

### Requirement: getAllRisks имеет ограничение объёма

Tool НЕ ДОЛЖЕН возвращать неограниченный массив. Он ДОЛЖЕН поддерживать configurable maximum и, при достижении, pagination/cursor или явный truncated error/result.

#### Scenario: Найдено больше maximum

- **WHEN** count превышает limit
- **THEN** client ДОЛЖЕН получить явный признак неполной выдачи или способ запросить следующую страницу

### Requirement: getAllRisks возвращает transport business objects

Каждый risk ДОЛЖЕН быть преобразован mapper в документированную BusinessObject schema без internal entity fields, semantic vector и иных неразрешённых технических данных.

#### Scenario: Risk содержит скрытые profile fields

- **WHEN** field не разрешено MCP read policy
- **THEN** оно НЕ ДОЛЖНО входить в result

### Requirement: createOrUpdateRisk различает create и update по businessId

Если `riskEntity.businessId` отсутствует, tool ДОЛЖЕН создать риск; если присутствует — найти и обновить существующий риск текущего tenant.

#### Scenario: Create без businessId

- **WHEN** обязательные поля валидны
- **THEN** tool ДОЛЖЕН вернуть `{status:"ok", businessId:<generated>}`

#### Scenario: Update с businessId

- **WHEN** risk существует в tenant
- **THEN** tool ДОЛЖЕН обновить разрешённые MCP fields и вернуть тот же businessId

#### Scenario: Update неизвестного businessId

- **WHEN** risk отсутствует
- **THEN** tool ДОЛЖЕН вернуть error/not-found
- **AND** НЕ ДОЛЖЕН неявно создать объект с клиентским id

### Requirement: MCP update использует allowlist полей

При update сервис ДОЛЖЕН копировать только `description`, `ownerDepartment`, `probability`, `criticality`, `relatedRisk`, `results`, `riskFactors`; identity, status, version, source и системные поля ДОЛЖНЫ сохраняться/рассчитываться сервером.

#### Scenario: Payload пытается изменить status

- **WHEN** riskEntity содержит новый status
- **THEN** MCP update ДОЛЖЕН проигнорировать или отклонить его
- **AND** status current risk НЕ ДОЛЖЕН измениться

### Requirement: MCP create проходит специальный pipeline

Create ДОЛЖЕН применить dictionary validation, required fields, auto-calculation, id generation, audit source `autoreg`, technical updater и tenant context.

#### Scenario: Probability/criticality не согласованы

- **WHEN** payload содержит допустимые inputs
- **THEN** pipeline ДОЛЖЕН рассчитать riskLevel по тем же правилам, что internal MCP path

### Requirement: taskUpdaterId обеспечивает корреляцию

Если `taskUpdaterId` передан, он ДОЛЖЕН ссылаться на существующую assessment task того же tenant или быть отклонён; созданная/обновлённая запись ДОЛЖНА сохранить updater task correlation.

#### Scenario: taskUpdaterId относится к Senate task

- **WHEN** создаётся risk без businessId
- **THEN** source ДОЛЖЕН стать `senate`, а status — `inReview` при завершённой stage Сената, иначе `draft`

#### Scenario: Senate payload пытается обновить существующий risk

- **WHEN** businessId уже присутствует
- **THEN** tool ДОЛЖЕН идемпотентно вернуть существующий id без Senate update согласно текущему контракту

### Requirement: createOrUpdateRisk возвращает стабильный outcome envelope

Business success ДОЛЖЕН иметь `status=ok` и `businessId`; business failure — `status=error`, безопасный `message`/code и без businessId, если commit не произошёл.

#### Scenario: Validation exception

- **WHEN** pipeline отклоняет поля
- **THEN** tool ДОЛЖЕН вернуть/выбросить машинно различимую validation error
- **AND** message НЕ ДОЛЖЕН содержать stack trace, SQL или секреты

### Requirement: Повтор createOrUpdateRisk безопасен

Для create с `taskUpdaterId` и детерминированным внешним key server ДОЛЖЕН предотвращать logical duplicate; update с тем же content НЕ ДОЛЖЕН создавать лишнюю версию.

#### Scenario: Агент повторяет tool после network timeout

- **WHEN** первый call был committed, но response потерян
- **THEN** повтор с тем же idempotency/correlation key ДОЛЖЕН вернуть исходный businessId

### Requirement: createInfoFeed требует taskUpdaterId

Tool ДОЛЖЕН валидировать `tenantId`, `taskUpdaterId` и `infoFeed`; externalId и иные обязательные fields определяются transport profile.

#### Scenario: taskUpdaterId отсутствует

- **WHEN** tool вызван без него
- **THEN** result ДОЛЖЕН быть validation error без создания info feed

### Requirement: Активный инфоповод не дублируется по externalId

Перед create сервис ДОЛЖЕН искать `INFO_FEED` с тем же externalId и status `new` текущего tenant.

#### Scenario: Активный дубль существует

- **WHEN** найдено совпадение
- **THEN** новый объект НЕ ДОЛЖЕН создаваться
- **AND** result ДОЛЖЕН вернуть `status=error` с безопасным локализуемым сообщением или id существующего объекта согласно idempotency policy

#### Scenario: Совпадение только в archive

- **WHEN** прошлый info feed status `archive`
- **THEN** новая запись МОЖЕТ быть создана, если профиль не запрещает

### Requirement: createInfoFeed использует MCP pipeline

Create ДОЛЖЕН сгенерировать businessId, status/default fields, updaterTaskId, audit source, historic semantics и метрику только после commit.

#### Scenario: Pipeline успешен

- **WHEN** infoFeed валиден
- **THEN** tool ДОЛЖЕН вернуть status ok и новый businessId

### Requirement: MCP tools не принимают произвольные links

Текущие публичные MCP tools НЕ ДОЛЖНЫ создавать произвольные связи, если link schema не объявлена tool contract. Internal API с links является отдельным trusted contract.

#### Scenario: BusinessObject содержит pseudo-link field

- **WHEN** field не входит в allowed transport model
- **THEN** сервис ДОЛЖЕН отклонить/игнорировать его без вызова link service

### Requirement: Tool calls имеют timeout, cancellation и payload limits

Server ДОЛЖЕН ограничивать длительность, concurrent calls, request bytes, nesting depth, array sizes и result size; cancellation ДОЛЖНА прекращать незафиксированную работу.

#### Scenario: Аргумент содержит сверхбольшой массив

- **WHEN** payload превышает schema/config limit
- **THEN** call ДОЛЖЕН быть отклонён до domain pipeline

### Requirement: Ошибки разделяются по классам

MCP contract ДОЛЖЕН различать invalid arguments, unauthenticated, forbidden tenant, not found, state/version conflict, dependency unavailable, timeout и internal error.

#### Scenario: Dependency временно недоступна

- **WHEN** dictionary/tenant/link service возвращает retryable failure
- **THEN** tool error ДОЛЖЕН иметь retryable classification
- **AND** НЕ ДОЛЖЕН представляться как validation error пользователя

### Requirement: Наблюдаемость не раскрывает данные

Метрики ДОЛЖНЫ учитывать create risk, update risk, create info feed, error и latency по tool/tenant с ограниченной cardinality. Логи ДОЛЖНЫ содержать request/correlation id, tool name, outcome и duration, но не полный BusinessObject/INN/описание риска.

#### Scenario: Tool завершился exception

- **WHEN** ошибка зафиксирована
- **THEN** counter error ДОЛЖЕН увеличиться один раз с безопасным class tag
- **AND** вызывающая сторона ДОЛЖНА получить correlation id

### Requirement: MCP audit отличает caller и технического updater

Несмотря на технического DB updater, audit ДОЛЖЕН сохранять service principal/agent identity, tenantId, tool name, taskUpdaterId, idempotency key и target businessId.

#### Scenario: Проводится расследование изменения

- **WHEN** риск был обновлён MCP tool
- **THEN** аудит ДОЛЖЕН позволить установить, какой authenticated agent инициировал call

### Requirement: MCP dependency upgrade проходит contract tests

Обновление Spring AI/MCP library ДОЛЖНО проверять handshake, tools/list schemas, call serialization, auth, errors и backward compatibility на фиксированных golden contracts.

#### Scenario: Библиотека меняет default transport path

- **WHEN** версия обновлена
- **THEN** deployment route и client contract НЕ ДОЛЖНЫ измениться без versioned change
