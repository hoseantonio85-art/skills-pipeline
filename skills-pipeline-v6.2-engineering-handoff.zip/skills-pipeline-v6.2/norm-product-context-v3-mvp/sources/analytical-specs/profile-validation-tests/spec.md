# Purpose

Define validation tests for profile configuration loading across all tenants, ensuring BusinessObjectFieldsConfig, WorkflowConfig, and custom loader beans load correctly.

## Requirements

### Requirement: BusinessObjectFieldsConfig beans SHALL load successfully for every tenant
Every `BusinessObjectFieldsConfig` bean created via `ConfigSupplier.create(path, objectType)` SHALL load without errors on every `Supplier.get()` call for every active tenant, and `config.getRootFieldsConfig()` SHALL NOT be null.

#### Scenario: Default profile loads for unknown tenant
- **WHEN** tenant is absent from `config-profiles.yaml`
- **THEN** `ConfigSupplier.create` loads YAML from `profiles/risk/default/`

#### Scenario: Custom profile loads for known tenant
- **WHEN** tenant exists in `config-profiles.yaml` with profile `cb_fin_1`
- **THEN** `ConfigSupplier.create` loads YAML from `profiles/risk/cb_fin_1/`

#### Scenario: Root fields config is non-null
- **WHEN** configuration is loaded
- **THEN** `config.getRootFieldsConfig()` is not null

#### Scenario: Dependent object type fields are non-null
- **WHEN** configuration was created with `dependTypes`
- **THEN** `config.getFieldsConfig(dependType)` is not null for each `dependType`

---

### Requirement: WorkflowConfig beans SHALL load successfully for every tenant
Every `WorkflowConfig` bean created via `ConfigSupplier.create(class, loader)` SHALL load without errors on every `Supplier.get()` call, and both `config.getStatusesConfig()` and `config.getActionsConfig()` SHALL NOT be null.

#### Scenario: Workflow statuses config is non-null
- **WHEN** workflow configuration is loaded
- **THEN** `config.getStatusesConfig()` is not null

#### Scenario: Workflow actions config is non-null
- **WHEN** workflow configuration is loaded
- **THEN** `config.getActionsConfig()` is not null

---

### Requirement: Custom loader beans SHALL load successfully for every tenant
Every bean with a custom loader (`FilterStructureConfig`, `AttentionZoneConfig`, `GigaChatPrompt`) created via `ConfigSupplier.create(class, loader)` SHALL load without errors on every `Supplier.get()` call, and the result SHALL NOT be null.

#### Scenario: FilterStructureConfig loads successfully
- **WHEN** `riskFilterStructureConfigSupplier.get()` is called for any tenant
- **THEN** result is not null

#### Scenario: AttentionZoneConfig loads successfully
- **WHEN** `attentionZoneConfigSupplier.get()` is called for any tenant
- **THEN** result is not null

#### Scenario: GigaChatPrompt loads successfully
- **WHEN** `gigaChatPromptSupplier.get()` is called for any tenant
- **THEN** result is not null

---

### Requirement: All ObjectType constants SHALL be validated
Every `ObjectType` used in configuration classes via `ConfigSupplier.create` SHALL be covered by a test that verifies `config.getFieldsConfig(objectType)` is not null.

#### Scenario: Risk objects validated
- **WHEN** `RiskByProfilesConfig` is tested
- **THEN** all beans with `RISK_OBJECT` are tested: `riskFieldsConfigSupplier`, `riskLinkFieldsConfigSupplier`, `riskSearchFieldsConfigSupplier`, `riskFilterFieldsConfigSupplier`

#### Scenario: InfoFeed objects validated
- **WHEN** `InfoFeedByProfilesConfig` is tested
- **THEN** all beans with `INFO_FEED_OBJECT`, `INFO_FEED_SEARCH_OBJECT`, `INFO_FEED_SOURCE_OBJECT` are tested

#### Scenario: Limit objects validated
- **WHEN** `LimitByProfilesConfig` is tested
- **THEN** all beans with `LIMIT_OBJECT`, `LIMIT_CAMPAIGN_OBJECT`, `LIMIT_CAMPAIGN_RETRO_OBJECT`, `RISK_RETRO_OBJECT` are tested

#### Scenario: AttentionZoneTotal objects validated
- **WHEN** `AttentionZoneTotalByProfilesConfig` is tested
- **THEN** all beans with `GRAPH_OBJECT`, `ATTENTION_ZONE_OBJECT`, `RISK_OBJECT`, `OUT_ZONE_OBJECT`, `SUMMARY_OBJECT` are tested

#### Scenario: Agent objects validated
- **WHEN** `AgentVersionByProfilesConfig` is tested
- **THEN** all beans with `AGENT_OBJECT` are tested

#### Scenario: Agent category objects validated
- **WHEN** `AgentWorkflowConfig` is tested
- **THEN** workflow beans with `CATEGORY_OBJECT` are tested: `agentCategoryOperationalWorkflowSupplier`, `agentCategorySecurityWorkflowSupplier`, `agentCategoryReliabilityWorkflowSupplier`

#### Scenario: Product objects validated
- **WHEN** `ProductByProfilesConfig` is tested
- **THEN** all beans with `PRODUCT_OBJECT` are tested

#### Scenario: AssessmentTask objects validated
- **WHEN** `AssessmentTaskByProfilesConfigs` is tested
- **THEN** all beans with `ASSESSMENT_TASK_OBJECT` are tested

#### Scenario: SenateIssue objects validated
- **WHEN** `SenateIssueByProfilesConfig` is tested
- **THEN** beans with `SENATE_ISSUE_OBJECT` are tested

#### Scenario: Workflow objects validated
- **WHEN** `ProcessByProfilesConfig` and `ProductWorkflowConfig` are tested
- **THEN** all workflow beans are tested: `riskWorkflowConfigSupplier`, `limitCampaignWorkflowConfigSupplier`, `infoFeedWorkflowConfigSupplier`, `productWorkflowConfigSupplier`

---

### Requirement: Test structure SHALL follow existing conventions
Every test class SHALL follow the `BaseProfileTest` and subclass pattern: one class per configuration class, `forAllTenants()` for tenant iteration, one `@Test` method per `@Bean` using `ConfigSupplier.create`.

#### Scenario: Each config class has one test class
- **WHEN** a configuration class is scanned
- **THEN** there exists exactly one `*ProfileTest` class autowiring its beans

#### Scenario: Tests use forAllTenants iteration
- **WHEN** a test method validates a configuration
- **THEN** it invokes `forAllTenants(() -> { ... })` to cover all tenants

#### Scenario: Each @Bean with ConfigSupplier has one test method
- **WHEN** a configuration class is analyzed for `@Bean` methods using `ConfigSupplier.create`
- **THEN** there exists exactly one `@Test` method for each such bean
