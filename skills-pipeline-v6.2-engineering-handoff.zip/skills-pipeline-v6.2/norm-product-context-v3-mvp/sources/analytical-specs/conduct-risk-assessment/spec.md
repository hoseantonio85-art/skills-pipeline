# Спецификация рисков поведения продукта

## Назначение

Определить регистрацию продукта, управление документами, оркестрацию задачи оценки поведенческих рисков, приём созданных ИИ-агентом рисков и завершение жизненного цикла продукта.

## Доменная модель

### `PRODUCT`

`PRODUCT` — tenant-scoped versioned business object с `PRODUCT_HISTORIC`.

| Группа | Поля |
|---|---|
| Идентичность | system UUID, `tenantId`, `businessId`, `businessUiId`, persistence `version` |
| Описание | `productName`, `productStage`, `productDescription` |
| Lifecycle | `status`, `productVersionNumber`, `timeApprove` |
| Аудит/результат | `author`, `maxRiskLevel`, timestamps, updater, update source |

Default profile требует `productName` до 1000, `productStage`, `productDescription` до 2000, `status` и `productVersionNumber`.

### `PRODUCT_ASSESSMENT_TASK`

| Поле | Семантика |
|---|---|
| system UUID | внутренний primary key |
| `business_id` | taskId/correlation key, уникальный в tenant |
| `sys_ownerid` | tenant id |
| `author` | инициатор оценки |
| `type` | `conduct` |
| `time_created` | создание workflow |
| `time_ready_for_start` | документы готовы |
| `time_start_process` | вызов внешнего агента |
| `time_end` | terminal outcome |
| `status` | `pending`, `readyForStart`, `inProcess`, `success`, `error` |
| `file_id_list` | snapshot file ids для оцениваемой версии |
| `error_code` | код/описание ошибки |
| `inn` | ИНН организации tenant |
| `summary` | итоговое описание оценки |

## Требования

### Requirement: Продукт создаётся в статусе new

`POST /api/v1/risks/products/update` ДОЛЖЕН создать product текущего tenant с `productVersionNumber=0`, status `new`, identifiers и audit metadata.

#### Scenario: Валидный продукт создаётся

- **WHEN** пользователь имеет `ProductRisks.Create` и передал обязательные поля
- **THEN** сервис ДОЛЖЕН вернуть ProductViewResponse с workflow actions `estimate` и `archive`

#### Scenario: Product name превышает предел

- **WHEN** default profile получает имя длиннее 1000
- **THEN** сервис ДОЛЖЕН отклонить поле без commit

### Requirement: Product business identity неизменяема

`businessId`, tenant и system UUID НЕ ДОЛЖНЫ меняться после создания; `productVersionNumber` ДОЛЖЕН увеличиваться только при успешной оценке.

#### Scenario: Пользователь редактирует description до оценки

- **WHEN** product status допускает редактирование
- **THEN** persistence version ДОЛЖНА измениться
- **AND** productVersionNumber ДОЛЖЕН остаться 0

### Requirement: Product registry является tenant- и permission-scoped

Search/view/refresh ДОЛЖНЫ требовать `ProductRisks.View` и применять visibility current user.

#### Scenario: Поиск совпадает с чужим продуктом

- **WHEN** query соответствует продукту другого tenant
- **THEN** он НЕ ДОЛЖЕН входить в result или total

### Requirement: Карточка продукта является server-driven

`GET /api/v1/risks/products/{id}` ДОЛЖЕН возвращать entity, dictionaries, validation, editability, workflowActions, связанные risks/categories/measures и `maxRiskLevel`.

#### Scenario: Approved product открыт

- **WHEN** status `approved`
- **THEN** response ДОЛЖЕН показывать `timeApprove`, `maxRiskLevel` и доступное `reestimate`

#### Scenario: Archive product открыт

- **WHEN** status `archive`
- **THEN** response ДОЛЖЕН быть read-only и не содержать действий оценки, если profile не предусматривает восстановление

### Requirement: Refresh продукта не изменяет хранилище

`POST /api/v1/risks/products/refresh` ДОЛЖЕН пересчитать зависимые поля, dictionaries и errors без новой версии.

#### Scenario: Изменён productStage

- **WHEN** refresh получает новую stage
- **THEN** форма ДОЛЖНА применить selectable/visibility rules новой stage

### Requirement: Workflow продукта соблюдает state machine

| Status | Action | Target |
|---|---|---|
| `new` | `estimate` | `inProgress` |
| `new` | `archive` | `archive` |
| `inProgress` | `success` | `approved` |
| `inProgress` | `error` | `new` |
| `inProgress` | `errorReestimate` | `approved` |
| `approved` | `archive` | `archive` |
| `approved` | `reestimate` | `inProgress` |

#### Scenario: Новый product отправлен на оценку

- **WHEN** workflow task создана успешно
- **THEN** `estimate` ДОЛЖЕН перевести product в `inProgress`

#### Scenario: Product архивируется

- **WHEN** action `archive` вызван допустимой ролью и содержит обязательный comment
- **THEN** status ДОЛЖЕН стать `archive`, comment и author сохраниться в history

#### Scenario: Внешний клиент вызывает internal success

- **WHEN** action `success` вызван не из trusted assessment process
- **THEN** сервис ДОЛЖЕН отклонить действие

### Requirement: Workflow actions ограничены ролью

`estimate`, `reestimate`, `archive` ДОЛЖНЫ быть доступны только настроенным ролям risk manager, partner и product owner (`ORMCLOUD_PO`, если роль поддерживается платформой) плюс `ProductRisks.Create`.

#### Scenario: Viewer имеет только ProductRisks.View

- **WHEN** он открывает карточку
- **THEN** изменяющие workflowActions НЕ ДОЛЖНЫ возвращаться

### Requirement: Вложения продукта принадлежат target version

Документы ДОЛЖНЫ сохраняться с `objectType=product`, `businessId=productId` и `objectVersion=current productVersionNumber+1`.

#### Scenario: Документ загружается для новой оценки

- **WHEN** current version N
- **THEN** attachment metadata ДОЛЖНА ссылаться на N+1

### Requirement: Product attachment проходит безопасную валидацию

Save ДОЛЖЕН требовать `ProductRisks.Create` и проверять fileId, tenant, product, version, file size/type/name/hash/content signature; list/download требуют `ProductRisks.View`.

#### Scenario: Download fileId подставлен из другого продукта

- **WHEN** metadata не соответствует path productId
- **THEN** bytes НЕ ДОЛЖНЫ быть возвращены

#### Scenario: Сохранение metadata/bytes частично неуспешно

- **WHEN** один обязательный этап upload завершается ошибкой
- **THEN** сервис ДОЛЖЕН удалить orphaned side effect либо запланировать компенсацию

### Requirement: Запуск assessment проверяет продукт

`POST /api/v1/risks/products/{businessId}/start-assessment` ДОЛЖЕН требовать `ProductRisks.Create`, существующий product текущего tenant, допустимый status и отсутствие active task target version.

#### Scenario: Product уже inProgress

- **WHEN** повторно вызывается start
- **THEN** сервис ДОЛЖЕН вернуть conflict/already running

#### Scenario: Product подходит для оценки

- **WHEN** preconditions проходят
- **THEN** сервис ДОЛЖЕН создать scheduler workflow с unique/group key taskId

### Requirement: Task snapshot формируется при старте

Workflow ДОЛЖЕН зафиксировать tenantId, UUID taskId, productId, target version fileIds, author и ИНН tenant до первого activity.

#### Scenario: ИНН tenant не найден

- **WHEN** tenant directory не содержит однозначный INN
- **THEN** workflow НЕ ДОЛЖЕН стартовать внешнюю оценку
- **AND** ошибка ДОЛЖНА быть наблюдаемой

### Requirement: Create activity атомарно запускает lifecycle

Первое activity ДОЛЖНО выполнить `estimate` или `reestimate` по current productVersionNumber и создать `PRODUCT_ASSESSMENT_TASK` со status `pending`.

#### Scenario: Task persistence не создана

- **WHEN** запись task завершается ошибкой
- **THEN** product НЕ ДОЛЖЕН оставаться в `inProgress` без восстанавливаемой task

### Requirement: Ожидание файлов имеет polling и timeout

Пока document service сообщает pending files, workflow ДОЛЖЕН reschedule activity через `pollIntervalSeconds`; после `pendingTimeOutSeconds` task ДОЛЖНА завершиться error.

#### Scenario: Все файлы готовы

- **WHEN** pending list пуст
- **THEN** task ДОЛЖНА перейти `pending→readyForStart` и сохранить `timeReadyForStart`

#### Scenario: Файлы не готовы до timeout

- **WHEN** суммарное ожидание превышает предел
- **THEN** task ДОЛЖНА перейти в `error` с причиной `Files timeout`
- **AND** product workflow ДОЛЖЕН выполнить error/errorReestimate

### Requirement: Внешнему агенту отправляется типизированный запрос

Start-agent activity ДОЛЖНО отправить `taskId`, `productId`, `inn`, snapshot `fileIds` в `/api/start-conduct-risk-assessment`, затем перевести task `readyForStart→inProcess` и сохранить `timeStartProcess`.

#### Scenario: Agent integration enabled

- **WHEN** внешний вызов успешно принят
- **THEN** task ДОЛЖНА стать `inProcess`

#### Scenario: Agent integration disabled на стенде

- **WHEN** feature flag отключён
- **THEN** пропуск вызова ДОЛЖЕН быть явно наблюдаемым
- **AND** production profile НЕ ДОЛЖЕН считать его успешной реальной оценкой без тестового режима

#### Scenario: Внешний вызов неуспешен

- **WHEN** request не принят
- **THEN** task/product ДОЛЖНЫ перейти в согласованный error outcome, а не бесконечно ждать callback

### Requirement: Agent response имеет ограниченный timeout

После start workflow ДОЛЖЕН ждать internal callback не дольше `agent.timeOutSeconds`.

#### Scenario: Callback отсутствует

- **WHEN** timeout истёк
- **THEN** task ДОЛЖНА стать `error` с `Agent timeout`
- **AND** product ДОЛЖЕН вернуться в `new` для первичной оценки или `approved` для переоценки

### Requirement: Поведенческие риски создаются только в контексте task

До terminal callback внешний агент МОЖЕТ вызывать internal `createOrUpdateRisk` с `riskEntity` и links; сервис ДОЛЖЕН связать каждый risk с product и task и использовать conduct semantics.

#### Scenario: Создаётся новый conduct risk

- **WHEN** task существует, status `inProcess`, product/tenant совпадают и payload валиден
- **THEN** risk ДОЛЖЕН получить `relatedRisk=conduct`, `conductRiskType`, source/updaterTaskId
- **AND** связи `riskToProduct`/`riskToAssessmentTask` ДОЛЖНЫ быть созданы

#### Scenario: Task не inProcess

- **WHEN** agent пытается записать risk после terminal error/success
- **THEN** сервис ДОЛЖЕН отклонить позднюю запись или дедуплицировать ранее принятую

### Requirement: Internal risk upsert валидирует links

`POST /api/v1/internal/risks/update` ДОЛЖЕН принимать только allowlisted link types/targets, проверять tenant ownership и применять MCP/internal risk pipeline.

#### Scenario: Link указывает на чужой product

- **WHEN** target не принадлежит task tenant/product
- **THEN** risk и links НЕ ДОЛЖНЫ быть частично сохранены

### Requirement: Terminal callback аутентифицирован и идемпотентен

`POST /api/v1/conduct-risks/end-assessment` ДОЛЖЕН проверять service identity, обязательный `taskId`, существование task/product и допустимый status `inProcess`/повторяемый `error`.

#### Scenario: Успешный callback

- **WHEN** `result=success`
- **THEN** wait activity ДОЛЖНА завершиться с `summary`
- **AND** workflow ДОЛЖЕН перейти к complete activity

#### Scenario: Повтор terminal callback

- **WHEN** task уже `success`
- **THEN** сервис ДОЛЖЕН вернуть idempotent success или conflict без повторной product version

#### Scenario: Неизвестный taskId

- **WHEN** task отсутствует
- **THEN** internal API ДОЛЖЕН вернуть 404

### Requirement: Successful completion утверждает новую product version

Complete activity ДОЛЖНО выполнить automatic action `success`, установить `productVersionNumber=N+1`, `timeApprove=now`, task `success`, `timeEnd`, `summary` и metrics.

#### Scenario: Все risks применены

- **WHEN** callback success и обязательные links существуют
- **THEN** product ДОЛЖЕН перейти `inProgress→approved`
- **AND** новая business version ДОЛЖНА стать current

#### Scenario: Complete pipeline неуспешен

- **WHEN** product update конфликтует или DB недоступна
- **THEN** task НЕ ДОЛЖНА ложно стать success
- **AND** activity ДОЛЖНА быть retryable без дублей risk/product versions

### Requirement: Error completion восстанавливает предыдущую product version

Fail activity ДОЛЖНО выполнить `error` для initial version либо `errorReestimate` для approved version, удалить target attachments и сохранить task error.

#### Scenario: Initial assessment failed

- **WHEN** current version равна 0
- **THEN** product ДОЛЖЕН вернуться в `new`

#### Scenario: Reassessment failed

- **WHEN** current version больше 0
- **THEN** product ДОЛЖЕН вернуться в `approved` с прежними version/timeApprove/risks

### Requirement: Статусы task изменяются compare-and-set

Каждый переход task ДОЛЖЕН указывать допустимые исходные статусы, чтобы конкурирующие activities/callback не перезаписывали terminal outcome.

#### Scenario: Timeout и success callback пришли одновременно

- **WHEN** один процесс первым зафиксировал terminal transition
- **THEN** второй ДОЛЖЕН получить status conflict и не менять product повторно

### Requirement: File ids terminal error очищаются согласованно

При terminal failure сервис ДОЛЖЕН удалить attachments target version или пометить их недействующими; успешная оценка ДОЛЖНА сохранить их как документы этой product version.

#### Scenario: Удаление одного файла неуспешно

- **WHEN** cleanup частично завершился
- **THEN** должен быть retry/compensation с task correlation

### Requirement: Риски продукта доступны отдельным internal read

`GET /api/v1/conduct-risks/{productId}` ДОЛЖЕН возвращать связанные risks текущего tenant для downstream agent/process, применяя service authorization и server limit.

#### Scenario: Product имеет много risks

- **WHEN** count превышает limit
- **THEN** API ДОЛЖЕН иметь документированное pagination/limit поведение, а не silently обрезать критичный набор

### Requirement: Result summary и ошибки не раскрывают лишние данные

Summary МОЖЕТ быть показан уполномоченному пользователю; error details, file ids и agent payload НЕ ДОЛЖНЫ раскрывать документы, секреты или stack trace.

#### Scenario: Callback содержит техническую ошибку

- **WHEN** error сохраняется
- **THEN** пользователю ДОЛЖЕН возвращаться безопасный локализованный текст, а correlation id — для поддержки

### Requirement: Метрики отражают один logical outcome

Для task ДОЛЖНЫ регистрироваться start, success/error и duration ровно один раз по logical outcome, даже при retries/callback duplicates.

#### Scenario: Callback повторён

- **WHEN** duplicate не меняет status
- **THEN** success counter НЕ ДОЛЖЕН увеличиваться повторно

## Публичные операции capability

| Операция | Permission/доверие |
|---|---|
| Product search/view/refresh | `ProductRisks.View` |
| Product create/update/workflow/start assessment | `ProductRisks.Create` |
| Attachment list/download | `ProductRisks.View` |
| Attachment save | `ProductRisks.Create` |
| Conduct result, internal risk upsert/read | trusted service identity |
