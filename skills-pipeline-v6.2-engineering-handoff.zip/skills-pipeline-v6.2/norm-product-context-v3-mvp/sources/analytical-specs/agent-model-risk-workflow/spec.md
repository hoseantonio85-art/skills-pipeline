# Категория modelType — workflow и lifecycle

## Назначение

Определить создание, workflow и оценку категории `modelType` для ИИ-агентов, а также уведомления владельца и ограничения riskLevel для modelRisk.

## Требования

### Requirement: Категория modelType создаётся при наличии риска с aiRiskType=modelRisk

Когда агент имеет риск с `aiRiskType=modelRisk`, сервис ДОЛЖЕН создать категорию `agentCategoryType=modelType` в `agent.data.categories` после завершения обработки evaluation callback. Категория не влияет на `agent.status` — агент может находиться в любом статусе (`review`, `approved` и т.д.) независимо от статуса категории `modelType`.

#### Scenario: Категория modelType создана для агента с modelRisk
- **WHEN** у агента есть риск с `aiRiskType=modelRisk` и категория `modelType` ещё не создана
- **THEN** сервис ДОЛЖЕН создать категорию с `status=notAssessed`, `categoryType=modelType`
- **AND** `agent.maxRiskLevel` НЕ ДОЛЖЕН измениться до оценки категории

#### Scenario: Категория modelType уже существует
- **WHEN** агент уже имеет категорию `modelType` при повторной оценке
- **THEN** сервис НЕ ДОЛЖЕН создавать дубликат категории
- **AND** существующая категория ДОЛЖНА продолжить существовать в своём текущем статусе

### Requirement: modelType workflow actions для регулятора UMR

Сервер ДОЛЖЕН возвращать workflow actions для категории `modelType` как описано в конфигурации:

**Роли** (из YAML-конфига + `RiskWorkflowServiceImpl.resolveCategoryPermission`):
`ORMCLOUD_REGULATOR`, `ORMCLOUD_PARTNER`, `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_RISKMANAGER`, `ORMCLOUD_AI_OWNER`

- `takeToWork` — доступна перечисленным ролям, записывает пользователя в `author`, доступна на статусе `notAssessed`, переводит в `inProgress`
- `sendForAssessment` — доступна перечисленным ролям, с тегом `onlyAuthor`, записывает пользователя в `verifier`, переводит в `assessed`
- `assignToSelf` — доступна перечисленным ролям, с тегом `notAuthor`, записывает пользователя в `author`, не меняет статус (остаётся `inProgress`)

**Важно:** actions для категории `modelType` доступны, когда агент находится в статусе `review` ИЛИ `approved`. Для остальных категорий (`operationalType`, `securityType`, `reliabilityType`) actions доступны только в статусе `review`.

#### Scenario: Регулятор UMR берёт модельType в работу
- **WHEN** пользователь с одной из ролей (`ORMCLOUD_REGULATOR`, `ORMCLOUD_PARTNER`, `ORMCLOUD_REGULATOR_UMR`, `ORMCLOUD_RISKMANAGER`, `ORMCLOUD_AI_OWNER`) вызывает action `takeToWork` для категории в статусе `notAssessed`
- **THEN** сервис ДОЛЖЕН выполнить действие
- **AND** категория ДОЛЖНА перейти в статус `inProgress`
- **AND** поле `author` ДОЛЖНО быть заполнено идентификатором пользователя

#### Scenario: Action sendForAssessment доступен только автору
- **WHEN** пользователь НЕ является автором категории (поле `author`)
- **THEN** action `sendForAssessment` НЕ ДОЛЖЕН быть доступен (тег `onlyAuthor`)

### Requirement: modelType assessed не является терминальным для агента

Статус `assessed` категории `modelType` НЕ ДОЛЖЕН влиять на автоперевод агента в `approved`. Метод `AgentRiskCategories.isAssessed()` ДОЛЖЕН исключать категории `modelType` из проверки — автоматический `approve` срабатывает только когда все НЕ-modelType категории в статусе `assessed`.

Реализация: `AgentRiskCategories.isAssessed()` удаляет `modelType` категории перед проверкой `allMatch`. Дополнительно, `AgentApplyWorkflowStage.resolveCategoryAction()` не вызывает `autoApply`, если агент уже в статусе `approved`.

### Requirement: Изменение категории modelType пересчитывает maxRiskLevel агента

Когда категория `modelType` переходит в статус `assessed`, сервис ДОЛЖЕН пересчитать интегральный уровень риска агента (`maxRiskLevel`) через `AgentMaxRiskLevelService.recalculate()`. Пересчёт учитывает все риски агента, включая `modelRisk`.

#### Scenario: modelType стал assessed — maxRiskLevel пересчитан
- **WHEN** категория `modelType` изменяет статус на `assessed`
- **THEN** `GenericAgentRiskCategoryWorkflow.onActionApplied()` ДОЛЖЕН вызвать `AgentMailSender.sendToOwnerForModelRisk()`
- **AND** `agent.maxRiskLevel` ДОЛЖЕН быть пересчитан через `AgentMaxRiskLevelService.recalculate()`
- **AND** если `modelRisk.riskLevel` установлен, он ДОЛЖЕН участвовать в расчёте (как max из всех riskLevel агента)

### Requirement: Уведомление владельца при assessed для modelType

Когда категория `modelType` переходит в статус `assessed`, сервис ДОЛЖЕН отправить email-уведомление владельцу агента (`agent.owner`).

Тема письма: "Риски ИИ-решений"

Шаблон письма: `agentModelRiskAssessed.html` — аналогичен `agentApproved.html` с изменённым текстом:
- `${userName}, привет 😊<br />По ИИ-решению проведена оценка модельного риска` (вместо "По ИИ-решению проведена оценка рисков")

Дополнительные параметры шаблона: все стандартные поля (`standUrl`, `supportLink`, `userName`, `tenantName`, `tenantId`, `businessUiId`, `businessId`, `agentName`, `currentDate`, `maxRiskLevel`, `riskColor`).

#### Scenario: modelType стал assessed, владелец уведомлён
- **WHEN** категория `modelType` меняет статус на `assessed` и у агента заполнен `owner`
- **THEN** сервис ДОЛЖЕН отправить email на адрес владельца
- **AND** тема письма ДОЛЖНА быть "Риски ИИ-решений"
- **AND** `isTechnical(owner)` ДОЛЖЕН проверяться — технические пользователи пропускаются

#### Scenario: Владелец не заполнен
- **WHEN** `modelType` перешёл в `assessed`, но `agent.owner` равен `null`
- **THEN** email НЕ ДОЛЖЕН отправляться
- **AND** в лог ДОЛЖНА быть записана соответствующая информация

### Requirement: Для modelRisk допустимы только riskLevel low, medium, high, без critical

Для рисков с `aiRiskType=modelRisk` поле `riskLevel` на UI ДОЛЖНО скрывать значение `critical` (через `RiskDictionaryFilters.riskLevel(dictionarySet, isModelRisk)`). Остальные значения справочника (low, medium, high, no_risks, not_estimated, unknown) остаются видимыми, если помечены как `editable` в словаре.

#### Scenario: Редактирование modelRisk с допустимым уровнем
- **WHEN** пользователь устанавливает `riskLevel=medium` для риска с `aiRiskType=modelRisk`
- **THEN** сервис ДОЛЖЕН принять изменение

#### Scenario: Значение critical скрыто для modelRisk
- **WHEN** пользователь открывает форму редактирования риска с `aiRiskType=modelRisk`
- **THEN** значение `critical` НЕ ДОЛЖНО быть доступно в выпадающем списке `riskLevel`

#### Scenario: modelRisk создаётся без riskLevel
- **WHEN** `modelRisk` создаётся через callback (начальное значение)
- **THEN** `riskLevel` ДОЛЖЕН быть `null` (не задан)
- **AND** на UI поле `riskLevel` ДОЛЖНО быть доступно для выбора из видимых значений справочника
