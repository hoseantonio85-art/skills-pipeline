# Спецификация платформенных и эксплуатационных требований

## Назначение

Определить сквозной контракт HTTP/API, server-driven форм, конфигурации профилей, безопасности, хранения, фоновых процессов, наблюдаемости, надёжности и совместимости для всех capabilities `risk-cloud`.

## 1. API conventions

### Requirement: Публичный REST версионируется

Новые пользовательские операции ДОЛЖНЫ публиковаться под `/api/v1`; несовместимое изменение request/response/status semantics ДОЛЖНО использовать новую major API version или период совместимости.

#### Scenario: В response добавлено необязательное поле

- **WHEN** старый client игнорирует неизвестные поля
- **THEN** изменение МОЖЕТ быть выпущено в v1

#### Scenario: Поле переименовывается

- **WHEN** старое имя использовали клиенты
- **THEN** сервис ДОЛЖЕН поддержать alias/deprecation period либо новый endpoint version

### Requirement: OpenAPI является машинным контрактом

Каждый HTTP endpoint ДОЛЖЕН быть описан OpenAPI с operationId, tags, auth, parameters, required fields, limits, request/response schemas, content types и error responses.

#### Scenario: Реализация добавляет endpoint

- **WHEN** endpoint доступен в controller
- **THEN** соответствующая OpenAPI operation ДОЛЖНА существовать до release

#### Scenario: OpenAPI расходится с runtime

- **WHEN** contract test обнаруживает другое поле/status/content type
- **THEN** release ДОЛЖЕН быть заблокирован

### Requirement: Correlation id проходит через запрос

Ingress ДОЛЖЕН принять или сгенерировать непредсказуемый request/correlation id, вернуть его в response и передать во внешние calls, scheduler data и logs.

#### Scenario: Client передал некорректный id

- **WHEN** header превышает лимит или содержит управляющие символы
- **THEN** сервис ДОЛЖЕН заменить его безопасным server-generated id

### Requirement: JSON имеет единые правила

JSON ДОЛЖЕН быть UTF-8; date-time — ISO-8601; decimal — JSON number или документированная string без потери точности; null/empty handling — единообразно настроенным ObjectMapper.

#### Scenario: Optional field отсутствует

- **WHEN** значение пусто и default-property-inclusion исключает его
- **THEN** клиент НЕ ДОЛЖЕН интерпретировать отсутствие как очистку при partial model, если операция не объявлена PATCH

### Requirement: Изменяющие POST-команды имеют явную семантику

`update`, `workflow`, `refresh`, `start` endpoints ДОЛЖНЫ различать commit/non-commit, required version и idempotency; название POST не отменяет этих правил.

#### Scenario: Refresh вызван повторно

- **WHEN** entity одинакова
- **THEN** response ДОЛЖЕН быть эквивалентен и persistence не измениться

### Requirement: Коллекции ограничены

Любой request/response array ДОЛЖЕН иметь разумный configured maximum; OpenAPI `maxItems` ДОЛЖЕН соответствовать runtime validation. Search ДОЛЖЕН поддерживать page/limit/cursor, если result может превышать максимум.

#### Scenario: Передано 2001 значение при maxItems=2000

- **WHEN** schema задаёт максимум 2000
- **THEN** сервис ДОЛЖЕН вернуть validation error до выполнения query

### Requirement: Path/query ids валидируются

Business ids ДОЛЖНЫ соответствовать allowlisted pattern/length и использоваться как параметры DAO, а не составлять query/expression строкой.

#### Scenario: Id содержит traversal/SQL metacharacters

- **WHEN** pattern нарушен
- **THEN** request ДОЛЖЕН быть отклонён 4xx без обращения к registry

### Requirement: Ошибки типизированы

API ДОЛЖЕН иметь стабильную error envelope/notification с `code`, безопасным локализуемым message, optional field/path details, retryable и correlationId.

#### Scenario: Authentication отсутствует

- **WHEN** protected endpoint вызван anonymous caller
- **THEN** transport ДОЛЖЕН вернуть 401

#### Scenario: Permission отсутствует

- **WHEN** identity валидна, но permission не выдана
- **THEN** transport ДОЛЖЕН вернуть 403

#### Scenario: Объект отсутствует

- **WHEN** tenant-scoped lookup пуст
- **THEN** transport ДОЛЖЕН вернуть 404 либо documented empty semantics для legacy operation

#### Scenario: Version/state collision

- **WHEN** optimistic version или task status не совпали
- **THEN** transport ДОЛЖЕН вернуть 409 с current correlation, не 500

#### Scenario: Field validation failed

- **WHEN** model невалидна
- **THEN** transport ДОЛЖЕН вернуть 400/422 с field details

### Requirement: Internal API отделён от public API

Internal callbacks/jobs/email/upsert ДОЛЖНЫ быть доступны только через отдельный network policy/service auth scope и не полагаться на отсутствие ссылок в UI.

#### Scenario: Пользовательский token вызывает internal endpoint

- **WHEN** token не имеет service audience/scope
- **THEN** request ДОЛЖЕН быть отклонён

### Requirement: Deprecated legacy endpoints наблюдаемы

External paths без `/api/v1` ДОЛЖНЫ иметь владельца, compatibility contract, usage metric и план миграции.

#### Scenario: Legacy endpoint больше не используется

- **WHEN** usage=0 в согласованное окно
- **THEN** удаление ДОЛЖНО оформляться OpenSpec change и release note

## 2. Server-driven forms and configuration

### Requirement: FormComponent разделяет data и config

Response ДОЛЖЕН отделять entity values от form/view configuration, dictionaries, employees, notifications и workflow actions.

#### Scenario: Одно поле невидимо

- **WHEN** resolver вычислил `visible=false/never`
- **THEN** client config ДОЛЖЕН это отражать
- **AND** чувствительное значение НЕ ДОЛЖНО передаваться, если visibility является security boundary

### Requirement: Editability вычисляется сервером

Field `editable` ДОЛЖЕН учитывать mode, permission, role, status, owner, related object и profile; update pipeline ДОЛЖЕН повторно проверять те же guards.

#### Scenario: Client меняет read-only поле вручную

- **WHEN** payload отличается от current value
- **THEN** сервис ДОЛЖЕН отклонить или игнорировать изменение по documented policy

### Requirement: Validation metadata совпадает с commit validation

Правила `notNull`, maxLength, dictionary, dependent fields и cross-field errors в form ДОЛЖНЫ совпадать с server validation при update/workflow.

#### Scenario: Form разрешила значение, update отверг

- **WHEN** причина не связана с concurrent state change
- **THEN** это ДОЛЖНО считаться contract defect

### Requirement: Dictionaries имеют selectable policy

`current`, `all`, `path`, `managed` и иные selectable modes ДОЛЖНЫ применяться одинаково при form rendering, refresh и update validation.

#### Scenario: Текущее значение стало неактивным

- **WHEN** existing object хранит retired dictionary item
- **THEN** view ДОЛЖЕН уметь отобразить current label
- **AND** update НЕ ДОЛЖЕН разрешать выбрать его заново, если policy запрещает

### Requirement: Profile resolution детерминирован

Tenant ДОЛЖЕН сопоставляться ровно одному effective profile с документированным fallback `default`; конфликт или invalid profile должен быть виден при readiness/config validation.

#### Scenario: Tenant profile не настроен

- **WHEN** fallback разрешён
- **THEN** сервис ДОЛЖЕН использовать `default` и зафиксировать effective profile

#### Scenario: Fallback запрещён для tenant

- **WHEN** profile отсутствует
- **THEN** затронутые requests ДОЛЖНЫ завершаться configuration unavailable, а не частично формироваться

### Requirement: Конфигурация загружается атомарно

Новая profile/workflow/dictionary configuration ДОЛЖНА полностью валидироваться до публикации; все requests видят либо старую, либо новую согласованную версию.

#### Scenario: Один YAML невалиден

- **WHEN** reload не может разобрать workflow statuses
- **THEN** старая валидная конфигурация ДОЛЖНА остаться активной либо instance стать not-ready согласно policy

### Requirement: Localization keys разрешаются безопасно

Server ДОЛЖЕН возвращать локализуемые keys/values без format-string injection; отсутствующий key ДОЛЖЕН иметь наблюдаемый fallback.

#### Scenario: Перевод отсутствует

- **WHEN** key не найден
- **THEN** response НЕ ДОЛЖЕН быть 500
- **AND** metric/log ДОЛЖЕН указать missing key с bounded cardinality

## 3. Authentication, authorization and tenant security

### Requirement: Все business endpoints аутентифицированы

Public UI endpoints ДОЛЖНЫ требовать user identity, internal — service identity, MCP — agent/service identity. Исключения health/readiness ДОЛЖНЫ возвращать только безопасную информацию.

#### Scenario: Anonymous вызывает search

- **WHEN** token отсутствует
- **THEN** query к БД НЕ ДОЛЖЕН выполняться

### Requirement: Permission matrix применяется в controllers

Минимальная матрица:

| Capability | View | Change/start/workflow |
|---|---|---|
| Risks | `Risk.View` | `Risk.Create`; reassessment также `Risk.AgentReassessment` |
| Limits | `Limit.View` | `Limit.Edit` |
| Agents | `AgentRisks.View` | `AgentRisks.Create`/`AgentRisks.Edit` по операции |
| Products | `ProductRisks.View` | `ProductRisks.Create` |
| Dictionaries | `System.View` | не предоставляется этим API |
| Admin upload | — | `Administration.View` |
| Attention dashboard | `Home.AttentionZone` | — |

#### Scenario: Endpoint потерял annotation при рефакторинге

- **WHEN** security contract test вызывает его без permission
- **THEN** тест ДОЛЖЕН обнаружить доступ и блокировать release

### Requirement: Роли не заменяют permissions

Role определяет workflow/field guard внутри уже разрешённой capability; наличие роли без permission НЕ ДОЛЖНО разрешать endpoint.

#### Scenario: ORMCLOUD_PARTNER без Limit.Edit

- **WHEN** вызывает campaign workflow
- **THEN** request ДОЛЖЕН быть forbidden

### Requirement: Tenant извлекается из доверенного контекста

Для user REST tenant ДОЛЖЕН происходить из authenticated/session context; request body/path НЕ ДОЛЖНЫ произвольно его менять. Для trusted internal/MCP явный tenant сверяется с principal.

#### Scenario: Body содержит sysOwnerId

- **WHEN** пользователь пытается задать его
- **THEN** server ДОЛЖЕН игнорировать/отклонить поле и использовать context tenant

### Requirement: Объектная видимость применяется после permission

Owner department, related risk type, role, author и иные profile rules ДОЛЖНЫ ограничивать view/edit/search consistently.

#### Scenario: Search и direct get расходятся

- **WHEN** объект исключён visibility filter
- **THEN** direct get НЕ ДОЛЖЕН раскрывать его тому же пользователю

### Requirement: Technical user имеет минимальные полномочия

Background/internal pipeline ДОЛЖЕН использовать выделенную technical identity только для конкретной операции и сохранять исходный caller/task; technical mode НЕ ДОЛЖЕН отключать tenant isolation или validation без явного design.

#### Scenario: Job выполняется для tenant list

- **WHEN** переходит к следующему tenant
- **THEN** предыдущий TenantContext ДОЛЖЕН быть очищен даже после exception

### Requirement: Секреты загружаются извне

Credentials, tokens, encryption keys и endpoints с secrets ДОЛЖНЫ поступать из secret storage/mounted config, не храниться в Git и не возвращаться actuator/config endpoints.

#### Scenario: Secret случайно попал в exception

- **WHEN** client initialization failed
- **THEN** log/error formatter ДОЛЖЕН redacted значение

## 4. Input and data security

### Requirement: Все входы имеют size/depth limits

HTTP headers, JSON bytes/depth/string length, multipart, arrays, search query, comments и MCP payload ДОЛЖНЫ ограничиваться до deserialization/domain work.

#### Scenario: Oversized request

- **WHEN** request превышает limit
- **THEN** transport ДОЛЖЕН вернуть 413/validation error и не удерживать большой объект в памяти дольше необходимого

### Requirement: Upload защищён от вредоносных файлов

Сервис ДОЛЖЕН проверять extension, MIME, magic bytes, filename, size, archive structure и, если доступно, antivirus result до использования файла.

#### Scenario: ZIP содержит zip bomb

- **WHEN** expansion ratio/entry count превышает предел
- **THEN** обработка ДОЛЖНА быть прекращена и событие зафиксировано как security rejection

### Requirement: Текст очищается в контексте вывода

Comments, names, summaries, reasoning и external source fields ДОЛЖНЫ храниться как данные; HTML/mail/UI output ДОЛЖЕН применять escaping/sanitization.

#### Scenario: Comment содержит script tag

- **WHEN** он включается в письмо
- **THEN** tag НЕ ДОЛЖЕН исполняться/рендериться как активный script

### Requirement: Search не допускает injection

Filters и sorting ДОЛЖНЫ собираться из allowlisted fields/operators и параметризованных expressions; произвольный клиентский expression запрещён.

#### Scenario: Query содержит JSON path/operator

- **WHEN** поле не объявлено filter config
- **THEN** оно ДОЛЖНО быть отклонено как неизвестное

### Requirement: PII и чувствительные данные классифицированы

Employee ids, emails, INN, documents, descriptions и AI reasoning ДОЛЖНЫ иметь правила доступа, логирования, retention и masking.

#### Scenario: Metric label получает businessId/userId

- **WHEN** значение имеет высокую cardinality или PII
- **THEN** оно НЕ ДОЛЖНО использоваться как Prometheus tag

## 5. Persistence, transactions and migrations

### Requirement: Liquibase является единственным владельцем схемы

Изменение таблицы/index/constraint ДОЛЖНО оформляться новым immutable changeset; уже применённые production changesets НЕ ДОЛЖНЫ редактироваться.

#### Scenario: Добавляется обязательное поле

- **WHEN** в таблице есть данные
- **THEN** migration ДОЛЖНА включать backfill/nullable transition и rollback/compatibility plan

### Requirement: Tenant и business keys индексированы

Частые lookup/search keys (`tenantId`, `businessId`, status, taskId, parent/history, year, externalId) ДОЛЖНЫ иметь обоснованные constraints/indexes и query plan verification в CI/test environment.

#### Scenario: Добавлен новый scheduler scan

- **WHEN** job выбирает status+time по всем tenants
- **THEN** design ДОЛЖЕН предусмотреть покрывающий индекс или bounded tenant batches

### Requirement: История непрерывна

Для versioned object intervals `actingFrom`/`actingTo` НЕ ДОЛЖНЫ пересекаться; current record имеет открытый конец, historic revisions — закрытый.

#### Scenario: Две concurrent updates

- **WHEN** обе читают одну version
- **THEN** только одна ДОЛЖНА commit, другая получить version collision

### Requirement: JSON data эволюционирует совместимо

Чтение ДОЛЖНО терпеть отсутствующие новые optional fields; удаление/смена типа требует migration или version-aware mapper.

#### Scenario: Старая historic запись не содержит поле

- **WHEN** history resolver сравнивает её с current
- **THEN** отсутствие ДОЛЖНО интерпретироваться предсказуемо, не вызывать 500

### Requirement: Денежные данные точны

Все суммы/проценты ДОЛЖНЫ использовать BigDecimal/DECIMAL с определёнными precision, scale и rounding; float/double для сохранения запрещены.

#### Scenario: Сумма выходит за precision

- **WHEN** значение слишком велико
- **THEN** validation ДОЛЖНА отклонить его до SQL overflow

### Requirement: Transaction boundary не охватывает долгий network call без необходимости

Внешний AI/file/link/measure/mail вызов НЕ ДОЛЖЕН удерживать DB transaction/lock; orchestration ДОЛЖНА использовать state transition и idempotent side effect.

#### Scenario: AI service отвечает 30 секунд

- **WHEN** request ждёт ответ
- **THEN** DB connection/row lock НЕ ДОЛЖНЫ удерживаться весь timeout

### Requirement: Backup и восстановление проверяются

Current/historic/task/attachment metadata ДОЛЖНЫ входить в backup policy; RPO/RTO определяются эксплуатационным паспортом и регулярно проверяются restore drill.

#### Scenario: Восстановлена БД без файлового сервиса

- **WHEN** metadata указывает на отсутствующие blobs
- **THEN** reconciliation ДОЛЖЕН выявить orphan references и сформировать отчёт

### Requirement: Retention определён по типу данных

Historic risks/limits/agents/products, completed tasks, logs, metrics и attachment blobs ДОЛЖНЫ иметь согласованные business/legal retention и безопасное удаление после срока.

#### Scenario: Cleanup job удаляет task

- **WHEN** срок истёк
- **THEN** job ДОЛЖЕН учитывать audit/legal hold и связанные objects/files

## 6. Async jobs and integration reliability

### Requirement: Job имеет owner, trigger и concurrency policy

Каждый scheduled/internal job ДОЛЖЕН документировать enabled flag, cron/manual trigger, tenant batch, lock/singleton policy, retry, timeout, idempotency и метрики.

#### Scenario: Два instance запускают один job

- **WHEN** singleton required
- **THEN** distributed scheduler/lock ДОЛЖЕН позволить один logical execution

### Requirement: Tenant jobs изолируют failures

Ошибка одного tenant НЕ ДОЛЖНА останавливать остальные tenants; итог job ДОЛЖЕН показывать success/error counts и tenant-safe correlations.

#### Scenario: Tenant A завершился ошибкой

- **WHEN** batch содержит tenant B
- **THEN** B ДОЛЖЕН быть обработан, если глобальная dependency доступна

### Requirement: Retries используют backoff и budget

Retryable external/DB failure ДОЛЖЕН повторяться с bounded exponential/backoff/jitter или scheduler delay; business validation и auth errors НЕ ДОЛЖНЫ автоматически повторяться.

#### Scenario: Dependency отвечает 503

- **WHEN** retry budget не исчерпан
- **THEN** операция ДОЛЖНА reschedule/retry без duplicate business effect

### Requirement: Kafka delivery подтверждается после commit

Consumer ДОЛЖЕН ack только после успешной validation и persistence; poison messages после budget ДОЛЖНЫ направляться в DLQ/операционный разбор.

#### Scenario: JSON malformed

- **WHEN** повтор не исправит payload
- **THEN** сообщение ДОЛЖНО перейти в non-retryable/DLQ path, не образуя tight retry loop

### Requirement: Outbound call имеет timeout и circuit protection

Каждый HTTP client ДОЛЖЕН иметь connect/read timeout, retry classification, bulkhead/circuit breaker policy и метрики.

#### Scenario: Link service завис

- **WHEN** read timeout истёк
- **THEN** thread ДОЛЖЕН освободиться, операция — перейти в retryable/compensation state

### Requirement: Email является идемпотентным side effect

Business transition ДОЛЖЕН формировать notification event с deduplication key; повтор transition handler НЕ ДОЛЖЕН отправлять duplicate mail.

#### Scenario: Mail send timeout

- **WHEN** письмо могло быть принято
- **THEN** retry ДОЛЖЕН использовать message id/deduplication key

## 7. Observability and service levels

### Requirement: Structured logs имеют безопасный набор полей

Log ДОЛЖЕН включать timestamp, level, service, instance, correlationId, traceId, tenant-safe identifier, operation/tool/job, outcome, duration и error class. Payload, token, secret, file bytes и raw AI text запрещены.

#### Scenario: Error formatter получает exception

- **WHEN** exception содержит request payload
- **THEN** log ДОЛЖЕН redacted сообщение или логировать только class/correlation

### Requirement: Метрики покрывают API и бизнес-процессы

Обязательны HTTP rate/error/latency, DB pool, external client, scheduler/job, Kafka lag/error, MCP create/update/info/error, assessment start/success/error/duration, archive size и task counts.

#### Scenario: Assessment failure растёт

- **WHEN** error rate превышает alert threshold
- **THEN** alert ДОЛЖЕН содержать capability, environment и runbook, но не task payload

### Requirement: Метрики имеют bounded cardinality

Tags МОГУТ включать environment, operation, outcome, exception class и нормализованный tenant name при допустимом количестве; taskId, businessId, fileId, userId и free text запрещены.

#### Scenario: Новый metric добавляет taskId tag

- **WHEN** observability review выполняется
- **THEN** изменение ДОЛЖНО быть отклонено

### Requirement: Tracing связывает async boundaries

Trace/correlation context ДОЛЖЕН переноситься из HTTP/MCP в scheduler, Kafka/outbound clients и callbacks через сохранённый taskId/link.

#### Scenario: Callback приходит в новом trace

- **WHEN** taskId известен
- **THEN** span ДОЛЖЕН иметь link к исходному process trace/correlation

### Requirement: Health и readiness различаются

Liveness ДОЛЖНА отражать способность процесса работать; readiness — принимать business traffic с доступной DB и обязательной конфигурацией. Необязательная внешняя dependency НЕ ДОЛЖНА бесконечно перезапускать процесс.

#### Scenario: DB недоступна

- **WHEN** instance не может читать/писать
- **THEN** readiness ДОЛЖНА быть false

#### Scenario: Mail service недоступен

- **WHEN** business operations могут использовать queue/retry
- **THEN** readiness МОЖЕТ оставаться true, но degraded metric/health component обязателен

### Requirement: SLO определён по классу операции

Эксплуатационный паспорт ДОЛЖЕН задать availability и latency SLO отдельно для read/search, synchronous writes, MCP calls и async completion; async AI time не включается в latency синхронного start, но имеет собственный deadline/SLO.

#### Scenario: Search latency нарушает SLO

- **WHEN** rolling window превышает threshold
- **THEN** alert/runbook ДОЛЖЕН различать DB, dictionary, downstream и saturation причины

### Requirement: Graceful shutdown сохраняет работу

При shutdown instance ДОЛЖЕН перестать принимать новые requests, завершить/отменить in-flight операции в пределах grace period, не ack uncommitted Kafka records и не потерять scheduler tasks.

#### Scenario: Pod завершается во время callback

- **WHEN** commit не выполнен
- **THEN** callback ДОЛЖЕН быть безопасно повторён caller/queue

### Requirement: Ресурсные лимиты предотвращают перегрузку

Thread pools, HTTP queue, DB pool, scheduler executors, file/archive memory, Kafka concurrency и MCP concurrency ДОЛЖНЫ быть bounded и согласованы с container requests/limits.

#### Scenario: Очередь исчерпана

- **WHEN** saturation достигнута
- **THEN** сервис ДОЛЖЕН применять backpressure/429/503, а не создавать неограниченные threads

## 8. Delivery and verification

### Requirement: Contract tests покрывают внешние границы

CI ДОЛЖЕН проверять публичный OpenAPI, internal callbacks, MCP discovery/calls, link/measure/document clients и Kafka schema на backward compatibility.

#### Scenario: Callback required field удалён

- **WHEN** producer/consumer contracts сравниваются
- **THEN** breaking build ДОЛЖЕН быть остановлен

### Requirement: State machines покрыты переходами

Для risk, campaign, agent, product и task tests ДОЛЖНЫ покрывать каждый разрешённый переход и запрет остальных status/action combinations, включая roles/permissions.

#### Scenario: Добавлен новый status

- **WHEN** workflow YAML изменён
- **THEN** tests ДОЛЖНЫ доказать reachable/terminal paths и отсутствие dead ends

### Requirement: Multi-tenant negative tests обязательны

Для get/search/update/download/callback/MCP/job ДОЛЖЕН существовать тест, подтверждающий невозможность доступа tenant A к данным tenant B.

#### Scenario: Совпадающие businessIds в двух tenants

- **WHEN** запрос выполняется в A
- **THEN** test ДОЛЖЕН подтвердить изменение только A

### Requirement: Failure injection покрывает partial side effects

Tests ДОЛЖНЫ моделировать timeout/error после DB commit и после внешнего commit для links, measures, files, mail и AI callback.

#### Scenario: Measure создана, response потерян

- **WHEN** operation повторяется
- **THEN** test ДОЛЖЕН подтвердить одну logical measure/link

### Requirement: Миграция проверяется на production-like snapshot

Перед release Liquibase change ДОЛЖЕН применяться к схеме с representative data, проверяться время/locks/backfill и совместимость old/new app при rolling deployment.

#### Scenario: Migration берёт длительный exclusive lock

- **WHEN** превышен deployment budget
- **THEN** migration ДОЛЖНА быть переработана/разделена

### Requirement: Runbooks существуют для критических отказов

Runbooks ДОЛЖНЫ покрывать зависшие agent/product/risk assessments, failed limit apply, Kafka poison message, MCP error spike, DB saturation, broken profile config и file/link/measure inconsistency.

#### Scenario: Agent evaluation зависла

- **WHEN** alert сработал
- **THEN** оператор ДОЛЖЕН иметь безопасную процедуру locate/retry/fail по taskId без прямого ручного изменения status в БД

## Каталог endpoint families

| Семейство | Prefix/операции |
|---|---|
| Risks | `/api/v1/risks/search`, `/{id}`, `/update`, `/refresh`, `/workflow`, `/filters`, `/attention-zone*`, `/links/search` |
| Reassessment | `/api/v1/risks/ai/start-reassessment`, `/assessment-tasks*`, internal start/end/reactivate |
| Agents | `/api/v1/risks/agents/*`, attachments, start-assessment, internal updateEvaluations/hanging handler |
| Products | `/api/v1/risks/products/*`, attachments, start-assessment, internal conduct result/risks |
| Limits | `/api/v1/risks/limit/campaign*`, `/api/v1/risks/limit*`, internal apply/reset jobs |
| Info feeds | `/api/v1/risks/info-feeds*`, external `/api/v1/info/ai-compliance/*` |
| Dictionaries | `/api/v1/risks/dict/linear|structure|search` |
| Internal jobs | `/api/jobs/execute/*` |
| MCP | deployment-configured MCP transport, tools listed in `mcp-agent-integration` |
