# Спецификация создания и управления модельным риском

## Назначение

Определить создание/обновление риска `modelRisk` как части фиксированных рисков агента (`FixedAgentRisks.toEvaluations()`). modelRisk не создаётся отдельным шагом — он является равноправным участником в цикле создания/обновления рисков, проходящем через единый метод `processEvaluation()`.

## Требования

### Requirement: При оценке агента создавать modelRisk вместе с остальными фиксированными рисками

Обработчик `POST /api/v1/risks/agents/updateEvaluations` ДОЛЖЕН создавать modelRisk как часть `FixedAgentRisks.toEvaluations()` — после фиксированных рисков (`infrastructureFailure`, `multiAgentCollision`) добавляется `modelRisk` с фиксированными полями.

#### Scenario: modelRisk не существует

- **WHEN** modelRisk не найден в контексте существующих рисков агента
- **THEN** сервис создаёт его через общий пайплайн `RiskPipelines.getCreateEvaluationPipeline()`:
  - `summary` — `agent.summary.modelRisk` (из messages.properties)
  - `riskLevel` — `null` (не заполняется)
  - `aiRiskMeasureList` — пустой

#### Scenario: modelRisk уже существует

- **WHEN** modelRisk найден в контексте существующих рисков
- **THEN** сервис обновляет его через общий пайплайн `RiskPipelines.getUpdateEvaluationPipeline()`:
  - `riskLevel` сбрасывается в `null`
  - `description` НЕ обновляется из словаря (модельный риск не меняет описание динамически)

### Requirement: modelRisk создаётся без мер

При создании modelRisk сервис НЕ ДОЛЖЕН создавать меры. В `FixedAgentRisks.toEvaluations()` для modelRisk передаётся пустой `aiRiskMeasureList`.

#### Scenario: modelRisk создан

- **WHEN** модельный риск создан или обновлён
- **THEN** метод создания мер НЕ ДОЛЖЕН вызываться для modelRisk
- **AND** `measureEvaluationService.createMeasures()` с пустым списком возвращает `[]` (безопасно)

### Requirement: Доступ к modelRisk через единую точку входа

Все три фиксированных риска (`infrastructureFailure`, `multiAgentCollision`, `modelRisk`) проходят через единый метод `processEvaluation()` → `createNewRisk()` / `updateRisk()` в `AgentEvaluationServiceImpl`. Никакой отдельной логики для modelRisk не существует.

#### Scenario: Обновление modelRisk

- **WHEN** modelRisk уже существует в контексте
- **THEN** он проходит через `updateRisk()` как любой другой риск
- **AND** после обновления вызывается `createLinks()` с пустым билдером — линки не создаются (линки создавались при создании риска, не при обновлении)

#### Scenario: modelRisk в конце списка

- **WHEN** все три фиксированных риска созданы
- **THEN** modelRisk идёт последним в списке `toEvaluations()` (после `infrastructureFailure` и `multiAgentCollision`)
