# Спецификация лимитной кампании и лимитов

## Назначение

Определить формирование годовой лимитной кампании, привязку рисков, редактирование индивидуальных лимитов, согласование между риск-менеджером, куратором и партнёром, применение утверждённых лимитов к эффектам риска, ретроспективу и агрегаты использования.

## Доменная модель

### `LIMIT_CAMPAIGN`

Системные поля: UUID, `tenantId`, `businessId`, `version`, `actingFrom`, `timeCreated/timeUpdated`, updater, update source и JSON `data`.

Канонические business fields: `name`, `status`, `year`, `stage`, `lossAmt`, `nearMissAmt`, `creditLossAmt` и рассчитанные изменения `lossAmtChange`, `nearMissAmtChange`, `creditLossAmtChange`.

### `LIMIT_ENTITY`

Системные поля аналогичны campaign. Канонические business fields: `businessId`, `riskId`, `limitCampaignId`, `lossAmt`, `nearMissAmt`, `creditAmt`, `comment`, `description`, `isHidden`; UI-поля включают risk description/date/UI id, уровень/стратегию/статус риска, исходные значения, изменения, editability и visibility controls.

### `LIMIT_INFO`

Tenant-scoped snapshot содержит `objectId`, `reportingDate` и JSON `losses`, где по каждому типу финансового эффекта хранятся `loss`, `limit`, `lossDiff`.

## Требования

### Requirement: Кампания однозначно определяется для tenant и года

Сервис ДОЛЖЕН находить или создавать кампанию по `tenantId` и году; при создании `businessId` ДОЛЖЕН быть стабильным идентификатором года, а начальный статус — `reviewRM`.

#### Scenario: Кампания года отсутствует

- **WHEN** authorised job запрашивает campaign для нового года
- **THEN** сервис ДОЛЖЕН создать campaign с `year`, локализованным `name`, status `reviewRM`, техническим updater и audit source

#### Scenario: Кампания уже существует

- **WHEN** операция get-or-create повторяется для того же tenant и года
- **THEN** сервис ДОЛЖЕН вернуть существующую campaign без дублирования

### Requirement: Активная кампания выбирается детерминированно

Если настроен `activeId`, сервис ДОЛЖЕН использовать campaign с этим id; иначе ДОЛЖЕН выбрать campaign с максимальным доступным `year` текущего tenant.

#### Scenario: Настроенный activeId не найден

- **WHEN** конфигурация ссылается на отсутствующую campaign
- **THEN** сервис ДОЛЖЕН вернуть контролируемое отсутствие/ошибку конфигурации
- **AND** НЕ ДОЛЖЕН незаметно использовать campaign другого tenant

### Requirement: Кампания отдаётся server-driven карточкой

`GET /api/v1/risks/limit/campaign` ДОЛЖЕН вернуть entity, aggregates, retro, dictionaries, workflowActions, field visibility/editability, validation и notifications.

#### Scenario: Id не передан

- **WHEN** пользователь с `Limit.View` запрашивает campaign без `id`
- **THEN** сервис ДОЛЖЕН вернуть детерминированно выбранную активную campaign

#### Scenario: Запрошена предварительная валидация действия

- **WHEN** передан `validateOnAction`
- **THEN** сервис ДОЛЖЕН рассчитать ошибки и доступность указанного workflow action без выполнения перехода

### Requirement: Editability campaign зависит от статуса и роли

Campaign ДОЛЖНА быть редактируемой только при совпадении статуса и роли: `reviewRM` — `ORMCLOUD_RISKMANAGER`; `reviewCurator` — `ORMCLOUD_CURATOR`; `reviewRP`/`ready` — `ORMCLOUD_PARTNER`; `accepted` — не редактируется обычной формой.

#### Scenario: Роль не соответствует этапу

- **WHEN** пользователь с `Limit.Edit`, но без требуемой роли открывает campaign в edit mode
- **THEN** сервис ДОЛЖЕН вернуть read-only форму и запретить update/workflow, требующий этой роли

### Requirement: Workflow campaign соблюдает полную state machine

Сервис ДОЛЖЕН поддерживать следующие переходы:

| Статус | Action | Target | Роль |
|---|---|---|---|
| `reviewRM` | `sendForReview` | `reviewCurator` | risk manager |
| `reviewRM` | `toCurator` | `reviewCurator` | curator |
| `reviewRM` | `rmTransfer` | `reviewRP` | partner |
| `reviewCurator` | `toRework` | `reviewRM` | curator |
| `reviewCurator` | `toRM` | `reviewRM` | risk manager |
| `reviewCurator` | `curatorTransfer` | `reviewRP` | partner |
| `reviewCurator` | `sendForApprove` | `reviewRP` | curator |
| `reviewRP` | `decline` | `reviewRM` | partner |
| `reviewRP` | `accept` | `ready` | partner |
| `ready` | `approve` | `accepted` | partner |
| `accepted` | `toReworkRP` | `ready` | partner |

#### Scenario: Риск-менеджер отправляет campaign куратору

- **WHEN** `sendForReview` разрешён, campaign валидна и пользователь является risk manager
- **THEN** статус ДОЛЖЕН стать `reviewCurator`
- **AND** переход, комментарий и уведомление ДОЛЖНЫ быть зафиксированы

#### Scenario: Партнёр утверждает лимиты

- **WHEN** campaign в `ready` проходит финальную проверку и вызывается `approve`
- **THEN** статус ДОЛЖЕН стать `accepted`
- **AND** ДОЛЖНО быть запланировано/выполнено применение лимитов к effects рисков

#### Scenario: Action не принадлежит текущему статусу

- **WHEN** клиент напрямую вызывает `approve` для `reviewRM`
- **THEN** сервис ДОЛЖЕН отклонить переход без изменения campaign или limits

### Requirement: Workflow проверяет целостность всех лимитов

Перед переходом вперёд сервис ДОЛЖЕН валидировать campaign и каждый незакрытый/видимый limit, включая ссылку на риск, денежные поля, комментарии и профильные обязательные значения.

#### Scenario: Один limit невалиден

- **WHEN** хотя бы один включённый limit нарушает правила
- **THEN** campaign НЕ ДОЛЖНА переходить в следующий статус
- **AND** ответ ДОЛЖЕН содержать адресуемые ошибки limit/risk

### Requirement: Комментарии workflow сохраняются и рассылаются безопасно

Комментарий action ДОЛЖЕН сохраняться в истории и включаться в уведомление только после sanitization; обязательность определяется action config.

#### Scenario: Обязательный комментарий отсутствует

- **WHEN** action настроен как `requiredComment=true`, а comment пуст
- **THEN** сервис ДОЛЖЕН отклонить action до изменения статуса

### Requirement: Уведомления следуют успешному commit

Письма `sendForReview`, `sendForApprove`, `toRework`, `accept`, `approve` ДОЛЖНЫ формироваться из шаблона и отправляться только после успешного доменного перехода с корректными tenant recipients и ссылкой на campaign.

#### Scenario: Mail service недоступен

- **WHEN** campaign успешно перешла, но письмо не отправлено
- **THEN** сервис ДОЛЖЕН зафиксировать наблюдаемый retryable side effect
- **AND** НЕ ДОЛЖЕН повторно выполнять сам workflow transition при повторе отправки

### Requirement: Лимит принадлежит ровно одной campaign и риску

Каждый `LIMIT_ENTITY` ДОЛЖЕН содержать валидные `limitCampaignId` и `riskId` того же tenant; изменение этих ссылок после создания ДОЛЖНО быть запрещено либо оформляться отдельной relink-операцией.

#### Scenario: Риск не существует или недоступен

- **WHEN** создаётся limit для неизвестного/чужого `riskId`
- **THEN** сервис ДОЛЖЕН отклонить команду до генерации limit id

### Requirement: Лимит создаётся и обновляется с версией

`POST /api/v1/risks/limit/update` ДОЛЖЕН создавать новый limit или обновлять существующий с optimistic locking, historic revision и `Limit.Edit`.

#### Scenario: Создан новый limit

- **WHEN** campaign редактируема для пользователя и request валиден
- **THEN** сервис ДОЛЖЕН назначить businessId/version/audit и вернуть полную LimitViewResponse

#### Scenario: Campaign больше не редактируема

- **WHEN** статус campaign изменился после открытия формы
- **THEN** update limit ДОЛЖЕН завершиться conflict/forbidden без новой версии

### Requirement: Денежные поля имеют точную decimal semantics

`lossAmt`, `nearMissAmt`, `creditAmt` и агрегаты ДОЛЖНЫ обрабатываться как decimal, не как binary floating point; валюта, scale, rounding и допустимый знак ДОЛЖНЫ определяться профилем.

#### Scenario: Значение имеет лишнюю точность

- **WHEN** amount содержит scale выше допустимого
- **THEN** сервис ДОЛЖЕН применить документированное округление либо отклонить поле до сохранения

### Requirement: Refresh лимита не сохраняет данные

`POST /api/v1/risks/limit/refresh` ДОЛЖЕН пересчитать description, change fields, errors и editability без commit.

#### Scenario: Пользователь меняет lossAmt

- **WHEN** UI вызывает refresh с новым значением
- **THEN** сервис ДОЛЖЕН вернуть рассчитанное изменение относительно initial/retro value
- **AND** version в БД НЕ ДОЛЖНА измениться

### Requirement: Limit visibility меняется отдельной командой

`POST /api/v1/risks/limit/{id}/visibility` ДОЛЖЕН изменять `isHidden` только при `Limit.Edit`, допустимой роли и редактируемой campaign.

#### Scenario: Limit скрывается

- **WHEN** пользователь с `canManageHidden=true` отправляет новое visibility state
- **THEN** сервис ДОЛЖЕН сохранить новую версию limit и вернуть фактическое состояние

#### Scenario: Скрытый limit применяется к risk effect

- **WHEN** campaign утверждается
- **THEN** скрытый limit НЕ ДОЛЖЕН переноситься в effects риска

### Requirement: Реестр лимитов фильтруется в пределах campaign

`POST /api/v1/risks/limit/campaign/{id}/search` ДОЛЖЕН возвращать только limits указанной campaign с query/filters, server limit, total и FormComponent.

#### Scenario: В фильтре указан risk status

- **WHEN** пользователь фильтрует limits по атрибуту связанного риска
- **THEN** сервис ДОЛЖЕН применить join/derived filter без подмены tenant boundaries

### Requirement: Quick filters рассчитываются по campaign

`GET /api/v1/risks/limit/campaign/{id}/quick-filters` ДОЛЖЕН вернуть count и параметры преднастроенных фильтров на согласованном snapshot campaign.

#### Scenario: Данные campaign изменились

- **WHEN** limit update завершён до запроса quick filters
- **THEN** counts ДОЛЖНЫ отражать committed current versions

### Requirement: Риски привязываются к campaign без дублей

`POST /api/v1/risks/limit/campaign/link` ДОЛЖЕН создавать отсутствующие limits/links для выбранных risks идемпотентно, проверяя tenant, status и eligibility.

#### Scenario: Один risk выбран повторно

- **WHEN** `riskId` уже имеет limit в campaign
- **THEN** сервис НЕ ДОЛЖЕН создать второй логический limit
- **AND** ДОЛЖЕН вернуть существующий результат или признак already linked

### Requirement: Поиск кандидатов на связь исключает недопустимые риски

`POST /api/v1/risks/limit/campaign/link/search` ДОЛЖЕН исключать risks другого tenant, запрещённых статусов, уже связанных и невидимых пользователю.

#### Scenario: Поиск выполнен по неполному id

- **WHEN** query соответствует большому числу risks
- **THEN** сервис ДОЛЖЕН вернуть ограниченный count/list и не загружать неограниченную выборку

### Requirement: История campaign и limit восстанавливает изменения

History endpoints ДОЛЖНЫ показывать versions, status transitions, author, timestamp, comments и field changes, включая изменения links, где применимо.

#### Scenario: Пользователь открывает историю лимита

- **WHEN** существует несколько versions
- **THEN** изменения amounts и comment ДОЛЖНЫ быть представлены относительно предыдущей версии в хронологическом порядке

### Requirement: Ретроспектива сопоставляет кампании и факты

Campaign/limit retro ДОЛЖНА сопоставлять год, status, фактические суммы, лимиты и изменения отдельно для loss, near miss и credit loss.

#### Scenario: Предыдущих данных нет

- **WHEN** для типа эффекта отсутствует прошлый limit или fact sum
- **THEN** percent change/utilization ДОЛЖЕН быть `null`, а не бесконечностью или вводящим в заблуждение нулём

### Requirement: Формулы процентов единообразны

Utilization ДОЛЖЕН вычисляться как `sum / limit * 100`, а изменение — `(current - previous) / previous * 100`, с HALF_UP и целочисленным представлением процентов; деление на zero ДОЛЖНО давать отсутствие значения.

#### Scenario: Изменение положительное

- **WHEN** current больше ненулевого previous
- **THEN** display value ДОЛЖЕН иметь формат `+N%`

#### Scenario: Изменение равно нулю

- **WHEN** calculated difference равна нулю
- **THEN** display change МОЖЕТ не выводиться согласно текущему контракту

### Requirement: Утверждение переносит лимиты в effects рисков

При apply campaign сервис ДОЛЖЕН для каждого видимого limit установить поле `limit` соответствующего risk effect на год campaign и тип `loss`/`nearMiss`/`creditLoss`.

#### Scenario: Effect нужного типа отсутствует

- **WHEN** limit amount задан, а effect за год/тип отсутствует
- **THEN** сервис ДОЛЖЕН создать effect с детерминированным id `<finEffectNature>_<year>`

#### Scenario: Risk не имеет limit в campaign

- **WHEN** активный risk не включён в applied campaign
- **THEN** его effect.limit за год ДОЛЖЕН быть сброшен в zero согласно бизнес-правилу

#### Scenario: Risk исчез между согласованием и apply

- **WHEN** связанный risk отсутствует или больше не active
- **THEN** операция ДОЛЖНА пропустить/зафиксировать проблему адресно и НЕ ДОЛЖНА применить limit к другому risk

### Requirement: Apply/reset jobs идемпотентны

Internal jobs `limitCampaignApply` и `limitCampaignReset` ДОЛЖНЫ принимать tenantIds и campaign context, вести correlation и безопасно повторяться после частичного сбоя.

#### Scenario: Apply запущен повторно

- **WHEN** effects уже содержат значения той же accepted campaign
- **THEN** повтор НЕ ДОЛЖЕН создавать duplicate effects или лишние risk versions без фактического изменения

### Requirement: Kafka snapshot потерь обрабатывается tenant-aware

Limit consumer ДОЛЖЕН валидировать payload `tenantid`, `reportingDate` и список `losses`, установить TenantContext и сохранить snapshot идемпотентно по его business key.

#### Scenario: Payload не парсится

- **WHEN** Kafka message не соответствует схеме
- **THEN** сообщение НЕ ДОЛЖНО подтверждаться как успешно применённое
- **AND** ДОЛЖНО попасть в контролируемую retry/DLQ policy без логирования полного чувствительного payload

#### Scenario: Ошибка после парсинга retryable

- **WHEN** БД временно недоступна
- **THEN** ack НЕ ДОЛЖЕН фиксироваться до успешного commit

### Requirement: Сводка потерь доступна только допустимым ролям

`GET /api/v1/risks/limit` с `Risk.View` ДОЛЖЕН скрывать limit-loss dashboard от пользователя только с ролью `ORMCLOUD_USER` и возвращать последний snapshot текущего года другим допустимым ролям.

#### Scenario: Snapshot текущего года отсутствует

- **WHEN** агрегаты не поступали
- **THEN** сервис ДОЛЖЕН вернуть пустое body/явное отсутствие, не используя устаревший год как текущий

### Requirement: Сводка сортируется и связывается с фильтрами риска

Loss categories ДОЛЖНЫ сортироваться `loss`, `nearMiss`, `creditLoss`; для поддерживаемых типов response ДОЛЖЕН содержать boolean filters, открывающие соответствующие risks/effects.

#### Scenario: Пользователь выбирает near miss

- **WHEN** клиент применяет filter из summary item
- **THEN** реестр рисков ДОЛЖЕН отфильтровать effects с `inUtilizationNearMiss=true`

## Публичные операции capability

| Операция | Permission |
|---|---|
| Campaign view/history/search/quick filters/link search | `Limit.View` |
| Campaign workflow/link limits | `Limit.Edit` |
| Limit view/retro/history/refresh | `Limit.View` |
| Limit create/update/visibility | `Limit.Edit` |
| Limit utilization summary | `Risk.View` плюс role guard |
