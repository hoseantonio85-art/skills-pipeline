# agent-category-auto-assess Specification

## Purpose
TBD - created by archiving change agent-category-level-auto-assess. Update Purpose after archive.
## Requirements
### Requirement: Agent pipeline SHALL aggregate risks by category type

When resolving risks for an agent, the pipeline SHALL classify active risks by their `categoryType` attribute from the `aiRiskType` dictionary and expose them as `Map<String, List<Risk>>` in `AgentCtx`.

#### Scenario: Risks classified by categoryType
- **WHEN** an agent has linked risks with different `aiRiskType` values, each mapped to a `categoryType` attribute in the `aiRiskType` dictionary
- **THEN** `AgentCtx.setRiskByCategories()` SHALL contain a map where keys are `categoryType` strings and values are lists of active risks

#### Scenario: Risks without aiRiskType are excluded
- **WHEN** a risk linked to an agent has null `aiRiskType`
- **THEN** the risk SHALL NOT appear in any category map entry

#### Scenario: Only active risks are resolved
- **WHEN** `AgentResolveRisksStage.apply()` is executed
- **THEN** only risks with `status=ACTIVE` SHALL be queried via `RiskFilters.byStatus(ACTIVE)`

### Requirement: Category SECURITY SHALL be auto-assessed when maxRiskLevel is LOW or MEDIUM

For an agent in `REVIEW` or `APPROVED` status with no existing categories, if a `SECURITY` category exists and the maximum risk level of risks in that category is `LOW` or `MEDIUM`, the category SHALL be auto-assessed with `status=ASSESSED` and `verifier=TECHNICAL_ID`.

#### Scenario: SECURITY category with LOW risk → ASSESSED
- **WHEN** agent is in status `REVIEW`, has a `SECURITY` category, and the only risk in that category has `riskLevel=LOW`
- **THEN** `AgentCategoryService.resolve()` SHALL set category status to `ASSESSED` and verifier to `TECHNICAL_ID`

#### Scenario: SECURITY category with MEDIUM risk → ASSESSED
- **WHEN** agent is in status `APPROVED`, has a `SECURITY` category, and the maximum risk level across all risks in that category is `MEDIUM`
- **THEN** the category SHALL be auto-assessed with `status=ASSESSED` and `verifier=TECHNICAL_ID`

#### Scenario: SECURITY category with HIGH risk → NOT ASSESSED
- **WHEN** agent is in status `REVIEW`, has a `SECURITY` category, and the maximum risk level in that category is `HIGH`
- **THEN** the category SHALL NOT be auto-assessed — its status SHALL remain `notAssessed` (unchanged)

#### Scenario: SECURITY category with no_risks → NOT ASSESSED
- **WHEN** agent has a `SECURITY` category but the max risk level is `no_risks`
- **THEN** the category SHALL NOT be auto-assessed

### Requirement: Category RELIABILITY SHALL be auto-assessed when agentEntityType is application

For an agent in `REVIEW` or `APPROVED` status with no existing categories, if a `RELIABILITY` category exists and the agent's `agentEntityType` equals `"application"`, the category SHALL be auto-assessed with `status=ASSESSED` and `verifier=TECHNICAL_ID`.

#### Scenario: RELIABILITY category for application agent → ASSESSED
- **WHEN** agent status is `APPROVED`, `agentEntityType="application"`, and a `RELIABILITY` category exists
- **THEN** the category SHALL be auto-assessed with `status=ASSEED` and `verifier=TECHNICAL_ID`

#### Scenario: RELIABILITY category for non-application agent → NOT ASSESSED
- **WHEN** agent status is `REVIEW`, `agentEntityType="api"`, and a `RELIABILITY` category exists
- **THEN** the category SHALL NOT be auto-assessed

### Requirement: Empty categories SHALL be removed from agent

When resolving categories for an agent, if a category type has no associated risks, it SHALL be removed from the agent's category list.

#### Scenario: Category with no risks is removed
- **WHEN** `AgentCategoryService.resolve()` processes risks grouped by category, and `SECURITY` type has zero risks
- **THEN** the `SECURITY` category SHALL be removed from `AgentRiskCategories`
- **AND** the updated categories SHALL be written back to the agent via `AgentRiskCategories.toAgent()`

#### Scenario: Non-empty categories are preserved
- **WHEN** `AgentCategoryService.resolve()` processes risks grouped by category, and `RELIABILITY` type has one or more risks
- **THEN** the `RELIABILITY` category SHALL remain in the agent's category list

### Requirement: Category maxRiskLevel SHALL be computed from associated risks

For each category rendered in the UI, the `maxRiskLevel` field SHALL be computed as the maximum `riskLevel` among all risks in that category, using `RiskLevel.NOT_ESTIMATED` as the default when risks lack the `riskLevel` attribute.

#### Scenario: Max risk level computed from multiple risks
- **WHEN** a category contains 3 risks with levels `[LOW, HIGH, MEDIUM]`
- **THEN** `maxRiskLevel` for that category SHALL be `HIGH`

#### Scenario: All risks lack riskLevel → NOT_ESTIMATED
- **WHEN** a category contains risks but none have `riskLevel` set
- **THEN** `maxRiskLevel` for that category SHALL be `NOT_ESTIMATED`

#### Scenario: Empty risk list for category
- **WHEN** a category has zero associated risks
- **THEN** `AgentRiskCategories.resolveMaxRiskLevel()` SHALL return `Optional.empty()`

### Requirement: Agent workflow context SHALL carry risksByCategories

`AgentWorkflowContext` SHALL store `agent`, `user`, and `risksByCategories` fields, replacing the generic `WorkflowContext<Agent>` used by `AgentWorkflowServiceImpl`.

#### Scenario: Agent approved workflow action passes risksByCategories
- **WHEN** `AgentWorkflowServiceImpl.onActionApplied()` processes a `success` action for an agent transitioning to `REVIEW`
- **THEN** `agentCategoryService.resolve(agent, context.getRisksByCategories())` SHALL be invoked with the risks-by-categories from the context

#### Scenario: Auto-apply workflow action carries risksByCategories
- **WHEN** `AgentServiceImpl.updateAndAutoApply()` executes a workflow action
- **THEN** `AgentAutoApplyWorkflowStage.apply()` SHALL call `agentWorkflowService.autoApply(ctx.toWorkflowContext(), actionRequest)`

### Requirement: Links resolver SHALL support template visibility control

`AgentLinkComponentResolver.resolveCategories()` SHALL accept a `showTemplates` flag that controls whether category templates (empty category entries) are rendered alongside existing categories.

#### Scenario: showTemplates=true renders all category types
- **WHEN** `showTemplates` is true and the agent has categories `[SECURITY]`
- **THEN** the rendered category items SHALL include ALL dictionary `agentCategoryType` entries

#### Scenario: showTemplates=false renders only existing categories
- **WHEN** `showTemplates` is false and the agent has categories `[SECURITY]`
- **THEN** the rendered category items SHALL include ONLY `SECURITY`

#### Scenario: showTemplates=true for agent with no categories
- **WHEN** `showTemplates` is true and the agent has zero categories
- **THEN** the rendered category items SHALL include ALL dictionary `agentCategoryType` entries as empty templates

