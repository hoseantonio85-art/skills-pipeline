## Purpose

Define requirements for the confirm-message mechanism that warns users before editing critical agent fields (criticality, entity type, stage).

## Requirements

### Requirement: Форма редактирования агента содержит confirm-маркер для критичных полей

При запросе карточки агента в режиме редактирования (`isForEdit = true`) `GET /api/v1/risks/agents/{id}` ДОЛЖЕН возвращать `FormComponent`, где критические поля содержат `extras.showConfirmMessage` со значением `true`.

Критические поля (определяются константами из `AgentBusinessFields`):
- `agentCriticalityLevel` (`AgentBusinessFields.Agent.AGENT_CRITICALITY_LEVEL`)
- `agentEntityType` (`AgentBusinessFields.Agent.AGENT_ENTITY_TYPE`)
- `agentStage` (`AgentBusinessFields.Agent.AGENT_STAGE`)

#### Scenario: Редактирование критичности

- **WHEN** пользователь с `AgentRisks.Edit` запрашивает карточку агента в режиме редактирования
- **THEN** `FormComponent.fields.agentCriticalityLevel.extras.showConfirmMessage` ДОЛЖЕН быть `true`
- **AND** фронтенд ДОЛЖЕН показать confirm-dialog перед отправкой save

#### Scenario: Редактирование типа сущности

- **WHEN** пользователь с `AgentRisks.Edit` запрашивает карточку агента в режиме редактирования
- **THEN** `FormComponent.fields.agentEntityType.extras.showConfirmMessage` ДОЛЖЕН быть `true`
- **AND** фронтенд ДОЛЖЕН показать confirm-dialog перед отправкой save

#### Scenario: Редактирование этапа оценки

- **WHEN** пользователь с `AgentRisks.Edit` запрашивает карточку агента в режиме редактирования
- **THEN** `FormComponent.fields.agentStage.extras.showConfirmMessage` ДОЛЖЕН быть `true`
- **AND** фронтенд ДОЛЖЕН показать confirm-dialog перед отправкой save

#### Scenario: Просмотр без подтверждений

- **WHEN** пользователь запрашивает карточку агента в режиме просмотра (`isForEdit = false`)
- **THEN** `FormComponent.fields.agentCriticalityLevel.extras` НЕ ДОЛЖЕН содержать `showConfirmMessage`
- **AND** `FormComponent.fields.agentEntityType.extras` НЕ ДОЛЖЕН содержать `showConfirmMessage`
- **AND** `FormComponent.fields.agentStage.extras` НЕ ДОЛЖЕН содержать `showConfirmMessage`

#### Scenario: Extras существуют как карта на форме

- **WHEN** пользователь запрашивает карточку агента (в любом режиме)
- **THEN** `FormComponent.entity.fields` ДОЛЖЕН быть типом карты (Map)
- **AND** каждый элемент карты ДОЛЖЕН иметь ключ — имя поля (String)
- **AND** каждый элемент карты ДОЛЖЕН иметь значение — объект с полями `value`, `extras` и другими

### Requirement: Confirm-механизм является универсальным

Дизайн extras-confirm ДОЛЖЕН поддерживать повторное применение для других полей без изменения core-архитектуры.

#### Scenario: Добавление confirm для нового поля

- **WHEN** необходимо добавить confirm-маркер для нового поля
- **THEN** разработчик ДОЛЖЕН:
  1. Добавить поле в карту extras в `AgentResolveExtrasStage.apply()`
  2. Использовать константы из `AgentBusinessFields`
  3. Фронтенд автоматически отобразит confirm-dialog при `showConfirmMessage == true`
