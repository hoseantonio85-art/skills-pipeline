# Analytical specifications — on-demand evidence

Эти документы предоставлены аналитиками и хранятся как **reference/evidence layer**, а не как автоматически загружаемый product context.

Правила:

- сначала открыть `index.yaml` и выбрать только релевантные capability specs;
- наличие файла не означает, что он current: статус `unknown` требует осторожности;
- для UX извлекать только user-visible/domain-significant факты;
- для SDD переводить техническое описание в наблюдаемое продуктовое поведение;
- API/DTO/storage/classes/topics и иные implementation details не копировать в SDD;
- при конфликте с Intent/Brief/approved UX или фактическим repository contract фиксировать конфликт, а не выбирать источник молча.
