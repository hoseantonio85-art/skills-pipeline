# Спецификация переоценки и supporting domains

## Назначение

Определить общую переоценку рисков, задачи `RISK_ASSESSMENT_TASK`, информационные поводы AI Compliance, задачи Сената, общую модель вложений и типизированных связей, которые поддерживают основные risk capabilities.

## 1. Общая переоценка рисков

### Модель `RISK_ASSESSMENT_TASK`

| Поле | Семантика |
|---|---|
| system UUID | primary key |
| `business_id` | стабильный taskId, уникальный в tenant |
| `external_id` | id внешней задачи/задачи Сената |
| `sys_ownerid` | tenant |
| `author` | пользователь или technical id |
| `type` | `b2b`, `senate`, `newFiles`, `external` |
| timestamps | created, readyForStart, startProcess, end |
| `status` | `new`, `pending`, `readyForStart`, `inProcess`, `success`, `error` |
| `file_id_list` | snapshot ids документов |
| `error_code` | terminal/processing error |
| `inn` | организация tenant |
| `summary` | terminal summary |

### Requirement: Переоценка с файлами требует непустой snapshot

`POST /api/v1/risks/ai/start-reassessment` ДОЛЖЕН при новом запуске требовать непустые `fileIds`, определить author/tenant/INN и создать task type `newFiles`, status `pending`.

#### Scenario: Новая задача создана

- **WHEN** пользователь с `Risk.Create` или `Risk.AgentReassessment` передаёт файлы
- **THEN** сервис ДОЛЖЕН создать UUID taskId и неизменяемый snapshot fileIds

#### Scenario: FileIds отсутствуют

- **WHEN** taskId не передан и список пуст
- **THEN** сервис ДОЛЖЕН вернуть validation error без task

### Requirement: Ошибочную задачу можно перезапустить

Если передан существующий taskId status `error`, сервис ДОЛЖЕН перевести его в `pending`, сохранив исходный file snapshot и correlation.

#### Scenario: Task не error

- **WHEN** restart запрошен для active/success task
- **THEN** сервис ДОЛЖЕН вернуть state conflict и не менять status

### Requirement: B2B-задача стартует без файлов

Trusted internal `startReassessment` ДОЛЖЕН создать task type `b2b`, status `readyForStart`, technical author и переданный валидный INN.

#### Scenario: Повтор B2B-trigger

- **WHEN** внешняя система повторяет один logical event
- **THEN** idempotency key ДОЛЖЕН предотвращать duplicate active tasks для того же события

### Requirement: Senate-задача связывается с external issue

Создание Senate assessment ДОЛЖНО требовать existing `SENATE_ISSUE`, сохранять его id в `externalId`, snapshot materials fileIds, INN, type `senate`, status `pending`.

#### Scenario: Senate issue отсутствует

- **WHEN** job пытается создать assessment
- **THEN** task НЕ ДОЛЖНА создаваться без валидной external reference

### Requirement: Ожидание файлов переводит pending в readyForStart

File-checker ДОЛЖЕН проверять готовность snapshot ids; все готовые файлы переводят task в `readyForStart`, timeout — в `error`.

#### Scenario: Все документы обработаны

- **WHEN** document service не возвращает pending ids
- **THEN** status ДОЛЖЕН стать `readyForStart`, `timeReadyForStart=now`

#### Scenario: Документ не готов до timeout

- **WHEN** configured deadline истёк
- **THEN** status ДОЛЖЕН стать `error`, уведомление и metric ДОЛЖНЫ быть отправлены один раз

### Requirement: Запуск внешнего агента типизирован

Для ready/new retry task сервис ДОЛЖЕН отправить `id`, `inn`, `type`, optional `fileIds`; для Senate дополнительно title issue в `info` и выделенный agent endpoint/client.

#### Scenario: Внешний старт успешен

- **WHEN** agent принимает запрос
- **THEN** task ДОЛЖНА стать `inProcess`, `timeStartProcess=now`

#### Scenario: Внешний старт неуспешен

- **WHEN** вызов выбрасывает ошибку
- **THEN** task ДОЛЖНА стать/вернуться `new` для controlled job retry
- **AND** НЕ ДОЛЖНА ложно считаться inProcess

### Requirement: Start job предотвращает бесконечные retries

Scheduled start handler ДОЛЖЕН учитывать возраст, attempts/backoff и terminal policy; task, просроченная с момента создания, ДОЛЖНА стать `error`.

#### Scenario: Внешний агент длительно недоступен

- **WHEN** retry budget исчерпан
- **THEN** task ДОЛЖНА получить terminal error и support correlation

### Requirement: Callback завершения устанавливает tenant безопасно

Internal `end-reassessment` ДОЛЖЕН аутентифицировать caller, найти task и использовать сохранённый tenant/INN mapping; входной INN НЕ ДОЛЖЕН позволять доступ к другому tenant.

#### Scenario: Result success

- **WHEN** existing task `inProcess` получает success
- **THEN** status ДОЛЖЕН стать `success`, `timeEnd` и summary сохраниться, completion mail/metrics отправиться один раз

#### Scenario: Result error

- **WHEN** existing task `inProcess`/`new` получает failure
- **THEN** status ДОЛЖЕН стать `error`, error code сохраниться и failure notification отправиться

### Requirement: External terminal callback имеет явную семантику

Если callback относится к неизвестной локальной task, сервис МОЖЕТ создать terminal task type `external`, но только для trusted source и при наличии уникального external correlation.

#### Scenario: Неизвестный trusted success callback

- **WHEN** policy допускает external task
- **THEN** сервис ДОЛЖЕН создать одну terminal `external/success` запись без имитации локального start timestamp

#### Scenario: Повтор external callback

- **WHEN** terminal запись уже создана
- **THEN** duplicate НЕ ДОЛЖЕН создавать вторую запись

### Requirement: Assessment UI отражает ход задачи

View/list/summary ДОЛЖНЫ возвращать status, title/hint, counts new/reassess, percentage, info messages, closable/redirectable/source и возможность restart, вычисленную по роли/status.

#### Scenario: Admin видит ошибочную task

- **WHEN** status `error` и user имеет `ORMCLOUD_ADMIN`
- **THEN** server-driven form МОЖЕТ вернуть restart action

#### Scenario: Обычный viewer видит техническую ошибку

- **WHEN** нет admin role
- **THEN** raw errorCode НЕ ДОЛЖЕН раскрывать внутренние детали

### Requirement: Task summary выбирается детерминированно

При наличии нескольких tasks summary ДОЛЖЕН отдавать приоритет active `inProcess/new`, затем earliest `readyForStart`, затем `pending`, согласно продуктовой политике.

#### Scenario: Есть active и pending task

- **WHEN** запрашивается summary
- **THEN** active task ДОЛЖНА определять banner/progress

## 2. Информационные поводы и AI Compliance

### Модель `INFO_FEED`

Info feed — versioned tenant business object с historic revision и полями: `businessId`, `externalId`, `name`, `description`, `impact`, `company`, `type`, publication/inspection counts, `creator`, risks, riskLevel, sources, region, publicationDate, trend, status, disagreeCause, relatedDocs, signatoryAuthority и updaterTaskId.

### Requirement: Инфоповод создаётся только из доверенного источника

Create через MCP/internal pipeline ДОЛЖЕН требовать external correlation, tenant, updaterTaskId и валидную transport model.

#### Scenario: Активный externalId уже существует

- **WHEN** status existing item `new`
- **THEN** duplicate НЕ ДОЛЖЕН создаваться

### Requirement: Инфоповод имеет lifecycle new/archive

Action `delete` ДОЛЖЕН переводить `new→archive` для risk manager/partner с `Risk.Create`; physical deletion запрещён.

#### Scenario: Archived item получает delete повторно

- **WHEN** action отсутствует в status `archive`
- **THEN** сервис ДОЛЖЕН вернуть idempotent outcome/conflict без новой версии

### Requirement: Info feed read/search соблюдает Risk.View

View/search endpoints ДОЛЖНЫ фильтровать tenant, visibility и section, возвращая server-driven fields, source components, links к risks и history-safe metadata.

#### Scenario: Источник содержит URL

- **WHEN** link выводится клиенту
- **THEN** server ДОЛЖЕН валидировать разрешённую схему и не генерировать исполняемый content

### Requirement: AI Compliance search имеет ограниченный контракт

External search ДОЛЖЕН принимать только allowlisted fields/query, ограничивать result size и возвращать quick filters/view config, не открывая общий registry query язык.

#### Scenario: Query содержит injection payload

- **WHEN** пользовательский текст передан в search
- **THEN** он ДОЛЖЕН обрабатываться как значение, не как expression/SQL

## 3. Интеграция с Сенатом

### Модель `SENATE_ISSUE`

Tenant-scoped versioned object хранит JSON `data`: `issueId`, `title`, `stage`, change/create/decline dates, `decision`, `status`, `category`; материалы описываются `id`, `version`, `name`, `encrypted`, `ecmId`, `size`.

### Requirement: Senate issues синхронизируются по внешнему ключу

Сервис ДОЛЖЕН upsert issue по tenant+issueId/object id с optimistic version и не создавать duplicate при повторной синхронизации.

#### Scenario: Получена новая версия issue

- **WHEN** external lastChangeDate новее current
- **THEN** current data ДОЛЖНА обновиться с audit/history

### Requirement: Senate preprocessing классифицирует issue наблюдаемо

Preprocess job ДОЛЖЕН выбрать eligible issue, вызвать configured classification model с bounded input, сохранить classification/stage outcome либо status `error`.

#### Scenario: GigaChat недоступен

- **WHEN** вызов неуспешен
- **THEN** issue НЕ ДОЛЖЕН перейти в prepared/completed
- **AND** retry должен иметь ограниченный budget

### Requirement: Senate assessment использует материалы

Assessment job ДОЛЖЕН получить материалы, безопасно создать document records/fileIds, создать Senate task и связать её с issue.

#### Scenario: Один материал не загружен

- **WHEN** обязательный набор неполон
- **THEN** assessment НЕ ДОЛЖНА стартовать как полная
- **AND** issue/task ДОЛЖНЫ получить диагностируемое состояние

### Requirement: Senate risk status зависит от stage

Risk, созданный Senate task, ДОЛЖЕН получить source `senate`; при stage `completed` — status `inReview`, иначе `draft`.

#### Scenario: Senate task повторно присылает existing businessId

- **WHEN** risk уже существует
- **THEN** Senate MCP/internal path ДОЛЖЕН пропустить update и вернуть existing id согласно идемпотентной политике

## 4. Общие вложения

### Requirement: Attachment metadata целостна

Каждая запись `ATTACHMENT` ДОЛЖНА однозначно связывать fileId с tenant, businessId, objectVersion/type, типом вложения, безопасным именем, extension, size, author, timestamp и cryptographic hash.

#### Scenario: Hash не совпадает при скачивании для обработки

- **WHEN** bytes файлового сервиса не соответствуют metadata hash
- **THEN** файл НЕ ДОЛЖЕН передаваться внешнему агенту
- **AND** incident/metric ДОЛЖЕН быть зафиксирован

### Requirement: Attachment lifecycle компенсирует orphan data

Создание/удаление metadata и remote blob ДОЛЖНЫ иметь идемпотентную compensation policy.

#### Scenario: Blob сохранён, metadata commit неуспешен

- **WHEN** upload transaction откатилась
- **THEN** remote blob ДОЛЖЕН быть удалён или зарегистрирован для cleanup

### Requirement: Бинарный ответ безопасен

Download ДОЛЖЕН возвращать корректные `Content-Type`, safe `Content-Disposition`, длину, no-sniff и не отражать CR/LF из filename.

#### Scenario: Filename содержит управляющие символы

- **WHEN** формируется header
- **THEN** имя ДОЛЖНО быть нормализовано/encoded

## 5. Связи и внешние объекты

### Requirement: Link types имеют каноническое направление

Сервис ДОЛЖЕН иметь allowlist link type, from object type и to object type; по крайней мере поддерживаются risk→measure, risk→agent, risk→agentCategory, risk→product, risk→productCategory, risk→assessmentTask, risk→infoFeed.

#### Scenario: Направление перепутано

- **WHEN** from/to types не соответствуют config
- **THEN** link command ДОЛЖНА быть отклонена

### Requirement: Link creation идемпотентна

Одинаковая комбинация tenant/linkType/fromBusinessId/toBusinessId НЕ ДОЛЖНА создавать logical duplicate.

#### Scenario: Callback переотправлен

- **WHEN** те же links создаются повторно
- **THEN** link service/result ДОЛЖЕН считать их уже существующими без ошибки business process

### Requirement: Частичный link batch не маскируется

Batch response ДОЛЖЕН позволять определить outcome каждого link либо обеспечивать атомарность всего batch.

#### Scenario: Один target отсутствует

- **WHEN** часть batch невалидна
- **THEN** risk-cloud ДОЛЖЕН применить documented all-or-nothing/compensation policy

### Requirement: Интеграция с сервисом мер сохраняет AI identity

Draft measure, созданная по recommendation, ДОЛЖНА хранить AI measure id, name/description и возвращать businessId для link; повтор должен находить её по AI id в контексте risk.

#### Scenario: Measure service timeout после commit

- **WHEN** response потерян
- **THEN** retry ДОЛЖЕН использовать idempotency key и не создать вторую меру

### Requirement: Все external calls имеют correlation

Document, link, measure, tenant, dictionary, employee, Senate, AI и mail вызовы ДОЛЖНЫ передавать/логировать безопасный correlation id, связанный с task или request.

#### Scenario: Распределённая ошибка расследуется

- **WHEN** support использует correlation id
- **THEN** trace ДОЛЖЕН связывать входную команду, внешние вызовы и domain outcome без содержимого документов
