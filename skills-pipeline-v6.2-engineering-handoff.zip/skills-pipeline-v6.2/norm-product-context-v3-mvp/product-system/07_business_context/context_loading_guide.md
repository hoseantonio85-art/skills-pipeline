# Руководство по загрузке контекста

## Общий принцип

Сначала читайте manifest и профиль текущего stage. Не передавайте модели весь repository.

## Этап 01 — Intent + Product Brief

Автоматически: status, authority, mission, constraints, product philosophy, services map, roles, glossary, common rules и known capabilities.

По запросу: только релевантный service document и evidence, влияющее на feasibility.

Не читать: UX, UI, UI Kit и frontend rules.

## Этап 02 — UX Solution

Автоматически: stage 01 foundation в необходимом объёме, current product state/sources, UX principles и UX patterns.

По запросу: релевантные services и evidence текущего flow.

Не читать: UI Kit API, design tokens и frontend implementation rules.

## Этап 03 — Visual HTML Prototype

Автоматически: UX principles, UX patterns, UI context status и visual rules.

По запросу: один relevant service document и один approved UI pattern.

Не читать: весь UI Kit package, все services, полные frontend rules и product repositories.

## Этап 03.5 — UX Sync

Автоматически: UX principles и UX patterns. Главный вход — task artifacts и review evidence. Не менять Intent и не загружать UI Kit без необходимости.

## Этап 04 — SDD Specification

Автоматически: foundation, services map, roles, common business rules, capabilities и constraints.

По запросу: только подтверждённые service/domain/architecture sources, необходимые для конкретного требования.

Не читать как authority: prototype code, mock fields, DOM/CSS structure и feature-specific данные из product context.

## Длинные задачи

Progress и реально прочитанные sources фиксируются в increment-файле текущего stage. После `/clear` новая сессия продолжает работу по checkpoint, а не повторяет исследование.
