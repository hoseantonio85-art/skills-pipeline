# UI context

Раздел содержит стабильный UI/visual context для `build-visual-html-prototype` и будущих implementation-этапов вне pipeline v6.

- `ui_context_status.md` — доступность и ограничения;
- `prototype_ui_rules.md` — компактные UX/UI правила stage 03;
- `frontend_prototype_rules.md` — компактные технические правила prototype;
- `ui_sources.yaml` — маршруты к точным источникам;
- `ui-kit/component-index.yaml` — быстрый индекс API;
- `ui-kit/ui_base.md` — документация, читаемая только фрагментами;
- `patterns/` — расширяемый optional registry.

Полные packages и нормативные первоисточники находятся в `sources/` и не входят в auto-load.
