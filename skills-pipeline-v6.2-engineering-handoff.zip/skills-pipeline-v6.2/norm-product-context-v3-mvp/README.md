# NORM Product Context v3 MVP

Единый локальный context repository для пяти GigaCode skills:

1. `formulate-product-intent-and-brief` — этап 01;
2. `design-ux-solution` — этап 02;
3. `build-visual-html-prototype` — этап 03;
4. `sync-ux-decisions` — этап 03.5;
5. `build-sdd-specification` — этап 04.

Точка входа:

```text
product-system/context-manifest.yaml
```

Контекст отделён от skills и task increments. Skills устанавливаются отдельно, а feature-specific документы (`00_intent.md`, `01_product_brief.md`, `02_ux_solution.md`, `03_visual_prototype.md`, `03_5_ux_sync.md`, `04_sdd_specification.md`) находятся в рабочем проекте.

## Принцип устройства

- `product-system/` — компактные нормализованные знания, которые разрешено загружать в контекст модели;
- `sources/` — полные первоисточники и пакеты для точечной проверки, но не для автоматической загрузки;
- `loading` в manifest определяет, какой объём получает каждый skill;
- отсутствующие UI patterns не блокируют быстрый этап 03: используется UX Solution, visual rules и HTML starter.

Product context хранит только стабильные знания продукта, домена и guardrails. Не добавляйте в него feature-specific Intent/Brief или имена параметров и реализации конкретного прототипа.

См. `CONTEXT_SETUP.md`, `CONTEXT_MAINTENANCE.md` и `product-system/07_business_context/stage_access_matrix.yaml`.

