# NORM product + frontend engineering pipeline

For product, UX and engineering tasks, use the matching skill/subagent from `.gigacode/skills/` and `.gigacode/agents/` explicitly or automatically.

Before any NORM conclusion:

1. Read `.gigacode/product-context.yaml` and obtain `context_id`.
2. Read `~/.gigacode/product-contexts.yaml`.
3. Resolve `contexts[context_id].provider.root` and `provider.manifest`.
4. Read `<provider.root>/<provider.manifest>` and the profile required by the active skill/subagent.
5. List the manifest and actually read files in `Context trace`.

If NORM is selected but the registry, manifest or required profile cannot be read, stop with `BLOCKED_BY_CONTEXT`. Do not produce a generic NORM result.

Pipeline contract:

1. `formulate-product-intent-and-brief` creates both `00_intent.md` and `01_product_brief.md`.
2. `design-ux-solution` treats Intent as outcome guardrail and Brief as product truth.
3. `build-visual-html-prototype` creates fast HTML/CSS/JS UX evidence, not a production contract.
4. `sync-ux-decisions` finalizes UX Solution after review and never edits Intent.
5. `build-sdd-specification` creates observable Product SDD and must exclude implementation design.
6. Only after `APPROVED_FOR_ENGINEERING`, `frontend-planner` reads target repo and creates `05_frontend_plan.md`.
7. `frontend-implementer` implements only selected FE increment(s) from the approved plan and records `06_frontend_implementation.md`.
8. `frontend-reviewer` independently reviews the diff and creates `07_frontend_review.md`; `FIX_REQUIRED` returns narrow finding IDs to implementer.
9. `frontend-standards` is shared engineering knowledge for stages 05–07, not a product/UX skill.

Context discipline:

- Product stages 01–04 must not load frontend rules or repository implementation details unless an explicit product-level dependency requires evidence, and even then technical mechanisms are not copied into SDD.
- Engineering stages 05–07 may load `sources/frontend-rules/**`, target repo contracts and actual UI Kit APIs.
- One implementation context = one bounded FE increment. Use a new/clean context for independent review.
