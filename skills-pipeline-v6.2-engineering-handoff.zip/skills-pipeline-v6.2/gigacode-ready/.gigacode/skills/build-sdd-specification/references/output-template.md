# SDD / Delta Specification — шаблон

## Metadata and status

## 1. Intent trace

- Intent:
- Why Now:
- Expected improvement:
- Success criteria covered:

Не копировать весь Intent; дать ссылки и краткую traceability.

## 2. Scope and actors

## 3. User stories and scenarios

Каждый сценарий должен быть самостоятельным и понятным без прототипа.

### SCN-01 — <название через пользовательский результат>

- Actor and preconditions:
- Trigger:
- Main flow:
- Alternatives:
- Result:
- Sources:

## 4. Business rules

| ID | Rule | Source | Status |
|---|---|---|---|
| BR-01 | | | confirmed / TBD |

Использовать business vocabulary. Не ссылаться на prototype variable/parameter names.

## 5. Acceptance criteria

### AC-01 — <результат>

```gherkin
Given <подтверждённое состояние>
When <действие или событие>
Then <наблюдаемый результат системы>
And <наблюдаемый результат для пользователя>
```

## 6. Error and consistency matrix

| ID | Condition / error | System reaction | User-visible result | Recovery / next step | Source/status |
|---|---|---|---|---|---|
| ERR-01 | | | | | |

## 7. Data and state consistency

Только подтверждённые authoritative sources, state transitions, persistence и concurrency rules. Остальное — `TBD / requires analysis`.

## 8. Constraints, assumptions and dependencies

## 9. Technical design

Добавлять только подтверждённый анализом контент. Прототип не является основанием для API, schemas, stores, naming или production architecture.

### Confirmed design

### Requires analysis

## 10. Non-functional requirements

Только подтверждённые требования.

## 11. Traceability

| Requirement | Intent/Brief | UX decision | Prototype evidence | Technical source | Status |
|---|---|---|---|---|---|

## 12. Open questions and owners

## 13. Review and approval

