# SDD quality checklist

- [ ] Сценарии читаются без открытия прототипа.
- [ ] Каждое GWT проверяет requirement, а не CSS/DOM detail.
- [ ] Error matrix содержит condition, system reaction, user-visible result и recovery.
- [ ] Business rules используют предметные термины, а не prototype parameter names.
- [ ] Hardcoded prototype values не объявлены production constraints без источника.
- [ ] Technical design отделяет confirmed от `requires analysis`.
- [ ] Intent не переписан и не расширен implementation details.
- [ ] Deviations взяты из approved UX Sync.
- [ ] Для ключевых требований есть traceability.
- [ ] Unknowns не выданы за факты.
