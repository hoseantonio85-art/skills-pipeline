# Install frontend engineering v1

1. Copy `skill/frontend-standards/` to `.gigacode/skills/frontend-standards/`.
2. Copy `agents/frontend-planner.md`, `frontend-implementer.md`, `frontend-reviewer.md` to `.gigacode/agents/`.
3. Configure tool profiles:
   - planner: Read-only Tools;
   - implementer: Read & Edit & Execution Tools;
   - reviewer: Read-only Tools.
4. Ensure project `GIGACODE.md` contains the stage/status contracts or use `gigacode-ready/GIGACODE.md`.
5. Run `/clear` or start a new session after installation.

Recommended explicit calls:

- `Используй frontend-planner. На основании @04_sdd_specification.md и target repo сформируй @05_frontend_plan.md.`
- `Используй frontend-implementer. Реализуй только FE-01 из @05_frontend_plan.md.`
- `Используй frontend-reviewer. Независимо проверь diff FE-01 против SDD и frontend plan.`
