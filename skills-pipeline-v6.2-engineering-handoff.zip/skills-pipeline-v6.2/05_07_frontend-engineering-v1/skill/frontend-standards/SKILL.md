---
name: frontend-standards
description: Общие frontend-правила для инженерного планирования, реализации и независимого ревью в sberorm-cloud-*-front. Используй только после APPROVED_FOR_ENGINEERING, когда работа идёт с target frontend repo, React/TypeScript, UI Kit, архитектурой, i18n, accessibility, async-сценариями, toolchain или тестами.
---

# Frontend Standards

## Назначение

Это **общий нормативный skill**, а не самостоятельная роль. Его читают `frontend-planner`, `frontend-implementer` и `frontend-reviewer`.

Skill не должен активироваться на продуктовых стадиях 01–04 и не должен влиять на HTML-прототип. Он становится применим только после `APPROVED_FOR_ENGINEERING`.

## Приоритет источников

1. Применимые `AGENTS.md` и ограничения среды.
2. Явный запрос и утверждённый engineering scope.
3. `04_sdd_specification.md` для observable product behavior.
4. Фактический target repo: stack, runtime, package versions, APIs и local conventions.
5. `05_frontend_plan.md` после его утверждения.
6. Этот skill и его references.

Не применяй абстрактные best practices вопреки target repo. Спорное правило без подтверждения target repo — recommendation, кроме явно перечисленных blockers.

## Обязательный порядок чтения

Всегда прочитай:
- [Target-first reconnaissance](references/01_target_first.md)
- [Architecture and TypeScript](references/02_architecture_typescript.md)
- [UI Kit, states and accessibility](references/03_ui_states_accessibility.md)
- [Tests, checks and severity](references/04_tests_review.md)

## Сквозные инварианты

- Не переносить HTML prototype буквально в production React.
- Не придумывать props/icons/enums UI Kit по памяти: проверять фактические exports/types установленной версии.
- Не создавать параллельную архитектуру рядом с принятой в target repo.
- Не редактировать generated OpenAPI вручную.
- Новый пользовательский текст — через i18n.
- Цвета — только semantic UI Kit props или существующие theme tokens; hardcoded palette запрещена.
- Business logic не живёт в route-level JSX.
- Не скрывать несовместимости типами `any`, unsafe casts или подавлением TypeScript errors.
- Async action имеет явные pending/success/error transitions; повторный submit во время pending блокируется, если конкуренция не задумана.
- Новая/изменённая business logic в stores/helpers/normalizers покрывается релевантными тестами.
- Недоступное новое ключевое действие — blocker.

## Target family

Основные ориентиры, если они доступны в рабочем окружении:
- `sberorm-cloud-product-risks-front`
- `sberorm-cloud-risks-front`
- `sberorm-cloud-measures-front`
- `sberorm-cloud-contractors-front`
- `sberorm-cloud-agent-risks-front`
- `sberorm-cloud-front/mifes/*`

Target repo остаётся источником истины: ориентиры не используются для насильственной унификации legacy-проектов.
