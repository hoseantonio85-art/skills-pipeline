# Target-first reconnaissance

## Scope discovery

До архитектурных выводов прочитай применимые `AGENTS.md`, затем в объёме задачи проверь:

- `package.json` и lockfile;
- `tsconfig*.json`, `biome.json/jsonc`, релевантный `vite.config.*`;
- entrypoint, providers, router, store и i18n;
- один реальный пример похожей страницы;
- один store-connected component;
- похожую form/modal/drawer, если релевантно;
- helper/store test и фактический test stack;
- exports и типы установленного `@sber-orm/ui-kit`;
- существующие adapters/wrappers из `@sber-orm/components`;
- реальные API/OpenAPI contracts, если они доступны.

Для каждой потенциальной зависимости/части прототипа классифицируй:

`reuse | adapt | replace | discard | target-provided | unresolved`

## Runtime guardrails

- Не создавай `BrowserRouter`/`createRoot`, если фича живёт внутри существующего Single-SPA runtime.
- Сохраняй entrypoints, routing, externals и public exports target repo.
- Не вендорь UI Kit.
- Не маскируй запрещённую библиотеку adapter/barrel re-export.
- Generated/build paths (`src/openapi/**`, `coverage/**`, `dist/**`, `build/**`, `node_modules/**`, generated i18n types, binary assets) не рассматриваются как ручной код; изменения там помечаются separately/skipped, а `src/openapi/**` вручную не редактируется.

## Toolchain baseline

Если target/workspace использует корпоративный baseline, ожидаются фактически резолвящиеся:

| Назначение | Ожидание |
|---|---|
| TypeScript config | `@sber-orm/tsconfig-config` |
| Biome config | `@sber-orm/biome-config` |
| Biome CLI | `@biomejs/biome` |
| App tsconfig | `extends: "@sber-orm/tsconfig-config/tsconfig.base.json"` |
| Biome config | `extends: ["@sber-orm/biome-config"]` |

Версии бери только из target `package.json`/lockfile. Root workspace dependency достаточна, если команды/configs реально резолвятся. Не добавляй параллельный ESLint/Prettier pipeline без причины.

Dependency/lockfile изменения выполняются только разрешённым package-manager workflow. Lockfile вручную не редактируется.
