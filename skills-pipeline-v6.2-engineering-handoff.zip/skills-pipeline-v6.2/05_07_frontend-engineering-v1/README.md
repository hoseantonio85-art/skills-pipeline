# Frontend engineering stages 05–07

Этот пакет разделяет бывшего универсального frontend-субагента на:

- `frontend-standards` — общий skill с правилами;
- `frontend-planner` — read-only планирование;
- `frontend-implementer` — bounded implementation;
- `frontend-reviewer` — независимое read-only review.

## Почему так

Правила повторяются между ролями и поэтому живут в skill. Изолированные роли живут в subagents. Это уменьшает контекст, предотвращает self-review bias и не позволяет production engineering проникать в продуктовые стадии 01–04.

## Installation

Скопировать:

- `skill/frontend-standards/` → `.gigacode/skills/frontend-standards/`
- `agents/*.md` → `.gigacode/agents/`

При создании/настройке агентов в GigaCode назначить:

| Agent | Recommended tools |
|---|---|
| frontend-planner | Read-only Tools |
| frontend-implementer | Read & Edit & Execution Tools |
| frontend-reviewer | Read-only Tools |

После изменения skills/agents начать новую сессию или выполнить `/clear`, чтобы GigaCode перечитал конфигурацию.
