# Migration v6.1 → v6.2

## What changed

### Before

One `frontend-standards-reviewer` combined:
- target reconnaissance;
- planning;
- generation;
- review;
- optional fixes.

### Now

| Concern | v6.2 owner |
|---|---|
| Reusable frontend rules | `frontend-standards` skill |
| Target-first engineering decomposition | `frontend-planner` subagent |
| Bounded code implementation | `frontend-implementer` subagent |
| Independent conformance review | `frontend-reviewer` subagent |

## New artifacts

- `05_frontend_plan.md`
- `06_frontend_implementation.md`
- `07_frontend_review.md`

## New statuses

- `READY_FOR_FRONTEND_IMPLEMENTATION`
- `READY_FOR_FRONTEND_REVIEW`
- `PLAN_DEVIATION`
- `FIX_REQUIRED`
- `VERIFIED_FRONTEND`

## Context boundary

Frontend rules remain excluded from product stages 01–04. The context manifest now exposes dedicated frontend planning / implementation / review profiles after `APPROVED_FOR_ENGINEERING`.

## Intentional non-change

Stage 03 visual prototype is not converted to React and is not made production-like. Its UI-quality loop should be improved separately after the engineering handoff is validated end-to-end.
