# UX Sync output contract

Сохрани как `03_5_ux_sync.md`.

## Metadata

- Status: `READY_FOR_SDD` / `NEEDS_UX_REVIEW` / `NEEDS_UX_DECISION` / `REQUIRES_INTENT_REVIEW`
- Intent revision:
- Brief revision:
- Final UX Solution revision:
- Prototype revision/path:
- Reviewer / approval evidence:

## Finalized UX decisions

Только решения, реально подтверждённые review.

## Deviations

| ID | Было в UX Solution | Проверено в prototype | Решение | Класс | Влияние на SDD |
|---|---|---|---|---|---|
| | | | | approved / defect / unresolved / implementation-only | |

## Scenario and state coverage

- Проверено:
- Не проверено:
- Не входит:

## Open UX decisions

## Intent integrity check

Подтвердить, что Intent не изменён. Если требуется изменение, статус только `REQUIRES_INTENT_REVIEW`.

## Handoff to SDD

- Authoritative UX source:
- Approved prototype evidence:
- Prototype details explicitly excluded from production contract:

