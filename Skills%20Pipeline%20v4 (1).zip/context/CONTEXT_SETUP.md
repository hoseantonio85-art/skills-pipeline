# Подключение единого контекста NORM — Skills Pipeline v4

## 1. Разместить папку context

Папка `context/` из дистрибутива является самостоятельным provider-контекстом NORM.
Переместите или скопируйте её в стабильную директорию, например:

```text
D:/AI/context/norm
```

или

```text
~/work/norm-context
```

Не копируйте её внутрь каждого frontend-проекта.

## 2. Зарегистрировать provider

Создайте или обновите:

```text
~/.gigacode/product-contexts.yaml
```

по образцу `setup/product-contexts.yaml.example` и укажите абсолютный путь именно к этой папке `context/`.

Пример:

```yaml
contexts:
  norm:
    status: ready
    provider:
      type: local_repository
      root: "D:/AI/context/norm"
      manifest: "product-system/context-manifest.yaml"
```

## 3. Выбрать context в рабочем проекте

Если контекст не выбирается явно в запросе, создайте в рабочем проекте:

```text
<project>/.gigacode/product-context.yaml
```

```yaml
version: 1
context_id: norm
```

Этот selector относится к рабочему проекту и поэтому намеренно не хранится внутри provider-папки `context/`.

## 4. Установить skills

Каждая папка внутри `skills/` дистрибутива является самостоятельным GigaCode skill package.
Копируйте нужные папки по одной в:

```text
~/.gigacode/skills/
```

или в project-level:

```text
<project>/.gigacode/skills/
```

## 5. Установить agents

Файлы из `agents/` дистрибутива копируются в:

```text
~/.gigacode/agents/
```

или:

```text
<project>/.gigacode/agents/
```

После установки или обновления выполните `/clear` или начните новую сессию.

## 6. Loading profiles

- Stage 01: `always` + `for_product_intent_and_brief`;
- Stage 02: `always` + `for_ux_solution`;
- Stage 03: `always` + `for_visual_html_prototype`;
- Stage 03.5: `always` + `for_ux_sync`;
- Stage 04: `always` + `for_sdd_specification`, затем selective analytical evidence;
- Stage 05: `always` + `for_frontend_planning` + выбранный engineering profile + `frontend-standards`;
- Stage 06: `always` + `for_frontend_implementation` + approved plan/workspace + `frontend-standards`;
- Stage 07: `always` + `for_frontend_review` + diff/workspace + `frontend-standards`.

Не передавайте модели весь `context/` целиком. Manifest, skill/agent и on-demand routing определяют, что читать.

## 7. Проверка context

Из корня папки `context/`:

```bash
python3 tools/validate_context.py
```
