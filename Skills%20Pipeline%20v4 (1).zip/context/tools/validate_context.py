#!/usr/bin/env python3
from pathlib import Path
import json, re, sys, glob
try:
    import yaml
except ImportError:
    print('PyYAML is required: pip install pyyaml', file=sys.stderr)
    raise

root = Path(__file__).resolve().parents[1]
manifest_path = root / 'product-system/context-manifest.yaml'
errors=[]
with manifest_path.open(encoding='utf-8') as f:
    manifest=yaml.safe_load(f)

paths=[]
def collect(obj):
    if isinstance(obj, str):
        if obj.startswith(('product-system/','sources/','.gigacode/','setup/')):
            paths.append(obj)
    elif isinstance(obj, list):
        for x in obj: collect(x)
    elif isinstance(obj, dict):
        for x in obj.values(): collect(x)
collect(manifest.get('documents',{}))
collect(manifest.get('loading',{}))

# Validate direct and glob manifest paths.
for rel in sorted(set(paths)):
    if '*' in rel:
        if not glob.glob(str(root/rel), recursive=True):
            errors.append(f'glob has no matches: {rel}')
    elif not (root/rel).exists():
        errors.append(f'missing: {rel}')

# Parse structured files.
for y in root.rglob('*.yaml'):
    try:
        yaml.safe_load(y.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'yaml: {y.relative_to(root)}: {e}')
for j in root.rglob('*.json'):
    try:
        json.loads(j.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'json: {j.relative_to(root)}: {e}')

# Business registry consistency.
bc = root/'product-system/07_business_context'
try:
    services = yaml.safe_load((bc/'service_registry.yaml').read_text(encoding='utf-8'))
    roles = yaml.safe_load((bc/'role_registry.yaml').read_text(encoding='utf-8'))
    caps = yaml.safe_load((bc/'capability_registry.yaml').read_text(encoding='utf-8'))
    source_registry = yaml.safe_load((bc/'source_registry.yaml').read_text(encoding='utf-8'))
    service_ids=set(services.get('services',{}))
    cap_ids=[]
    for cap in caps.get('capabilities',[]):
        cap_ids.append(cap.get('id'))
        if cap.get('service') not in service_ids:
            errors.append(f"capability {cap.get('id')} references unknown service: {cap.get('service')}")
    if len(cap_ids)!=len(set(cap_ids)):
        errors.append('duplicate capability IDs')
    for rid, role in roles.get('roles',{}).items():
        for sid in role.get('services',[]):
            if sid not in service_ids:
                errors.append(f'role {rid} references unknown service: {sid}')
    # Validate source registry file/index paths; globs must match.
    for src in source_registry.get('sources',[]):
        refs=[]
        if src.get('path'): refs.append(src['path'])
        if src.get('index'): refs.append(src['index'])
        refs.extend(src.get('paths',[]) or [])
        for rel in refs:
            if '*' in rel:
                if not glob.glob(str(root/rel), recursive=True):
                    errors.append(f"source {src.get('id')} glob has no matches: {rel}")
            elif not (root/rel).exists():
                errors.append(f"source {src.get('id')} missing path: {rel}")
except Exception as e:
    errors.append(f'business registry validation failed: {e}')

# Required v4 compact business layer must be wired into early profiles.
manifest_text=manifest_path.read_text(encoding='utf-8')
for required in [
    'product-system/07_business_context/service_registry.yaml',
    'product-system/07_business_context/role_registry.yaml',
    'product-system/07_business_context/capability_registry.yaml',
    'product-system/07_business_context/product_decisions.md',
]:
    if required not in manifest_text:
        errors.append(f'v4 business source not routed: {required}')

# Hygiene: removed historical authoring/report layers must stay absent.
for forbidden in ['analysis/pattern-reports','product-system/04_ui/audit']:
    if (root/forbidden).exists(): errors.append(f'forbidden runtime report layer present: {forbidden}')
for p in root.rglob('*'):
    if p.is_file() and p.name in {'.DS_Store'} or (p.is_file() and p.name.startswith('._')):
        errors.append(f'metadata file present: {p.relative_to(root)}')
    if p.is_file() and p.suffix.lower() in {'.md','.yaml','.yml','.json','.py'}:
        text=p.read_text(encoding='utf-8', errors='replace')
        legacy_token = 'lova' + 'ble'
        if re.search(legacy_token, text, re.I): errors.append(f'forbidden legacy instruction reference: {p.relative_to(root)}')
        if p.resolve() != Path(__file__).resolve():
            for stale in ['norm-product-context-v3-mvp','product_to_ui_master_prompt.md','known_capabilities.md','roles.md']:
                if stale in text:
                    errors.append(f'stale v3/business reference {stale}: {p.relative_to(root)}')

result={
    'context_id': manifest.get('context_id'),
    'context_version': manifest.get('context_version'),
    'package_version': manifest.get('package_version'),
    'files_checked': sum(1 for p in root.rglob('*') if p.is_file()),
    'manifest_paths_checked': len(set(paths)),
    'errors': errors,
    'status': 'passed' if not errors else 'failed'
}
if '--write-report' in sys.argv:
    (root/'CONTEXT_VALIDATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if errors else 0)
