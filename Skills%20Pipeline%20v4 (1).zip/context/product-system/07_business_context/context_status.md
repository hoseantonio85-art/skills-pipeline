# Статус продуктового контекста NORM

## Метаданные

| Поле | Значение |
|---|---|
| Context ID | `norm` |
| Context version | `4` |
| Package version | `4.0.0` |
| Package readiness | `ready_for_product_ux_sdd_and_frontend_engineering` |
| Production evidence | `documented-partial` |
| Product owner review | требуется для новых/изменённых product facts |
| UX owner review | требуется для новых/изменённых UX/visual rules |
| Проверка production | task-specific; не выводится из canonical context |

## Что присутствует

- product foundation, service map и service documents;
- compact registries сервисов, ролей и capabilities со stable IDs;
- glossary, общие business rules, constraints и product decisions;
- UX principles/patterns и NORM visual/UI context;
- stage-aware loading profiles 01–07;
- UI Kit evidence `@sber-orm/ui-kit` 0.283.0 и frontend engineering rules;
- analytical specifications как on-demand evidence;
- source authority/registry, явно отделяющие product model от production evidence.

## Что не подключено постоянно

- authoritative release registry;
- полная permissions matrix и formal domain model;
- продуктовая аналитика;
- актуальные frontend/backend repositories как постоянные providers;
- production screenshots/session recordings.

`ready` означает целостность package contract, а не доказанность каждой production-фичи. Feature-specific Intent/Brief/UX/SDD живут в task increment; фактические права, API, release state и runtime подтверждаются task-specific evidence/target repo.
