# Business Context — NORM v4

Компактный, stage-aware слой бизнес-знаний продукта NORM. Он отделяет продуктовую модель от production evidence и предназначен для автоматической загрузки через `product-system/context-manifest.yaml`.

## Канонические компактные источники

- `service_registry.yaml` — сервисы, связи и статус подтверждения;
- `role_registry.yaml` — роли, цели и связанные сервисы; права отдельно не домысливаются;
- `capability_registry.yaml` — возможности со стабильными `CAP-*` ID и отдельным production status;
- `common_business_rules.md` — общие продуктовые правила `BR-NORM-*`;
- `product_decisions.md` — устойчивые продуктовые решения `PD-NORM-*`;
- `glossary.md` — термины и степень определённости;
- `known_constraints.md` — известные ограничения контекста;
- `released_features.md` — только release evidence, если оно реально подключено;
- `current_product_state.md` / `current_product_sources.yaml` — что известно о текущем продукте и что не подключено;
- `source_registry.yaml` / `source_authority.md` — provenance, authority и правила разрешения конфликтов.

## Подробные источники

`product-system/02_services/services_map.md` и service documents остаются каноническими подробными источниками, но читаются **on demand**. Компактные registries нужны для раннего определения затронутого сервиса, ролей и похожих capabilities без bulk-loading большого service map.

## Принципы v4

1. Product model не считается production truth.
2. `unknown`, `needs-review` и hypothesis не повышаются до факта.
3. Сначала загружается компактный registry; подробный service document — только по scope задачи.
4. Stable IDs используются для traceability, но не являются техническими API IDs.
5. Методические правила pipeline не хранятся как продуктовые решения NORM.
6. Новые product facts требуют source/owner evidence; отсутствие evidence фиксируется явно.
