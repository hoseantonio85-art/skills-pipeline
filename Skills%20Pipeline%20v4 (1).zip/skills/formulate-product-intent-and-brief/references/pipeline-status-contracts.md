# Pipeline status contracts — Stage 01 subset

This skill is intentionally self-contained when installed as an individual GigaCode skill folder.

## Stage 01 Intent + Brief

- Ready: `READY_FOR_UX`
- Return/blocking: `NEEDS_CLARIFICATION`, `NEEDS_DECOMPOSITION`, `BLOCKED_BY_CONTEXT`
- Required next-stage input: both `00_intent.md` and `01_product_brief.md` share the ready status/revision

Do not invent additional positive statuses for Stage 01.
