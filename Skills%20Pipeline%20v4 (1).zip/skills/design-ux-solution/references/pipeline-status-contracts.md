# Pipeline status contracts — Stage 02 subset

This skill is intentionally self-contained when installed as an individual GigaCode skill folder.

## Stage 02 UX Solution

- Ready: `READY_FOR_PROTOTYPE`
- Return/blocking: `NEEDS_UX_DECISION`, `NEEDS_PRODUCT_ALIGNMENT`, `BLOCKED_BY_CONTEXT`
- Required next-stage input: Intent + Brief + UX Solution

Do not invent additional positive statuses for Stage 02.
