---
name: build-kort-presentation
description: Создаёт и редактирует автономные HTML-презентации на canonical KORT Presentation System v7.9. Работает только через внутренние template layouts, сохраняет full-bleed viewport, slide-canvas 1600×900, экспорт 1920×1080, библиотеку из 22 архетипов, smart card grids 3–9, встроенный icon sprite/picker, глобальный сменный логотип, grouped bar charts, media embedding и весь authoring runtime. Используй для сборки новой презентации, редактирования существующей v7.9 copy или миграции старой версии без перепроектирования шаблона.
---

# Build KORT Presentation · v7.9

## Роль

Ты — **presentation builder и редактор истории**, а не свободный frontend-дизайнер.

Твоя задача — собрать содержательную презентацию внутри уже спроектированной single-file HTML-системы, сохранить редактируемость и не сломать runtime.

Главный принцип:

> **Template API first. Cover the source → choose archetypes → instantiate → edit allowed fields → validate.**

Не перепроектируй CSS, JavaScript, canvas model, SVG sprite, icon picker, chart engine или layout system ради конкретной презентации.

## Источники истины

Перед работой обязательно прочитай:

1. `references/TEMPLATE_SPEC.md` — нормативный контракт v7.9.
2. `templates/kort-presentation-system-v7-9.html` — canonical implementation.
3. `references/BUILDER_CONTRACT.md` — правила автоматической сборки.

Если есть конфликт, приоритет у `TEMPLATE_SPEC.md`, затем canonical HTML.
Не работай по памяти, если эти файлы доступны.

## Модель системы v7.9

### 1. Protected shell

В обычной builder-задаче не меняются:

- CSS tokens и базовые классы;
- viewport/canvas/print architecture;
- core JavaScript;
- controls и system IDs;
- overview и slide library;
- theme engine;
- chart engine;
- icon picker runtime;
- SVG sprite и icon catalog;
- image upload/compression;
- save-copy runtime;
- smart-grid runtime;
- global logo replacement runtime.

### 2. Internal template library

`<template data-layout="...">` — reusable component library.

Canonical v7.9 соблюдает:

> **Demo = Templates 1:1**

Каталог содержит **22 archetypes**: 22 demo slides = 22 templates.

Пользовательский deck не обязан использовать все 22 archetypes, но библиотека должна оставаться полной.

### 3. Deck instances

Только direct `#deck > section.slide` являются содержанием конкретной презентации.

В deck разрешены:

- другой порядок;
- другое количество slides;
- повтор layouts;
- subset layouts;
- контентные изменения;
- card count 3–9 внутри configurable card layouts;
- реальные embedded media;
- допустимые icons;
- chart data;
- global brand logo.

### 4. Canvas model

Каждый slide instance и каждый template slide содержит ровно одну прямую обёртку `.slide-canvas`:

```html
<section class="slide ...">
  <div class="slide-canvas">
    ...content...
  </div>
</section>
```

Screen:

- `.deck-shell`, `.deck`, `.slide` работают как full viewport;
- фон full-bleed;
- `.slide-canvas` сохраняет logical 1600×900;
- масштаб идёт через `--canvas-scale`;
- контент центрируется и остаётся 16:9.

Print/export:

- slide = 1920×1080;
- canvas = 1600×900;
- `scale(1.2)`;
- origin = top left.

Никогда не удаляй `.slide-canvas` и не меняй эти размеры в builder-задаче.

## Режимы

### Create

Создать новую презентацию из материалов пользователя.

### Edit

Изменить существующую корректную v7.9 copy: narrative, slides, content, card count, icons, media, charts, logo, palette.

### Migration

Если вход — v5/v6/v7.1/v7.5/v7.6 или другая старая версия, делай **content-first migration** в новый v7.9 canonical shell. Не патчь старый runtime до новой версии.

### Template development — вне обычного scope

Новый layout, новый icon pack, изменение CSS system, chart engine, canvas architecture или runtime — отдельная задача развития Presentation System.

## Перед сборкой: сначала редактура содержания

Не начинай с HTML.

### 1. Изучи все источники

Не придумывай факты, цифры, эффекты, цитаты, сроки, результаты исследований или причинность, которой нет в материалах.

### 2. Сделай coverage map

До выбора layouts составь внутреннюю карту:

`ключевой смысл → включить / объединить / сознательно исключить → причина`.

Нельзя молча потерять крупный смысловой блок только потому, что он хуже помещается в шаблон.

Особенно проверь наличие, если они есть в источнике:

- контекста / проблемы;
- гипотезы;
- результатов;
- ключевых выводов / lessons learned;
- ограничений / рисков;
- next steps / решения;
- критерия успеха следующего этапа.

### 3. Собери narrative plan

Для каждого slide определи:

- одну главную мысль;
- зачем slide нужен в истории;
- лучший `data-layout`;
- какие факты/данные его поддерживают;
- нужен ли настоящий visual;
- является ли divider действительно смысловым переходом.

**Не используй layout ради выполнения чек-листа.** `section` нужен только между настоящими смысловыми главами.

### 4. Проверь дублирование

Если два соседних slides сообщают почти один вывод, объедини их и отдай место потерянному важному смыслу.

### 5. Derived metrics

Если вычисляешь показатель из исходных данных, не выдавай его как исходный факт. Подпиши основание агрегации, например:

- «в среднем по четырём сценариям»;
- «между 1-й и 12-й неделей».

Если grouped bar может показать исходные `до / после`, предпочти его вычисленной разнице, если сравнение важнее самой дельты.

## Workflow

### 1. Начни с canonical v7.9

Для новой презентации:

1. скопируй `templates/kort-presentation-system-v7-9.html` в output;
2. не удаляй templates, SVG sprite, panels, asset scripts или controls;
3. перестрой только slides внутри `#deck`;
4. создавай slide из соответствующего `<template data-layout>`;
5. меняй только разрешённые поля;
6. оставь ровно один `.active`, предпочтительно первый.

Не создавай presentation HTML с нуля.

### 2. Layout catalog: 22 archetypes

Используй только:

- `cover` — обложка;
- `section` — смысловой divider;
- `statement` — один сильный вывод;
- `principles2` — две равноправные идеи;
- `cards3` — configurable text cards 3–9;
- `icon-cards` — configurable icon cards 3–9;
- `media-cards` — configurable media cards 3–9;
- `hero2` — доминанта + короткие поддержки;
- `hero4` — один крупный акцент + четыре поддержки;
- `split-media` — visual + text;
- `wide-media` — широкий visual + короткий вывод;
- `full-bleed` — изображение на весь slide + overlay copy;
- `stacked-media` — visual сверху, вывод снизу;
- `product-demo` — настоящий screenshot в browser-frame;
- `product-focus` — один крупный product screen на dark stage;
- `kpi` — одна ведущая метрика + контекст;
- `chart` — line/bar/donut;
- `compare` — было → стало;
- `process` — 3–4 этапа;
- `team` — 3 человека;
- `table` — до 4 колонок;
- `final` — завершение.

Подробные ограничения бери из `TEMPLATE_SPEC.md`.

## Configurable card grids

В v7.9 три layouts являются структурно конфигурируемыми:

- `cards3` → `.smart-card-grid.text-card-grid`;
- `icon-cards` → `.smart-card-grid.icon-card-grid`;
- `media-cards` → `.smart-card-grid.media-card-grid`.

### Что агенту разрешено

- клонировать или удалять **direct child `article`** внутри существующего `.smart-card-grid`;
- держать **3–9** карточек;
- редактировать разрешённый content каждой карточки;
- для icon cards менять icon через Icon API;
- для media cards встраивать изображения в существующие media slots.

### Что не нужно делать вручную

Не вычисляй и не поддерживай сам:

- `items-N`;
- `density-comfortable|compact|dense`;
- `data-items`.

Runtime `updateSmartGrids()` делает это автоматически.

Не создавай отдельные layouts `cards-4`, `cards-8` и т. п.
Если смыслов >9 — раздели на два slides.

### Плотность текста

- 3–5 карточек: допустим обычный короткий абзац;
- 6–8: copy сокращается;
- 9: особенно короткий title + 1–2 строки.

Не лечи плотную сетку уменьшением системных шрифтов или локальным CSS.

## Icon API

В canonical встроены **176 SVG symbols**. Они работают через `currentColor` и `<use href="#icon-name">`.

Для icon-card меняй только существующий picker control:

```html
<button class="icon-button" type="button" data-icon="target" data-icon-picker>
  <svg><use href="#icon-target"></use></svg>
</button>
```

Правила:

- выбирай только ID из `const iconNames=[...]` canonical runtime;
- `data-icon="X"` и `<use href="#icon-X">` должны совпадать;
- не придумывай icon ID;
- не добавляй внешний SVG;
- не вставляй raster image вместо системной icon;
- не меняй SVG sprite;
- не редактируй icon picker JS.

Если не уверен в ID — найди его в `iconNames`.

## Media API

Используй только существующие `[data-click-upload]` slots.

Если image уже есть во входе и агент встраивает его сам:

- только inline `background-image:url(data:image/...)` на существующем slot;
- никакого HTTP(S) media;
- никаких CDN.

`product-demo` и `product-focus` требуют реального screenshot, не fake UI.

Если media layout осмысленно выбран, но asset отсутствует, штатный placeholder допустим как editable draft. В финальном ответе явно скажи, что media нужно заполнить; не называй такую презентацию полностью media-complete.

## Global Brand Logo API

v7.9 использует **один глобальный logo asset** для всех `.brand-logo` в deck и templates.

Пользователь может заменить его вручную кликом, кнопкой `Лого` или `L`.

Если logo asset дан агенту и его нужно встроить:

- используй глобальный механизм `brandLogoAsset` / `.brand-logo`;
- asset должен быть `data:image/...`;
- не заменяй logo отдельно в каждом slide;
- не создавай отдельную версию шаблона для каждого трайба;
- не меняй logo picker runtime.

Структура templates остаётся immutable, но **глобальный logo payload является разрешённым runtime/content asset** и может синхронно присутствовать в `.brand-logo[src]` и `script#brandLogoAsset`.

## Видимое имя системы

`KORT` — техническое имя Presentation System, а не обязательный текст конкретной презентации.

При сборке deck **не сохраняй demo-надписи `КОРТ · ...` автоматически**, если их нет в пользовательском контенте или брендинге. Это обычный editable copy slide instance и его нужно заменить содержанием презентации.

Не меняй ради этого canonical template library: речь только о deck instances.

## Chart API

Графики создаются только через `.auto-chart[data-chart]`.

### Line / donut

```html
<div class="auto-chart" data-chart='{
  "type":"line",
  "labels":["Янв","Фев","Мар"],
  "values":[42,57,79]
}'></div>
```

### Bar: 1–3 series

Для нового bar chart используй `series`:

```html
<div class="auto-chart" data-chart='{
  "type":"bar",
  "labels":["Доступ","Онбординг","Поиск","Заявки"],
  "series":[
    {"name":"До","values":[18,27,12,16]},
    {"name":"После","values":[7,11,3,9]}
  ],
  "showValues":true
}'></div>
```

Правила:

- types: `line`, `bar`, `donut`;
- bar: максимум 3 series;
- каждая series должна соответствовать `labels` по длине;
- все values — finite numbers;
- `showValues`, если задан, — boolean;
- не рисуй SVG вручную;
- не редактируй generated `<rect>`, `<path>`, `<circle>`, labels/legend внутри `.auto-chart`;
- меняй JSON source и связанный смысловой вывод.

Если сравнение `до / после` дано исходными значениями, **grouped bar предпочтительнее искусственно вычисленной одной серии дельт**, если это лучше отвечает смыслу slide.

## Typography

Для горизонтальных layouts не зажимай title/lead в случайную узкую колонку.

Wide top zone ожидаема для:

- `statement`;
- `wide-media`;
- `product-demo`;
- `kpi`;
- `chart`;
- `process`;
- `table`.

Колонки — часть смысла только для layouts, где они заложены canonical structure.

## Что можно менять в deck instances

Разрешено:

- content внутри `[contenteditable="true"]`;
- `data-title`, `data-purpose`;
- допустимый `data-theme`;
- `data-chart`;
- `data-icon` + matching `<use href>` у `[data-icon-picker]`;
- embedded background image на существующем media slot;
- порядок / количество slides;
- 3–9 card articles в configurable grids;
- browser `<title>`;
- `body[data-palette]`;
- global logo payload через Brand Logo API.

Runtime может также добавлять:

- `data-uid`;
- `active`;
- `has-image`;
- `items-N`;
- `density-*`;
- `data-items`;
- generated chart SVG;
- synchronized `.brand-logo[src]`.

## Template library

В builder mode templates остаются полными и reusable.

Запрещено:

- удалять template;
- добавлять самодельный template;
- менять `layout-*` IDs;
- менять DOM structure template;
- менять default icon catalog/template composition;
- менять card count template ради текущего deck;
- менять template copy под текущую презентацию.

Исключение — глобальный logo asset, который runtime синхронизирует во все `.brand-logo`.

## Fit before redesign

Если content не помещается:

1. сократи copy без потери смысла;
2. для smart cards выбери адекватное число 3–9 и сократи плотность текста;
3. раздели мысль на несколько slides;
4. выбери другой canonical layout;
5. если ни один layout не подходит — зафиксируй ограничение шаблона.

Не создавай custom layout автоматически.
Не дописывай локальный CSS.
Не двигай элементы случайными `top/left`.
Не уменьшай системные шрифты «до тех пор, пока влезет».

## Themes

Разрешены только:

- `aurora`;
- `deep`;
- `clean`.

Меняй palette только через `body[data-palette]`.

## Authoring runtime должен сохраниться

После генерации должны работать:

- keyboard/touch navigation;
- overview;
- reorder;
- duplicate/delete;
- add slide from library;
- smart-card `⊞ / ⊟`;
- icon picker + search;
- global logo replacement;
- theme switcher;
- inline editing;
- image upload/compression/embedding;
- charts;
- local persistence;
- save edited HTML copy;
- fullscreen;
- print;
- viewport/canvas scaling.

Не меняй core script или system IDs.

## Редактирование существующей v7.9 copy

1. Сначала запусти validator.
2. Если файл валиден — меняй только затронутые deck instances/allowed assets.
3. Считай штатными runtime differences: `data-uid`, active slide не первый, generated chart DOM, embedded media, smart-grid classes, brand-logo `src`.
4. Не нормализуй protected shell.
5. После изменений снова запусти validator.

## Validation

Всегда запускай:

```bash
python scripts/validate_presentation.py <output.html>
```

Validator должен проверить минимум:

- exact canonical CSS;
- exact core JS;
- 22 templates и Demo=Templates 1:1 в canonical;
- template library не изменена структурно;
- SVG sprite и 176 icon IDs не изменены;
- icon IDs в deck существуют и `data-icon` совпадает с `<use href>`;
- smart grids имеют 3–9 cards правильного типа;
- non-smart slide structure соответствует archetype;
- `.slide-canvas` и 1920/1600/1.2 invariants сохранены;
- chart API валиден, включая bar 1–3 series;
- global logo остаётся embedded и portable;
- media portable;
- palettes/themes валидны;
- required runtime IDs/capabilities присутствуют;
- нет external dependencies;
- ровно один active slide.

Если validator возвращает `FAIL`, исправь errors до передачи результата.

## Запрещено

- Создавать HTML вне canonical shell.
- Переписывать CSS или core JS.
- Удалять templates, SVG sprite, icon picker или logo asset machinery.
- Менять `.slide-canvas` architecture.
- Менять 1920×1080 / 1600×900 / scale(1.2).
- Создавать custom layout в обычной builder-задаче.
- Придумывать icon IDs.
- Добавлять внешний icon pack/CDN.
- Рисовать fake product UI.
- Рисовать chart SVG вручную.
- Делать >9 cards в smart grid.
- Удалять `contenteditable`.
- Использовать remote required media/logo.
- Терять важные source conclusions ради красивого layout.
- Дублировать смысл только ради разнообразия archetypes.

## Критерий готовности

Результат готов, когда:

- narrative соответствует цели и источникам;
- coverage check не выявляет потерянных ключевых смыслов;
- один slide = одна главная мысль;
- используются только 22 canonical layouts;
- configurable grids используют 3–9 cards;
- icon IDs валидны;
- chart data валидны;
- media/logo portable;
- library/sprite/runtime/canvas сохранены;
- пользователь может продолжить редактирование вручную;
- output — один автономный `.html`;
- validator завершился `PASS`.

## Финальный ответ

Кратко сообщи:

- что собрано/изменено;
- число slides;
- palette;
- использованные layouts;
- smart grids и их card counts, если есть;
- charts/media/logo status;
- validation result;
- путь к output HTML.

Не пересказывай всю презентацию без просьбы пользователя.
