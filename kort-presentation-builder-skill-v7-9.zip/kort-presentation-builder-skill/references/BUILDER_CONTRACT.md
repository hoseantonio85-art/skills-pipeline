# KORT Presentation Builder Contract · v7.9

Этот файл уточняет, как применять `TEMPLATE_SPEC.md` при автоматической сборке конкретной презентации.

## 1. Слои системы

### Protected shell

Неизменяемые в builder mode:

- canonical CSS;
- core JavaScript;
- controls/panels/system IDs;
- palette engine;
- chart engine;
- icon picker engine;
- smart-grid engine;
- image upload/compression;
- save-copy runtime;
- viewport/print scaling architecture;
- SVG icon sprite и icon catalog;
- структура global brand logo API.

### Mutable global asset

`script#brandLogoAsset` содержит переносимый глобальный logo data URL. Его payload может меняться через штатный Brand Logo API.

`.brand-logo[src]` в deck/templates может быть синхронизирован с этим payload runtime'ом. Это разрешённая asset mutation, а не изменение layout structure.

### Viewport stage

- `.deck-shell` — full viewport;
- `.deck` — `100vw × 100vh`;
- `.slide` — `100vw × 100vh`;
- background — full-bleed.

### Slide canvas

Каждый slide содержит единственную direct `.slide-canvas`:

- logical 1600×900;
- screen scaling через `--canvas-scale`;
- print 1920×1080;
- print canvas `scale(1.2)`.

### Template library

22 immutable archetypes, кроме синхронизации `.brand-logo[src]` глобальным logo asset.

### Deck instances

Direct `#deck > section.slide` — содержимое конкретной презентации.

## 2. Demo = Templates 1:1

Canonical v7.9:

- 22 demo slides;
- 22 templates;
- layout sets совпадают 1:1.

User deck может использовать subset/repeats/any order.

## 3. Layout set

`cover`, `section`, `statement`, `principles2`, `cards3`, `icon-cards`, `media-cards`, `hero2`, `hero4`, `split-media`, `wide-media`, `full-bleed`, `stacked-media`, `product-demo`, `product-focus`, `kpi`, `chart`, `compare`, `process`, `team`, `table`, `final`.

## 4. Allowed instance mutations

Разрешено:

- contenteditable content;
- `data-title`, `data-purpose`, valid `data-theme`;
- `data-chart`;
- icon `data-icon` + matching `<use href>`;
- embedded media on existing upload slot;
- runtime `data-uid`, `active`, `has-image`;
- global logo asset;
- smart-grid card count 3–9.

## 5. Smart grids are a controlled structural exception

Layouts:

- `cards3` → grid type `text`;
- `icon-cards` → `icon`;
- `media-cards` → `media`.

Builder may add/remove only direct card `article` children of the existing `.smart-card-grid`.

Allowed counts: 3..9.

Dynamic grid state ignored by structural comparison:

- `items-N`;
- `density-comfortable|compact|dense`;
- `data-items`.

Everything outside the repeated card region remains structurally canonical.

Each repeated card must match the canonical card prototype for that grid type. Arbitrary child structure, extra wrappers, local geometry styles or foreign controls are invalid.

For text/icon grids no more than one card should be `primary`. Media grid does not use `primary`.

## 6. Icon contract

Canonical includes 176 `<symbol id="icon-*">` entries and the same 176 values in `iconNames`.

For each `[data-icon-picker]`:

- `data-icon` must be in canonical `iconNames`;
- exactly one `<use>` must reference `#icon-{data-icon}`;
- no external SVG is allowed.

SVG sprite and `iconNames` are protected.

## 7. Chart contract

Line/donut:

- non-empty `labels` + `values`;
- equal lengths;
- finite numeric values.

Bar:

- preferred API: `series`;
- 1–3 series;
- each series has values matching labels;
- finite numeric values;
- `showValues`, if present, boolean.

Legacy single `values` bar remains readable by canonical runtime, but builder should generate `series` for new grouped comparisons.

Generated chart children inside `.auto-chart` are runtime output and ignored in structural validation. Source of truth is `data-chart`.

## 8. Media contract

Allowed runtime mutation on existing `[data-click-upload]` slot:

- `has-image`;
- `style="background-image:url(data:image/...)"`.

Remote media is invalid.

## 9. Brand logo contract

Canonical contains:

- `.brand-logo-slot[data-brand-slot="global-logo"]`;
- `.brand-logo` images;
- `#brandLogoInput`;
- `script#brandLogoAsset[type="application/json"]`;
- logo replacement JS.

Logo data must remain embedded `data:image/...`.

When `.brand-logo[src]` values are present, they must be embedded and consistent with the global asset.

## 10. Template immutability

Template fingerprints protect:

- DOM structure;
- default copy;
- classes;
- data-layout IDs;
- default card count;
- default icon choices;
- media slots;
- metadata.

Only `.brand-logo[src]` is normalized away because it is intentionally global and mutable.

## 11. Narrative contract

Builder is responsible not only for valid HTML but for source coverage.

Before final output:

- compare presentation against source coverage map;
- ensure important results / conclusions / limitations / next steps were not silently dropped;
- remove duplicated slides that merely restate the same conclusion;
- do not insert section divider unless it marks a real chapter transition;
- derived metrics must be labeled as derived/aggregated when relevant.

Validator cannot prove semantic coverage; this remains a mandatory reasoning step.

## 12. Migration

Old shells are not upgraded by CSS/JS patching.

Migration = fresh v7.9 canonical + content mapping into supported archetypes + new APIs for smart cards/icons/logo/charts.
