# v7.9 builder notes

## Что изменилось относительно v7.5 skill

1. Layout catalog: 20 → 22.
2. Добавлены `icon-cards` и `media-cards`.
3. `cards3` превращён в configurable text grid 3–9.
4. Все три card layouts используют `.smart-card-grid` и runtime `⊞ / ⊟`.
5. Добавлены dynamic classes `items-N`, `density-*` и `data-items`.
6. Встроен SVG sprite из 176 icons и icon picker/search.
7. Добавлен global replaceable brand logo с `brandLogoAsset`.
8. Bar chart поддерживает 1–3 series и value labels.
9. Validator больше не требует exact repeated-card child count в deck instances, но проверяет 3–9 и canonical card prototype.
10. Validator разрешает synchronized global logo payload в templates/deck, не ослабляя template structure.
11. В skill добавлен обязательный source coverage check и защита от semantic duplication после smoke-test AI Navigator.
12. Техническое имя KORT не считается обязательным visible copy user deck: demo text должен заменяться содержанием презентации, если пользователь не просил этот бренд.

## Что не изменилось

- single-file requirement;
- Demo = Templates 1:1 для canonical;
- full-bleed viewport;
- `.slide-canvas` 1600×900;
- print 1920×1080, scale 1.2;
- exact CSS/core JS in builder mode;
- no external dependencies;
- no custom layout in normal builder task.
