# build-kort-presentation · v7.9

Skill для GigaCode/LLM-сборки автономных editable HTML-презентаций на canonical Presentation System v7.9.

## Установка

Скопируйте папку `kort-presentation-builder-skill` в путь skill'а проекта, например:

`.gigacode/skills/build-kort-presentation/`

После замены skill перезагрузите контекст GigaCode (`/clear`, если используется такой механизм загрузки skills).

## Что внутри

- `SKILL.md` — рабочая инструкция агента;
- `templates/kort-presentation-system-v7-9.html` — canonical single-file template;
- `references/TEMPLATE_SPEC.md` — нормативная спецификация v7.9;
- `references/BUILDER_CONTRACT.md` — contract автоматической сборки;
- `references/V7_9_NOTES.md` — изменения относительно v7.5;
- `scripts/validate_presentation.py` — dependency-free validator;
- `references/VALIDATION_TESTS.txt` — smoke tests validator.

## Главная идея

Builder не проектирует presentation system заново. Он сохраняет canonical shell и выбирает/наполняет 22 archetypes.

v7.9 отдельно поддерживает:

- configurable text/icon/media card grids 3–9;
- 176 embedded SVG icons + picker;
- global replaceable embedded logo;
- grouped bar charts до 3 series;
- full authoring runtime;
- editorial coverage check перед финализацией.
