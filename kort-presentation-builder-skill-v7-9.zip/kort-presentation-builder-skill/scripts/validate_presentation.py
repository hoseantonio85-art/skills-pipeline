#!/usr/bin/env python3
"""Validate a Presentation System v7.9 deck against the canonical builder contract.

Dependency-free: Python standard library only.
Accepts generated decks and user-saved runtime copies while protecting the v7.9
viewport/canvas/export architecture, 22-layout library, SVG icon catalog,
smart-card grids, grouped bar API, global embedded logo and authoring runtime.
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
import math
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable

SKILL_ROOT = Path(__file__).resolve().parents[1]
CANONICAL = SKILL_ROOT / "templates" / "kort-presentation-system-v7-9.html"
SPEC = SKILL_ROOT / "references" / "TEMPLATE_SPEC.md"

EXPECTED_LAYOUTS = {
    "cover", "section", "statement", "principles2", "cards3", "icon-cards", "media-cards",
    "hero2", "hero4", "split-media", "wide-media", "full-bleed", "stacked-media",
    "product-demo", "product-focus", "kpi", "chart", "compare", "process", "team", "table", "final",
}
SMART_LAYOUTS = {"cards3": "text", "icon-cards": "icon", "media-cards": "media"}
ALLOWED_PALETTES = {"aurora", "deep", "clean"}
ALLOWED_SLIDE_THEMES = {"light", "dark"}
VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
DENSITY_CLASSES = {"density-comfortable", "density-compact", "density-dense"}


# ---------- parsing helpers ----------

def normalize_block(s: str) -> str:
    return s.strip().replace("\r\n", "\n").replace("\r", "\n")


def script_blocks(source: str) -> list[tuple[str, str]]:
    return [(m.group(1), m.group(2)) for m in re.finditer(r"<script\b([^>]*)>(.*?)</script>", source, flags=re.I | re.S)]


def extract_core_script(source: str) -> str:
    blocks = script_blocks(source)
    candidates = [body for attrs, body in blocks if not re.search(r"\bid\s*=\s*['\"]brandLogoAsset['\"]", attrs, flags=re.I)]
    if len(candidates) != 1:
        raise ValueError(f"Expected exactly one core <script>; found {len(candidates)}")
    return candidates[0]


def extract_style(source: str) -> str:
    m = re.search(r"<style\b[^>]*>(.*?)</style>", source, flags=re.I | re.S)
    if not m:
        raise ValueError("<style> not found")
    return m.group(1)


@dataclass
class Node:
    tag: str
    attrs: dict[str, str | None]
    children: list["Node | str"] = field(default_factory=list)
    parent: "Node | None" = None

    @property
    def classes(self) -> set[str]:
        return set((self.attrs.get("class") or "").split())


class TreeParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = Node("__root__", {})
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = Node(tag.lower(), {k.lower(): v for k, v in attrs}, parent=self.stack[-1])
        self.stack[-1].children.append(node)
        if tag.lower() not in VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        node = Node(tag.lower(), {k.lower(): v for k, v in attrs}, parent=self.stack[-1])
        self.stack[-1].children.append(node)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(data)

    def handle_entityref(self, name):
        self.stack[-1].children.append(f"&{name};")

    def handle_charref(self, name):
        self.stack[-1].children.append(f"&#{name};")


def parse_html(source: str) -> Node:
    p = TreeParser()
    p.feed(source)
    return p.root


def walk(node: Node) -> Iterable[Node]:
    for child in node.children:
        if isinstance(child, Node):
            yield child
            yield from walk(child)


def find_by_id(root: Node, node_id: str) -> Node | None:
    return next((n for n in walk(root) if n.attrs.get("id") == node_id), None)


def nodes_with_class(node: Node, class_name: str) -> list[Node]:
    return [n for n in [node, *walk(node)] if class_name in n.classes]


def direct_element_children(node: Node) -> list[Node]:
    return [c for c in node.children if isinstance(c, Node)]


def deck_slides(root: Node) -> list[Node]:
    deck = find_by_id(root, "deck")
    if not deck:
        return []
    return [n for n in direct_element_children(deck) if n.tag == "section" and "slide" in n.classes]


def template_nodes(root: Node) -> dict[str, Node]:
    result: dict[str, Node] = {}
    for n in walk(root):
        if n.tag != "template" or not n.attrs.get("data-layout"):
            continue
        layout = n.attrs["data-layout"] or ""
        if layout in result:
            result[f"__duplicate__:{layout}:{len(result)}"] = n
        else:
            result[layout] = n
    return result


def template_slide(template: Node) -> Node | None:
    return next((n for n in direct_element_children(template) if n.tag == "section" and "slide" in n.classes), None)


def normalized_text(s: str) -> str:
    return " ".join(s.split())


def normalized_attr_value(v: str | None) -> str:
    return "" if v is None else " ".join(v.split())


def node_text(node: Node) -> str:
    parts: list[str] = []
    for child in node.children:
        if isinstance(child, Node):
            parts.append(node_text(child))
        else:
            parts.append(child)
    return "".join(parts)


def find_icon_sprite(root: Node) -> Node | None:
    return next((n for n in walk(root) if n.tag == "svg" and "icon-sprite" in n.classes), None)


def symbol_names(sprite: Node | None) -> list[str]:
    if not sprite:
        return []
    names = []
    for n in walk(sprite):
        if n.tag == "symbol" and (n.attrs.get("id") or "").startswith("icon-"):
            names.append((n.attrs.get("id") or "")[5:])
    return names


def extract_icon_names(core_js: str) -> list[str]:
    m = re.search(r"const\s+iconNames\s*=\s*(\[[^;]+\])\s*;", core_js, flags=re.S)
    if not m:
        return []
    try:
        data = json.loads(m.group(1))
    except Exception:
        return []
    return data if isinstance(data, list) and all(isinstance(x, str) for x in data) else []


def canvas_child(slide: Node) -> Node | None:
    children = direct_element_children(slide)
    if len(children) != 1:
        return None
    child = children[0]
    return child if child.tag == "div" and "slide-canvas" in child.classes else None


# ---------- protected fingerprints ----------

def immutable_tree_fingerprint(node: Node, *, ignore_brand_src: bool = False) -> tuple:
    attrs = []
    for k, v in node.attrs.items():
        if ignore_brand_src and k == "src" and "brand-logo" in node.classes:
            continue
        attrs.append((k, normalized_attr_value(v)))
    children = []
    for c in node.children:
        if isinstance(c, Node):
            children.append(immutable_tree_fingerprint(c, ignore_brand_src=ignore_brand_src))
        else:
            text = normalized_text(c)
            if text:
                children.append(("#text", text))
    return (node.tag, tuple(sorted(attrs)), tuple(children))


def strip_allowed_media_background(style: str | None, node: Node) -> str:
    if not style:
        return ""
    value = style
    if "data-click-upload" in node.attrs:
        value = re.sub(r"(?:^|;)\s*background-image\s*:\s*url\([^)]*\)\s*;?", ";", value, flags=re.I | re.S)
    value = re.sub(r";+", ";", value).strip(" ;\t\r\n")
    return " ".join(value.split())


def normalized_classes(node: Node, *, root: bool = False, smart_grid: bool = False, card_item: bool = False) -> tuple[str, ...]:
    classes = set(node.classes)
    if root:
        classes.discard("active")
    classes.discard("has-image")
    if smart_grid:
        classes = {c for c in classes if not re.fullmatch(r"items-\d+", c) and c not in DENSITY_CLASSES}
    if card_item:
        classes.discard("primary")
        classes.discard("main")
    return tuple(sorted(classes))


def structure_attrs(node: Node, *, root: bool = False, smart_grid: bool = False, icon_dynamic: bool = False) -> tuple[tuple[str, str], ...]:
    ignored = {"data-title", "data-purpose", "data-theme", "data-uid"} if root else set()
    attrs: list[tuple[str, str]] = []
    for k, v in node.attrs.items():
        if k in {"class", *ignored}:
            continue
        if k == "style":
            style = strip_allowed_media_background(v, node)
            if style:
                attrs.append(("style", style))
            continue
        if k == "data-chart":
            attrs.append((k, "__dynamic_chart_data__"))
            continue
        if smart_grid and k == "data-items":
            continue
        if icon_dynamic and k == "data-icon":
            attrs.append((k, "__dynamic_icon__"))
            continue
        if icon_dynamic and node.tag == "use" and k in {"href", "xlink:href"}:
            attrs.append((k, "__dynamic_icon_href__"))
            continue
        if k == "src" and "brand-logo" in node.classes:
            continue
        attrs.append((k, normalized_attr_value(v)))
    return tuple(sorted(attrs))


def slide_structure_signature(node: Node) -> tuple:
    """Compare slide shell while treating smart-card repeated children as a controlled region."""

    def rec(n: Node, *, root: bool = False) -> tuple:
        is_grid = "smart-card-grid" in n.classes
        head = (
            n.tag,
            normalized_classes(n, root=root, smart_grid=is_grid),
            structure_attrs(n, root=root, smart_grid=is_grid),
        )
        if "auto-chart" in n.classes:
            return (head, ("__dynamic_auto_chart__",))
        if is_grid:
            return (head, ("__dynamic_smart_grid_items__",))
        kids = tuple(rec(c) for c in n.children if isinstance(c, Node))
        return (head, kids)

    return rec(node, root=True)


def card_item_signature(node: Node) -> tuple:
    def rec(n: Node) -> tuple:
        icon_dynamic = ("data-icon" in n.attrs) or n.tag == "use"
        head = (
            n.tag,
            normalized_classes(n, card_item=(n is node)),
            structure_attrs(n, icon_dynamic=icon_dynamic),
        )
        kids = tuple(rec(c) for c in n.children if isinstance(c, Node))
        return (head, kids)
    return rec(node)


# ---------- domain helpers ----------

def is_finite_number(value) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(float(value))


def validate_numeric_list(values, label: str, slide_no: int, errors: list[str]) -> bool:
    if not isinstance(values, list) or not values:
        errors.append(f"Slide {slide_no}: {label} must be a non-empty array.")
        return False
    ok = True
    for i, value in enumerate(values):
        if not is_finite_number(value):
            errors.append(f"Slide {slide_no}: {label}[{i}] must be a finite number.")
            ok = False
    return ok


def validate_chart(node: Node, slide_no: int, errors: list[str], warnings: list[str]) -> None:
    raw = node.attrs.get("data-chart") or ""
    try:
        data = json.loads(raw)
    except Exception as exc:
        errors.append(f"Slide {slide_no}: invalid data-chart JSON ({exc}).")
        return
    if not isinstance(data, dict):
        errors.append(f"Slide {slide_no}: data-chart must be a JSON object.")
        return

    chart_type = data.get("type")
    labels = data.get("labels")
    if chart_type not in {"line", "bar", "donut"}:
        errors.append(f"Slide {slide_no}: unsupported chart type {chart_type!r}; use line/bar/donut.")
        return
    if not isinstance(labels, list) or not labels:
        errors.append(f"Slide {slide_no}: data-chart labels must be a non-empty array.")
        return
    if "showValues" in data and not isinstance(data.get("showValues"), bool):
        errors.append(f"Slide {slide_no}: data-chart showValues must be boolean when present.")

    if chart_type in {"line", "donut"}:
        values = data.get("values")
        if validate_numeric_list(values, "data-chart values", slide_no, errors) and len(labels) != len(values):
            errors.append(f"Slide {slide_no}: data-chart labels/values length mismatch ({len(labels)} vs {len(values)}).")
        return

    series = data.get("series")
    if series is not None:
        if not isinstance(series, list) or not 1 <= len(series) <= 3:
            errors.append(f"Slide {slide_no}: bar data-chart series must contain 1–3 series.")
            return
        for j, item in enumerate(series):
            if not isinstance(item, dict):
                errors.append(f"Slide {slide_no}: bar series[{j}] must be an object.")
                continue
            name = item.get("name")
            if len(series) > 1 and (not isinstance(name, str) or not name.strip()):
                errors.append(f"Slide {slide_no}: grouped bar series[{j}] needs a non-empty name for the legend.")
            vals = item.get("values")
            if validate_numeric_list(vals, f"bar series[{j}].values", slide_no, errors) and len(labels) != len(vals):
                errors.append(f"Slide {slide_no}: labels/series[{j}].values length mismatch ({len(labels)} vs {len(vals)}).")
        return

    # Canonical runtime still reads legacy values/values2/values3. Accept it, but new builds should prefer series.
    legacy_keys = [k for k in ("values", "values2", "values3") if k in data]
    if not legacy_keys:
        errors.append(f"Slide {slide_no}: bar chart requires data-chart.series (preferred) or legacy values.")
        return
    if len(legacy_keys) > 1:
        warnings.append(f"Slide {slide_no}: legacy multi-series bar API detected; new v7.9 decks should use data-chart.series.")
    for key in legacy_keys[:3]:
        vals = data.get(key)
        if validate_numeric_list(vals, f"bar {key}", slide_no, errors) and len(labels) != len(vals):
            errors.append(f"Slide {slide_no}: labels/{key} length mismatch ({len(labels)} vs {len(vals)}).")


def smart_grid(slide: Node) -> Node | None:
    grids = nodes_with_class(slide, "smart-card-grid")
    return grids[0] if len(grids) == 1 else None


def grid_items(grid: Node) -> list[Node]:
    return [n for n in direct_element_children(grid) if n.tag == "article" and ("card" in n.classes or "icon-card-item" in n.classes or "media-card" in n.classes)]


def canonical_card_prototype(template_slide_node: Node) -> Node | None:
    grid = smart_grid(template_slide_node)
    items = grid_items(grid) if grid else []
    return items[0] if items else None


def validate_smart_grid(slide: Node, tpl_slide: Node, layout: str, slide_no: int, errors: list[str]) -> None:
    grids = nodes_with_class(slide, "smart-card-grid")
    if len(grids) != 1:
        errors.append(f"Slide {slide_no} ({layout}): expected exactly one .smart-card-grid; found {len(grids)}.")
        return
    grid = grids[0]
    expected_type = SMART_LAYOUTS[layout]
    if grid.attrs.get("data-grid-type") != expected_type or grid.attrs.get("data-grid-min") != "3" or grid.attrs.get("data-grid-max") != "9":
        errors.append(f"Slide {slide_no} ({layout}): smart-grid data-grid-type/min/max differ from canonical contract.")

    items = grid_items(grid)
    if not 3 <= len(items) <= 9:
        errors.append(f"Slide {slide_no} ({layout}): smart grid must contain 3–9 card articles; found {len(items)}.")
    direct_articles = [n for n in direct_element_children(grid) if n.tag == "article"]
    if len(direct_articles) != len(items):
        errors.append(f"Slide {slide_no} ({layout}): smart grid contains unsupported article structure.")
    non_article_elements = [n for n in direct_element_children(grid) if n.tag != "article"]
    if non_article_elements:
        errors.append(f"Slide {slide_no} ({layout}): smart grid may contain only direct card <article> children.")

    data_items = grid.attrs.get("data-items")
    if data_items is not None and data_items != str(len(items)):
        errors.append(f"Slide {slide_no} ({layout}): runtime data-items={data_items!r} does not match {len(items)} cards.")

    proto = canonical_card_prototype(tpl_slide)
    if proto is None:
        errors.append(f"Slide {slide_no} ({layout}): canonical card prototype missing.")
        return
    expected_sig = card_item_signature(proto)
    primary_count = 0
    for j, item in enumerate(items, 1):
        if "primary" in item.classes:
            primary_count += 1
        if "main" in item.classes:
            errors.append(f"Slide {slide_no} ({layout}) card {j}: class 'main' is not part of smart-card API.")
        if card_item_signature(item) != expected_sig:
            errors.append(f"Slide {slide_no} ({layout}) card {j}: structure differs from canonical repeated-card prototype.")
    if layout in {"cards3", "icon-cards"} and primary_count > 1:
        errors.append(f"Slide {slide_no} ({layout}): at most one card may be primary; found {primary_count}.")
    if layout == "media-cards" and primary_count:
        errors.append(f"Slide {slide_no} (media-cards): media cards do not support primary class.")


def validate_icons(slide: Node, slide_no: int, icon_names: set[str], errors: list[str]) -> None:
    pickers = [n for n in [slide, *walk(slide)] if "data-icon-picker" in n.attrs]
    for picker in pickers:
        name = picker.attrs.get("data-icon") or ""
        if name not in icon_names:
            errors.append(f"Slide {slide_no}: unknown data-icon={name!r}; choose only from canonical iconNames.")
            continue
        uses = [n for n in walk(picker) if n.tag == "use"]
        if len(uses) != 1:
            errors.append(f"Slide {slide_no}: icon {name!r} must contain exactly one <use>.")
            continue
        href = uses[0].attrs.get("href") or uses[0].attrs.get("xlink:href") or ""
        if href != f"#icon-{name}":
            errors.append(f"Slide {slide_no}: data-icon={name!r} does not match <use href={href!r}>.")


def has_remote_url(value: str | None) -> bool:
    if not value:
        return False
    return bool(re.search(r"(?:url\(\s*['\"]?https?://|^https?://)", value, flags=re.I))


def embedded_image_url(value: str | None) -> bool:
    return isinstance(value, str) and value.startswith("data:image/")


def brand_asset(node: Node | None) -> str | None:
    if not node:
        return None
    raw = html_lib.unescape(node_text(node)).strip()
    try:
        value = json.loads(raw)
    except Exception:
        return None
    return value if isinstance(value, str) else None


def compact_css(s: str) -> str:
    return re.sub(r"\s+", "", s)


# ---------- canonical self-check ----------

def validate_canonical_v79(base: str, base_root: Node, errors: list[str]) -> tuple[dict[str, Node], set[str], set[str]]:
    base_templates = template_nodes(base_root)
    duplicate_keys = [k for k in base_templates if k.startswith("__duplicate__:")]
    if duplicate_keys:
        errors.append(f"Skill canonical has duplicate template layouts: {len(duplicate_keys)}")
    base_layouts = {k for k in base_templates if not k.startswith("__duplicate__:")}
    demo = deck_slides(base_root)
    demo_layouts = [s.attrs.get("data-layout") or "" for s in demo]

    if base_layouts != EXPECTED_LAYOUTS:
        errors.append(f"Skill canonical layout catalog differs from expected v7.9 set: {sorted(base_layouts)}")
    if len(base_layouts) != 22 or len(demo) != 22:
        errors.append(f"Skill canonical must contain 22 templates and 22 demo slides; found {len(base_layouts)} / {len(demo)}.")
    if len(demo_layouts) != len(set(demo_layouts)) or set(demo_layouts) != base_layouts:
        errors.append("Skill canonical violates Demo = Templates 1:1.")

    for i, s in enumerate(demo, 1):
        if canvas_child(s) is None:
            errors.append(f"Skill canonical demo slide {i} has no single direct .slide-canvas child.")
    for layout in sorted(base_layouts):
        ts = template_slide(base_templates[layout])
        if ts is None or canvas_child(ts) is None:
            errors.append(f"Skill canonical template {layout!r} has no single direct .slide-canvas child.")

    try:
        css = compact_css(extract_style(base))
        required_css = [
            "--w:1920;--h:1080;--base-w:1600;--base-h:900;--content-scale:1.2;",
            ".deck{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;",
            ".slide{position:absolute!important;inset:0!important;width:100vw!important;height:100vh!important;",
            ".slide-canvas{position:absolute!important;left:50%!important;top:50%!important;width:1600px!important;height:900px!important;transform:translate(-50%,-50%)scale(var(--canvas-scale,1))!important;",
            ".slide{position:relative!important;display:block!important;width:1920px!important;height:1080px!important;",
            ".slide-canvas{left:0!important;top:0!important;width:1600px!important;height:900px!important;transform:scale(1.2)!important;",
            ".smart-card-grid{--gap:22px;display:grid;",
            ".icon-picker-panel{position:fixed;",
            ".bar-value{font:70015pxvar(--font);",
        ]
        for fragment in required_css:
            if fragment not in css:
                errors.append(f"Skill canonical is missing required v7.9 CSS invariant: {fragment[:100]}")
    except ValueError as exc:
        errors.append(str(exc))

    try:
        core_js = extract_core_script(base)
        required_js = [
            "document.documentElement.style.setProperty('--canvas-scale',safeScale)",
            "Math.min((innerWidth-pad)/1920,(innerHeight-pad)/1080)",
            "function renderOverview(", "function moveSlide(", "function duplicateSlide(", "function deleteSlide(",
            "function renderLibrary(", "function addSlideFromTemplate(", "function applyPalette(",
            "function normalizeBarSeries(", "function renderCharts(", "function compressAndSetImage(",
            "function readBrandLogoAsset(", "function applyBrandLogo(", "function replaceBrandLogo(", "function hydrateBrandLogo(",
            "function setIcon(", "function renderIconPicker(", "function toggleIconPicker(",
            "function updateSmartGrids(", "function addCardToCurrentGrid(", "function removeCardFromCurrentGrid(",
            "function downloadEdited(", "function refreshSlides(", "function show(",
        ]
        for fragment in required_js:
            if fragment not in core_js:
                errors.append(f"Skill canonical is missing required v7.9 runtime invariant: {fragment}")
        icon_names = extract_icon_names(core_js)
    except ValueError as exc:
        errors.append(str(exc))
        icon_names = []

    sprite = find_icon_sprite(base_root)
    sprite_names = symbol_names(sprite)
    if len(icon_names) != 176 or len(set(icon_names)) != 176:
        errors.append(f"Skill canonical iconNames must contain 176 unique IDs; found {len(icon_names)} / {len(set(icon_names))} unique.")
    if len(sprite_names) != 176 or len(set(sprite_names)) != 176:
        errors.append(f"Skill canonical SVG sprite must contain 176 unique symbols; found {len(sprite_names)} / {len(set(sprite_names))} unique.")
    if set(icon_names) != set(sprite_names):
        errors.append("Skill canonical iconNames and SVG symbol IDs do not match 1:1.")

    asset_node = find_by_id(base_root, "brandLogoAsset")
    asset = brand_asset(asset_node)
    if not asset or not embedded_image_url(asset):
        errors.append("Skill canonical brandLogoAsset must contain an embedded data:image URL.")

    return base_templates, base_layouts, set(icon_names)


# ---------- output validation ----------

def validate(output: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not CANONICAL.exists():
        return [f"Canonical template missing: {CANONICAL}"], warnings
    if not SPEC.exists():
        return [f"TEMPLATE_SPEC missing: {SPEC}"], warnings

    base = CANONICAL.read_text(encoding="utf-8")
    source = output.read_text(encoding="utf-8")
    base_root = parse_html(base)
    root = parse_html(source)

    base_templates, base_layouts, icon_names = validate_canonical_v79(base, base_root, errors)

    # CSS and core JS are exact protected shell. brandLogoAsset is separately mutable.
    try:
        if normalize_block(extract_style(source)) != normalize_block(extract_style(base)):
            errors.append("Canonical CSS differs from v7.9. Builder must not edit or append CSS.")
    except ValueError as exc:
        errors.append(str(exc))
    try:
        if normalize_block(extract_core_script(source)) != normalize_block(extract_core_script(base)):
            errors.append("Core JavaScript differs from canonical v7.9; editor/runtime contract is broken.")
    except ValueError as exc:
        errors.append(str(exc))

    required_ids = [
        "deck", "overview", "overviewGrid", "libraryPanel", "libraryGrid",
        "iconPickerPanel", "iconPickerGrid", "iconSearchInput", "closeIconPickerBtn",
        "fileInput", "brandLogoInput", "brandLogoAsset", "themeSelect",
        "prev", "next", "overviewBtn", "addBtn", "cardAddBtn", "cardRemoveBtn",
        "themeBtn", "brandBtn", "saveBtn", "fullBtn",
        "openLibraryBtn", "closeLibraryBtn", "closeOverviewBtn",
    ]
    for node_id in required_ids:
        if not find_by_id(root, node_id):
            errors.append(f"Required runtime element missing: #{node_id}")

    body = next((n for n in walk(root) if n.tag == "body"), None)
    palette = body.attrs.get("data-palette") if body else None
    if palette not in ALLOWED_PALETTES:
        errors.append(f"body[data-palette] must be one of {sorted(ALLOWED_PALETTES)}; found {palette!r}.")

    # SVG sprite immutable.
    base_sprite = find_icon_sprite(base_root)
    out_sprite = find_icon_sprite(root)
    if not out_sprite:
        errors.append("Embedded SVG icon sprite is missing.")
    elif base_sprite and immutable_tree_fingerprint(out_sprite) != immutable_tree_fingerprint(base_sprite):
        errors.append("Embedded SVG icon sprite was modified; icon catalog is protected in builder mode.")

    # Global brand asset may change, but slot/script structure and portability are protected.
    base_asset_node = find_by_id(base_root, "brandLogoAsset")
    out_asset_node = find_by_id(root, "brandLogoAsset")
    if out_asset_node and base_asset_node:
        if {k: v for k, v in out_asset_node.attrs.items()} != {k: v for k, v in base_asset_node.attrs.items()}:
            errors.append("#brandLogoAsset attributes changed; only its JSON payload may change.")
        asset = brand_asset(out_asset_node)
        if not asset or not embedded_image_url(asset):
            errors.append("#brandLogoAsset must contain an embedded data:image URL.")
    else:
        asset = None

    logo_srcs = []
    for n in walk(root):
        if n.tag == "img" and "brand-logo" in n.classes:
            src = n.attrs.get("src")
            if src:
                logo_srcs.append(src)
                if not embedded_image_url(src):
                    errors.append(".brand-logo src must be embedded data:image URL.")
    if asset and logo_srcs and any(src != asset for src in logo_srcs):
        errors.append("One or more .brand-logo[src] values are inconsistent with #brandLogoAsset.")

    # Template library complete and immutable except global brand-logo src.
    out_templates = template_nodes(root)
    duplicate_keys = [k for k in out_templates if k.startswith("__duplicate__:")]
    if duplicate_keys:
        errors.append(f"Duplicate template data-layout entries found: {len(duplicate_keys)}")
    out_layouts = {k for k in out_templates if not k.startswith("__duplicate__:")}
    if out_layouts != base_layouts:
        errors.append(f"Template library layout set changed. Missing={sorted(base_layouts-out_layouts) or '-'} Extra={sorted(out_layouts-base_layouts) or '-'}")
    for layout in sorted(base_layouts & out_layouts):
        if immutable_tree_fingerprint(out_templates[layout], ignore_brand_src=True) != immutable_tree_fingerprint(base_templates[layout], ignore_brand_src=True):
            errors.append(f"Internal template modified for data-layout={layout!r}; only synchronized .brand-logo[src] may differ.")
        if out_templates[layout].attrs.get("id") != f"layout-{layout}":
            errors.append(f"Template {layout!r}: expected id='layout-{layout}'.")

    slides = deck_slides(root)
    if not slides:
        errors.append("No direct slide instances found inside #deck.")
        return errors, warnings

    active_count = 0
    for i, slide in enumerate(slides, 1):
        if "active" in slide.classes:
            active_count += 1
        if slide.attrs.get("data-custom") == "true":
            errors.append(f"Slide {i}: custom layouts are not allowed in normal v7.9 builder mode.")
        layout = slide.attrs.get("data-layout") or ""
        if layout not in base_layouts:
            errors.append(f"Slide {i}: unsupported or missing data-layout={layout!r}.")
            continue
        if canvas_child(slide) is None:
            errors.append(f"Slide {i} ({layout}): must contain exactly one direct .slide-canvas child.")

        tpl_slide = template_slide(base_templates[layout])
        if tpl_slide is None:
            errors.append(f"Slide {i}: canonical template {layout!r} has no slide section.")
        else:
            if slide_structure_signature(slide) != slide_structure_signature(tpl_slide):
                errors.append(f"Slide {i} ({layout}): shell DOM/classes/inline geometry differ from canonical template.")
            if layout in SMART_LAYOUTS:
                validate_smart_grid(slide, tpl_slide, layout, i, errors)

        if not slide.attrs.get("data-title"):
            errors.append(f"Slide {i}: missing data-title.")
        if not slide.attrs.get("data-purpose"):
            errors.append(f"Slide {i}: missing data-purpose.")
        if slide.attrs.get("data-theme") not in ALLOWED_SLIDE_THEMES:
            errors.append(f"Slide {i}: data-theme must be light/dark; found {slide.attrs.get('data-theme')!r}.")
        if not any(n.attrs.get("contenteditable") == "true" for n in [slide, *walk(slide)]):
            errors.append(f"Slide {i}: no contenteditable=true nodes; browser editability was lost.")

        validate_icons(slide, i, icon_names, errors)

        chart_nodes = nodes_with_class(slide, "auto-chart")
        if layout == "chart" and not chart_nodes:
            errors.append(f"Slide {i}: chart layout has no .auto-chart node.")
        for chart in chart_nodes:
            validate_chart(chart, i, errors, warnings)

        # Media: only existing upload slots can receive embedded background images.
        for n in [slide, *walk(slide)]:
            style = n.attrs.get("style") or ""
            if "background-image" not in style.lower():
                continue
            if "data-click-upload" not in n.attrs:
                errors.append(f"Slide {i}: background-image added to non-media node.")
            if has_remote_url(style):
                errors.append(f"Slide {i}: external HTTP(S) media dependency found.")
            m = re.search(r"background-image\s*:\s*url\((.*?)\)", style, flags=re.I | re.S)
            if m:
                url_value = m.group(1).strip().strip("'\"")
                if url_value and not embedded_image_url(url_value):
                    errors.append(f"Slide {i}: media background-image must be embedded data:image URL, found {url_value[:80]!r}.")

    if active_count != 1:
        errors.append(f"Exactly one deck slide must have class active; found {active_count}.")
    elif "active" not in slides[0].classes:
        warnings.append("Active slide is not first. Valid for a user-saved copy; newly generated decks should preferably start at slide 1.")

    # External dependencies forbidden. Hyperlinks in content are not runtime dependencies.
    for n in walk(root):
        if n.tag == "script" and n.attrs.get("src"):
            errors.append("External <script src=...> dependency is not allowed.")
        if n.tag == "link" and (n.attrs.get("href") or "").lower().startswith(("http://", "https://")):
            errors.append("External <link href=...> dependency is not allowed.")
        if n.tag in {"img", "source"} and (n.attrs.get("src") or "").lower().startswith(("http://", "https://")):
            errors.append(f"External <{n.tag} src=...> media dependency is not allowed.")

    try:
        css = extract_style(source)
        if re.search(r"@import\s+[^;]*https?://|url\(\s*['\"]?https?://", css, flags=re.I):
            errors.append("External URL dependency found in CSS.")
    except ValueError:
        pass

    return errors, warnings


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate Presentation System v7.9 deck")
    ap.add_argument("html", type=Path)
    args = ap.parse_args()
    if not args.html.exists():
        print(f"FAIL: file not found: {args.html}")
        return 2
    errors, warnings = validate(args.html)
    for w in warnings:
        print(f"WARN: {w}")
    for e in errors:
        print(f"ERROR: {e}")
    if errors:
        print(f"FAIL: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1
    print(f"PASS: 0 errors, {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
